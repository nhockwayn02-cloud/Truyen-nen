# CHANGELOG — Xưởng Truyện AI

## [V14.7.55] — Rò kế hoạch viết cảnh vào chương; giờ giấc và mã số dày
- **Hiện tượng (file 7 chương người dùng gửi):** (1) cuối chương 4 (~70 dòng) là LỜI TỰ NHẮC của model, không phải văn: "Viết cảnh S4, khoảng 600 từ…", "Hmm — … hợp lý?", "Giải pháp: …", "Tốt. Viết theo trình tự đó." — scene S4 thật gần như không được viết; (2) giờ giấc dày (chương 4 có ~13 mốc giờ, ch.3 ~6, ch.1–2 ~4–5, đếm bằng bộ lọc từ khóa nên có thể sót), (3) mã/số hiệu tài liệu nhiều (KT-07, TF-H-1109, M-04, P-1908, 114/ĐK-TK… lặp cả chương; "khu kỹ thuật số bảy" 17 lần, "tập hồ sơ đỏ bọc đen" 12 lần), (4) cảm giác máy móc.
- **Nguyên nhân:** bộ lọc cũ chỉ bắt "GHI CHÚ KỸ THUẬT", "Final rewrite", văn không dấu, lặp; không bắt kiểu model viết nháp kế hoạch ngay trong phần trả lời (thường do model thinking đổ suy nghĩ ra content). Không có luật nào hạn chế giờ/mã số, nên model (và cả bước lập scene) tự gắn giờ và mã vào hầu hết đoạn.
- **Sửa:** (1) `isPlanningLeakPara`/`planningLeakIndex`/`stripPlanningLeak`: nhận ra cụm kế hoạch (≥2 đoạn tự nhắc, hoặc "Viết cảnh S<số>"); `degenerationCheck` báo hỏng → scene bị cắt phần rò, viết lại, và (V14.7.54) viết tiếp phần thiếu; `cleanModelArtifacts` cắt cả chỗ rò khi lọc cuối; (2) `TIME_CODE_RULE` trong prompt viết scene: tối đa 2 mốc giờ/scene, không mở đoạn bằng giờ, không tự đặt mã/số hiệu mới, mỗi mã nhắc tối đa 1 lần; bước lập scene được dặn không gán giờ/mã cho mọi scene; (3) cảnh báo (không retry) khi scene có quá nhiều mốc giờ hoặc >3 mã.
- **Test:** `v14_7_55_plan_leak_time_code` (đoạn rò dựng lại; văn thường, thoại "Hmm"/"Tốt." không bị báo nhầm; dùng đúng file chương 4 của người dùng nếu có: nhận ra và cắt sạch, 6 chương còn lại nguyên vẹn).
- **Không sửa / chưa kiểm:** "máy móc" là cảm nhận văn phong — các luật này chỉ giảm giờ/mã/lặp, không thay được chất lượng model; chưa kiểm với model thật. Chương 4 của bạn đã lưu vẫn còn đoạn rò (cần xoá tay hoặc viết lại chương). Lặp cụm tên cơ quan chưa có luật riêng.

## [V14.7.54] — Scene sụp giữa chừng bị mất nửa sau
- **Hiện tượng (chương 3, mức 3500 từ):** S3 sụp giữa chừng, hệ thống cắt phần hỏng và giữ 1212 từ đầu; nửa sau cảnh (điểm gãy, lần vỡ thứ hai, aftercare, nhiệm vụ mới, nấc khuất phục 2) vắng hoàn toàn; AI rà báo MUST_CHANGE nhưng vá cục bộ không chèn nổi cả nửa cảnh.
- **Nguyên nhân:** sau khi cắt, scene chỉ còn ~1/3 độ dài mà không có bước viết bù phần beat đã mất.
- **Sửa:** khi scene được cắt cứu (`degenSalvaged`), còn dưới 80% `targetWords` và còn thời gian, chạy đúng MỘT lượt viết tiếp (model chính/fallback, nhiệt 0,55) chỉ cho phần beat chưa thể hiện, qua cổng văn suy biến; đạt ≥120 từ thì nối vào, không đạt thì ghi cảnh báo "nên đọc lại".
- **Test:** `v14_7_54_salvage_continue` (scene sụp → đúng 1 lượt viết tiếp, nội dung nằm trong chương; scene bình thường → 0 lượt).
- **Chưa sửa:** mâu thuẫn giờ ở S4 (contract 6h58 nhưng văn bản "Bảy giờ kém hai phút" rồi "Sáu giờ tám"). **Chưa kiểm:** model thật; lượt viết tiếp có thể vẫn lệch giọng nếu model chính tiếp tục sụp.

## [V14.7.53] — Cảnh 18+ chưa xong đã nhảy sang cảnh khác
- **Hiện tượng (file người dùng gửi):** đang bị bắt bú, nghe bước chân tuần tra, câu cuối cụt ("Nếu ai cửa này...") rồi đoạn sau nhảy "Một giờ mười tám phút… Lý Ái Vân đã đi lên B2 được mấy phút". Hành vi chưa tới cao trào/dư âm.
- **Nguyên nhân:** mỗi scene chỉ làm các mục checklist rồi "dừng ở handoff"; hành vi tình dục đang diễn ra không phải một mục có điều kiện kết thúc, nên scene dừng khi hết beat/ngân sách rồi scene sau mở bằng câu chuyển cảnh nhảy giờ. Không có bước nào kiểm cảnh nóng đã khép chưa.
- **Sửa:** (1) scene nóng nhận luật `HOT_SCENE_COMPLETION_RULE`: đi trọn tiếp diễn → leo thang → cao trào → dư âm tại chỗ; bị chen ngang thì phản ứng tại chỗ rồi viết tiếp, cấm nhảy giờ/đổi chỗ. (2) `hotActOpen` nhận ra cảnh nóng (≥3 đoạn tường minh) mà không có cao trào/dư âm → đúng MỘT lượt viết tiếp tại chỗ (300–600 từ), qua cổng văn suy biến, không viết lại cả scene; không đạt thì giữ bản cũ + cảnh báo.
- **Test:** `v14_7_53_hot_scene_finish` (dùng đúng cảnh kho của người dùng nếu có: nhận ra là còn dở; cảnh chương 2 đã khép thì không bị đụng).
- **Chưa kiểm:** model thật; bộ nhận diện dựa trên từ khóa nên cảnh dùng cách nói khác có thể lọt, và cảnh cố ý kết không cao trào mà không dùng từ cao trào nào sẽ bị viết tiếp. Cảnh đã được lưu từ trước vẫn phải sửa tay hoặc dùng Viết tiếp.

## [V14.7.52] — Hậu kỳ với model thinking (GLM flash uncensored): chỉ rõ chỗ đổi
- **Hiện tượng:** "Hậu kỳ chỉ cập nhật một phần (chưa cập nhật: Status) … JSON gộp bị cắt [finish=length, 0 ký tự, reasoning 28774]".
- **Nguyên nhân:** model chính (`z-ai/glm-5.3-flash-uncensored`) là model thinking: nó dùng hết ~7.800 token đầu ra cho phần suy nghĩ (reasoning ~28.000 ký tự), phần trả lời JSON rỗng. Lệnh tắt thinking gửi kèm bị gateway/model bỏ qua nên thử lại vẫn cắt. Đây là giới hạn của model, không phải lỗi dữ liệu; dữ liệu cũ được giữ nguyên.
- **Cách khắc phục sẵn có:** mục 10.3 «Model theo bước» → «Model Hậu kỳ» → nhập model không-thinking (vd. `deepseek/deepseek-v3.2`, `google/gemini-2.5-flash`). Viết cảnh vẫn dùng model chính.
- **Sửa:** (1) thông báo lỗi nay nói rõ chỗ đổi này; (2) ở nhánh hậu kỳ thất bại hẳn, lý do bị cắt ở 220 ký tự làm mất đúng phần chỉ dẫn → nâng lên 700.
- **Test:** `v14_7_52_thinking_post_model` (tái hiện model thinking ăn hết token; đặt Model Hậu kỳ thì hậu kỳ DONE và mọi lượt hậu kỳ dùng đúng model đó). Harness giả nay hỗ trợ trường `reasoning`.
- **Chưa kiểm:** model thật; chưa biết AnonRouter có nhận tham số tắt thinking nào cho GLM (nên cách chắc chắn là đổi model Hậu kỳ).

## [V14.7.51] — Chương 2 viết sau cảnh bỏ dở: dính dấu câu + rò từ tiếng Anh
- **Hiện tượng (file chương 2 người dùng gửi):** cảnh nối từ chương 1 chỉ ~400 từ rồi nhảy sang việc khác; cảnh đồ chơi ở kho hồ sơ viết dính dấu câu ("đi tới,không thèm trả lời.Nàng") và rò từ Anh ("—but", "—he nói", "from nay", "or không—and", "one cái gật", "knuckle", "Aftercare", "old-file").
- **Nguyên nhân:** (1) cảnh nối ngắn: chương trước dừng giữa cảnh nhưng chương sau không được báo (đã sửa ở V14.7.50 — nếu bạn viết bằng bản cũ hơn thì chưa có hiệu lực); (2) bộ làm sạch chỉ có danh sách rò từ Anh cố định (without, because…) và không sửa dấu câu dính chữ.
- **Sửa:** `fixGluedPunctuation` (thêm khoảng trắng sau , ; : ! ? và dấu chấm trước chữ hoa, tách dấu — dính chữ) và `fixEnglishLeaks` (but/and/or/from/one/he/she/knuckle/aftercare/old-file → tiếng Việt, chỉ khi quanh đó là tiếng Việt; he/she lấy theo đại từ truyện đang dùng hắn/anh, nàng/cô). Không đụng giờ 10:30, số phiên bản, câu tiếng Anh cố ý trong lời thoại.
- **Test:** `v14_7_51_glued_punct_leaks` (dùng chính chương 2 người dùng gửi); thêm kiểm ngân sách ≥1.500 từ cho scene mở đầu cảnh bỏ dở ở `v14_7_50`.
- **Chưa kiểm:** độ dài cảnh nối do model thật sinh; lỗi đổi đại từ giữa chừng ("Cô đưa ra trước mặt nàng" thay vì "Hắn") chưa có bộ sửa tự động.

## [V14.7.50] — Nút "Viết tiếp" bị văn trôi; chương sau nối cảnh bỏ dở quá ngắn
- **Hiện tượng (file người dùng gửi):** chương dừng ở "…lớp này tới lớp khác; rồi." → bấm Viết tiếp thì phần sau lê thê không dấu câu, chèn giọng chat/"bye bye"; xóa đi viết chương mới thì cảnh 18+ chốt trong vài trăm từ.
- **Nguyên nhân 1:** `continueChapterBtn` không có cổng văn suy biến (đường viết chương thì có), chỉ gọi `stripForeign` rồi nối thẳng. Cũng `salvageBeforeDegeneration` không biết câu lê thê/giọng bản tin nên không cắt được.
- **Nguyên nhân 2:** chương trước kết GIỮA cảnh nhưng chương sau không được báo → model coi phần đó là đuôi cần chốt nhanh; scene mở đầu cũng chỉ được chia ngân sách từ bình thường.
- **Sửa:** (a) Viết tiếp: bắt văn trôi → viết lại tối đa 2 lần ở nhiệt độ/penalty thấp, giữ phần sạch, không nối rác; không còn phần sạch thì giữ nguyên chương và báo. (b) `salvageBeforeDegeneration` cắt cả ở đoạn có câu lê thê/giọng bản tin (file thật: cắt đúng tại "…; rồi.", giữ 4.158 từ). (c) `endsMidScene` + `UNFINISHED_SCENE_RULE`: chương trước kết giữa cảnh → scene mở đầu phải tiếp đúng cường độ, không chốt nhanh, và được nâng ngân sách tối thiểu ~40% mục tiêu chương.
- **Test:** `v14_7_50_continue_gate` (dùng chính file người dùng nếu có, worker giả, Chromium thật).
- **Chưa kiểm:** model thật có viết đủ dài ở cảnh bỏ dở hay không (mới kiểm prompt và ngân sách, chưa đo độ dài do model sinh).

## [V14.7.49] — Model chèn "GHI CHÚ KỸ THUẬT"/lời trợ lý giữa chương
- **Hiện tượng:** giữa chương xuất hiện "GHI CHÚ KỸ THUẬT (không thuộc phần văn xuôi)… Nếu bạn muốn tôi xuất bản phiên bản sạch… hãy xác nhận", kèm chữ Latin dính liền ("lánhanymorefromkeyfobBattery").
- **Nguyên nhân:** model (GLM/uncensored) bị lệch vai: tự nhận xét bản thảo như trợ lý ngay trong ô văn xuôi, sau khi scene cuối vượt contract và sinh chuỗi lai ngữ. App chưa có bộ bắt kiểu này (chỉ bắt "Viết lại", "Final rewrite", câu "Xin lỗi…").
- **Sửa:** `degenerationCheck` bắt ghi chú trợ lý và chữ Latin dính liền (≥16 chữ, có chữ hoa giữa từ hoặc ≥14 chữ Latin liền) → viết lại scene; `salvageBeforeDegeneration` giữ phần sạch phía trước; `stripForeign`/`cleanModelArtifacts` cắt đoạn ghi chú khỏi mọi chương. Không cắt nhầm lời thoại có "ghi chú/lưu ý" hay tên thương hiệu (PlayStation, YouTube).
- **Test:** `v14_7_49_assistant_note` dùng đúng đoạn người dùng gửi.
- **Chưa kiểm:** model thật; các biến thể câu chữ khác của lời trợ lý có thể lọt (chỉ bắt các mẫu đã thấy).

## [V14.7.48] — Người mới phải có tên ngay lần đầu xuất hiện
- **Nguyên nhân:** prompt viết không hề yêu cầu đặt tên; lại giới hạn "tối đa N nhân vật có tên" nên model hay để người mới chỉ là "cô ta/anh ta". Bước quét nhân vật chỉ ghi theo tên (và cố ý bỏ qua đại từ để khỏi tạo hồ sơ rác/gộp nhầm), nên người không tên không bao giờ vào Character Database.
- **Sửa (từ gốc):** thêm `NAMING_RULE` vào prompt mọi scene (client + worker): ai có lời thoại/ảnh hưởng cảnh/sẽ quay lại phải có tên riêng ngay lần đầu, rồi mới dùng đại từ; ngoại lệ: ẩn danh có chủ đích theo brief (biệt danh cố định) và người qua đường không ảnh hưởng.
- **Test:** `v14_7_48_naming_rule` (4 lượt scene đều chứa luật).
- **Chưa kiểm:** model thật có tuân thủ hay không. Nếu vẫn lọt người không tên thì bước tiếp theo là hồ sơ "chưa rõ tên" làm lưới an toàn.

## [V14.7.47] — Kiểm tra toàn bộ theo bảng 10 tình huống: sửa 3 lỗi thật
- **Cách kiểm:** 14 kịch bản phía worker (job nền) + 25 kiểm tra phía trình duyệt, dùng API giả (không gọi model thật). Đã đăng ký vào `npm test`: `qa/worker_sweep.test.js`, `v14_7_47_qa_client_sweep.test.js`.
- **Lỗi 1 (hàng 5 Memory Timeline):** `mergeBackgroundChapter` ghép mốc thời gian theo kiểu "local đè remote" → khi viết lại/viết nền một chương, mốc CŨ ở máy đè mốc MỚI do job nền vừa ghi. Sửa: mốc có `updatedAt` mới hơn thắng; mốc chỉ có ở một phía vẫn được giữ.
- **Lỗi 2 (hàng 7/6 API key):** job nền thất bại vẫn giữ API key (mã hóa hoặc rõ) trong kho. Sửa: xóa `apiKey`/`apiKeyEncrypted` khi job `failed`.
- **Lỗi 3 (hàng 10 iPhone):** ô nhập trong hồ sơ nhân vật/quan hệ/chế độ có chữ 10.5–11.5px, đặc hiệu hơn luật 16px của iOS → Safari tự phóng to trang khi bấm vào ô. Sửa: ép 16px trên thiết bị cảm ứng (`hover:none`+`pointer:coarse`).
- **Nhỏ:** chương thiếu từ hiện "⚠ Thiếu từ x/y" ngay ở dòng tiến độ; bỏ số phiên bản cũ cứng trong header `X-Title`.
- **Đã xác nhận ĐÚNG (không cần sửa):** hồ sơ gốc khóa không bị AI ghi đè (chi tiết mới đi vào `newDetails`); AI trả rác/cụt/429 không làm mất nhân vật, World Bible; JSON cụt được cứu phần đủ, không bịa; 401/402/403/404 không retry vô ích, 429 retry có giới hạn, không lộ key; localStorage đầy vẫn giữ chương và tải lại còn; model MAIN/NSFW định tuyến đúng; 12 chương liền không lặp.
- **Chưa kiểm:** model thật, Safari iPhone thật (chỉ giả lập Chromium), Netlify thật.

## [V14.7.46] — Sửa lỗi V14.7.45: tự dựng hồ sơ nhân vật mới KHÔNG chạy khi viết chương bình thường
- **Phát hiện khi kiểm tra trên trình duyệt thật:** V14.7.45 chỉ gắn "tự dựng hồ sơ" vào `updateCharactersIncremental` (chỉ chạy khi bấm Rescan NV). Đường viết chương thường chạy hậu kỳ trên job nền rồi gộp qua `mergeBackgroundChapter`, nên nhân vật mới không được dựng hồ sơ.
- **Sửa:** `mergeBackgroundChapter` nhận diện nhân vật mới sau khi gộp, rồi chạy `autoFillNewCharacters` ở nền (không chặn lưu chương), tôn trọng công tắc. `__xta` xuất thêm 2 hàm để kiểm thử.
- **Test:** `v14_7_46_autofill_job_path` chạy Chromium thật + API giả: bật → 1 lượt AI và điền ô trống; tắt → 0 lượt; không ghi đè tuổi/giới tính đã có.
- **Đã kiểm trên trình duyệt (API giả):** nút "✨ AI điền hồ sơ trống" bấm được, hộp xác nhận hoạt động, prompt chứa canon + đoạn truyện, ô đã nhập không bị ghi đè.
- **Chưa kiểm:** model thật, iPhone, Netlify; đường job nền thật (mới thử gọi trực tiếp `mergeBackgroundChapter`).

## [V14.7.45] — Giới thiệu nhân vật: tả kỹ lần đầu, nhắc ngắn lần hai, rồi thôi; hồ sơ vắng mặt; tự dựng hồ sơ nhân vật mới
- **Nguyên nhân:** (1) "đã giới thiệu ngoại hình" chỉ cần tên xuất hiện trong 4 chương gần nhất → nhân vật chưa từng được tả vẫn bị cấm tả; (2) nhân vật hồ sơ trống không có khối hồ sơ/neo ngoại hình nào; (3) hồ sơ của người vắng mặt ("nhận hồ sơ A") không vào scene.
- **Sửa:** `characterIntroStage`: `first` (chưa có đoạn tả → tả KỸ 4–6 chi tiết, một đoạn riêng), `reminder` (đã tả 1 lần gần đây hoặc vắng ≥6 chương → nhắc NGẮN 1–2 chi tiết), `done` (tả ≥2 lần gần đây → không tả lại). "Có đoạn tả" = tên + ≥3 từ khóa ngoại hình trong ~360 ký tự, không phải chỉ nhắc tên. Nhân vật hồ sơ trống vẫn nhận chỉ dẫn giới thiệu. `dossierBlock`: khi beat/mục đích scene nhắc hồ sơ/lý lịch/thông tin của X và X vắng mặt, thẻ của X (tuổi, giới tính, nghề, ngoại hình…) được đưa vào cảnh, bắt buộc nêu chi tiết thật. Nới giới hạn: ngoại hình 320, tính cách 160 ký tự; thêm điểm yếu/nỗi sợ/điểm mạnh vào scene (KHÔNG thêm bí mật để khỏi lộ).
- **Tự dựng hồ sơ:** sau khi chương cập nhật Character DB, nhân vật MỚI còn ≥6 ô trống được AI dựng hồ sơ (tối đa 4/lần), tắt bằng công tắc "✨ Tự dựng hồ sơ trống khi có nhân vật MỚI" (mặc định bật).
- **Giới hạn:** nhận diện "đã tả" bằng từ khóa; scene thứ hai cùng chương chỉ được nhắc bằng chỉ dẫn trong prompt (không biết scene trước đã tả); chưa thử model thật.
- **Test:** `v14_7_45_intro_taper`; cập nhật 2 test cũ (V14.7.15, V14.5.11 đường chỉ-có-trạng-thái) theo ngữ nghĩa mới.

## [V14.7.44] — Nút "✨ AI điền hồ sơ trống" cho nhân vật
- **Nguyên nhân gốc:** bước cập nhật DB sau chương bị cấm bịa ("chỉ điền khi chương nêu rõ") nên nhân vật mới chỉ có tên; scene lại chỉ nhận hồ sơ của người CÓ MẶT trong cảnh → không có dữ kiện để tả → DB tiếp tục trống.
- **Thêm:** nút trên thẻ nhân vật; một lượt gọi AI dựng các ô trống (tuổi, giới tính, nghề, chức vụ, ngoại hình, tóc/mắt/da…, tính cách, bí mật, điểm yếu…, ghi chú xuất thân) dựa trên canon đã nhập + đoạn truyện có nhân vật + dàn nhân vật khác. CHỈ vào ô trống, không ghi đè, không điền nhóm 18+, nhân vật dưới 18 không tạo chi tiết thân thể gợi dục; ô do AI điền được ghi vào `aiFilledFields`.
- **Giới hạn:** chưa áp cho Nhân vật chính (form riêng); chưa tự chạy khi nhân vật mới xuất hiện; chưa sửa 2 điểm đã nêu (hồ sơ nhân vật vắng mặt không vào scene; "nhắc tên = đã giới thiệu ngoại hình"). Chưa thử model thật.
- **Test:** `v14_7_44_char_fill`.

## [V14.7.43] — Bắt và cắt văn "lan man" (câu lê thê, lạc sang giọng bản tin)
- **Lỗi (từ chương người dùng gửi):** giữa chương model trôi: câu 45–110 từ gần như không dấu phẩy, hay kết "…", chèn "các bạn ơi, bye bye, hẹn gặp lại kỳ sau", "quê hương tôi…". Cổng cũ chỉ bắt lặp cụm/chữ dính nên bỏ lọt; nút Chuẩn hóa cũng không xử lý.
- **Đối chiếu:** 19 chương tác giả có 0–1 câu thưa dấu/chương; chương app lan man có 12–39 câu → ngưỡng ≥2 câu hoặc ≥1 chỗ giọng bản tin.
- **Sửa:** `countRunOnDrift` + `degenerationCheck` bắt; lượt viết lại hạ phạt lặp (0,08/0,04) vì phạt cao đẩy model đi tìm từ lạ; lượt cuối nếu vẫn lan man thì `trimRunOnDrift` cắt câu lê thê còn ~26 từ đầu (kèm cảnh báo); nút Chuẩn hóa hỏi rồi cắt gọn; chuẩn hóa dấu toàn chiều rộng `；（）` và `——`.
- **Giới hạn:** cắt chỉ là cứu hộ (câu cụt, nên đọc lại/viết lại scene); lỗi mạch (đổi "hắn/anh ta", lệch giờ trong chương) chưa tự sửa; nguyên nhân gốc là model — nên đổi model hoặc rút ngắn targetWords nếu tái diễn. Chưa thử model thật.
- **Test:** `v14_7_43_runon_drift` (có chạy trên file thật của người dùng).

## [V14.7.42] — Cứu scene khi model sụp ("america america…")
- **Lỗi:** model sụp giữa scene (lặp cụm, chữ dính, đoạn không dấu); cả 2 lượt viết đều sụp → SCENE_REJECTED, hủy job.
- **Sửa:** `salvageBeforeDegeneration` cắt từ đoạn hỏng đầu tiên, giữ phần đầu còn sạch nếu ≥ max(200 từ, 50% ngân sách scene); khi sụp được thêm 1 lượt viết (tổng 3) với nhiệt độ 0,55, giới hạn token 1,5×, phạt lặp 0,4/0,3. (Bản 14.7.41 kèm: chỉnh nhịp 18+ theo mẫu.)
- **Giới hạn:** nếu model sụp ngay từ đầu cả 3 lượt vẫn hủy; khi đó nên đổi model (GLM hay sụp ở scene dài). Chưa thử model thật.

## [V14.7.41] — Chỉnh nhịp 18+ theo 19 chương mẫu của người dùng
- **Đo từ mẫu (19 chương):** ~70% chương có cảnh nóng (chương cốt truyện 1/3/12/15 không có); chương nóng dành 40–60% độ dài cho cảnh nóng; mỗi cảnh thêm một yếu tố mới (đạo cụ/địa điểm/nấc quyền lực); nhiều chương kết bằng tin nhắn/cuộc gọi của kẻ thù; nhịp khuất phục của tác giả nhanh hơn thang V14.7.40.
- **Sửa:** thang khuất phục nhanh hơn (theo chương <2/<5/<10/≥10; theo số lần <=0/1/3/nhiều); mục tiêu PRIMARY nâng lên 40–60% độ dài chương + móc kết chương; thêm `noveltyLedger` ("Sổ leo thang": đã dùng/chưa dùng, mỗi cảnh nóng thêm ≥1 yếu tố mới) đưa vào prompt lập kế hoạch; `degenerationCheck` bắt đoạn dài lặp nguyên văn.
- **Giới hạn:** sổ leo thang dò bằng từ khóa; chưa thử với model thật/iPhone/Netlify.
- **Test:** `v14_7_41_calibration`.

## [V14.7.40] — PRIMARY luôn có cảnh nóng, thang khuất phục theo nấc, bắt văn lẫn lời chat
- **Nguyên nhân (từ backup 6 chương):** bộ lập kế hoạch Scene Graph (đường mặc định) KHÔNG có khối "lịch cảnh nóng" — khối này chỉ nằm ở bộ lập kế hoạch văn bản cũ mà đường adaptive không dùng. Câu cũ "chỉ đặt cảnh trưởng thành khi mạch truyện cần" còn cho phép bỏ cảnh nóng. Không có bước kiểm plan nên chương 4 không có beat nóng nào.
- **Sửa:** `matureScenePlanBlock` đưa vào prompt Scene Graph: Trọng tâm PRIMARY bắt buộc ≥1 scene "cảnh nóng" (2 nhân vật ≥18, targetWords ≥1100, nấc kháng cự → cơ thể phản bội → điểm gãy → day dứt). Plan thiếu beat nóng bị từ chối và lập lại; sau lượt cuối vẫn thiếu thì `injectHotBeat` tự chèn beat [S] xác định → chương PRIMARY không còn thiếu cảnh nóng. Chỉ áp cho PRIMARY (SECONDARY/AUTO giữ hành vi cũ).
- **Thang khuất phục:** `submissionLadder` tính nấc cho từng nhân vật theo số chương từ lúc xuất hiện và số chương đã có cảnh nóng cùng nhân vật (lấy nấc thấp hơn). 4 nấc: chống đối → giằng xé → phụ thuộc → quy phục (chỉ nấc 4 mới được tự nguyện/gọi chủ/tuyên thệ). Khối này nằm trong plan và trong prompt scene nóng.
- **Cổng văn suy biến:** thêm dấu hiệu model tự chèn "Final rewrite/BẢN CUỐI/Xin lỗi! Tôi bị lỗi…" và văn lẫn lời chat (≥4 chỗ). Không tính "á" đơn vì là tiếng rên trong cảnh nóng (đã thấy ở backup).
- **Giới hạn:** thang nấc là ràng buộc trong prompt (model vẫn có thể lệch) và đếm "cảnh nóng" bằng từ khóa; chưa thử với model thật.
- **Test:** `v14_7_40_primary_heat_pacing`.

## [V14.7.39] — Dọn rò rỉ model, cổng văn suy biến, định tuyến plan/check
- **Dọn rò rỉ (xác định, không tốn tiền AI), chạy trong `stripForeign`:** thay từ tiếng Anh lẻ trong câu Việt (without→"mà không", because→"vì", tonight→"đêm nay", when→"lúc", ...), xóa câu model tự rò ("Chi tiết dưới đây viết đầy đủ..."), nhãn "Nội tâm người nữ:", dấu `*` lẻ, ".," → ". ". Từ mượn hợp lệ (carton, jean, garage...) giữ nguyên; từ lạ khác vẫn do findStrayWords xử lý.
- **Cổng văn suy biến** (`degenerationCheck`): cụm lặp ≥9 lần, dòng ngắn lặp ≥4, chữ vỡ/dính, đoạn không dấu, câu lẩm bẩm "Viết lại". Kiểm trên văn BẢN GỐC của model (bước dọn lặp sẽ che mất vòng lặp). Bắt được → lỗi cứng của scene, viết lại bằng model chính (`fallbackModel`). 0/30 dương tính giả trên chương thật của người dùng.
- **Định tuyến (worker):** chương nóng không còn đẩy mọi lời gọi sang model NSFW. Lập kế hoạch lượt đầu và 2 lời gọi chỉ chấm JSON dùng model chính (hoặc model "check" ở mục 10.3). Văn xuôi (scene, bù từ, vá, sửa) vẫn dùng model NSFW. Đo trên trạng thái truyện thật: chỉ khoảng 20% lượng đầu vào chuyển được sang model chính (không phải 3/4 như nói trước đó).
- **Test:** `v14_7_39_cleanup_routing` (gồm bài thử pipeline). Dữ liệu giả của `e2e.py` được đổi sang văn đa dạng vì cổng mới bắt đúng loại văn giả lặp một câu hàng chục lần. Chưa thử với model thật/iPhone/Netlify.

## [V14.7.38] — Bước Arc tự đo theo diễn biến thật (viết không cần Outline)
- **Vấn đề:** không có Outline thì kế hoạch chương chỉ thấy 500 ký tự đầu của Arc + "chương X/Y"; phần sau của Arc (đoạn dài ~7.000 ký tự) AI không thấy.
- **Sửa:** `arcStageBlock`: tách Arc thành câu theo thứ tự; so cặp âm tiết có trọng số hiếm với tóm tắt 6 chương gần nhất; lấy mốc XA NHẤT đã chạm tới (truyện hay quay lại chủ đề cũ nên câu khớp nhất dao động); khớp vượt mốc chặn theo phần trăm chương bị bỏ; không khớp thì lùi về tiến độ chương. Chỉ đưa "Đang ở" + "Bước kế" vào kế hoạch chương (phần Arc xa hơn bị giấu). Nếu truyện đang đi nhanh hơn nhịp trung bình → nhắc đào sâu bằng diễn biến mới.
- Không chèn khi chương đã có Outline (Outline thắng) hoặc ở bước chấm chất lượng; không gọi AI thêm; không có công tắc (tự động).
- **Thử trên 30 chương thật:** mốc tiến từ "edging" (câu 13) tới "tuyên thệ/quy tắc Dominant" (câu 24/63) nhưng còn dao động vài bước giữa các chương.
- **Test:** `v14_7_38_arc_stage`. Chưa thử với model thật/iPhone/Netlify.

## [V14.7.37] — Sổ rút kinh nghiệm, model theo bước, lọc danh xưng chung
- **Sổ rút kinh nghiệm:** không huấn luyện model. App tính lại từ chính các chương (autoUpdateIssues, review.hardFailures/warnings, continuityWarnings): lỗi cùng loại lặp ở ≥2 chương (7 loại: địa điểm, beats, cast, lặp cụm, kết chương, quyền lực, canon) → thành 1 dòng nhắc trong prompt scene (tối đa 4 dòng, ≤700 ký tự); tự mờ nếu >7 chương không tái phạm; xóa chương tự cập nhật. Có danh sách trong Thiết lập để Tắt/Bật từng bài học hoặc tắt hẳn.
- **Model theo bước:** trước đây `stepModels` có trong code nhưng KHÔNG có ô nhập. Nay có 4 ô (Hậu kỳ, Quality Gate, kiểm tra scene, gợi ý chương sau); để trống = model chính.
- **Nút "Kiểm tra JSON của model Hậu kỳ":** gửi một đoạn mẫu, báo đọc được JSON không, nhận ra nhân vật không, câu trích có khớp nguyên văn không.
- **Danh xưng chung** ("Gã hàng xóm", "Giám đốc vận hành") không còn tự thành thẻ NV (từ cuối không viết hoa). "Giám đốc Hoàng", "chị Linh" vẫn hợp lệ; thẻ đã có sẵn không bị đụng.
- **Test:** `v14_7_37_learning`. Chưa thử với model thật/iPhone/Netlify.

## [V14.7.36] — Character Database trống dù Memory/Status chạy
- **Lỗi (ảnh người dùng, chẩn đoán chương: "Quỳnh Anh (evidence không khớp văn bản chương)"):** cổng evidence cấp hàng nhân vật đòi trích ≥70% từ nguyên văn; AI trích tóm lược là cả thẻ bị bỏ.
- **Sửa:** nhận hàng nếu evidence cấp hàng, hoặc bất kỳ fieldEvidence/stateEvidence khớp chương, hoặc NV đã có trong roster được nhắc tên. Từng trường vẫn qua cổng riêng.
- **Test:** `v14_7_36_char_row_gate` (fail trên code cũ, pass trên code mới).

## [V14.7.35] — Hướng dẫn chống cụm sáo thật sự tới được prompt
- **Lỗi của V14.7.28 (phát hiện khi kiểm tra chi phí):** guide chống cụm sáo nằm trong khối Từ vựng; khối này bị clip còn 600 ký tự ở ngữ cảnh và 260 ký tự ở prompt scene, nên phần guide gần như không bao giờ tới model, trong khi cổng đếm vẫn buộc viết lại → tốn lượt gọi (Sửa/vá) vô ích.
- **Sửa:** `buildVocabularyBlockFrom` không còn chứa guide; `overusedPhraseGuide` thành dòng riêng trong ngữ cảnh (client + worker); `compactOverusedGuide` (<500 ký tự) vào mọi prompt scene.
- **Test:** `v14_7_35_overused_reaches_prompt`; cập nhật test V14.7.28, stub cho test cô lập V12.31. Chưa thử với model thật.

## [V14.7.34] — Xóa hết chương nhưng bộ nhớ còn (mục mồ côi)
- **Lỗi (ảnh người dùng):** 0 chương, L0–L5 đều 0, nhưng Memory Engine vẫn hiện Timeline 7 sự kiện, Foreshadowing 2, Knowledge 11, "Diễn biến gần: Ch16…". Khi xóa chương mà không có snapshot chương trước (xóa đến chương 1, hoặc xóa lệch thứ tự), nhánh khôi phục không chạy nên chỉ lọc theo đúng số chương bị xóa, các mục có số chương cũ vẫn còn.
- **Sửa:** `pruneOrphanChapterMemory` (timeline, memoryEvents, foreshadowing, knowledgeLedger, threads, scenes, consentLog, characterStateTracker): mục có số chương > số chương hiện có bị bỏ; 0 chương thì bỏ hết và dọn L1–L4. Tự chạy sau mỗi lần xóa chương khi bật "Xoá kèm bộ nhớ"; thêm nút "🧹 Dọn bộ nhớ mồ côi (chương đã xóa)" ở Memory Engine để dọn dữ liệu đang tồn đọng. Không đụng nhân vật, Current Status, cài đặt.
- **Test:** `v14_7_34_orphan_memory`. Chưa thử trên iPhone/model thật.

## [V14.7.33] — Canon âm mưu dài không bị cắt + lịch vật chứng theo chương
- **Lỗi:** `conspiracyBlock` cắt canon ở 3.400 ký tự; bản của người dùng ~5.640 ký tự nên phần cuối (vật chứng cố định, điều cấm lộ, quy tắc nhân vật) bị mất đúng chỗ quan trọng nhất.
- **Sửa:** giới hạn `CONSPIRACY_MAX_CHARS = 7000`; lúc Lưu báo số ký tự và cảnh báo nếu vượt.
- **Thêm:** `conspiracyParseClues`/`conspiracyClueFor` đọc các dòng "… → lộ khoảng chương a–b": đến lượt (từ 6 chương trước đến hết khoảng) thì ngữ cảnh ghi VẬT CHỨNG ĐẾN LƯỢT LỘ và kế hoạch chương bắt buộc đưa đúng vật chứng đó; chưa tới thì chỉ "KẾ TIẾP, gợi nhẹ".
- **Test:** thêm 4 kiểm tra vào `v14_7_32_conspiracy`. Chưa thử với model thật.

## [V14.7.32] — Âm mưu & Kẻ thù (canon) tự dựng cho người đọc
- **Vấn đề:** app không có chỗ cho kẻ thù/âm mưu cụ thể (Cốt Truyện Chính chỉ nói "đại âm mưu" chung chung), nên mạch chính yếu và AI dễ bịa mâu thuẫn mỗi chương. (Đính chính: ô id `antagonist` thực ra là "Quy Tắc Khác", không phải ô phản diện.)
- **Thêm (Story Bible):** nút "🕵️ Tạo / 🔄 Tạo lại âm mưu & kẻ thù": AI đọc Cốt Truyện Chính + dàn nhân vật, dựng bản nhiều phe/nhiều tầng (sự thật năm xưa, mảnh ghép, 3–5 phe, 4–5 tầng có mốc chương + vật chứng, chủ mưu thật, kẻ thù đang hành động, vai trò từng nhân vật). Người dùng chỉ đọc/sửa rồi "✅ Lưu làm canon"; chưa lưu thì không ảnh hưởng truyện.
- **Dùng canon (shared/core.js → client + worker):** `conspiracyBlock` vào ngữ cảnh viết (kèm TẦNG ĐANG ÁP DỤNG theo số chương) và vào `chapterCraftPlanBlock` (beat đẩy mạch phải dùng manh mối của tầng hiện tại, không lộ chủ mưu sớm). Lưu trong state + `meta.storyBible`.
- **Test:** `v14_7_32_conspiracy` mới; thêm stub `conspiracyBlock` cho test cô lập V12.31. Chưa thử với model thật.

## [V14.7.31] — 5 mục chất lượng tiểu thuyết
- **Kết chương có móc:** scene cuối nhận quy tắc không kết bằng tóm tắt nội tâm/kế hoạch; `endingHookCheck` + cảnh báo trong `prosePatternGate` (trên backup thật bắt 6/30 chương, bộ lọc thận trọng nên bỏ sót một phần).
- **Thay đổi quan hệ mỗi chương:** `chapterCraftPlanBlock` bắt buộc beat [R] cuối ghi ai mất/được/lộ gì khiến quan hệ khác đi (chỉ là chỉ dẫn prompt, chưa có cổng kiểm).
- **Nhân vật nữ tự quyết định:** chương chia hết 3 nhận chỉ dẫn hành động chủ động có hậu quả.
- **Biệt danh lời kể:** `NARRATOR_EPITHETS` ("gã/tên/kẻ bảo vệ", "thấp kém", "hèn mọn") có hạn mức mỗi chương, cảnh báo + nhắc luân phiên trong prompt (backup thật: 9/30 chương vượt).
- **Mạch chính:** `mainThreadDrift`: ≥3 chương liền ít nhắc tu luyện/âm mưu → kế hoạch bắt buộc một beat đẩy mạch; cổng cảnh báo nếu chương mới vẫn vắng. Backup thật: chương 31 sẽ kích hoạt.
- **Chưa làm:** tự đặt tên chương. Sửa test V14.7.28 cho khỏi nhầm với cảnh báo mới. Test mới `v14_7_31_novel_craft`. Chưa thử với model thật.

## [V14.7.30] — Nhân vật phụ thúc đẩy truyện (vừa đủ)
- **Nguyên nhân (backup 30 chương):** nhân vật phụ có trong hồ sơ nhưng hầu như không xuất hiện: Yến Nhi 6/30 chương, Hùng 8, Tuấn 3, Phương Anh 2; role "không rõ". Cũ: `castPoolForPlan` lấy 4 người đầu danh sách, chỉ "nếu hợp mạch"; `lastAppearance` trong hồ sơ không đáng tin (Tuấn ghi 29, văn bản chỉ tới chương 18).
- **Sửa (shared/core.js → client + worker):** `castPoolForPlan` chọn tối đa 2 người theo độ vắng × tầm quan trọng, đo bằng văn bản chương thật (chỉ dùng `lastAppearance` khi chưa có chương); mỗi người kèm CHỨC NĂNG chương này suy từ vai trò (cấp trên → áp lực đúng quyền hạn; đối tượng theo dõi → manh mối; người cung cấp tin → một mẩu thông tin…); `castPoolBlock` BẮT BUỘC ≥1 người xuất hiện trực tiếp và để lại tác động cụ thể; khi 5 chương gần đây có <3 nhân vật có tên (`recentNamedCastCount`) được phép giới thiệu TỐI ĐA 1 nhân vật phụ mới.
- **Test:** `v14_7_30_supporting_cast` mới; cập nhật 2 kiểm tra V14.7.9 theo hành vi mới. Chưa thử với model thật.

## [V14.7.29] — Giọng nội tâm riêng từng người + nhịp câu
- **Nguyên nhân (backup 30 chương):** Quỳnh Anh và Minh Châu cùng một công thức "nhục nhã nhưng cơ thể phản bội"; nhịp câu đều, ít câu cụt.
- **Sửa (shared/core.js → client + worker):** (1) `innerVoiceBlock`/`reactionModesForScene`: mỗi nhân vật (trừ NVC) trong scene nhận một kiểu phản ứng khi bị kiểm soát suy từ tính cách/giọng nói trong hồ sơ (giữ thể diện / tính toán / im lặng nuốt xuống / cãi rồi gục / đùa gượng); hai người cùng cảnh không bao giờ trùng kiểu; (2) `SENTENCE_RHYTHM_RULE` vào mọi prompt scene; (3) `sentenceRhythmStats` + cảnh báo trong `prosePatternGate` khi <8% câu ≤6 từ hoặc có chuỗi ≥12 câu dài liền (chỉ cảnh báo, không chặn).
- **Test mới:** `v14_7_29_voice_rhythm`. Chưa thử với model thật.

## [V14.7.28] — Chống văn máy móc (cụm sáo lặp, kiểu mở chương)
- **Nguyên nhân (đo trên backup 30 chương/108k từ):** "run rẩy" 285 lần, "nhục nhã" 134, "hít một hơi thật sâu" 33…; 15/30 chương mở bằng "Bùi Lạc đứng/tiến/buông…". Ô Từ vựng trống nên prompt không có gì để tránh; Quality Gate chấm 95 dù chính nó cảnh báo lặp.
- **Sửa (shared/core.js → client + worker):** (1) `buildVocabularyBlockFrom` luôn thêm danh sách cụm sáo có hạn mức + cụm 4 từ tự phát hiện lặp ở ≥3/8 chương gần nhất (`detectOverusedPhrases`); (2) `prosePatternGate` nối vào `evaluateReview`: cụm sáo vượt hạn mức → cảnh báo, vượt gấp đôi → LỖI NẶNG (buộc viết lại, kèm gợi ý thay thế); mở chương giống chương trước hoặc 3 chương liền "nhân vật + động từ" → cảnh báo; (3) scene mở chương nhận khối `KIỂU MỞ CHƯƠNG` (`chapterOpeningVariationBlock`).
- **Test mới:** `v14_7_28_anti_repetition` (13 kiểm tra, gồm chạy trên backup thật nếu có). Chưa thử với model thật; lỗi nặng sẽ tăng số lần viết lại, giới hạn bởi số lần thử của Quality Gate.

## [V14.7.27] — Thư ký CEO lại sợ tổ trưởng bảo vệ dù đã quy định thứ bậc
- **Nguyên nhân (đọc code):** "Định nghĩa chung nhân vật nữ" và chức vụ chỉ vào ngữ cảnh chung; prompt từng scene chỉ có hồ sơ khóa + thẻ Current Status ("mới hơn, ưu tiên khi khác hồ sơ") chứa `mức phục tùng`/`tâm lý` → nỗi sợ tích lũy lấn át chức vụ. Không có quy tắc nào nói chức cao không được sợ chức thấp.
- **Sửa (shared/core.js → client + worker):** `powerHierarchyBlock` thêm vào cuối khối hồ sơ scene (khi có ≥2 nhân vật): chức vụ từng người, quy tắc ứng xử theo cấp bậc, sợ/phục tùng chỉ khi có nguyên nhân cụ thể và ở nơi riêng tư, Current Status không được xóa chức vụ, kèm nguyên tắc nhân vật nữ của tác giả.
- **Test mới:** `v14_7_27_power_hierarchy`. Chưa thử với model thật.

## [V14.7.26] — Thẻ nhân vật rỗng dù Current Status mô tả đầy đủ (ví dụ Trần Minh Châu)
- **Nguyên nhân (đọc code + ảnh):** Current Status có ngoại hình/trang phục/cảm xúc của Châu (từ bước thẻ Status), nhưng thẻ trong Character Database gần như trống. AI thường chỉ đưa MỘT câu trích chung cho cả nhân vật (về sự kiện), không đưa câu trích riêng cho từng trường; cổng cũ đòi từ khóa của giá trị ngoại hình/tuổi/nghề… phải nằm trong chính câu trích đó, mà ngoại hình nằm ở câu khác → bị loại. Nhân vật mới vẫn được tạo (chỉ có tên) nên thành thẻ rỗng, và các chương sau gặp lại đúng lỗi này.
- **Sửa (shared/core.js → client + worker):** `chapterCoverageSupports` + `fieldSupportedInChapter` — trường cụ thể được nhận nếu hoặc có câu trích hỗ trợ (như cũ), hoặc phần lớn từ khóa (≥ 60%) của giá trị CÓ THẬT trong chương và MỌI con số (tuổi, số đo) có đúng trong chương. Áp cho trường hồ sơ cụ thể và `currentLocation`. Bí mật (`secret`) giữ nguyên cổng chặt (cần bằng chứng riêng).
- **Test mới:** `v14_7_26_chapter_coverage` (5 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** cổng mới kiểm tra giá trị có xuất hiện trong chương, không kiểm tra nó gắn đúng nhân vật; chương có nhiều người cùng miêu tả có thể gán nhầm chi tiết. Thẻ đã rỗng sẽ không tự điền bù: cần chạy lại cập nhật nhân vật từ các chương đã viết.

## [V14.7.25] — Xóa/gộp nhân vật nhưng Current Status vẫn còn nhân vật đó
- **Nguyên nhân (đọc code):** xóa tay, "xóa bản trùng" và "gộp" chỉ bỏ nhân vật khỏi Character Database. Thẻ nhân vật trong `statusState.characterStates` và dòng "• Tên: …" trong văn bản Current Status không được dọn, nên nhân vật đã xóa/gộp vẫn hiện ở Status cho tới khi một lượt cập nhật Status sau đó ghi lại.
- **Sửa (shared/core.js → client):** `purgeCharacterFromStatus` xóa thẻ theo tên/bí danh/id và dựng lại khối "Thông tin nhân vật cập nhật" trong văn bản Status; khi GỘP, thẻ của nhân vật nguồn chuyển sang nhân vật đích nếu đích chưa có thẻ (không mất dữ liệu trạng thái), ngược lại bỏ. Áp cho xóa tay, xóa bản trùng và gộp; hộp Status làm mới ngay; "Hoàn tác" khôi phục cả Status.
- **Test mới:** `v14_7_25_status_purge` (4 kiểm tra).
- **Hạn chế:** chỉ dọn thẻ và khối nhân vật; nếu tên nhân vật đã xóa còn nằm trong các dòng Status khác (Tình huống, Sự kiện chính…) thì vẫn còn, vì đó là văn bản AI tự viết. Nhân vật bị tạo trùng từ trước vẫn cần gộp bằng "Dọn nhân vật trùng".

## [V14.7.24] — Nhân vật xuất hiện nhiều chương nhưng hồ sơ không cập nhật
- **Nguyên nhân (đọc code):** V14.7.19 chỉ chuyển 9 trường (vai trò, quan hệ, 18+) sang cổng "câu trích thật". Các trường tâm lý/diễn biến — tính cách, mục tiêu, điểm yếu, nỗi sợ, hiểu biết, `chapterEvent`, `mentalState`, `physicalState` — vẫn bị so từ khóa (0.35–0.45) với câu trích. Nhân vật chủ yếu xuất hiện trong cảnh nội tâm/quan hệ có giá trị là tóm tắt trừu tượng ("chống cự yếu dần, bắt đầu lệ thuộc…") nên gần như mọi trường bị rụng, dù đã viết nhiều chương quanh họ.
- **Sửa:** mở rộng `INTERPRETIVE_CHAR_FIELDS` sang nhóm tâm lý/diễn biến nói trên; bước ghi của bản chạy nền dùng `fieldQuoteSupports` cho nhóm này, kể cả `mentalState`/`physicalState`, `chapterEvent`. Bí mật (`secret`) vẫn cần bằng chứng RIÊNG (không suy đoán). Trường cụ thể (tuổi, giới, nghề, chức vụ, phe, ngoại hình, vị trí) vẫn dùng cổng từ khóa. Hồ sơ khóa vẫn được bảo vệ: tính cách/ngoại hình/mục tiêu của NV khóa chỉ vào "Chi tiết mới".
- **Test mới:** `v14_7_24_char_state_fields` (4 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** nếu chương gọi nhân vật chỉ bằng đại từ (không có tên) hoặc tên trùng nhiều người thì vẫn bị bỏ qua — xem dòng "NV: … bỏ qua (lý do)" trong báo cáo hậu kỳ của chương.

## [V14.7.23] — Story Clock đứng yên dù chương đã qua ngày
- **Nguyên nhân (đọc code):** ô Story Clock là ô NHẬP TAY và app không bao giờ cập nhật nó; `currentTimeMark` lại cho ô nhập tay thắng mốc tự trích từ chương (Status). Nhập một lần (hoặc bất kỳ giá trị nào) là đồng hồ đứng yên và mọi prompt viết chương cứ nhận "thời điểm hiện tại" cũ, kể cả khi chương đã sang ngày khác. Nhật ký thời gian cũng ghi lại đúng mốc cũ đó, nên cảnh báo "đứng một ngày" lẫn với đồng hồ đứng.
- **Sửa (shared/core.js → client + worker):** mặc định đồng hồ TỰ THEO chương: `currentTimeMark` ưu tiên mốc Status tự trích; `syncStoryClockFromStatus` kéo ô Story Clock theo mốc đó sau mỗi chương (ở cả đường chạy nền và đường trong trình duyệt). Thêm ô **"Tự theo chương"** (bật mặc định); bấm **Lưu** = ghim tay (tắt tự theo) cho tác giả muốn tự quyết; bật lại để đồng hồ chạy tiếp.
- **Test mới:** `v14_7_23_story_clock` (6 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** mốc tự theo phụ thuộc AI trích được thời điểm ở cuối chương (cần có dấu hiệu trong chương); nếu chương không có dấu hiệu thời gian nào thì đồng hồ giữ nguyên. Nếu truyện thực sự diễn ra trong một ngày qua nhiều chương, hãy chỉnh "Nhịp thời gian" (Cùng ngày / Khoảng 1 ngày/chương…) cho đúng ý.

## [V14.7.22] — Threads kẹt ở "seeded", chỉ 1 thread sau 16 chương
- **Nguyên nhân (đọc code):** (1) cổng bằng chứng của bản nền so `status` ("developing", "paid_off"…) với câu trích — một từ khóa trạng thái không bao giờ nằm trong câu văn nên LUÔN bị xóa → thread không thể đổi trạng thái; (2) mô tả thread bị so từ khóa (0.35) nên thread trừu tượng bị loại; (3) prompt bản nền không hề nói thread là gì, mấy thread mỗi chương, giá trị `status` hợp lệ, hay cách khớp thread cũ (`matchExistingDesc`); (4) giao diện đọc `lastUpdatedChapter` nhưng bản nền ghi `lastUpdated` nên luôn hiện "cập nhật chN" = chương gieo.
- **Sửa (shared/core.js → client + worker):** `normalizeThreadStatus` (seeded/developing/blocked/resolved/paid_off/abandoned + đồng nghĩa tiếng Việt) thay cổng so từ khóa; mô tả thread chỉ cần câu trích thật (`fieldQuoteSupports`); status địa điểm/vật phẩm cũng theo câu trích thật; thread ghi `lastUpdatedChapter` + `statusHistory`; prompt: 1–3 thread/chương, enum status, khớp thread cũ bằng `matchExistingDesc`; giao diện đọc `lastUpdated`. Thêm nút **🧵 Quét lại Threads toàn truyện** (chỉ thêm/cập nhật, không xóa; cũng điền bù địa điểm/vật phẩm).
- **Test mới:** `v14_7_22_threads` (4 kiểm tra). Chưa thử với model thật.
- **Lưu ý:** "Rescan từ chương X" trong app xóa thread/lịch sử từ chương đó trở đi; để điền bù Threads hãy dùng nút mới thay vì nút đó.

## [V14.7.21] — Hồ sơ nhân vật lặp ý; Memory chỉ ghi 1 sự kiện sau 16 chương
- **Nguyên nhân 1 (ảnh Character Database):** bước nối text chỉ bỏ đoạn trùng NGUYÊN VĂN. AI mỗi chương diễn đạt lại cùng một ý ("mâu thuẫn giữa sự kiêu kỳ… và sự yếu đuối… khi bị áp chế") nên đoạn nào cũng bị coi là mới và được nối thêm → ô tính cách của Quỳnh Anh có hàng chục đoạn cùng nghĩa. Prompt NV [MỞ KHÓA] còn "BẮT BUỘC bổ sung" mỗi chương, và AI chỉ thấy 180 ký tự hồ sơ hiện có nên không biết mình đang lặp.
- **Sửa (shared/core.js → client + worker):** `segmentsNearDuplicate` (so từ khóa: Jaccard ≥ 0.5 hoặc trùm ≥ 80% đoạn ngắn) + `dedupeTextSegments` (giữ đoạn đầu tiên) dùng trong `mergeTextSegments` — client và worker (`mergeTextField`) đều nối qua hàm này; cũng dọn luôn phần lặp đã có trong ô đang nối. Thêm `cleanCharacterRepeats` + nút **✂ Dọn ý lặp trong hồ sơ** (nhân vật phụ + nhân vật chính, mọi ô tích lũy) để dọn dữ liệu cũ. Prompt: bỏ "BẮT BUỘC bổ sung" cho [MỞ KHÓA], thêm "CHỐNG LẶP: đổi từ vẫn là lặp"; worker đưa AI 360 ký tự tính cách/300 ngoại hình hiện có (trước đây 180).
- **Nguyên nhân 2 (ảnh Memory Engine v9: Timeline 1 sự kiện, Foreshadowing 1/16 chương):** cổng bằng chứng của bản nền so từ khóa tóm tắt với câu trích (ngưỡng 0.45) nên mục trừu tượng bị loại ("bỏ n mục"); prompt cũng dặn "chỉ thêm sự kiện có ý nghĩa". **Sửa:** `fieldQuoteSupports` (câu trích phải là câu thật trong chương) thay cổng cũ cho events/foreshadowing/knowledge; prompt yêu cầu 3–6 sự kiện chính mỗi chương + điểm gieo + dữ kiện ai biết gì (cả đường nền lẫn nút "Quét lại Memory toàn truyện").
- **Sửa hiển thị:** "L1 · summary đã đóng băng: 23/16" đếm cả bản sửa (-rN) và mục của chương đã xóa; nay đếm theo mục duy nhất trong phạm vi chương hiện có.
- **Test mới:** `v14_7_21_repeat_memory` (6 kiểm tra, dùng chính đoạn lặp trong ảnh). Chưa thử với model thật.
- **Hạn chế:** dọn lặp dựa trên trùng từ khóa — hai đoạn khác ý nhưng dùng nhiều từ giống nhau có thể bị gộp (giữ đoạn đầu); ý lặp ít từ trùng vẫn còn. Memory cũ không tự điền bù: cần bấm "Quét lại Memory toàn truyện".

## [V14.7.20] — "chị A", "anh B", tên gọi tắt không nhận ra → không cập nhật hoặc tạo nhân vật mới
- **Nguyên nhân:** `resolveCharacterTarget` chỉ khớp tên đầy đủ hoặc bí danh khai sẵn; "chị Hùng", "anh Lạc", "Quỳnh Anh" (so với "Trần Quỳnh Anh") không khớp → bản client tạo nhân vật mới; bản nền chỉ cứu được tên gọi tắt không kèm danh xưng. "chị"/"anh ấy" trơn cũng có thể thành nhân vật mới.
- **Sửa (shared/core.js → client + worker):** bỏ danh xưng đứng đầu (anh, chị, em, cô, chú, bác, ông, bà, thím, cậu, mợ, dì, dượng, thầy, cụ, sếp) rồi khớp tên đầy đủ/bí danh/nhân vật chính, CHỈ khi duy nhất một người khớp. Trùng (hai người cùng tên gọi) → `ambiguous`: bỏ qua, ghi lý do, không đoán, không tạo mới. Chỉ danh xưng/đại từ ("chị", "anh ấy", "cô ta") → bỏ qua. Nhận diện được thì tự lưu cách gọi thành bí danh (tối đa 6) để lần sau khớp thẳng. Roster gửi cho AI nay kèm `aliases`; prompt dặn dùng đúng tên đầy đủ/id, không tạo NV mới cho "chị X".
- **Test mới:** `v14_7_20_honorific_names` (8 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** đại từ thuần ("chị ấy", "anh") không biết là ai thì bị bỏ qua, không đoán theo ngữ cảnh; nếu hai nhân vật trùng tên gọi, hãy đặt bí danh riêng cho từng người (ví dụ "chị Hoa kế toán").

## [V14.7.19] — Vai trò, Quan hệ & Ranh giới 18+ không cập nhật theo chương
- **Nguyên nhân (đã đo):** cổng bằng chứng của bản chạy nền so khớp TỪ KHÓA giữa giá trị AI viết và câu trích. Các trường diễn giải (vai trò, mức liên quan, ranh giới, sở thích, hấp dẫn/căng thẳng 18+, và các trường quan hệ: stage/trust/attraction/boundaries/notes...) là tóm tắt của AI nên gần như không trùng từ với câu trích → bị loại hết (mẫu thử: tỉ lệ khớp 0.00–0.07 so với ngưỡng 0.35/0.45). Ngoài ra `role` đã có thì bị bỏ qua im lặng; nhân vật chính chỉ nhận 4 trường trạng thái + tu luyện, không nhận 18+.
- **Sửa (shared/core.js → client + worker):** `INTERPRETIVE_CHAR_FIELDS` + `fieldQuoteSupports` — nhóm này chỉ cần câu trích là câu THẬT trong chương (≥70% từ có trong chương); câu trích bịa/rỗng vẫn bị loại. Áp cho trường hồ sơ, `relationships[]` và `relationshipWithMain`. `role` đã khóa: vai trò mới vào ô "Chi tiết mới" (`Vai trò mới: …`) thay vì rơi mất; nghề/chức vụ/phe vẫn khóa. `applyMainCharUpdate`: nhân vật chính nhận `sexualExperience/boundaries/preferences` (nối ý, không ghi đè; chặn < 18 tuổi).
- **Test mới:** `v14_7_19_character_fields` (6 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** AI vẫn phải đưa câu trích; trường khác (ngoại hình, tính cách, mục tiêu) vẫn khóa hồ sơ gốc như cũ. Nhân vật chính chưa có mục "Chi tiết mới" nên chỉ nhận 3 trường 18+ ở trên.

## [V14.7.18] — Tu luyện không có tiến bộ rõ ràng
- **Nguyên nhân:** quy tắc cũ chỉ nói "không tự nâng cảnh giới, chỉ đột phá khi có sự kiện" — không có yêu cầu nào buộc truyện cho thấy tiến bộ, nên AI chỉ nhắc "tu luyện, mạnh hơn một chút".
- **Thêm (shared/core.js → client + worker):** `CULTIVATION_PROGRESS_CRAFT` (mốc cụ thể tầng/linh lực/kinh mạch/thần thông; phép thử trước–sau; quá trình và cái giá; nhịp tiểu tầng vs đại cảnh giới và tiến độ tích lũy; một câu tường minh nêu cảnh giới mới để hồ sơ nhận bằng chứng; song tu: kết quả ở hậu cảnh). Gắn vào `cultivationSystemBlock` (mọi prompt viết) và `cultivationPlanBlock` (kế hoạch chương: beat tu luyện phải ghi mốc, phép thử, cái giá). Client/worker truyền `cultivation: cultivationActive(state)`.
- **Test mới:** `v14_7_18_cultivation_progress` (5 kiểm tra). Chưa thử với model thật.
- **Hạn chế:** chỉ áp dụng khi truyện thuộc thể loại tu luyện hoặc có Hệ thống tu luyện/thang cảnh giới trong Story Bible; hồ sơ chỉ đổi cảnh giới khi chương nêu rõ (cổng bằng chứng giữ nguyên).

## [V14.7.17] — Cung cảm xúc và kỹ thuật điều khiển nhịp cho cảnh 18+ nặng tâm lý
- **Thêm (shared/core.js → client + worker):** `EROTIC_ARC_PACING_CRAFT`: (A) đảo chiều cảm xúc theo nấc — kháng cự → cơ thể phản bội (lý trí vẫn từ chối, hai mạch thể xác/ý chí va nhau) → ĐIỂM GÃY là một khoảnh khắc cụ thể → day dứt sau khi đổ; không đổ quá nhanh, điểm gãy ở nửa sau cảnh (hoặc chương sau); (B) căng thẳng = trì hoãn có chủ đích của kẻ nắm quyền, mỗi lần trì hoãn khác nhau và đẩy tới ngưỡng mới; (C) pacing = ghìm/đẩy người đọc, nhịp chậm nặng tâm lý ở đầu và giữa, dồn nhanh chỉ ở đoạn vỡ, tiết lộ từng mảnh. Gắn vào neo 18+ của scene nóng, đường viết thường (khi truyện 18+) và kế hoạch chương (cảnh có kháng cự/quyền lực phải lên nhịp theo nấc, không bỏ qua day dứt).
- **Lưu ý:** neo 18+ của scene nóng nay dài ~5.000 ký tự (cơ thể + hành động + nội tâm + cung cảm xúc/nhịp); model nhỏ có thể làm theo không hết.
- **Test mới:** `v14_7_17_arc_pacing` (3 kiểm tra). Chưa thử với model thật.

## [V14.7.16] — Cảnh nóng toàn hành động, và bị cắt sang cảnh khác giữa chừng
- **Nguyên nhân:** quy tắc 18+ chỉ nói về cơ thể/hành động/âm thanh; không có yêu cầu nội tâm, hồi tưởng, và không cấm chen cảnh khác (tu luyện, tin nhắn, người đi ngang) vào giữa lúc chưa tới cao trào — những beat đó trong Outline được viết thành scene riêng.
- **Sửa (shared/core.js → client + worker):** `EROTIC_INNER_CRAFT` — xen kẽ hành động → nội tâm → hành động; nội tâm của CẢ HAI phía theo đúng vai (chủ động: lạnh lùng/toan tính/chiếm hữu; bị chi phối: nhục/kháng cự/cơ thể phản bội); mảnh hồi tưởng 1–3 câu kết bằng hành động hiện tại; nội tâm ~1/4–1/3 cảnh dài. **KHÔNG CẮT CẢNH** giữa chừng: beat khác phải lồng trong cảnh (cảm nhận/suy nghĩ/tiếng động) hoặc xếp sau khi cảnh kết thúc. Gắn vào neo 18+ của scene nóng, đường viết thường (khi truyện 18+) và kế hoạch chương (beat chen giữa không thành cảnh riêng).
- **Test mới:** `v14_7_16_inner_continuity` (3 kiểm tra). Chưa thử với model thật.
- **Hạn chế đã biết:** nếu Outline tách beat chen giữa thành mục riêng, bộ chia scene vẫn có thể tạo scene riêng cho nó; quy tắc chỉ dặn scene đó lồng/đặt sau.

## [V14.7.15] — Mô tả thân hình ("cao 185cm...") lặp lại và thô mỗi scene/chương
- **Nguyên nhân:** neo ngoại hình bảo "khi nhân vật xuất hiện lần đầu trong chương, hoặc khi cảnh tả cơ thể" nêu chiều cao/số đo; mỗi scene lại được viết độc lập và nhận hồ sơ đầy đủ nên scene nào cũng coi là "lần đầu" và đọc lại số liệu.
- **Sửa (shared/core.js → client + worker):** (1) mỗi nhân vật trong hồ sơ scene được gắn nhãn **ĐÃ GIỚI THIỆU** (xuất hiện trong ~4 chương gần nhất, kể cả chương đang viết dở) hoặc **CHƯA GIỚI THIỆU**; (2) nhân vật ĐÃ GIỚI THIỆU: cấm nhắc lại chiều cao/cân nặng/số đo/dáng, không mở scene/chương bằng đoạn tả hình thể, mỗi scene tối đa 1–2 chi tiết thân thể MỚI hoặc phản ứng/cử động hiện tại; (3) neo chỉ tả đầy đủ ở lần đầu trong truyện, khi quay lại sau ≥ 6 chương vắng, hoặc khi thân thể/trang phục thay đổi; (4) `BODY_PROSE_CRAFT`: bộ phận chỉ tả đầy đủ lần đầu, các lần sau một chi tiết mới/cảm giác với hình ảnh khác; (5) đường viết thường có dòng CHỐNG LẶP tương tự.
- **Test mới:** `v14_7_15_no_repeat_description` (4 kiểm tra). Chưa thử với model thật.

## [V14.7.14] — Cảnh nóng thiếu hành động, âm thanh, hình ảnh chân thật
- **Nguyên nhân:** các neo 18+ trước chỉ dặn tả cơ thể, "4 lớp" và không tóm tắt; không có quy tắc tả TỪNG hành động, và cảnh nóng chỉ nhận phần ngân sách từ tỉ lệ theo độ dài beat nên thường quá ngắn để tả từng nhịp.
- **Sửa (shared/core.js → client + worker):** `EROTIC_ACTION_CRAFT` — mỗi hành động (liếm, mút, ngón tay, đẩy vào, tát mông, kéo tóc...) là một nhịp riêng với đủ 5 yếu tố: bộ phận/vị trí, lực và tốc độ, cảm giác da thịt thật, âm thanh, phản ứng cơ thể của cả hai; đi theo thứ tự thật (dạo đầu → chạm → vào từng đoạn, dừng một nhịp → tăng/giảm nhịp → đổi tư thế → cao trào), không gộp nhiều hành động vào một câu. Gắn vào neo cơ thể 18+ của scene nóng và neo của đường viết thường (chỉ khi truyện 18+). Beat nóng trong kế hoạch được chia ngân sách từ x1,6 (tổng chương không đổi).
- **Chương trước dừng giữa cảnh nóng:** đuôi chương trước có từ khóa 18+ mà chưa có dấu hiệu cao trào/kết cảnh thì prompt chương sau được thêm lưu ý "viết tiếp NGAY từ đúng khoảnh khắc đó, tả từng hành động, đưa tới cao trào + hậu cảnh ngắn rồi mới sang beat Outline mới" (đường viết thường và từng scene). Trước đây chỉ có yêu cầu giữ đúng địa điểm/thời điểm.
- **Từ khóa cảnh nóng:** danh sách cũ bỏ sót nhiều từ Outline thật (phá trinh, bú, edging, trứng rung, nước dâm, kích thích, đâm chậm...) nên các tính năng V14.7.7/V14.7.11/V14.7.14 có thể không nhận cảnh là cảnh nóng. Đã bổ sung; câu thường (họp, đâm kiếm...) không bị nhận nhầm.
- **Test mới:** `v14_7_14_action_detail` (4 kiểm tra), `v14_7_14b_unfinished_scene` (6 kiểm tra). Chưa thử với model thật.

## [V14.7.13] — Mô tả thân thể khô như báo cáo ("dài 25 cm", "84-60-88")
- **Nguyên nhân:** các neo ngoại hình/cơ thể (V12.32.8, V14.7.4, V14.7.11) yêu cầu nêu "bằng con số hoặc so sánh cụ thể" để chữa lỗi tả chung chung; model hiểu là đọc số liệu hồ sơ, nên ra câu khô.
- **Sửa (shared/core.js → client + worker):** thêm `BODY_PROSE_CRAFT` — số đo/kích thước là dữ kiện ngầm cần DỊCH thành hình ảnh; để thân thể tự kể chuyện qua (1) hình ảnh vật thể/thiên nhiên, (2) cảm nhận của người nhìn/chạm, (3) chuyển động và vải, (4) tương phản; mỗi bộ phận một cụm 2–4 câu giàu giác quan; con số chỉ thoáng một lần trong hình ảnh; mỗi lần nhắc đổi góc nhìn. Áp vào cả ba neo (ngoại hình trong scene, cơ thể 18+, đường viết thường). Vẫn chống tính từ trống; rào chắn tuổi giữ nguyên.
- **Test mới:** `v14_7_13_body_prose` (4 kiểm tra). Chưa thử với model thật: chất lượng văn còn phụ thuộc model.

## [V14.7.12] — Chương 5–6 bị cảnh báo "Outline chưa thấy: Chương 1 …, Chương 2 …"
- **Triệu chứng (ảnh chụp):** thẻ Chương 5 và 6 báo thiếu các ý của Chương 1–2 trong Outline; Chương 6 bị yêu cầu viết lại sự kiện đầu truyện.
- **Nguyên nhân:** Outline viết dạng `Chương 1 Nội dung…` (không có dấu `:` `.` `)` `-` sau số) không được nhận là tiêu đề chương. Khi không dòng nào khớp, app coi outline là "không đánh số" và gán **900 ký tự đầu outline** (= nội dung chương 1–2) làm dòng của chương đang viết.
- **Sửa:** (1) chuẩn hóa `Chương N Nội dung` → `Chương N: Nội dung` cho cả bộ tách dòng và bộ tách ý; (2) tiêu đề đơn `Chương 6` đứng một mình (đúng định dạng Outline thật của người dùng: dòng `Chương N`, nội dung ở các dòng dưới) được nhận ở cả bộ tách dòng lẫn bộ tách ý/Hậu quả/Móc kết — mỗi dòng bên dưới là một ý; (3) outline có đánh số chương mà không tách được thì **không còn** lấy đầu outline gán cho chương hiện tại (client + worker).
- **Test mới:** `v14_7_12_outline_noseparator` (6 kiểm tra, có chạy trên định dạng thật). Chưa thử với model thật.

## [V14.7.11] — Hồ sơ 18+ (kích thước...) không xuất hiện trong cảnh nóng
- **Nguyên nhân:** đường viết từng scene chỉ đưa các trường nghề/ngoại hình/số đo vào prompt, **không đưa `sexualExperience` ("Đặc điểm 18+"), `preferences`, `boundaries`...** nên model không hề thấy dữ kiện "24–25 cm". Đường viết thường lại cắt "Đặc điểm 18+" còn 120 ký tự. Ngoài ra không có chỉ dẫn tả phản ứng của người chứng kiến nên chỉ ra "to lớn".
- **Sửa (shared/core.js):** scene nóng (truyện bật 18+ và beat/contract có từ khóa 18+) nhận thêm các trường 18+ (320 ký tự cho Đặc điểm 18+) và **NEO CƠ THỂ 18+**: tả cụ thể theo số liệu hồ sơ, rồi tả phản ứng/cảm giác/cảm xúc của người tiếp nhận, không lặp mẫu câu. Scene thường và truyện tắt 18+ không bị lẫn. Đường viết thường nới 120→320 ký tự.
- **Neo cơ thể áp cho MỌI người trong cảnh nóng** (không chỉ khi có trường 18+): nêu rõ ngực, núm vú, mông, đùi, âm hộ/lồn, dương vật; gọi thẳng tên theo mức 18+ của STYLE LOCK, tả theo số đo/hồ sơ, không né bằng ẩn dụ.
- **Tối ưu:** `findRepeatedParagraphs` tách từ một lần và loại sớm cặp đoạn có quá ít từ chung (kết quả y hệt) — bài kiểm tra tốc độ trước đó sát ngưỡng 3 giây nên lúc đạt lúc trượt khi máy bận.
- **Test mới:** `v14_7_11_adult_profile` (5 kiểm tra). Chưa thử với model thật.

## [V14.7.10] — Nội dung chương không vào Character Database
- **Nguyên nhân (2 chỗ):** (1) trang phục, dấu vết cơ thể, đồ chơi đang dùng, cảm xúc, mức phục tùng... chỉ nằm trong thẻ Current Status (`statusState`), thẻ nhân vật không có chỗ chứa nên tab Nhân vật trông "đứng yên"; (2) mọi nhân vật mặc định **khóa hồ sơ gốc** (`coreLocked`): ngoại hình/tính cách/mục tiêu đã có giá trị thì chi tiết mới từ chương bị bỏ hẳn, không ghi ở đâu.
- **Sửa:** trường mới **currentState** (tự phản chiếu từ thẻ Status đã qua kiểm bằng chứng) và **newDetails** (chi tiết mới có bằng chứng bị khóa chặn — ghi riêng, không ghi đè hồ sơ gốc, không lặp). Cả hai hiện trong thẻ nhân vật, đi qua server hậu kỳ và so sánh canon. Hàm dùng chung `characterStateLine`/`divertLockedDetail` ở `shared/core.js`; client và worker cùng gọi.
- **Giữ nguyên:** hồ sơ gốc khóa vẫn không bị ghi đè; mọi giá trị vẫn phải có bằng chứng trích từ chương.
- **Test mới:** `v14_7_10_character_state` (4 kiểm tra). Chưa thử với model thật.

## [V14.7.9] — 5 chương chỉ có 2 nhân vật
- **Nguyên nhân:** outline chỉ có "hắn" và "ả"; Cast Planner (V14.7.6) phải bấm tay nên không ai bấm; kế hoạch chương không biết có nhân vật phụ nào để đưa vào.
- **Sửa:** (1) khi bắt đầu chương ≥ 2 mà có < 3 người ngoài NVC, app **tự chạy Cast Planner một lần** (cả viết thường lẫn viết nền; lỗi thì bỏ qua, không chặn viết); (2) kế hoạch chương nhận danh sách nhân vật phụ đã khai báo nhưng chưa/lâu chưa xuất hiện và được yêu cầu cho ít nhất một người xuất hiện/được nhắc nếu hợp mạch, không phá mốc brief, không tạo tên ngoài hồ sơ.
- **Sửa lỗi V14.7.6:** Cast Planner báo `(s||"").replace is not a function` vì đưa kết quả `callAI` (object {text, finishReason}) thẳng vào `safeJsonParse`; nay đọc `.text`. Lỗi này khiến nút 🎭 và tự nạp không bao giờ thêm được nhân vật.
- **Test mới:** `v14_7_9_cast_auto` (6 kiểm tra). Chưa thử với model thật.

## [V14.7.8] — create-job không phản hồi sau 90 giây (đã tải lên xong 100%)
- **Triệu chứng:** "create-job không phản hồi sau 90 giây… tải lên ĐÃ xong… server Netlify vẫn tới được".
- **Phân tích:** create-job là hàm đồng bộ (Netlify mặc định ~10 giây); ngân sách cũ có thể cộng tới 11,5 giây (dọn job 1,5 + ghi Blobs 6 + kích hoạt 4) nên có thể vượt giới hạn, và khi phản hồi bị mất app không biết job đã tạo hay chưa. Không có log Netlify nên chưa xác định chắc nguyên nhân phía server.
- **Sửa:** (1) ngân sách mới ≤ 8,8 giây (dọn 0,8 + ghi 5 + kích hoạt 3); (2) app tự sinh jobId + accessToken gửi kèm, server dùng nếu đúng định dạng; hết giờ sau khi đã tải lên xong thì app hỏi job-status tối đa 5 lần/4 giây, thấy job thì coi như thành công và theo dõi bình thường (không tạo job trùng); không thấy mới báo lỗi như cũ.
- **Outline dạng chặng:** tiêu đề "Chương 2–3" (nhiều chương chung một khối, các dòng Beat/18+/Hậu quả/Móc kết bên dưới) trước đây không được đọc: chương 2 bị gán nội dung "3…", chương 3+ không có dòng outline nên kế hoạch chương không thấy outline. Nay mỗi chương trong chặng nhận nội dung chặng kèm nhãn "phần k/n — chỉ làm bước k"; dòng chương đơn lẻ luôn thắng. Test `v14_7_8_outline_range` (5 kiểm tra).
- **Test mới:** `v14_7_8_create_job_recovery` (7 kiểm tra, có chạy thật hàm khôi phục với fetch giả). Chưa thử trên Netlify thật.

## [V14.7.7] — Truyện PRIMARY nhưng chương 3–6 không có cảnh 18+
- **Tái hiện từ bản truyện thật (6 chương):** chỉ chương 2 có cảnh nóng; chương 3–6 hoàn toàn không. Model uncensored và mức 18+ không phải nguyên nhân (chương 2 viết rất thẳng).
- **Nguyên nhân gốc:** bước lập kế hoạch chương chỉ có dòng "nếu có cảnh trưởng thành" (tùy chọn) và không hề biết Trọng tâm trưởng thành; khi có brief/mệnh lệnh thì còn bị cấm thêm sự kiện, nên AI không lên cảnh nóng nào.
- **Sửa (shared/core.js → client + worker):** khối **LỊCH CẢNH NÓNG** trong prompt kế hoạch: PRIMARY bắt buộc có beat "cảnh nóng" (2 nhân vật ≥18 tuổi, đổi quan hệ/quyền lực), thêm dưới dạng [S] để không lệch brief; SECONDARY chỉ gợi ý nhưng bắt buộc sau 3 chương liền không có cảnh nóng. Tắt 18+ hoặc focus NONE thì không thêm gì.
- **Test mới:** `v14_7_7_mature_plan` (4 kiểm tra). Chưa kiểm chứng với model thật.

## [V14.7.6] — Cast Planner: AI đề xuất dàn nhân vật mới bám truyện
- **Vấn đề:** nhân vật mới chỉ được ghi nhận sau khi đã xuất hiện trong chương, nên dàn nhân vật phụ nghèo nàn và Gate cấm người "lạ".
- **Thêm:** nút **🎭 AI đề xuất dàn nhân vật mới (người lớn)** ở tab Nhân vật. AI dựng ~6 nhân vật dựa trên cốt truyện, thể loại, nhân vật chính, outline và dàn đã có; tự nạp thành **bản nháp** (không khóa hồ sơ) để tác giả sửa sau. Mỗi thẻ gồm vai trò + quan hệ với NVC + mong muốn + bí mật, ngoại hình + chiều cao/vóc dáng/số đo, cách nói + xưng hô.
- **An toàn:** chỉ nhận nhân vật có tuổi ghi bằng số ≥ 18; thiếu tuổi hoặc < 18 bị loại và báo lý do; không ghi đè/trùng tên nhân vật đã có (kể cả NVC, không phân biệt hoa-thường/dấu). Rào chắn tuổi hiện có giữ nguyên.
- **Test mới:** `v14_7_6_cast_planner` (5 kiểm tra). Chưa kiểm chứng với model thật.

## [V14.7.5] — Dàn nhân vật bị bóp nghẹt (7 chương chỉ có 1 nhân vật chính + 2 phụ)
- **Nguyên nhân gốc:** (1) giới hạn cứng "tối đa 4 nhân vật có tên riêng mỗi chương" (tính cả nhân vật chính, trần cứng 6, không có ô chỉnh trong giao diện), vượt thì Quality Gate báo lỗi cứng bắt viết lại; (2) khi chưa có nhân vật phụ nào, prompt viết chương bảo model "ưu tiên nhân vật KHÔNG TÊN"; (3) nhiều câu "không tùy tiện tạo nhân vật mới" và `unauthorizedImportantCharacter` khiến model chọn an toàn là không thêm ai. Kết hợp lại, dàn nhân vật gần như không lớn lên.
- **Sửa:** mặc định mới 6; trần 12; thêm ô **👥 Số nhân vật có tên tối đa mỗi chương** (4/5/6/8/10/12, cạnh "Nhịp thời gian"), lưu theo từng truyện trong `storyControl` với cờ `castCapUserSet`. Truyện cũ còn giá trị 4 do mặc định cũ KHÔNG bị coi là lựa chọn của tác giả nên tự lên 6; tác giả đã chọn thì giữ nguyên. Prompt viết chương: người thoáng qua để không tên, nhân vật có vai trò lặp lại (đối tác, người thân, đồng nghiệp, đối thủ, người tình, cấp trên) thì đặt tên riêng ngay; truyện dài được giới thiệu thêm một nhân vật phụ có vai trò lặp lại khi brief/outline cho phép. Gate chỉ báo lỗi cứng khi vượt giới hạn hiện hành; `unauthorizedImportantCharacter` giữ nguyên.
- **Test mới:** `v14_7_5_cast_limit` (7 kiểm tra) và 2 kiểm tra E2E (chọn trên giao diện → lưu → nạp lại) trong `e2e_upgrade_compat.py`.

## [V14.7.4] — Scene tả ngoại hình chung chung, thiếu kích thước theo hồ sơ
- **Nguyên nhân gốc (đã tái hiện bằng test trước khi sửa):** cảnh báo "Miêu tả ngoại hình chung chung, thiếu kích thước/chi tiết cụ thể" là đúng. Trong pipeline viết từng scene, `sceneProfileBlock` chỉ gửi `ngoại hình` cắt 110 ký tự và KHÔNG gửi chiều cao, dáng, SỐ ĐO, tóc, mắt, da, giọng, mùi, phong cách, sẹo, xăm; khối "NEO NGOẠI HÌNH" chỉ có ở đường viết thường. Model viết scene không có dữ kiện để tả nên viết "gương mặt căng thẳng", "váy ngắn bó sát".
- **Sửa (shared/core.js, dùng chung client + worker nền):** hồ sơ scene mang thêm các trường hình thể (ngoại hình nâng lên 160 ký tự; tổng khối hồ sơ 2400 → 3800 để nhân vật thứ 5 không bị cắt); thêm `SCENE_APPEARANCE_ANCHOR` (dùng ĐÚNG hồ sơ, tả bằng con số/so sánh cụ thể, cấm tính từ trống thay cho hình thể, trang phục tả kèm cách ôm/hở trên đúng phần cơ thể) — chỉ chèn khi scene có nhân vật có hồ sơ. Rào chắn tuổi không đổi.
- **Lưu ý dữ liệu:** trường hồ sơ trống thì model tự đặt chi tiết rồi giữ nhất quán; muốn bám đúng số đo, điền Chiều cao / Dáng người / Số đo trong thẻ nhân vật.
- **Test mới:** `v14_7_4_scene_body_profile` (5 kiểm tra).

## [V14.7.3] — Truyện 18+ bị viết nhạt/né tránh trong pipeline từng scene
- **Nguyên nhân gốc (đã tái hiện bằng test trước khi sửa):** pipeline viết theo scene (`compactSceneStyleLock` + `SCENE_SYSTEM_PROMPT`, dùng chung client và worker nền) chỉ gửi cho model một dòng `mức_18+` bị cắt 330 ký tự; mức **Cực mạnh (wild) bị hạ xuống Mạnh**; bộ quy tắc erotic (từ thô tục, 4 lớp cơ thể–cảm giác–nội tâm–âm thanh, nhịp 3 phần, không tóm tắt cao trào) KHÔNG hề tới model viết scene, trong khi system prompt chỉ nói "show, don't tell". Vì vậy thử trực tiếp với model uncensored viết được nhưng viết trong truyện thì nhạt.
- **Sửa:** scene dùng đúng mức người dùng chọn (`EXPLICIT_PROMPTS[level]`, không hạ cấp); mức Mạnh/Cực mạnh thêm `EROTIC_SCENE_LOCK` (mức Nhẹ/Gợi cảm/Rõ ràng giữ nguyên, không bị ép); `SCENE_SYSTEM_PROMPT` thêm chỉ dẫn viết thẳng cho cảnh nóng giữa người trưởng thành; STYLE LOCK trong prompt scene nâng giới hạn 1500 → 2800 ký tự. Rào chắn tuổi (≥18) vẫn luôn bật và có ưu tiên cao nhất.
- **Chế độ NSFW "Luôn dùng":** `adultModelFor` (tóm tắt, gợi ý chương) nay chuyển model 18+ không cần từ khóa khi chế độ là "Luôn dùng" (trước đó vẫn đòi từ khóa).
- **Lưu ý cấu hình:** để viết truyện thuần 18+ cần bật "Cho phép trưởng thành", Trọng tâm = PRIMARY (NONE chèn lệnh cấm nội dung trưởng thành và tắt chuyển model), NSFW = "Luôn dùng", mức 18+ = Mạnh hoặc Cực mạnh.
- **Test mới:** `v14_7_3_adult_scene_style` (12 kiểm tra, client + worker).

## [V14.7.2] — Che API key trong thông báo lỗi, xử lý phản hồi không phải JSON, bài kiểm tra nâng cấp
- **Lỗi bảo mật (P0, đã tái hiện bằng test trước khi sửa):** `callAI` ghép nguyên văn thông báo của nhà cung cấp (401 thường lặp lại API key) và `networkErr.message` vào lỗi hiển thị cho người dùng. Nay mọi thông báo lỗi đi qua `redactKey` (che key đang dùng, dạng `sk-…`/`Bearer …`).
- **Worker nền:** `callOpenRouter` được bọc `redactApiKey` nên lỗi ghi vào trạng thái job cũng không còn lộ key.
- **Lỗi phản hồi 200 không phải JSON** (proxy/gateway trả trang HTML): trước đây lộ `Unexpected token < in JSON`; nay báo tiếng Việt rõ ràng, không retry ghi lặp.
- **Test mới:** `v14_7_1_callai_api` (9 kịch bản bằng fetch giả: 200, 401/403/404 không retry, 429+Retry-After, 503 hết lượt retry, lỗi mạng, key rò rỉ, JSON hỏng, rỗng, thiếu key); `e2e_upgrade_compat.py` (tạo record bằng app V14.5.15 gốc qua `UPGRADE_OLD_DIR`, nạp vào bản hiện tại; kiểm tra Accuracy Mode, min/max, thế lực, L1 và trạng thái thread sống sót qua lưu/nạp). Cầu nối test `__xta` (chỉ bật khi `__XTA_TEST__`) bổ sung `hydrateFromRecord`.
- Khi đổi `app/client.js` nhớ tăng `?v=` trong `index.html` (nay `14.7.2`).

## [V14.7.1] — Chốt bản phát hành, tách client, sửa lỗi Accuracy/Memory, nâng hợp đồng văn xuôi
- **Chốt phát hành:** đồng bộ phiên bản (package.json, README, CHANGELOG, tiêu đề/nhãn UI, header X-Title); mục `[Unreleased]` cũ được đổi thành `[V14.6–V14.7.0]`; gỡ test lỗi thời `v12_26_fast_write` (kiểm tra tính năng đã bị thay thế, 0/7 PASS và không nằm trong `npm test`).
- **Tách client khỏi `index.html`:** toàn bộ script (~830KB) chuyển sang `app/client.js`; `index.html` chỉ còn khung HTML (~50KB) và thẻ `<script src="app/client.js?v=14.7.1">`. `scripts/sync-shared.js` nay đồng bộ `SHARED-CORE`/`CLIENT-MIRROR` vào `app/client.js`. Test cũ đọc qua `tests/_read_index.js` (nhúng lại client vào HTML) nên các kiểm tra regex giữ nguyên ngữ nghĩa. **Khi deploy phải upload cả thư mục `app/`.** Khi đổi `app/client.js`, tăng `?v=` trong `index.html` để trình duyệt/iPhone không dùng bản cache cũ.
- **Sửa lỗi Accuracy Mode:** (1) worker nền tự dựng cấu hình Quality Gate nên bỏ qua Accuracy Mode (vẫn nhận SOFT_FAIL, Gate có thể tắt) — nay dùng chung `accuracyModeQualityGateOptions` và, khi Accuracy Mode bật, worker ép về bản nháp (không tự Sync Canon vì worker không có audit beat `[R#]`); (2) bằng chứng beat một ký tự cũng được coi là xác minh — nay yêu cầu trích dẫn ≥12 ký tự và ≥3 từ; (3) so khớp trích dẫn nay chuẩn hóa Unicode NFC và gộp khoảng trắng, tránh báo sai do dấu tiếng Việt dạng NFC/NFD; prompt audit nói rõ yêu cầu này; (4) bộ quét đoạn lặp bỏ qua cặp có độ dài chênh quá ngưỡng trước khi tính khoảng cách chỉnh sửa.
- **Sửa lỗi bộ nhớ L0–L5:** L2/L3/L4 không còn bị đóng băng khi thiếu chương/tầng nguồn (trước đây tóm tắt thiếu bị khóa vĩnh viễn và làm lệch các tầng trên); lỗi API khi bù L1 trong vòng L2 không còn làm sập cả lượt xây — được ghi vào báo cáo và xây bù được ở lần sau.
- **Văn xuôi tiếng Việt:** `vietnameseNovelWritingPrompt()` (dùng chung viết thường, worker, scene) thêm 5 nguyên tắc: scene có mong muốn–vật cản–giá phải trả–thay đổi; thoại có ẩn ý; chi tiết cảm giác riêng và không chỉ thị giác; chậm nhịp ở khoảnh khắc nặng và có dư âm; kết cảnh bằng bước ngoặt thay vì tóm tắt cảm xúc.
- **Test mới:** `v14_7_1_accuracy_hardening`, `v14_7_1_memory_partial_sources`, `v14_7_1_prose_contract`; cập nhật `v12_47_autonomous_write` theo chính sách Gate dùng chung.

## [V14.6–V14.7.0] — Bộ nhớ truyện dài L0–L5, continuity, min/max chương và Accuracy Mode
- Thêm snapshots L1–L4 đóng băng theo tầng, L2/L3/L4 gộp theo 4/20/60 chương, L5 có version history; hỗ trợ xây bù và chỉ đưa summary quá khứ vào prompt trong ngân sách giới hạn.
- Thêm CRUD hồ sơ thế lực; cho phép sửa/đóng threads có history, giữ trạng thái do tác giả chọn qua merge worker và lưu mốc thời gian theo chương.
- Thêm giới hạn min/max theo truyện, rút gọn có snapshot/giữ Outline và bản gốc, báo cáo hậu kiểm độ dài/continuity/time/threads theo từng chương.
- Cập nhật E2E client cho Scene Graph/telemetry, CRUD thế lực, đóng thread, min/max, condensation, L1 memory và báo cáo hậu kiểm; sửa chuyển chế độ Expert và flex layout để các form settings thực sự mở/tương tác được.
- Xác minh: `npm test` PASS; `python3 tests/e2e.py` — 52/52 PASS; 7 E2E phụ bị skip do runner thiếu dependency riêng.

### Chế độ Ưu tiên độ chính xác
- Công tắc theo từng truyện, mặc định tắt; khi bật ép Quality Gate PASS, không nhận SOFT_FAIL/Manual Override, bật rào chắn Required Beat và tối đa ba lượt review/sửa.
- Audit beat độc lập yêu cầu mã [R#] có bằng chứng trích nguyên văn; audit lỗi, thiếu mã, sai trích dẫn hoặc fingerprint cũ đều fail-closed và chặn Sync/Publish/Export Canon.
- Rà đoạn văn dài trùng/gần trùng, ưu tiên vá cục bộ có snapshot và kiểm tra lại; không fallback viết lại toàn chương. Retry hậu kỳ cũng bị chặn trước khi có thể ghi MANUAL_OVERRIDE.
- Export backup JSON vẫn được phép để giữ bản nháp; chỉ các luồng xuất bản/Canon bị audit chặn.
- Xác minh Accuracy Mode: helper, policy, export/sync barriers, retry-postprocess regression và `npm test` PASS; UI E2E 52/52 PASS.

## [V14.5.15] — Telemetry chi tiết theo scene và đồng bộ metadata phát hành
- **Telemetry scene:** adaptive pipeline lưu từng scene: số lượt thử/retry, input chars, output words, trạng thái (`accepted`, `patched`, `kept_with_warning`, `rejected`), lỗi rút gọn, số lượt rà AI và thời lượng.
- **Hiển thị:** telemetry được lưu trong `chapter.adaptiveStats.sceneTelemetry` và hiện ngay dưới kế hoạch chương để người dùng biết cảnh nào bị viết lại, vá hoặc giữ kèm cảnh báo.
- **Parity:** `shared/core.js` tiếp tục là nguồn dùng chung; sau `npm run sync`, client và worker dùng cùng logic.
- **Metadata:** sửa `package.json` và README từng còn ghi V14.5.1 trong khi mã/changelog đã ở V14.5.14.

## [V14.5.14] — Mục Outline ghép thành ý con, Kháng cự/Hậu quả vào prompt scene, lọc nhận xét "không lỗi"
- **Mục ghép (>= 3 hành động) = ý con:** `outlineItemParts`; bước kiểm bằng chứng chỉ cho `done` khi đủ TẤT CẢ ý con trong một đoạn liền mạch. Thiếu ý con -> lỗi `THIẾU TRÌNH TỰ BẮT BUỘC` (không thuộc diện vá chèn) nên scene được viết lại liền mạch thay vì chèn rải rác.
- **Prompt scene:** `sceneScopeOf(scenes, i, meta, items)` thêm "KHÁNG CỰ CỦA CHƯƠNG" cho mọi scene có mục, "HẬU QUẢ CẦN THỂ HIỆN" đúng một scene, và "TRÌNH TỰ LIÊN TỤC BẮT BUỘC" cho mục ghép. Trước đây writer không thấy Kháng cự (chỉ prompt lập kế hoạch thấy).
- **Hậu quả trùng mục:** `dedupeOutlineMeta` gỡ mệnh đề của `Hậu quả` đã được một mục nêu, tránh một sự kiện bị yêu cầu hai lần (cảnh lặp ba lần).
- **Auditor:** `isNoopAuditNote` lọc dòng chỉ là nhận xét "không phải lỗi/hợp lý/đúng trình tự" khỏi `warnings`/`hardFailures` trong `evaluateReview` (dòng có từ chỉ lỗi thật được giữ).
- Test mới: `v14_5_14_outline_subparts.test.js`; toàn bộ 95 nhóm PASS, sync-check OK.

## [V14.5.8] — Độ dài chương theo số người dùng nhập (±500) + Quality Gate mặc định TẮT
- **Độ dài:** `chapterWordLimits/adaptiveChapterWordLimits` lấy "Độ dài mục tiêu" làm chuẩn: chấp nhận mục tiêu ±500 từ (5000 → 4500–5500; 4500 → 4000–5000; 3000 → 2500–3500), hardMax = mục tiêu + 600. Không còn kẹt cứng 4500–5500: hợp đồng chương, báo "Thiếu từ x/y", kiểm tra Gate, bù từ đều dùng cùng giới hạn. Chưa nhập → mặc định 5000.
- **Quality Gate (chấm + tự sửa):** mặc định TẮT; truyện cũ được chuyển sang tắt MỘT lần (cờ `qgOffV1458`), sau đó công tắc 🛡 vẫn bật lại được. Tắt Gate: chương được duyệt/ghi Canon ngay, không chấm điểm, không tự sửa.
- Test: cập nhật `v13_adaptive_scene` và `e2e.py` (bật Gate rõ ràng cho nhóm test Gate).

## [V14.5.7] — Outline dán từ Word/Docs không đọc được → chương 9 bị gán beat của chương 3 (nguyên nhân thật)
- Outline có ngắt dòng mềm U+2028 (Shift+Enter) trước "Sự kiện:/Kháng cự:/Hậu quả:/Móc kết:". `.` của JS không khớp U+2028 nên `outlineChapterLines` trả RỖNG: app không thấy chương nào trong Outline, lùi về 900 ký tự đầu của cả Outline (= chương đứng đầu, "Chương 3") và đòi AI/Gate bám theo.
- `outlineNormalizeText` đổi U+2028/U+2029/U+0085/VT/FF thành khoảng trắng (và CRLF→LF) trước khi tách; áp dụng cho `outlineChapterLines` và `outlineChapterItems`. Test: `v14_5_7_outline_soft_linebreak.test.js` (kiểm trên outline thật 21 chương 3–23: trước 0 chương, nay đủ).

## [V14.5.6] — Viết chương 9 nhưng Gate đòi beat của "Chương 3"
- Outline đánh số lại từ 1 trong từng gói (gói áp dụng chương 7–12 viết Ch1…Ch6) làm chương 9 không có dòng nào; code lại lấy 900 ký tự đầu của CẢ outline (= beat chương đứng đầu) thay cho chương này.
- `outlineChapterLines/Items(content, ol)` đổi số cục bộ về số tuyệt đối khi gói có from>1; thiếu dòng của chương thì để trống thay vì lấy 900 ký tự đầu (chỉ lùi về khi outline hoàn toàn không đánh số chương). Test: `v14_5_6_outline_local_numbering.test.js`.

## [V14.5.5] — SCENE_FAILED không rõ nguyên nhân
- Lỗi API khi viết scene nay kèm thông báo thật (`SCENE_FAILED: … (S2: API 400: …)`), trước đây bị nuốt.
- Lỗi API ở một scene được thử lại CHÍNH scene đó (theo `sceneRetries`) thay vì hủy cả job. Test: `v14_5_5_scene_api_error.test.js`.

## [V14.5.4] — SCENE_REJECTED "scene lộ chỉ dẫn/tiêu đề"
- Model lớn hay tự thêm tiêu đề `Scene 2:` / `**Cảnh 2.**` hoặc nhắc tên khối chỉ dẫn (STATE DELTA, STYLE LOCK…). Nay `stripSceneLeaks` gỡ các dòng đó (giữ phần văn xuôi nếu nhãn nằm đầu câu) trước khi kiểm tra, cho cả scene lẫn bù từ; chỉ báo lỗi nếu sau khi gỡ vẫn còn. Test: `v14_5_4_scene_leak.test.js`.

## [V14.5.3] — Model thinking viết scene ngắn/cụt, rà AI trả JSON rỗng
- **Nguyên nhân:** mọi lệnh viết scene / bù từ / rà AI / vá scene gọi với `creative:true` nên KHÔNG bao giờ gửi lệnh tắt thinking (chỉ bước plan có). Model thinking (deepseek-v4.x) dùng chung `max_tokens` cho reasoning → scene 800 từ chỉ ra ~250 từ và dừng giữa câu; rà AI (500 token) hết sạch cho reasoning → "JSON hỏng/rỗng".
- **Sửa (worker `callAI`):** luôn gửi lệnh tắt thinking (`noReasoning`), giữ nguyên lấy mẫu/penalty; endpoint phớt lờ lệnh thì đo reasoning thực tế và cộng "đệm suy nghĩ" (tối đa 4000 token) vào mọi lệnh sau; lệnh ngắn hoặc content rỗng bị reasoning ăn sạch → gọi lại ngay một lần với đệm. Đường gọi lại sau lỗi 400 không còn làm mất frequency/presence penalty.
- Test: `v14_5_3_scene_thinking.test.js`.

## [V14.5.2] — Sửa PLAN_REJECTED với model lớn/thinking (deepseek-v4.x)
- Scene Graph: chấp nhận khóa đặt tên khác (must_change, hand_off, ending_anchor…); thiếu `mustChange`/`handoff`/`endingAnchor`/`chapterGoal` thì tự suy ra từ purpose/beats/scene kế thay vì PLAN_REJECTED.
- Bước plan: ngân sách token 5000 (lượt 1) / 7800 (lượt sửa); `callExtract` leo thang x2 rồi x4 (bậc sau phải lớn hơn bậc trước, trần AI_MAX_OUTPUT_TOKENS); nếu content rỗng mà reasoning đã chứa JSON `"scenes"` thì vớt ra (cả stream và không stream).

## [V14.5.1 — Quality Gate chặn khi chương thiếu ý của Outline]

- **Vấn đề:** điểm `outlineCompliance` của AI chấm chỉ để hiển thị và `outlineDeviation` không đổi verdict, nên chương lệch Outline vẫn được 85–100 điểm.
- **Mới:** `outlineGateCheck` đối chiếu từ khóa (0 token) từng ý của Outline chương với văn bản khi duyệt. Thiếu từ 40% số ý đánh giá được (và có từ 2 ý) → **lỗi nặng** (HARD_FAIL, kích hoạt vòng tự vá để bổ sung đúng các ý thiếu); thiếu ít hơn → chỉ cảnh báo. Thông báo nêu rõ các ý chưa thấy và nhắc có thể duyệt thủ công nếu truyện đã viết bằng câu chữ khác.
- **Áp dụng:** cả Quality Gate chạy trên máy và trên server (worker). Công tắc mới "📋 Chặn khi thiếu ý của Outline" ở phần cài đặt Quality Gate (`state.outlineBeatGate`, mặc định bật).
- **Giới hạn:** đối chiếu bằng từ khóa nên có thể báo thừa hoặc bỏ sót; khác với "Chặn thiếu Required Beat [R]" (dựa trên danh sách beat AI chấm) và vẫn cho Manual Override.
- **Test:** `v14_5_1_outline_gate.test.js`.

## [V14.5.0 — Cách 3: mỗi cảnh gắn với mục Outline, kiểm tra kế hoạch TRƯỚC khi viết]

- **Vấn đề:** AI tự chia cảnh rồi mới đối chiếu Outline sau khi đã viết, nên kế hoạch chia lệch (bỏ mục, dồn mục, lặp cảnh) chỉ bị phát hiện muộn.
- **Tách mục Outline:** `outlineChapterItems` tách "Chương N — Tiêu đề Sự kiện: … " + các dòng gạch đầu dòng thành các MỤC đánh số; Kháng cự/Hậu quả/Móc kết tách thành ghi chú kết quả (Móc kết = endingAnchor). Chỉ áp dụng khi chương có 3–10 mục; chương Outline một dòng/trống chạy như cũ.
- **Kế hoạch phải gắn mục:** prompt lập kế hoạch thêm khối "OUTLINE ĐÁNH SỐ"; mỗi scene khai báo `outlineItems`.
- **App kiểm tra (0 token):** `validateOutlineMapping` — mọi mục đều có đúng một scene, đúng thứ tự, mỗi scene 1–3 mục liền kề, tối đa 1 scene nối không có mục. Sai thì lập lại (kèm lý do "OUTLINE: …").
- **Đường lùi:** sau 2 lượt vẫn sai (chỉ sai ánh xạ), `buildOutlineGraph` dựng cảnh theo từng mục Outline (1 mục = 1 cảnh; >6 mục thì gom) từ chính kế hoạch AI (nhân vật, nơi, giờ), `endingAnchor` = Móc kết. Thẻ chương ghi "kế hoạch cảnh của AI không khớp các mục Outline nên đã dựng cảnh theo từng mục Outline". Tắt bằng `deps.outlineMap=false`.
- **Test:** `v14_5_0_outline_mapping.test.js`.

## [V14.4.4 — Sự kiện chính của Outline phải có và đầy đủ; vẫn được thêm tình tiết]

- **Theo yêu cầu:** thay vì cấm thêm tuyến/nhân vật, quy tắc nay là: MỌI sự kiện chính của Outline phải có mặt và viết ĐẦY ĐỦ trong chính chương đó (không bỏ, không tóm tắt, không dời sang chương sau); yếu tố mới/xung đột nên nằm bên trong hoặc xen kẽ sự kiện Outline; vẫn được thêm chi tiết/tình tiết phụ miễn không chiếm chỗ hay làm thiếu sự kiện chính. Cập nhật prompt lập kế hoạch cảnh và dòng "LƯU Ý ƯU TIÊN" của THREADS/FORESHADOWING.
- **Ép thật sự (không chỉ nhắc):** sau khi viết xong các scene, nếu đối chiếu từ khóa thấy beat của Outline còn thiếu thì chạy tối đa 2 lượt bù RIÊNG cho các beat đó, kể cả khi chương đã đủ số từ (chỉ khi còn chỗ dưới số từ tối đa; bỏ lượt bù nếu đoạn mới lặp lại nội dung đã có). Bật qua `deps.outlineComplete === true` (client và worker đều bật; mặc định tắt trong core).
- **Giới hạn:** đối chiếu bằng từ khóa nên có thể bỏ sót hoặc báo thừa; lượt bù nối vào cuối chương chứ không chèn đúng vị trí.
- **Test:** `v14_4_4_outline_complete.test.js`; cập nhật câu chữ trong `v14_4_2_outline_adherence.test.js`.

## [V14.4.3 — THREADS/FORESHADOWING không còn kéo truyện khỏi Outline]

- **Phát hiện:** khi Gợi ý chương sau để trống và Mệnh lệnh chỉ có quy tắc, truyện vẫn đi sang tuyến điều tra ("ân nhân", Hoàng Minh) không có trong Outline. Ngữ cảnh gửi model còn có THREADS (≤6), FORESHADOWING CHƯA GIẢI (≤8), TIMELINE, KIẾN THỨC nhân vật mà KHÔNG có nhãn ưu tiên nên bị coi là việc phải đẩy tiến ở mỗi chương; các quy tắc chung (yếu tố mới, xung đột, thất bại, bước tiến) cũng khuyến khích thêm tuyến mới.
- **Sửa:** `buildContextBlock` (client + bản mirror worker) thêm dòng "LƯU Ý ƯU TIÊN" trước các khối đó: chỉ là bối cảnh nhất quán, không phải đẩy tiến, không mở tuyến/nhân vật/bí mật/địa điểm mới vì chúng; Outline quyết định việc chính. Prompt lập kế hoạch cảnh thêm: các quy tắc chung chỉ áp dụng BÊN TRONG sự kiện Outline giao.
- **Test:** thêm 2 kiểm tra vào `v14_4_2_outline_adherence.test.js`.

## [V14.4.2 — Truyện bám Outline hơn: Outline đứng cuối prompt + đối chiếu beat]

- **Nguyên nhân truyện lệch Outline (ví dụ chương 6):** (1) trước V14.4.1 các dòng gạch đầu dòng của chương không vào prompt; (2) trong prompt lập kế hoạch scene, Outline nằm GIỮA, còn "Gợi ý chương sau" của AI (mang nhãn "Gợi ý người dùng", tới 6000 ký tự) và đoạn gần nhất đứng SAU nên lấn át; (3) AI duyệt chấm `outlineCompliance` cao dù truyện lệch.
- **Sửa prompt kế hoạch:** thứ tự mới = hợp đồng → bối cảnh → đoạn gần nhất → mệnh lệnh → gợi ý chương sau (nhãn "THAM KHẢO — THẤP HƠN Outline", cắt 2500 ký tự) → quy tắc ưu tiên khi mâu thuẫn → ARC/OUTLINE LOCK → REQUIRED BEAT CHECKLIST ở CUỐI.
- **Đối chiếu beat (0 token):** `outlineMissingBeats` tách Outline chương thành các beat (Sự kiện/Kháng cự/Hậu quả/Móc kết, dấu `;`, `+`, câu), so từ khóa có dấu với văn bản cuối (bỏ tên nhân vật); beat phủ dưới 40% được liệt kê trên thẻ chương: "⚠ Outline: chưa thấy trong truyện: «…»". Chỉ cảnh báo, không chặn. `deps.outlineCheck=false` để tắt.
- **Test:** `v14_4_2_outline_adherence.test.js`.

## [V14.4.1 — Outline nhiều dòng: gạch đầu dòng thuộc về chương]

- **Lỗi:** `outlineChapterLines` chỉ lấy đúng DÒNG có số chương. Với Outline dạng "Chương 3 — Tiêu đề Sự kiện: …" rồi các dòng "• …" bên dưới (kèm Kháng cự/Hậu quả/Móc kết), prompt chỉ nhận dòng tiêu đề; mọi gạch đầu dòng (cảnh chính, kháng cự, hậu quả, móc kết) KHÔNG vào prompt, hợp đồng chương hay chấm AI.
- **Sửa:** các dòng bắt đầu bằng •, -, *, –, ·… nằm ngay dưới tiêu đề chương được nối vào khối của chương đó (ngăn bằng `;` nếu câu trước chưa kết). Dòng không có gạch đầu dòng và dòng mồ côi trước chương đầu vẫn bị bỏ qua; định dạng một dòng cũ ("Ch3: …") giữ nguyên.
- Prompt tiến độ Outline cho chương hiện tại nâng giới hạn 500 → 900 ký tự để không cắt mất phần gạch đầu dòng.
- **Test:** `v14_4_1_outline_multiline.test.js`.

## [V14.4.0 — Kiểm tra Outline trước khi viết]

- **Vấn đề:** Outline có quá nhiều chi tiết ép buộc (số lần, thứ tự, câu thoại nguyên văn, nhiều mục nhỏ) biến thành nhiều beat `[R]` mà model hay làm thiếu một chỗ, dẫn tới Hard failure/lặp cảnh khi duyệt; Outline quá dài còn bị cắt khi đưa vào hợp đồng chương.
- **Mới:** `lintChapterOutline` (thuần cấu trúc, không đánh giá nội dung) đo độ dài, số mục nhỏ (Sự kiện/Hậu quả/Móc kết…), câu thoại bắt buộc, ràng buộc số lần/thứ tự, chuỗi bước nối tiếp, tổng số ý. Mức: ok / warn / high.
- **Trong app:** trước khi viết chương (✦ Tạo Chương Hoàn Chỉnh, ☁ viết nháp nền, ↻ viết lại): mức `high` hiện hộp thoại "Vẫn viết / Sửa Outline" kèm gợi ý; mức `warn` chỉ nhắc ở dòng trạng thái; chương đã chọn "Vẫn viết" không bị hỏi lại cho tới khi Outline đổi. Nút mới **🔎 Kiểm tra Outline** ở phần Outline liệt kê các chương chưa viết cần gọn lại.
- **Test:** `v14_4_0_outline_lint.test.js`. Bước kiểm tra bị bỏ qua trong môi trường test E2E (`__XTA_TEST__`).

## [V14.3.8 — Dọn các cảnh báo lặp lại qua nhiều chương]

Rà 7 chương đầu (ảnh chụp thẻ chương) thấy 5 nhóm cảnh báo lặp lại; sửa từ gốc:
- **"scene kết thúc giữa câu"** (thật sự bị cắt vì hết token, câu cụt nằm giữa chương): scene nay được lùi về câu hoàn chỉnh gần nhất ngay khi nhận (chỉ cắt phần dở ≤ 60 từ). Thẻ ghi "đã bỏ câu dở cuối scene: S2".
- **HANDOFF "scene sau ở tầng hầm buổi tối nhưng scene này kết ở hành lang buổi sáng":** gốc là scene sau không mở bằng câu chuyển cảnh. Prompt scene nay có khối CẦU NỐI BẮT BUỘC khi khác địa điểm/thời điểm so với scene trước (`deps.sceneBridge=false` để tắt); rà AI không còn báo HANDOFF chỉ vì khác nơi/giờ; các HANDOFF còn lại gộp một dòng "gợi ý nối scene (HANDOFF, không phải lỗi): S2, S3".
- **"Từ lạ cần kiểm tra: mini, notebook, micro, router, switch, robot, analog, decibel, drap, vest":** từ vay mượn thông dụng, không còn bị báo. Chữ rò thật (crazy, second, hand, runtime...) vẫn được báo.
- **Bù từ lặp lại ở mọi chương (3.868–4.441 từ thô so với tối thiểu 4.500):** model viết scene chỉ ~75–90% ngân sách. Prompt các scene sau nâng mục tiêu theo tỉ lệ đạt được của các scene trước (tối đa ×1,35; kiểm tra vẫn dùng mục tiêu gốc; `deps.sceneTargetBoost=false` để tắt) để bớt phải nối thêm sau câu kết.
- **Test:** `v14_3_8_scene_hygiene.test.js`.

## [V14.3.7 — Rà scene bớt khắt khe, vá trước rồi mới viết lại]

- **Vấn đề:** AI rà scene hay tự nghĩ thêm yêu cầu ngoài kế hoạch (vd đòi "yêu cầu kiểm tra / đe dọa kỷ luật" khi mustChange chỉ nói nghi ngờ tăng lên), kéo theo vòng viết lại → vá → rà lại → vẫn báo, mất 5–6 lời gọi/scene và cuối cùng chỉ "GIỮ BẢN CUỐI".
- **Prompt rà scene:** MUST_CHANGE chỉ báo khi thay đổi cốt lõi HOÀN TOÀN vắng; thực hiện một phần hoặc bằng hành động khác vẫn là ĐẠT; cấm đòi hành động/kết quả cụ thể mà mustChange không nêu; ví dụ AI hình dung không phải yêu cầu.
- **Vá trước:** lỗi chỉ do AI rà và vá-được (MUST_CHANGE/LOCATION_TIME) → vá cục bộ ngay (1 lời gọi, chèn ≤ 320 từ) thay vì viết lại cả scene. Tắt bằng `deps.scenePatchFirst = false` (quay về luồng cũ).
- **Cảnh báo dài hơn:** cắt ở 360–480 ký tự thay vì 220–300 để không bị cụt giữa câu.
- **Test:** `v14_3_7_patch_first.test.js`; hai test cũ (`v14_3_scene_local_patch`, `v14_0_16_scene_check_quickfix`) đặt `scenePatchFirst:false` vì chúng kiểm tra luồng viết-lại-rồi-vá.

## [V14.3.6 — Gợi ý/hướng sửa của AI duyệt không được đi lệch Outline]

- **Vấn đề:** prompt duyệt chỉ yêu cầu so bản thảo với Outline, còn phần "Hướng sửa"/gợi ý do AI tự đề xuất không bị ràng buộc bám Outline (vd khuyên xoá cảnh lặp rồi "thay bằng cảnh phụ đời thường"). Prompt tự sửa/vá lại coi "HƯỚNG SỬA ƯU TIÊN" là ưu tiên cao nhất nên có thể kéo chương lệch khỏi Outline.
- **Prompt duyệt:** hướng sửa PHẢI bám Chapter Contract/Outline: không đề xuất xoá/thay/làm nhẹ beat [R], không thêm cảnh ngoài Outline; có đoạn lặp thì giữ một bản đầy đủ nhất và bổ sung phần Outline còn thiếu; mỗi hướng sửa ghi rõ phục vụ [R#] nào.
- **Prompt viết lại và vá cục bộ:** thêm "OUTLINE/CONTRACT luôn thắng HƯỚNG SỬA"; nhãn hướng sửa ghi rõ chỉ áp dụng phần không mâu thuẫn Outline.
- **Test:** `v14_3_6_review_outline_priority.test.js`.

## [V14.3.6 — Gợi ý chương sau bám Chapter Outline]

- **Vấn đề:** `generateNextChapterHint` không nhận dàn ý chương sau một cách tường minh (chỉ lọt trong khối ngữ cảnh, bị cắt khi > 7000 ký tự) và bảng ưu tiên không có dàn ý, nên gợi ý hay lệch Outline.
- **Sửa:** đưa dàn ý/việc bắt buộc của chương N+1 (`arcProgressPrompt`) vào prompt gợi ý như nguồn chuẩn, thêm bậc ưu tiên (0). Ý tưởng người dùng vẫn cao hơn.
- Khi viết chương, thứ tự ưu tiên vẫn: canon > mệnh lệnh người dùng > dòng Outline đúng chương > gợi ý đã xác minh > đề xuất AI (Outline luôn thắng gợi ý).
- **Test:** `v14_3_6_hint_outline.test.js`.

## [V14.3.5 — Chữ "de" (pinyin 的) và "then" rò vào truyện được bắt và sửa]

- **Nguyên nhân:** model (nhất là model gốc Trung) rò chữ pinyin "de" (的/得/地, nghĩa "của/mà/một cách") vào câu tiếng Việt, và "then" (tiếng Anh "rồi/sau đó"). Nút Chuẩn hóa chỉ xóa chữ Hán thật (汉字) nên không thấy "de"; `findStrayWords` bỏ qua mọi từ < 4 chữ cái; "then" là âm tiết Việt hợp lệ ("then cài") nên bị coi là đúng.
- **Tự sửa chắc chắn:** `fixPinyinDe` đổi "de" thành "của" khi đứng trước từ xác định/đại từ/tên riêng ("de một tiểu thư", "de nàng thư ký", "de Bùi Lạc"); giữ nguyên tên nước ngoài như "Charles de Gaulle". Chạy trong `sanitizeChapterText` (nút Chuẩn hóa và mọi bước viết).
- **Phần còn lại báo cho bước sửa AI:** `findStrayWords` nay báo "de" (khi đứng trước động/tính từ — cần AI chọn "mà/để/một cách…") và "then" rò rỉ.
- **Test:** `v14_3_5_pinyin_de.test.js`; sửa 3 test E2E (`e2e.py`, `e2e_bg.py`, `e2e_bg_slim.py`) để giải nén gzip khi đọc request create-job của V14.3.4 (E2E trong Chromium thật cũng xác nhận đường gửi XHR + gzip chạy đúng).

## [V14.3.4 — create-job: chẩn đoán tiến độ upload, nén gzip, Blobs có timeout]

- **Bối cảnh:** payload giảm 1,16MB → 574KB mà create-job vẫn "không phản hồi sau 90 giây" nên nguyên nhân không phải dung lượng thuần túy. Nghi ngờ đường upload mạng di động hoặc ghi Blobs treo; app chưa phân biệt được hai trường hợp.
- **Client:** gửi bằng XHR để đo tiến độ upload (fetch không đo được). Thông báo lỗi nay nói rõ: "tải lên KẸT ở x%" (lỗi mạng máy/iPhone, chưa tới hàm) hay "ĐÃ tải xong 100% nhưng server không trả lời" (lỗi hàm/Blobs). Kẹt 30 giây không tiến thêm thì dừng sớm. Body được nén gzip khi trình duyệt hỗ trợ (`CompressionStream`), tự quay về JSON thường nếu không.
- **Server `create-job`:** giải nén gzip (header `X-Body-Encoding: gzip`); ghi log `[create-job] received` ngay khi nhận request (có/không dòng này trong Netlify Logs cho biết request có tới hàm hay không); ghi Netlify Blobs tối đa 6 giây, quá hạn trả 504 kèm timings thay vì treo.
- **Test:** `v14_3_4_create_job_gzip.test.js`.

## [V14.3.3 — Scene quá ngắn viết lại tại chỗ; rà AI không đòi nội dung scene khác; top-up không lặp outline]

- **Scene quá ngắn:** scene dưới 60% ngân sách từ (vd S2 923/1950) nay được viết lại ngay (mềm: lượt cuối vẫn nhận, không hủy job) thay vì để bước bù từ nối thêm ~2.000 từ SAU câu kết chương — cách đó làm các chi tiết cảnh chính dồn xuống cuối chương, sai thứ tự. Tắt bằng `deps.sceneShortRetry = false`.
- **Rà AI scene:** `buildSceneReviewPrompt` không còn đưa `mustChange` cả chương (toàn bộ outline) cho từng scene — trước đó S3 bị báo "thiếu lời thoại bắt buộc" của S2 và phải viết lại + vá.
- **Top-up (bù từ):** không đưa lại requiredBeats/outline cả chương; thay bằng danh sách sự kiện đã kể đủ (không kể lại), chỉ mở rộng phản ứng/nội tâm/hậu quả.
- **Prompt scene:** mỗi mục checklist có gợi ý số từ (≈ ngân sách/số beat), "dành cho scene sau" cho phép gợi sang bằng 1–2 câu cuối theo handoff.
- **Test:** `v14_3_3_scene_length.test.js`.

## [V14.3.2 — Viết nháp: scene không còn kể lại sự kiện của scene khác]

- **Nguyên nhân:** prompt của MỌI scene chứa cả outline chương 3 lần (REQUIRED CHECKLIST, `chapterOutline`/`requiredBeats`/`mustChange` trong CONTRACT COMPACT) + đuôi scene trước, nên model kể lại cả chuỗi sự kiện ở từng scene; bước dọn lặp chỉ bắt lặp gần nguyên văn.
- **Sửa prompt:** mỗi scene chỉ nhận checklist riêng (mustChange + beats), danh sách "ĐÃ KỂ XONG ở scene trước — không kể lại" và "dành cho scene sau — không kể ở đây". Contract trong prompt scene bỏ outline/requiredBeats/mustChange. Tắt bằng `deps.sceneScope = false`.
- **Kiểm tra lặp diễn đạt:** `sceneParaphraseOverlap` so từ đặc trưng từng đoạn; ≥3 đoạn (≥30%) kể lại scene trước → viết lại kèm lý do. Hết lượt thì giữ bản cuối + cảnh báo (không hủy job). Tắt bằng `deps.sceneOverlapCheck = false`.
- **Test:** `v14_3_2_scene_scope.test.js`.

## [V14.3.1 — create-job nhẹ hơn + nút Chuẩn hóa không cắt cụt chương]

- **Viết nháp / hậu kỳ nền:** không còn gửi `storyMetaData` (bản sao dẫn xuất của state, ~416KB) và `chapterDrafts` (~146KB) lên `create-job` — worker không đọc hai khóa này (đã kiểm tra, 0 tham chiếu). Payload ~1,16MB giảm còn khoảng 0,6MB.
- **Nút ¶ Chuẩn hóa:** `dedupeRepeatedScene` cắt từ chỗ lặp đầu tiên trở đi nên chương ~5.000 từ có thể còn ~1.500 từ. Nay chỉ cắt khi mất ≤ 20% số từ; nếu hơn thì chỉ bỏ riêng các đoạn trùng lẻ (và không động vào nếu vẫn mất > 20%), kèm thông báo.

## [V14.3.0 — Rà AI scene: vá cục bộ + hiển thị đủ cảnh báo]

- **Vá cục bộ:** scene hết lượt viết lại mà AI rà vẫn báo `MUST_CHANGE` / `LOCATION_TIME` → thay vì chỉ giữ bản cuối, chạy 1 lượt vá CHÈN vài câu (tối đa 3 chỗ, +320 từ, không đụng đoạn kết) rồi rà lại một lần. Qua rà → nhận (`ĐÃ VÁ CỤC BỘ`); AI vẫn chê → giữ bản đã vá + cảnh báo; vá hỏng → giữ bản cuối như V14.2.4. `NEW_THREAD`/`CAST` không vá chèn. Tắt bằng `deps.sceneAiPatch = false`.
- **Hiển thị:** scene "GIỮ dù AI rà báo" và "ĐÃ VÁ" luôn hiện đủ ở dòng trạng thái (không bị cắt ở 4), cảnh báo thường báo rõ số bị ẩn; giới hạn lưu 10 → 40. Thêm `stats.sceneKept`, `stats.scenePatched`.
- **Khôi phục thay vì hủy job:** nếu lượt viết lại làm scene HỎNG kiểm tra cứng (vd lẫn nhân vật ngoài cast) trong khi bản trước chỉ bị AI rà chê → dùng lại bản trước (kèm cảnh báo) thay vì `SCENE_REJECTED` cả job.
- **Rà AI không còn "im lặng":** phản hồi rà AI không đọc được (JSON hỏng/rỗng) hoặc `ok:false` không nêu lý do nay ghi cảnh báo, không còn coi như đạt mà không báo.
- **Đường viết thường (client):** trước đây bỏ qua toàn bộ `stats` của pipeline scene; nay dòng trạng thái hiện `📝 scene giữ dù AI rà báo lỗi: S2 … · đã vá cục bộ: S3 …`.
- **Test:** `v14_3_scene_local_patch.test.js`, đã thêm vào `run-all.js`; đăng ký thêm 2 test mồ côi (`v12.31.2`, `v12.32.1`) và sửa `v12.31.2` theo hằng số `AI_MAX_OUTPUT_TOKENS`.
- **Metadata:** `package.json` / README lên 14.3.0 (trước đó vẫn ghi 14.0.20 dù CHANGELOG đã tới V14.2.4).

## [V14.2.4 — Viết nháp: không hủy job vì rà AI scene quá chi tiết]

- **Lỗi:** `SCENE_REJECTED S3 … MUST_CHANGE: thiếu chi tiết …` — sau 2 lượt viết, scene chỉ bị bước rà AI từ chối (kiểm tra cứng cục bộ đã qua) nhưng cả job nháp bị hủy, mất các scene đã viết.
- **Sửa:** scene hết lượt viết lại mà chỉ bị rà AI → giữ bản viết cuối (≥80 từ) và ghi cảnh báo `GIỮ BẢN CUỐI dù AI rà báo: …` trong cảnh báo scene. Lỗi cứng cục bộ (quá ngắn, lặp, nhân vật ngoài cast, ngoại ngữ) vẫn từ chối như cũ.
- **Test:** thêm ca vào `v14_0_16_scene_check_quickfix.test.js`.

## [V14.2.2 — Viết nháp nền: create-job không phản hồi]

- Nút ☁ Viết nháp nền dùng cùng cách gửi như hậu kỳ: đo byte, rút gọn văn bản chương cũ từ 1,5MB (giữ 3 chương cuối), chờ 90 giây, báo dung lượng + phần nặng nhất khi lỗi (bản V14.1.9/10 chỉ sửa đường hậu kỳ).

## [V14.2 — Phong cách chậm–sâu: quy tắc mặc định + Quality Gate]

- **Quy tắc nâng cao mặc định (truyện MỚI):** nhịp 1–2 sự kiện trục/chương, cấu trúc 4 phần cho chương 18+, cảnh nóng chậm–dày–có mục đích (chống liệt kê hành động), nhân vật bị thống trị, quyền lực, leo thang không lặp, móc kết. Truyện cũ giữ ô 2.5 đã lưu (dán tay khối mới nếu muốn).
- **Story Control mặc định mới:** `maxMainEvents` 2 (truyện cũ giữ 3).
- **Quality Gate:** cách đếm sự kiện (dẫn dắt + cao trào + hậu quả = một sự kiện; ít sự kiện nhưng sâu không bị trừ pacing/stagnation/arcStall); thêm cảnh báo MỀM `listLikeProse` (văn liệt kê hành động) và `weakHook` (kết chương không có móc); nhắc hạ điểm khi lặp chương trước. Không chặn Sync.

## [V14.1.10 — create-job không phản hồi sau 45 giây]

- Rút gọn văn bản chương cũ ngay từ 1,5MB (trước 3,5MB) để upload nhanh hơn trên mạng di động.
- Client chờ create-job 90 giây (trước 45); khi hết giờ báo dung lượng đã gửi + 4 phần nặng nhất.
- create-job: dọn job cũ tối đa 1,5 giây/10 job (trước: tuần tự tới 50 lần xóa), chờ kích hoạt worker 4 giây (trước 8) — để hàm đồng bộ Netlify (mặc định 10 giây) kịp trả lời.

## [V14.1.9 — "Không gửi được hậu kỳ server: Load failed"]

- **Nguyên nhân khả dĩ:** kiểm tra kích thước đếm KÝ TỰ (≤5.000.000) nhưng Netlify giới hạn ~6MB BYTE; tiếng Việt UTF-8 ~2 byte/ký tự nên truyện dài vượt giới hạn mà không bị chặn, Safari chỉ báo "Load failed".
- **Sửa:** đo byte thật; quá 3,5MB thì rút gọn văn bản chương cũ (giữ chương hậu kỳ + 2 chương trước), văn bản đầy đủ được khôi phục từ bản local khi hợp nhất; quá 5,5MB báo rõ. Lỗi mạng nay kèm dung lượng đã gửi; HTTP 413 có thông báo riêng.

## [V14.1.8 — Hậu kỳ: cứu JSON bị ngắt, chạy nhóm song song]

- **Nguyên nhân:** gateway đóng stream giữa chừng (`finish=?`, JSON dừng ở 6–12 nghìn ký tự, không phải do token) và các lần gọi chạy tuần tự nên hết 15 phút ("không thử lại do sắp hết thời gian").
- **Cứu JSON bị ngắt:** phần hoàn chỉnh được giữ (vẫn qua kiểm tra evidence); khóa không có trong bản cứu được coi là chưa làm và được gọi lại riêng.
- **Song song:** các nhóm core / NV / Thế giới+Status và các lần thử lại chạy đồng thời.
- **Bấm thử lại sau PARTIAL/FAILED:** bỏ lần gọi gộp (luôn hỏng với chương dài), chạy thẳng các nhóm nhỏ.

## [V14.1.7 — Sửa hậu kỳ "chỉ cập nhật một phần" (Thế giới, Status)]

- **Lý do lỗi bị cắt mất:** thông báo chỉ lấy 4 ghi chú đầu nên lần thử lại của world/status không bao giờ hiện, và ghi chú "thành công" chiếm chỗ. Nay bỏ ghi chú thành công, hiện tới 8 lỗi (≤1400 ký tự).
- **Chẩn đoán:** JSON hỏng kèm đuôi phản hồi (90 ký tự cuối) và cảnh báo khi `finish=?` (stream bị ngắt không có finish_reason).
- **Đọc được thêm:** loại khối `<think>…</think>`; gộp nhiều object JSON rời nhau (`{"world":…}{"status":…}`).
- **Nhóm NV:** lần đầu 8 nhân vật (trước 12, hầu như luôn bị cắt), thử lại 4 (trước 5) — đỡ tốn một lần gọi.
- **Test:** thêm ca 8 vào `v12_30_unified_postprocess.test.js`.

## [V14.1.6 — Tự chèn câu chuyển cảnh + gợi ý hành động]

- **Tự chèn câu chuyển cảnh:** bản nháp nền chỉ có cảnh báo thiếu chuyển cảnh (SOFT_FAIL) nay vẫn được tự sửa, bằng vá cục bộ CHỈ CHÈN 1–2 câu cầu nối (`insert_after/insert_before`, không replace/delete, không viết lại chương). Bản vá được giữ nếu ít chỗ thiếu chuyển cảnh hơn dù điểm bằng nhau (`reviewIsBetter`), nếu không thì khôi phục bản cũ.
- **Dòng trạng thái bản nháp:** hiện nội dung tối đa 2 lỗi nặng + hành động nên làm (`reviewActionAdvice`): chạy hậu kỳ / đọc lướt cảnh báo / 🔍 Duyệt lại / rút bớt sự kiện-nhân vật / ↻ Viết lại.
- **Test:** `v14_1_6_transition_fix_advice.test.js`.

## [V14.1.5 — Thiếu chuyển cảnh không còn là lỗi nặng]

- **Chương bị "LỖI NẶNG" dù 85/100:** Auditor ghi một lỗi chuyển cảnh hai lần (dòng `sceneViolation:` trong hardFailures + cờ `sceneViolation`) nên bị đếm 2 lỗi nặng. `evaluateReview` nay gộp thành một.
- **Chỉ thiếu câu chuyển cảnh** (nhảy địa điểm/thời gian, không ai nói/làm khi vắng mặt) nay là cảnh báo; người đã rời đi/không có mặt mà vẫn nói/làm vẫn là lỗi nặng.
- **Prompt:** Auditor được dặn không xếp thiếu chuyển cảnh vào hardFailures; prompt viết chương yêu cầu 1–2 câu cầu nối mỗi lần đổi địa điểm/thời gian.
- **Test:** `v14_1_5_scene_transition.test.js`.

## [V14.1.1 — Sửa hậu kỳ bị chặn / chỉ cập nhật một phần]

- **Hậu kỳ chỉ cập nhật một phần:** prompt hậu kỳ yêu cầu model bỏ hẳn khóa/mảng rỗng, nhưng worker bắt buộc đủ `world.locations/items/threads`, `memory.events/foreshadowing/knowledge`, `continuityWarnings`, `status.changes` → Thế giới/Memory/Continuity bị báo lỗi và dữ liệu hợp lệ bị bỏ (PARTIAL). Nay khóa thiếu (null/undefined) trong lần gọi AI đã thành công được coi là rỗng, phần hợp lệ vẫn được ghi. Kiểu sai (chuỗi/số) vẫn bị từ chối; nhóm gọi AI thất bại (JSON bị cắt/hỏng) vẫn báo lỗi thật.
- **Hậu kỳ bị chặn trên chương Bản nháp:** nút ☁ Chạy hậu kỳ server gửi chương `DRAFTED` nên rào chắn Canon (V14.0.19) chặn toàn bộ. Nay nút tự duyệt chương (APPROVED, `MANUAL_OVERRIDE`) trước khi gửi; chương `REVISION_REQUIRED/REJECTED/FAILED` hỏi xác nhận trước. Rào chắn ở worker giữ nguyên.
- **Hậu kỳ lỗi NV + Thế giới + Status (JSON bị cắt):** schema nhân vật liệt kê >100 khóa rỗng (tăng mạnh từ V14.1) nên model chép nguyên khung, mỗi nhân vật ~600 token và vượt giới hạn ~7800 token. Schema nay là khung gọn + danh sách trường hợp lệ (`UNIFIED_CHAR_FIELDS`). Nhóm bị cắt/hỏng được thử lại một lần với phạm vi nhỏ hơn (NV: tối đa 5 nhân vật; Thế giới và Status gọi riêng). Thông báo PARTIAL nay kèm lý do thật ("— lý do: nhóm characters: vẫn bị cắt…").
- **Chẩn đoán hậu kỳ:** mỗi lần gọi AI hỏng nay ghi `finish`, số ký tự, độ dài reasoning và lý do bị ngắt (timeout) vào thông báo, để phân biệt cắt token / model thinking ăn token / timeout; có gợi ý đổi model bước Hậu kỳ khi nghi model thinking.
- **Tắt thinking cho lệnh JSON trên endpoint không phải OpenRouter (AnonRouter):** DeepSeek V4 (v4-flash) bật thinking mặc định và reasoning dùng chung `max_tokens` nên JSON hậu kỳ bị cắt. Lệnh trích xuất/JSON nay gửi `thinking:{type:"disabled"}`; gateway trả HTTP 400 thì gọi lại không kèm tham số. Viết văn không đổi. Test `v14_1_4_thinking_off.test.js`.
- **Test:** cập nhật `v12_30_unified_postprocess.test.js` (+3 ca), thêm `v14_1_1_postprocess_approve.test.js`.

## [V14.1 — Hệ thống tu luyện (tu tiên / huyền huyễn / võ hiệp)]

- **Hồ sơ nhân vật:** thêm cảnh giới (kèm tiểu tầng đệ nhất → đệ cửu trọng), cảnh giới cao nhất từng đạt (tự cập nhật), linh căn/thể chất, tư chất, thuộc tính, công pháp chính, thần thông/chiêu thức, sức chiến đấu, bản mệnh pháp bảo, túi trữ vật, linh thạch, tuổi ngoại hình, thọ nguyên, sư môn/bối phận, đạo hiệu (`aliases`), cơ duyên, ân oán, bí mật thân thế, tâm ma, nghiệp lực. Dùng chung cho nhân vật chính và nhân vật phụ.
- **Nhân vật chính ngang nhân vật phụ:** thêm chức vị, thế lực, điểm yếu, nỗi sợ, điều biết. Form lưu giữ các khóa không có trên form (không còn bị xóa khi lưu).
- **Story Bible:** ô "Hệ Thống Tu Luyện" + thang đại cảnh giới (mặc định Luyện Khí → Trúc Cơ → Kết Đan → Nguyên Anh) + nút nạp mẫu. Khối canon này vào prompt viết chương (client và worker); cảnh giới cao hơn thang chỉ là lời đồn, không được đặt tên.
- **Khóa đột phá:** đổi cảnh giới chỉ được ghi khi AI báo `explicitCoreChange` + `changeEvidence` trích từ chương; bác cảnh giới ngoài thang và nhảy từ 2 đại cảnh giới. Công pháp chính/pháp bảo/thọ nguyên đổi theo cùng cơ chế; thần thông, cơ duyên, ân oán cộng dồn. Áp dụng cho cả client (`mergeCharacterUpdate`) và worker (`mergeCharacter`); Character State Tracker lấy cảnh giới từ hồ sơ.
- **Hồ sơ khóa:** cảnh giới, công pháp, thần thông, pháp bảo, sư môn, tuổi ngoại hình, thọ nguyên, tên khác vào `characterLockPrompt` kèm luật "không tự nâng/hạ cảnh giới, vượt một đại cảnh giới phải có bù đắp".
- **Vật phẩm:** thêm loại, phẩm cấp, công dụng, đã nhận chủ; AI trích xuất điền khi còn trống.
- **Nhãn theo thể loại:** thể loại tu tiên/huyền huyễn/võ hiệp đổi nhãn Nghề→Thân phận, Vị trí→Chức vị/bối phận, Phe→Tông môn/thế lực, Tuổi→Tuổi thực.
- **Rào chắn tuổi:** `parseAgeNum` ưu tiên số đứng trước "tuổi"; rào chắn 18+ lấy số nhỏ nhất giữa tuổi và tuổi ngoại hình.
- **Test:** `v14_1_cultivation.test.js`, `e2e_v14_1_cultivation.py`.

## [V14.0.20] — Vietnamese Novel Writing

- **Vietnamese-native prose contract:** added one shared prompt block for normal writing, background writing and adaptive scenes.
- **Natural language:** instructs the model to avoid literal translation, preserve Vietnamese word order/collocations, vary sentence rhythm and avoid repeated sentence openings.
- **Dialogue and POV:** locks point of view, tense, forms of address, social position, character knowledge and individual voice; requires purposeful dialogue and separate speaker paragraphs.
- **Mobile readability:** requires short-to-medium paragraphs at action/voice/beat changes and bans AI metadata, scene labels, recap padding and explanatory notes from prose output.
- **Regression coverage:** worker mirror tests now verify the shared Vietnamese prose, POV and dialogue-layout rules reach the background writing prompt.
- **Documentation alignment:** current version metadata, README overview, deployment/security references, implementation plan and historical-document banners were aligned to V14.0.20.
- **Verification:** installed Playwright/Chromium and brought all five E2E suites to PASS; the delete-chapter E2E now asserts V14.0.18 snapshot invalidation instead of reading a deliberately cleared future snapshot.
- **Post-audit fixes:** `netlify.toml` now blocks `/TODO.md`, `/plan.md`, `/PROMPT_OPTIMIZER_AUDIT.md`, `/VALIDATION_V1233.md` and `/.pre-p0-p1-p2-backup.txt`; the site-wide `Access-Control-Allow-Origin: *` header was removed and the background worker now honours `ALLOWED_ORIGIN` like the other functions; `TODO.md` E2E status and the `DEPLOY.md` `.github` note were corrected; hygiene test extended to cover all of this.
- **Character suggestions:** the "Gợi ý nhân vật chưa có trong Database" box listed technique and realm names (e.g. "Huyền Nguyên Quyết", "Luyện Khí") because it only looked for repeated capitalised phrases. In cultivation/xianxia stories (detected from the genre or from ≥4 cue words such as tu luyện, linh khí, cảnh giới) it now skips known realm names, technique/concept heads and 3+ word names ending in Quyết/Công/Pháp/Kinh/Thuật/… unless they start with a common surname. Other genres are unaffected. Added a "🎒 Vật phẩm/Công pháp" button to file such a suggestion as an item.
- **Outline AI 18+:** the "🤖 AI đề xuất" button of 0.6 Chapter Outline ignored the story's mature settings, so it always proposed ordinary outlines. It now reads `mature` + `chapterMatureFocus` (SECONDARY ≈ 2–3 of 10 chapters, PRIMARY ≈ 4–6 of 10 carry a "cảnh nóng" beat that also triggers NSFW model routing), includes the age guard, rejects results where an adult beat involves an under-18 character, and reports in the status line when the outline is ordinary because 18+ is off or the focus is NONE. Outline text stays plan-level (no explicit detail). Age rule: a character with no age in the Character Database counts as an adult (also in the base system prompt); only an explicit age under 18, or a description as a child/student, blocks adult content (the 18+ hint under section 4 now says so instead of warning). New `shared/core.js` helpers `outlineMaturePrompt` / `outlineAdultViolations` + test `v14_0_20_outline_mature.test.js`.

## [V14.0.19] — Character Canon Manager

- **Accepted-only Character Database updates:** unified server postprocess and manual character rescans refuse to commit Character/Memory canon when the source chapter is explicitly draft, rejected, failed, running or revision-required.
- **Canon Sync barrier:** a blocked draft postprocess cannot reach `applyCanonSync`; accepted chapters retain the existing soft-failure behavior when an extraction API fails.
- **Identity protection retained:** stable name/aliases, core identity, role, occupation, position, relationships and locked profile fields remain protected by evidence/explicit-change rules; new major-character proposals stay demoted to supporting until user promotion.
- **Regression coverage:** draft postprocess makes no API call and does not mutate Character Database; existing V14.0.14 evidence and merge tests remain passing.

## [V14.0.18] — Chapter Memory / Accepted Canon Safety

- **Accepted-canon precedence:** recent continuity, story history and adaptive scene planning prefer accepted/synced chapters over draft or soft-fail chapters; legacy chapters without a status remain compatible.
- **Deletion invalidation:** deleting a chapter invalidates exact-target hints, remaps later hint/status/memory chapter references, and clears future snapshots derived from the deleted chapter so they cannot resurrect stale canon.
- **Memory regression tests:** added coverage for draft exclusion, accepted-ending selection, exact dependency invalidation and chapter-number remapping.

## [V14.0.17] — Canon-safe Prompt Optimizer

- **Hint provenance:** `nextChapterHint` now carries target chapter, version, status, timestamp and source. Hints without valid metadata, wrong target chapter, or inactive status are excluded from the active prompt and reported as unverified.
- **Canon/Conflict policy:** the planner now treats synced canon and locked profiles as immutable. A directive that requests a retcon must be marked `CONFLICT` and requires explicit confirmation instead of silently overriding canon.
- **Dynamic character budget:** planner and main-write prompts use `storyControl.maxNamedCharacters` instead of a hard-coded limit of 4; client and worker remain aligned.
- **Active-record filtering:** deleted/invalidated chapters are excluded from recent continuity, story history and adaptive scene generation.
- **Tests:** updated prompt-context regression coverage for verified/unverified hints; all logic tests pass. E2E suites remain skipped when Playwright/Python are unavailable.

## [V14.0.16] — Kiểm tra từng scene + tự sửa sau chấm nhanh

- **🔎 Kiểm tra từng scene (client + worker dùng chung `runAdaptiveChapterPipeline`):** ngay sau khi viết xong MỘT scene, code kiểm tra (0 token): nhân vật ngoài allowed cast, scene quá ngắn (< 80 từ), lộ chỉ dẫn/tiêu đề ("Scene 2:", CONTRACT, STATE DELTA…). Lỗi nặng → viết lại ĐÚNG scene đó (tối đa 1 lần, kèm danh sách lỗi cần sửa, nhiệt độ thấp hơn), scene sai không bao giờ được ghép vào chương. Vẫn lỗi sau khi viết lại → `SCENE_REJECTED (sau 2 lượt viết)` như cũ (dừng an toàn). Hết thời gian job thì không viết lại.
- **Cảnh báo mềm (không tốn lượt gọi AI, chỉ ghi vào telemetry của chương nháp):** scene < 50% hoặc > 220% ngân sách từ, kết giữa câu, `mustChange` có vẻ chưa thực hiện, không nhắc nhân vật nào trong kế hoạch, scene cuối chưa chạm điểm kết.
- **🔬 Rà AI từng scene (tùy chọn, mặc định TẮT):** bật ở "Công cụ" → 1 lượt gọi ngắn/scene (chỉ gửi contract scene + văn bản scene) kiểm tra thay đổi bắt buộc, địa điểm/thời gian, tuyến mới. Lỗi chắc chắn → viết lại scene; HANDOFF chỉ là cảnh báo; lỗi gọi/parse → bỏ qua, không chặn.
- **🛠 Tự sửa sau chấm nhanh (nháp nền, ô tick mặc định bật):** nếu chấm nhanh ra HARD_FAIL (hoặc SOFT_FAIL có cảnh báo Canon/continuity/Beat hành động được) thì sửa tối đa 1 vòng (vá cục bộ → sửa theo vùng → viết lại cả chương nếu vừa) rồi chấm lại. **Best Draft Guard:** bản sửa không tốt hơn (verdict/điểm/số lỗi nặng), không chấm lại được, hoặc làm chương dưới 4.500 từ → khôi phục bản cũ. SOFT_FAIL chỉ vì văn phong không bị ép sửa. Vẫn là Bản nháp: không Gate đầy đủ, không hậu kỳ, không ghi Canon. Phiếu hiện "🛠 Đã tự sửa 1 vòng: 55 → 91/100" hoặc "(bản sửa không tốt hơn nên giữ bản cũ)".
- Hạ tầng: `reviewIsBetter` tách thành hàm dùng chung (Gate loop + tự sửa sau chấm nhanh); `create-job` nhận `autoFixQuick`, `quickFixRounds`; `sceneAiReview` thuộc Story Record.
- Test mới: `v14_0_16_scene_check_quickfix.test.js` (13 nhóm), `v14_0_16_worker_quickfix.test.js` (6 kịch bản); E2E nháp nền kiểm tra payload `autoFixQuick`.

## [V14.0.15] — Minh bạch hậu kỳ, gợi ý nhân vật, chi phí theo bước, sức khỏe truyện

- **🧾 Hậu kỳ đã thay đổi gì:** worker ghi `canonDiff` cho mỗi chương (NV mới/cập nhật từng trường, địa điểm, vật phẩm, thread, mục bị bỏ + lý do). Panel dưới tiêu đề chương, có nút ↶ hoàn tác từng trường hoặc gỡ NV mới.
- **📬 Gợi ý nhân vật:** tên riêng lặp lại chưa có hồ sơ hiện trong mục 0.3; thêm NV / địa điểm / bỏ qua bằng một chạm (không tốn token).
- **📊 Chi phí theo bước + model riêng:** 💰 hiện token/USD theo Viết, Scene, Gate, Sửa, Hậu kỳ…; đặt model rẻ cho Hậu kỳ / Quality Gate / Kiểm tra / Gợi ý (server cũng dùng). Bước Viết luôn dùng model chính.
- **🩺 Sức khỏe truyện:** NV vắng lâu, thread/foreshadowing tồn đọng, tiến độ Arc, xu hướng điểm chất lượng.
- **🔎 Rà mâu thuẫn:** kiểm tra bằng code (người chết xuất hiện lại, người phối ngẫu lệch, trùng tên) + quét AI trên tóm tắt chương; nhắc quét lại mỗi 10 chương.
- **Tách module:** CSS → `app/app.css`; tính năng mới → `app/features.js` (nối với `index.html` qua cầu `window.__XTA__` và hook). Logic thuần nằm ở `shared/core.js`.
- Test mới: `v14_0_15_features.test.js`, `e2e_v14_0_15.py`.

## [V14.0.14] — Sửa hậu kỳ không cập nhật 0.3. Character Database

Nguyên nhân: bộ lọc "evidence" của hậu kỳ server loại bỏ gần như mọi dòng nhân vật.
- Tên rút gọn trong chương ("Minh Anh") không còn bị coi là "không xuất hiện" so với hồ sơ ("Nguyễn Minh Anh"); AI trả `id` hoặc tên rút gọn đều được ánh xạ về đúng NV có sẵn, không tạo trùng.
- NV mới bị AI xếp `major` không còn bị BỎ QUA: được thêm ở hạng `supporting` (không bao giờ tự thành major) và ghi chú để bạn nâng hạng tay.
- NV mới thiếu `chapterEvent` được lấy từ evidence thay vì bị bỏ.
- Ngưỡng bằng chứng theo trường hạ 0.55 → 0.35 (evidence vẫn phải là câu thật trong chương); báo số trường bị loại.
- NV có sẵn xuất hiện trong chương luôn được ghi `lastAppearance` (thống kê "Vắng" đúng).
- Prompt hậu kỳ yêu cầu rõ: NV mới có tên riêng phải có mặt, dùng đúng id.
- Test mới `tests/v14_0_14_character_update.test.js`; cập nhật test V12.30 theo quy tắc mới.

## [V14.0.0] — Contract-First Complete Chapter Pipeline

- Chapter Contract bất biến khóa Arc/Outline, Required Beat, Allowed Cast, Forbidden Drift, continuity mở chương và thay đổi bắt buộc.
- Scene Graph bị validate trước khi viết; plan drift bị retry một lần rồi dừng an toàn, không fallback âm thầm sang writer cũ.
- Mỗi scene và Top-up giữ cùng Contract; Sync Canon chỉ được thực hiện sau khi Contract barrier đạt.
- Dọn tài liệu patch cũ vào `docs/patch-notes/`; client và worker dùng chung helper V14.

## [V14.0.1] — Scene Graph Response Parser

- Cứu phản hồi Scene Graph hợp lệ khi model bọc JSON trong markdown, thêm lời dẫn hoặc có phần văn bản sau JSON.
- Lần retry hiển thị đúng lỗi parse thay vì báo sai đồng thời “không có scene/chapterGoal/endingAnchor”.
- Bổ sung regression parser và đồng bộ client/worker.

## [V14.0.2] — Allowed Cast Context

- Allowed Cast nay quét toàn bộ Arc/Outline, không chỉ dòng Outline của chương hiện tại.
- Tránh loại nhầm nhân vật canon hợp lệ như nhân vật được khai báo ở phần setup/consequence của Arc.
- Nhân vật không có trong Story Bible/Outline vẫn bị chặn khi tự xuất hiện trong scene.

## [V14.0.3] — Canon Cast / Active Cast Separation

- Tách `canonicalCharacters` (toàn bộ nhân vật đã có trong Story Bible) khỏi `allowedCharacters` (nhân vật đang hoạt động trong Arc/chương).
- Nhân vật canon như Trần Mỹ Duyên hoặc Lâm Tịnh Nhã không còn bị từ chối chỉ vì không nằm trong 12/24 nhân vật Active Cast được ưu tiên.
- Nhân vật không tồn tại trong Canon vẫn bị validator chặn; bổ sung regression cho cả hai trường hợp.

## [V13.6] — Arc Lock và chống Plot Drift

- Scene Graph nhận Arc/Outline lock, allowed cast và danh sách hướng drift bị cấm; các scene và top-up đều giữ cùng ràng buộc.
- Không cho AI tự biến nhân vật phụ/nhân vật mới thành tuyến chính hoặc tự đổi nghề, tài nguyên, địa vị và mục tiêu sinh tồn của nhân vật chính.
- Segment Repair được hướng dẫn thay toàn bộ vùng tuyến phụ sai bằng đoạn cầu nối đúng Outline thay vì cố giữ tuyến drift.
- Thêm regression cho Arc lock, allowed cast và forbidden drift; toàn bộ client/worker parity đã PASS.

## [V13.5] — Hard Minimum không phụ thuộc cờ cũ

- Hard minimum 4.500 từ nay luôn được áp dụng, kể cả Story Record cũ đang lưu `adaptiveScenePipeline=false`.
- Mọi fallback ngắn đều phải chạy Top-up trước khi tạo chapter object và Quality Gate.

## [V13.4] — Fallback Short-Draft Guard

- Thêm hàng rào Top-up cuối cho mọi bản nháp dưới 4.500 từ, kể cả khi Scene Graph lỗi và app phải dùng fallback prompt cũ.
- Không còn đường tạo chương nào được lưu trực tiếp ở khoảng 1.000–2.000 từ khi Adaptive Scene đang bật.

## [V13.3] — Viết lại dùng chung Adaptive Scene

- Sửa lỗi nút **Viết lại** bỏ qua Adaptive Scene/Top-up vì nhánh cũ chỉ áp dụng cho chương mới.
- Cả tạo chương mới và viết lại nay đều phải đi qua Scene Graph, scene nối tiếp và Top-up tối thiểu 4.500 từ.

## [V13.2] — Adaptive Scene Top-up và Hard Minimum

- Khi Adaptive Scene ghép xong dưới 4.500 từ, app tự viết bổ sung tối đa 6 lượt bằng prompt compact chỉ truyền đoạn đuôi, state delta và Required Beat; prompt yêu cầu tối thiểu phần từ còn thiếu.
- Chương dưới 4.500 từ bị Quality Gate đánh dấu `HARD_FAIL`, không thể được coi là đạt chỉ vì điểm văn phong/continuity cao.
- Bổ sung regression cho prompt top-up, giới hạn token và hard minimum 4.500 từ.

## [V12.47.1] — Background Worker Parity

- Background Worker nay dùng cùng chế độ `autoRepairOnCreate` với client.
- Cảnh báo Canon/continuity/Beat có thể hành động sẽ buộc chạy rewrite/Targeted Repair và chấm lại trước khi Sync Canon.
- Worker tôn trọng cả `qualityAcceptSoft`, tránh duyệt mềm ngoài cấu hình người dùng.
- Bổ sung regression assertion cho parity client/worker.

## [V12.47.0] — Tạo Chương Hoàn Chỉnh

- Đổi nút chính thành **✦ Tạo Chương Hoàn Chỉnh**.
- Thêm công tắc bật mặc định để tự động chạy Semantic Prose Check, Quality Gate, patch/Targeted Segment Repair và chấm lại trước khi Sync Canon.
- Khi tạo chương mới, cảnh báo Canon/continuity/Beat có thể hành động không còn bị bỏ qua chỉ vì điểm tổng là `PASS`.
- Lưu cấu hình tự sửa vào Story Record; người dùng vẫn có thể tắt trong phần Công Cụ Sáng Tác.
- Thêm regression test cho pipeline tự hoàn thiện.

## [V12.46.1] — Canon Warning AutoFix

- Sửa lỗi nút **AI tự sửa** dừng ngay khi Quality Gate trả `PASS` dù vẫn có cảnh báo Canon/continuity/Beat có hướng xử lý.
- Khi bật AI tự sửa, các cảnh báo có thể hành động được sẽ được chuyển vào luồng patch/Targeted Segment Repair; cảnh báo phong cách nhẹ không bị ép sửa.
- Thêm regression test bảo đảm cảnh báo Canon được gửi cho AI sửa và phải chấm lại sau đó.

## [V12.46.0] — Semantic Prose Check

- Rà văn xuôi theo từng câu để phát hiện cụm tiếng Việt có thể vô nghĩa hoặc sai chính tả theo ngữ cảnh, kể cả khi từng từ riêng lẻ đều hợp lệ.
- Gửi riêng từng nhóm câu cho AI; chỉ tự sửa khi AI trả đúng cụm nguyên văn, cụm thay thế và độ tin cậy từ 85% trở lên.
- Trường hợp `uncertain`, không tự thay; lưu cảnh báo để người dùng xem và quyết định.
- Áp dụng cho client và Background Worker, có regression test cho lỗi kiểu “tớn tiền”.

## [V12.45.0] — Targeted Segment Repair

- Nút **AI tự sửa** tự chuyển sang sửa theo vùng khi patch câu neo thất bại và chương quá dài để viết lại toàn bộ.
- AI trả mốc đầu/cuối nguyên văn và chỉ viết lại vùng lỗi; phần còn lại của chương được giữ nguyên.
- Áp dụng cho cả client và Background Worker, có backup trước khi thay và kiểm tra giới hạn thay đổi độ dài.
- Giữ Best Draft Guard: bản sửa vẫn được Quality Gate chấm lại; nếu kém hơn, bản tốt hơn được khôi phục.

## [V12.44.0] — E2E Stable Patch

- Sửa hiển thị cảnh báo `JOB_SECRET` và lỗi mã truy cập trong Background Postprocess.
- Poll Background Job nhanh hơn trong môi trường test, giữ Canon version và trạng thái rà khi hợp nhất.
- Bổ sung mock Netlify Job cho E2E giao diện; cập nhật payload/snapshot E2E theo luồng Postprocess hiện hành.
- Unit/Core 39/39 và các E2E giao diện, job nền, payload slim được chuẩn hóa để kiểm tra đúng hành vi hiện tại.

## [V12.43.0] — Required Beat Barrier

- Thêm công tắc mặc định bật: `Chặn thiếu Required Beat [R]`.
- Khi còn `[R]` thiếu, không cho Manual Override, không Sync Canon và không xuất bản TXT/MD/DOC.
- Xuất bản kiểm tra toàn bộ chương trong truyện, không chỉ chương đang mở.
- Có thể tắt khóa trong phần Quality Gate nếu người dùng chủ động muốn xuất bản bản nháp.

## [V12.42.0] — Plan Completion Guard

- Ô kế hoạch vẫn có thanh cuộn; nội dung không bị mất chỉ vì vượt 220px chiều cao hiển thị.
- Tăng ngân sách lập Chapter Plan và tự retry khi model trả `finishReason: length`.
- Lượt retry yêu cầu trả đủ `[R]`, `[S]`, `REQUIRED_DONE`, `STOP_AFTER` và `CONFLICT`, tránh viết chương dựa trên kế hoạch bị cắt.

## [V12.41.0] — AutoFix Retry + Patch Trace

- Khi thiếu `[R]` nhưng lượt vá đầu không ghép được, AI được retry với `insert_before_end` thay vì neo vào mã beat không có trong bản thảo.
- Quality Review hiển thị số patch đã ghép, thao tác và đoạn neo; không còn báo mơ hồ rằng AI đã sửa nếu thực tế không ghép được.
- Giữ Best Draft Guard: bản sửa làm điểm tụt vẫn bị khôi phục.

## [V12.40.0] — Nested Main Events

- Giữ giới hạn tối đa 3 sự kiện trục chính mỗi chương.
- Cho phép biến cố lớn lồng bên trong một sự kiện trục khi có quan hệ nhân-quả trực tiếp và thật sự cần.
- Không ép chương nào cũng phải thêm biến cố lồng; không tính biến cố lồng thành sự kiện chính thứ 4.
- Đồng bộ luật này vào planner, writer prompt và Story Control.

## [V12.39.0] — Canon Barrier + Required Beat Contract

- Mặc định không cho bản SOFT_FAIL trở thành Canon; thêm công tắc **Chặn điểm thấp vào Canon**.
- Tách `[R]` (beat bắt buộc từ brief/Outline/canon) khỏi `[S]` (beat hỗ trợ do AI đề xuất), tránh chấm thấp vì ý AI tự phát sinh.
- Thêm thứ tự ưu tiên Canon → mệnh lệnh mới → Outline → gợi ý → đề xuất AI và buộc ghi nhận xung đột thay vì tự chọn im lặng.

## [V12.38.0] — Marital Status Lock

- Thêm ô **Tình trạng hôn nhân** và **Vợ/chồng/người yêu** cho nhân vật chính.
- Thêm các trường tương ứng vào từng hồ sơ NPC, Story Bible, character summary và worker prompt.
- Xem tình trạng hôn nhân là dữ liệu lõi; AI không tự đổi nếu không có sự kiện và bằng chứng rõ ràng.

## [V12.37.0] — Gender Anatomy Lock

- Truyền giới tính từng nhân vật vào HỒ SƠ KHÓA thay vì chỉ truyền tên và tuổi.
- Prompt viết yêu cầu xác định chủ thể trước mỗi đoạn tả thân thể, không trộn đặc điểm sinh học giữa các nhân vật.
- Quality Gate có cờ `genderAnatomyMismatch` và chuyển lỗi này thành Hard Failure.

## [V12.36.0] — Best Draft Guard

- Không còn mặc định giữ bản tự sửa cuối cùng nếu điểm Quality Gate bị tụt.
- Xếp hạng bản chấm theo `PASS > SOFT_FAIL > HARD_FAIL`, sau đó so điểm và số hard failure.
- Khi vòng sửa sau kém hơn, tự khôi phục bản tốt nhất đã chấm và hiển thị cảnh báo `Best Draft Guard`.

## [V12.35.0] — Beat Ledger

- Kế hoạch chương đánh mã `[B1]`, `[B2]`... và ghi rõ mục tiêu, hành động bắt buộc, bằng chứng hoàn thành, hậu quả.
- Prompt viết buộc hoàn thành từng beat theo thứ tự trước khi đi tới Ending Anchor.
- Quality Gate audit từng beat bằng bằng chứng trong bản thảo, không tính việc chỉ nhắc lại kế hoạch.

## [V12.34.0] — Targeted beat repair

- Khi Quality Gate phát hiện thiếu beat/sự kiện bắt buộc, AI có thể dùng `insert_before_end` để chèn cảnh ngay trước đoạn kết mà không cần đoán câu neo nguyên văn.
- Client và worker dùng chung thao tác vá; giữ nguyên đoạn kết, không viết lại chương dài.
- Thêm regression test cho trường hợp “phát hiện kẻ theo dõi” bị bỏ sót.

## [V12.33.1] — Responsive iPhone topbar

- Ẩn đúng label trợ năng `sr-only` khỏi layout nhưng vẫn giữ cho trình đọc màn hình.
- Thu gọn topbar trên màn hình ≤600px: mô tả dài ẩn, tiêu đề không bị xuống từng chữ, nút điều khiển vừa chiều ngang iPhone.

## [V12.33.0] — P0/P1/P2 hardening

- P0: thêm age gate 18+, bảng kiểm tra cấu hình bảo mật deployment và endpoint `security-status` không tiết lộ secret.
- P0: thêm `REQUIRE_HARDENED_SECURITY=1` để từ chối background job khi thiếu `JOB_SECRET` hoặc `APP_PASSCODE`.
- P1: thêm Chế độ đơn giản/Chuyên gia, tự lưu lựa chọn trên thiết bị và wizard khởi tạo truyện.
- P2: thêm progress strip cho luồng lập kế hoạch, viết và Quality Gate; cập nhật tài liệu kế hoạch/module.

Gộp từ toàn bộ file `PATCH_NOTES_*.md` và `README_V*.md` cũ (mới nhất ở trên). Nội dung các bản được giữ nguyên, chỉ hạ cấp tiêu đề.
Bản hiện hành: **V14.0.20** (xem mục đầu tiên). Hướng dẫn tổng quan: `README.md`; kiến trúc/Memory Engine/Backup lịch sử: `docs/ARCHITECTURE.md`; bảo mật: `SECURITY_SETUP.md`.


---

## [V12.33.0] — Tiến độ Arc + Outline theo từng chương (chống truyện đi quá chậm)

- **Vấn đề:** prompt chỉ nhận tên + mục tiêu Arc (cắt 200 ký tự) mà không biết đang ở đâu trong Arc; chương bắt đầu/kết thúc dự kiến của Arc bị bỏ phí; Outline là một khối chung cắt 800 ký tự nên AI không biết chương này phải làm bước nào.
- **`arcProgressPrompt`:** khối TIẾN ĐỘ ARC (chương x/y, % đã đi, còn bao nhiêu chương, nửa chặng/chương cuối/quá hạn phải thu Arc) và khối Outline (VIỆC BẮT BUỘC của chương lấy từ dòng `Ch12: …`, kèm dòng chương kế để nối mạch, giới hạn 1500 ký tự khi không có dòng theo chương).
- **Outline 🤖 AI đề xuất** nay tạo từng chương (JSON `chapters[{chapter, beat}]` + mốc kết giai đoạn), lưu thành các dòng `ChN: …`; cảnh báo trên giao diện khi Outline sắp hết/đã hết.
- **Kế hoạch chương** có mục 7a "TIẾN ĐỘ ARC/OUTLINE"; ngân sách sự kiện yêu cầu mỗi sự kiện là một BƯỚC TIẾN thật.
- **Quality Gate:** cờ cứng `arcStall` (chỉ khi có Arc/Outline và chương không làm bước nào) → HARD_FAIL → viết lại.

## [V12.32.17] — Nhân vật phụ có đời riêng (ngôi 3 giới hạn không còn dồn hết vào nhân vật chính)

- **Vấn đề:** prompt ghi nhân vật chính "BẮT BUỘC là trung tâm mọi chương" và "Ngôi 3 giới hạn" không được giải thích, nên AI hiểu là chỉ viết xoay quanh nhân vật chính; nhân vật phụ chỉ phản ứng.
- **Ngôi 3 giới hạn** nay được mô tả đúng: mỗi cảnh/đoạn bám sát MỘT nhân vật (thường là nhân vật chính, được chuyển sang nhân vật phụ ở cảnh khác có chuyển cảnh rõ), không nhảy vào đầu nhiều người trong cùng đoạn.
- Nhân vật chính là **trục** và phải có mặt trong chương, nhưng không cần có mặt ở mọi cảnh; kế hoạch chương ghi nhịp nào theo góc nhìn nhân vật nào.
- Story Control thêm "NHÂN VẬT PHỤ CÓ ĐỜI RIÊNG": việc riêng, mong muốn riêng, hành động chủ động kể cả khi nhân vật chính vắng mặt.

## [V12.32.16] — Thử lại bền hơn khi nhà cung cấp model trả 502/5xx

- **Vấn đề:** lỗi "502: The server had an error while processing your request" là lỗi từ phía nhà cung cấp model/endpoint (quá tải, model sập tạm); app chỉ thử lại tổng ~7 giây (client) hoặc ~3 giây (worker) nên dễ bỏ cuộc.
- **Client:** tối đa 4 lần thử lại; lỗi 5xx chờ 2s/5s/10s/20s (tôn trọng Retry-After, tối đa 30s); thông báo lỗi cuối nêu rõ lỗi phía nhà cung cấp.
- **Worker nền:** lỗi 5xx được thêm 1 lần thử và chờ 2s/6s/12s, nhưng dừng nếu không còn đủ thời gian an toàn của hàm.

## [V12.32.15] — Thời gian chảy theo mạch truyện (văn xuôi thuần túy)

- **Vấn đề:** luật thời gian cũ ép AI "nêu mốc ngay đầu chương, mỗi lần chuyển cảnh, và cuối chương để thời điểm rõ ràng"; kế hoạch chương bắt ghi "mốc mở chương + mốc kết chương"; Quality Gate cảnh báo "thiếu mốc thời gian" nên các lần tự sửa lại chèn nhãn kiểu "Chiều thứ Sáu, …". Kết quả đọc như báo cáo, không giống văn xuôi.
- **Prompt viết (`timePrompt`):** thời gian là một phần câu chuyện, không phải nhãn. Cấm mở chương bằng câu báo ngày giờ, cấm kết chương bằng câu tổng kết thời điểm, cấm nhãn "Thời gian:". Chỉ nêu giờ/ngày cụ thể khi nhân vật nhìn đồng hồ/lịch hoặc tình tiết cần (hạn chót, hẹn giờ). Thời điểm thể hiện qua chi tiết trong cảnh (ánh sáng, thời tiết, bữa ăn, độ mệt, việc đang làm). Thời gian trôi/nhảy được lồng thành một mệnh đề trong mạch kể. Vẫn giữ luật nhất quán: chỉ tiến về phía trước, hồi phục/quan hệ/kế hoạch tiến triển theo thời gian, nhịp thời gian do tác giả chọn, cảnh báo khi nhiều chương liền đứng yên.
- **Kế hoạch chương:** mục 5 thành "DÒNG THỜI GIAN (ghi chú nội bộ, không in thành nhãn)", bỏ yêu cầu mốc mở/kết chương.
- **Quality Gate:** `timeStagnation` chỉ báo khi có bằng chứng thời gian sai (đi lùi/mâu thuẫn ngày, vết thương, hạn chót…) hoặc đứng yên thật; **không** báo chỉ vì chương thiếu ngày/giờ. Cảnh báo đổi thành "Thời gian truyện bất nhất hoặc đứng yên". Vẫn là cảnh báo mềm, không chặn.
- **AI tự sửa/vá:** cấm chèn câu/dòng báo ngày giờ làm nhãn ở đầu hoặc cuối chương; sửa lỗi thời gian phải lồng vào mạch kể. Chuyển cảnh/địa điểm cũng dùng "câu chuyển tự nhiên", không "di chuyển + mốc thời gian".
- **Hậu kỳ (Current Status):** `changes.time` được suy từ cả mốc nói thẳng lẫn dấu hiệu ngầm, ghi dạng tương đối được ("sáng hôm sau", "đêm cùng ngày…"); không có dấu hiệu đáng tin thì giữ mốc cũ, không bịa. Nhật ký `timeLog` và phát hiện đứng yên vẫn hoạt động.
- **Giao diện:** ô Story Clock ghi rõ là không bắt buộc, chỉ để AI giữ nhất quán, không in ra văn.

## [V12.32.14] — Dọn dẹp an toàn

- **Tài liệu:** gộp 41 file `PATCH_NOTES_*.md` / `README_V*.md` thành `CHANGELOG.md` (không mất dòng nào); README cũ lưu ở `docs/ARCHITECTURE.md`, prompt ở `docs/PROMPT_V12.22.md`; `README.md` viết lại gọn, đúng hiện trạng.
- **Code chết (phân tích cú pháp bằng acorn, không chỉ đoán theo tên):** gỡ 21 hàm ở giao diện (~230 dòng): extractBalancedJson, idbGetAll, loadStoryStateFromDisk, syncMainCharCoreFromProfile, buildFemaleDefinitionBlock, matureFocusLabel, timingSummary, runFastPostTasks, normalizeStoryControlClient, qualityHardCheck, applyNextChapterHint, previewNextChapterHint, beginCanonSync, completeCanonSync, checkCheckpoint, startBackgroundWrite, _fmtDur, enqueueTask, showCheckpointBanner, runQueue, hideCheckpointBanner; và 16 hàm ở worker (~430 dòng): genSecret, encryptText, recentContext, generateSummary, generateNextChapterHint, updateCharacters, updateWorld, formatStatus, updateCurrentStatus, updateLongMemory, scanScenes, parseArrayWithRepair, parseObjectWithRepair, extractModelFor, compactCharacterList, repairJsonWithAI. Phần lớn là luồng cũ đã bị thay: viết nền từ giao diện (`startBackgroundWrite`) và các bước trích xuất riêng lẻ ở worker (đã gộp thành hậu kỳ một lệnh gọi từ V12.30). Chỉ gỡ hàm không còn được nhắc ở bất kỳ đâu (kể cả HTML, chuỗi, test) và không nằm trong khối `SHARED-CORE`. Hành vi không đổi.
- **Bảo mật xuất bản:** `netlify.toml` thêm redirect 404 (force) cho `tests/`, `netlify/`, `shared/`, `lib/`, `scripts/`, `docs/` và file cấu hình/tài liệu gốc, để chúng không tải công khai được từ site (`publish = "."` giữ nguyên, không đổi cấu trúc thư mục).

---

## [PATCH_NOTES_V12.32.10_PATCH_REWRITE] — Ghi chú bản vá

### V12.32.10 — AI tự sửa cục bộ (patch) + nút 🛠 AI tự sửa

#### Vấn đề
Chương bị "🟠 Cần sửa" (vd 65/100) vẫn không tự lên điểm: Quality Gate yêu cầu AI **viết lại cả chương** (~5000 từ).
AI thường trả về bản bị cắt/tóm tắt (vd 1159/5309 từ) → app từ chối ("Bản sửa quá ngắn/rỗng") và giữ nguyên bản thảo.
Nút 🔍 Duyệt lại chỉ chấm lại (rewrite:false) nên cũng không sửa gì.

#### Thay đổi
1. **Sửa cục bộ (patch)** — `shared/core.js`: `buildPatchPrompt`, `parsePatchResponse`, `applyChapterPatches`, `checkPatchAcceptable`.
   AI chỉ trả JSON các thao tác nhỏ: `replace`, `delete`, `insert_after`, `insert_before`, `insert_start`, `insert_end`.
   Xoá/thay đoạn dài bằng `from`+`to` (đầu/cuối đoạn). Đoạn bị lặp chọn bằng `which` (số thứ tự hoặc `"last"`).
   Phần không nhắc đến giữ nguyên 100%. Tốn ít token hơn nhiều (≈4000 token ra thay vì ≈16000).
2. **An toàn:** find phải khớp nguyên văn (có dung sai khoảng trắng); khớp mơ hồ/không thấy → bỏ qua chỗ đó, không đoán;
   range `from→to` > 40% chương bị chặn; sau vá chương phải dài 60%–135% bản gốc; luôn backup bản cũ vào `versions`.
3. **Gate dùng patch trước**, nếu không vá được mới dự phòng viết lại cả chương (cả client và worker nền).
4. **Nút 🛠 AI tự sửa** (cạnh 🔍 Duyệt lại): chạy chấm → vá → chấm lại tối đa `qualityMaxAttempts` lượt cho chương đang "Cần sửa".
   Đạt thì hỏi Sync Canon như 🔍 Duyệt lại. Không đạt vẫn giữ bản đã vá tốt nhất, xem/khôi phục bản cũ ở lịch sử phiên bản.

#### Test
`tests/v12_32_10_patch_rewrite.test.js` (mới) + cập nhật mock `worker.test.js`, `worker.gatefail.js` cho luồng vá-trước.

#### V12.32.11 (sửa tiếp)
- **Lỗi:** bộ chấm được xem ĐOẠN KẾT CHƯƠNG TRƯỚC để đối chiếu cảnh mở đầu, nhưng AI sửa (cả vá cục bộ lẫn viết lại cả chương) thì KHÔNG → vá mù, tự đoán địa điểm
  (vd chương trước kết ở hành lang nhưng AI nối vào "văn phòng"/"bãi xe") nên lần chấm sau lại báo lỗi continuity mới.
- **Sửa:** truyền `prevEnding` (1500 ký tự cuối chương trước) vào prompt vá và prompt viết lại, ở cả client lẫn worker nền;
  thêm quy tắc "câu chuyển cảnh phải nối đúng từ đoạn kết chương trước, không dời sang địa điểm khác; chi tiết thêm vào phải khớp canon".

#### V12.32.12 (AI tự làm hết trước khi giao chương)
- **Tối đa 5 vòng** chấm → vá (trước là 3). Mặc định 5; giá trị lưu cũ = 3 (mặc định cũ, không có ô chỉnh trên giao diện) cũng được hiểu là 5.
- **Nhớ lỗi đã sửa:** lỗi nặng của các vòng trước mà vòng này không còn bị truyền vào prompt vá/viết lại ("giữ nguyên chỗ đã sửa, đừng hoàn tác"), tránh sửa chỗ này làm hỏng chỗ khác.
- **Duyệt kèm cảnh báo:** nếu chỉ còn SOFT_FAIL (điểm ≥ ngưỡng mềm 75) và KHÔNG có hard failure thì duyệt luôn, ghi cảnh báo, không chạy thêm vòng.
  Tắt bằng `qualityAcceptSoft:false` trong state nếu muốn giữ chuẩn PASS ≥ 90 nghiêm ngặt.
- Tốn thêm: tối đa 2 vòng chấm+vá so với trước, chỉ khi chương vẫn còn lỗi nặng.

#### V12.32.13 (trần output ~7800 token: hết "viết lại cả chương" vô ích)
- **Vấn đề gốc:** mọi lệnh gọi AI bị chặn ở 7800 token output (`AI_MAX_OUTPUT_TOKENS`, provider ~8192) dù code xin 12000–24000.
  Chương ~5000 từ tiếng Việt ≈ 9–11k token nên KHÔNG thể được "viết lại toàn bộ" trong một lệnh gọi → bị cắt/tóm tắt, bản sửa bị từ chối, tốn token vô ích.
- **Mở rộng cuối (V12.23) đổi sang chèn đoạn** (client + worker): AI chỉ trả các khối `>>> SAU: <neo>` / `>>> TRƯỚC: <neo>` + đoạn mới
  (không dùng JSON để khỏi vỡ vì dấu ngoặc kép trong lời thoại). App ghép vào, giữ nguyên 100% văn bản gốc. Khối nào đổi đoạn kết chương, vượt `maxWords`,
  neo không khớp hoặc không phải thao tác chèn đều bị bỏ. `maxTokens` xin vừa đủ theo số từ cần thêm (`expandMaxTokens`).
- **Gate: viết lại cả chương chỉ còn là dự phòng và bị chặn** khi chương quá dài so với trần (`wholeRewriteFits`) — khỏi tốn một lệnh gọi chắc chắn thất bại.
- Hằng số `AI_MAX_OUTPUT_TOKENS` dùng chung (client `callAI`, worker `callOpenRouter`/retry).
- Chèn/vá nhận biết cuối đoạn/đầu đoạn tốt hơn: neo thiếu dấu chấm/ngoặc đóng cuối đoạn, hoặc thiếu ngoặc mở/gạch thoại đầu đoạn, vẫn chèn thành đoạn mới thay vì xé câu.
- Viết chương chính và các lượt "viết tiếp" vẫn theo từng đoạn như cũ (đã thiết kế nối nhiều lượt), không đổi.
- Test: `tests/v12_32_13_expand_inserts.test.js` (mới); harness `v12_30_streaming_fix` khai báo thêm hằng mới.

---

## [PATCH_NOTES_V12.32.2_POSTPROCESS_TRUNCATION] — Ghi chú bản vá

### V12.32.2 — Hậu kỳ nền không cập nhật nhưng vẫn báo "Đã đồng bộ"

#### Nguyên nhân
- Hậu kỳ gộp bắt AI trả MỘT JSON chứa summary + toàn bộ nhân vật (~70 trường/người) + world + status + memory + continuity + gợi ý, với trần 7800 token. Chương dài (~5500 từ) gần như luôn vượt → `finish=length` → code hoàn tác TOÀN BỘ dữ liệu hậu kỳ.
- Dù hoàn tác, job vẫn ghi `postProcess.status="DONE"` / `completed`, và client luôn hiện "☁ Đã đồng bộ ... NV/World/Status/Scene đã hợp nhất" → báo thành công giả.

#### Sửa
- Schema yêu cầu AI BỎ trường rỗng/không đổi, tối đa 12 nhân vật → phản hồi ngắn hơn nhiều.
- Nếu JSON gộp bị cắt/hỏng: tự chạy 3 nhóm nhỏ (summary+memory+continuity+hint / nhân vật / world+status). Nhóm nào lỗi chỉ nhóm đó giữ dữ liệu cũ. Lỗi API vẫn chỉ gọi 1 lần (không tốn thêm).
- Server ghi trạng thái thật: DONE / PARTIAL / FAILED (+ lý do, danh sách task chưa cập nhật); `job-status` trả `postProcessStatus/Error/Failed`.
- Client hiện cảnh báo ⚠ nêu rõ task nào chưa cập nhật thay vì "Đã đồng bộ".
- Test cập nhật + thêm test fallback theo nhóm.

#### Bổ sung (cùng bản)
- Tiết kiệm token: prompt hậu kỳ chỉ gửi hồ sơ đầy đủ của nhân vật xuất hiện trong chương (tối đa 40) + danh sách tên các nhân vật khác; Current Status cũ 14000 → 8000 ký tự (4000 cho nhóm không cần). Mỗi nhóm fallback chỉ gửi phần nó cần (roster rút gọn, bỏ World/Status/đoạn cuối chương trước khi không dùng).
- Evidence: ngưỡng Status 0.55 → 0.35 (giá trị thường là diễn giải), characterChanges 0.4; ghi số mục bị loại do evidence không khớp vào ghi chú NV/Status.
- Client: khi người dùng viết thêm chương trong lúc hậu kỳ chạy, kết quả hậu kỳ (summary, continuityWarnings, postProcess, review...) vẫn được chép vào đúng chương N.

#### V12.32.3 (tiết kiệm token Quality Gate)
- Kiểm tra continuity bằng AI (gửi cả chương) chỉ chạy ở vòng 1 của Gate; vòng 2+ chỉ chạy kiểm tra cứng.
- Ngữ cảnh Review 18000 → 9000 ký tự, Rewrite 15000 → 8000, nhưng bỏ trước các khối không liên quan (văn phong, mức miêu tả, độ khó, từ cấm/STYLE chỉ bỏ ở Review) và giữ phần cuối (Current Status) thay vì cắt cứng phần cuối như trước.

#### V12.32.4 (Hồ sơ khóa — AI bám đúng thiết lập nhân vật)
- Prompt viết chương: thêm khối "HỒ SƠ KHÓA" (NVC + tối đa 8 nhân vật liên quan): nghề, vai trò, chức vụ/địa vị, phe, tuổi, năng lực, cách nói, tính, kiến thức, kèm luật chung: không tự nâng/hạ cấp quyền lực-tài sản-năng lực, lời thoại phải hợp địa vị, chỉ vượt hồ sơ khi có sự kiện rõ trong chương + brief cho phép, mục hồ sơ trống thì không bịa chi tiết quan trọng. Các lượt auto-continue/chèn diễn biến/chốt kết dùng bản rút gọn.
- Siết câu "ĐƯỢC TỰ DO": không áp dụng cho địa vị/nghề/quyền hạn/tài sản/năng lực/tuổi/kiến thức/cách nói.
- Quality Review: thêm `profileViolation` + `profileViolations`; vi phạm = HARD_FAIL (kích hoạt viết lại). Chỉ báo khi có câu cụ thể trái hồ sơ. Review/Rewrite nhận hồ sơ của nhân vật có mặt trong bản thảo.

#### V12.32.5 (chống dậm chân + liền lạc)
- Luật TIẾN TRIỂN BẮT BUỘC trong prompt viết (và lượt viết tiếp/chèn diễn biến): cuối chương phải đổi ít nhất một điều; cấm lặp hành động/miêu tả để kéo dài; PRIMARY: cảnh trưởng thành chỉ ~1/2–2/3 chương, phải làm đổi quan hệ/quyền lực/bí mật/hậu quả và mở bước kế tiếp. storyControl và matureFocus PRIMARY cũng được bổ sung.
- Kế hoạch chương: thêm mục 7b "THAY ĐỔI/TIẾN TRIỂN" và mục 8 yêu cầu nêu cảnh nóng làm đổi điều gì.
- Quality Gate: cờ `stagnation` (+`stagnationNotes`) = lỗi nặng → viết lại; chỉ báo khi cuối chương gần như không đổi hoặc cảnh lặp để kéo dài.
- Trí nhớ truyện: khối "TRUYỆN ĐẾN NAY" (1–2 câu mỗi chương cũ, ≤~2800 ký tự, chỉ lấy chương trước chương đang viết khi viết lại) + "ĐANG DANG DỞ" (unresolved/conflict/nextGoal/nextHooks từ Current Status).

#### V12.32.6b/c (văn xuôi thuần tiếng Việt)
- `cleanProseArtifacts` (chạy trong mọi đường viết qua `stripForeign`): Unicode NFC, Ð→Đ, bỏ HTML/markdown/emoji, bỏ nhãn rò rỉ "(tiếng Anh/Trung/Việt…)" (đoạn có ≥2 nhãn bị bỏ), bỏ dòng meta của AI (Ghi chú/Lưu ý/(Còn tiếp)… ở đầu dòng, không đụng lời thoại), chuẩn dấu câu bất thường, chặn lặp ký tự/từ thoái hóa, bỏ dòng trùng liền kề.
- `formatParagraphs`: nối dòng bị ngắt cứng giữa câu, không tách ở viết tắt (TP. TS. Mr. N.V.A…), bỏ đoạn rác/trùng, nối mảnh vụn chưa kết thúc.
- Nút "¶ Chuẩn hóa" (trước là "Ngắt đoạn"): làm sạch → bỏ cảnh viết lặp → ngắt đoạn → báo số ký tự đã dọn → kiểm tra từ lạ (AI sửa, rồi hỏi xóa hẳn các từ còn lại, khớp nguyên từ).

#### V12.32.7 — Thời gian truyện (chống "10 chương vẫn một ngày")
- Mốc thời gian tự cập nhật: hậu kỳ ghi `statusState.currentState.time` + `timeLog` theo chương; nếu ô Story Clock trống, prompt dùng mốc này ("THỜI ĐIỂM").
- Story Control có mục THỜI GIAN TRUYỆN: chương phải nêu mốc thời gian, cho phép nhảy thời gian khi sự kiện trước đã khép trọn, tiến triển theo thời gian.
- Ô chọn "Nhịp thời gian giữa các chương" (Tự do / cùng ngày / 1 ngày / vài ngày / 1 tuần) — mặc định Tự do.
- Phát hiện ≥3 chương liên tiếp cùng mốc thời gian → prompt ép chương sau chuyển sang mốc sau.
- Kế hoạch chương có mốc thời gian từng beat; prompt viết bỏ ràng buộc "nối từng giây"; gợi ý chương sau cho phép nhảy thời gian.
- Gate: cờ mềm `timeStagnation` (chỉ cảnh báo, không chặn).

#### V12.32.8 — Neo ngoại hình + số đo cụ thể
- Trường mới `measurements` (Số đo / kích thước cơ thể) cho nhân vật chính (ô nhập) và NV phụ (bảng hồ sơ); hậu kỳ trích/điền khi trống, không ghi đè khi đã có.
- Prompt viết chương: NEO NGOẠI HÌNH — tả 2–4 câu khi xuất hiện lần đầu, cấm tính từ trống ("to", "đầy đặn") nếu không kèm kích thước/so sánh; hồ sơ trống thì tự đặt và giữ nhất quán. Cảnh 18+: nêu kích thước cụ thể cho nhân vật đủ 18 tuổi; dưới 18/không rõ tuổi thì không tả số đo.
- Hồ sơ khóa: ngoại lệ cho ngoại hình trống (được tự đặt).
- Gate: cờ mềm `appearanceVague` (chỉ cảnh báo).

#### V12.32.9 — Chuyển cảnh & người có mặt
- Story Control có mục CẢNH & NGƯỜI CÓ MẶT: người vào/rời cảnh phải có câu chuyển; người đã rời không được nói tiếp; chuyển địa điểm/thời điểm phải có câu chuyển cảnh.
- Kế hoạch chương: mỗi beat ghi địa điểm | ai có mặt | ai vào | ai rời.
- Gate: cờ cứng `sceneViolation` (nhân vật nói/hành động khi không có mặt, lẫn cảnh) -> HARD_FAIL -> viết lại.
- Làm sạch: `{phương án tài chính}` -> giữ chữ, bỏ ngoặc nhọn.

---

## [PATCH_NOTES_V12.32.1_BACKGROUND_POSTPROCESS_TOKEN_CAP] — Ghi chú bản vá

### V12.32.1 — Fix background post-process not updating

- Root cause found: the unified background post-process (`runUnifiedPostProcess`) still requested `maxTokens: 16000`, despite V12.31.2's cap on other API call paths. Models advertising an 8192-token output maximum can reject the call before returning JSON; the fail-safe then preserves old data, making background post-processing appear not to update.
- Fix: cap the unified post-process call at 7800 output tokens, below 8192.
- This addresses the known request-limit rejection. It does not guarantee every task updates if the model truncates the large JSON response; check per-task status/problems when diagnosing other failures.

---

## [PATCH_NOTES_V12.32.0_PROMPT_COMPACTION] — Ghi chú bản vá

### V12.32.0 — Tối ưu ngữ cảnh chương và nhân vật

- Chỉ gửi tóm tắt ngắn của chương gần nhất (tối đa khoảng 1.100 ký tự) và đoạn cuối chương (tối đa 1.400 ký tự) để nối tiếp.
- Ngừng tự động gửi danh sách tóm tắt chương xa trong prompt viết chương. Dữ liệu gốc vẫn được lưu; Story Bible/Current Status/Memory có liên quan tiếp tục là nguồn canon.
- Xóa phần chèn lặp “TÓM TẮT 3 CHƯƠNG GẦN” trong khối bối cảnh vì recent block đã cung cấp thông tin chương gần nhất.
- Danh sách nhân vật được giới hạn tối đa 8, loại nhân vật đã chết và nhân vật phụ/minor cũ không liên quan; hồ sơ nhân vật chính không bị gửi lặp trong roster.
- Character State Tracker giảm còn tối đa 8 mục và bỏ mục đánh dấu đã chết khỏi danh sách trạng thái hoạt động.
- Đồng bộ logic giữa giao diện viết thường và Netlify Background Worker. Không xóa dữ liệu lịch sử trong IndexedDB.

Lưu ý: bộ lọc ưu tiên sự liên quan và metadata hiện có; cần thử trên truyện thực tế để xác nhận các nhân vật quan trọng lâu không xuất hiện vẫn được chọn nhờ tier/locked/quan hệ.

---

## [PATCH_NOTES_V12.31.2_OUTPUT_TOKEN_CAP] — Ghi chú bản vá

### V12.31.2 — Output token cap compatibility fix

- Capped every foreground `callAI` request to max 7,800 output tokens, regardless of a larger task-specific requested limit.
- Capped background worker OpenAI-compatible streaming requests to 7,800 output tokens.
- Capped background retry-doubling logic to 7,800 so retries cannot exceed the same model/provider limit.
- Kept chapter target length and auto-continue logic unchanged; this is a per-request output cap, not a total chapter word cap.
- Added `tests/v12.31.2-output-token-cap.test.js`.

Validation:
- Focused output-token cap test: PASS.
- `npm test`: all runnable tests PASS; four browser E2E suites SKIP because Playwright is unavailable in the environment.
- Not live-tested against the user's AnonRouter key/model.

---

## [PATCH_NOTES_V12.31_PROMPT_CONTEXT_AUDIT] — Ghi chú bản vá

### V12.31 — Prompt Context Audit

#### Thay đổi
- Brief của chương (Chỉ đạo + Gợi ý) không còn bị chèn lặp trong context khi lập kế hoạch/viết chương; hai mục này được chèn một lần tại vị trí chuyên biệt trong prompt.
- Không tự động gửi `autoNextChapterHint` cũ vì trường này không có ID chương xác nhận tính còn hiệu lực. Gợi ý chính thức đang áp dụng là nội dung `nextChapterHint`.
- Quy Tắc Nâng Cao và Quy Tắc Khác được đưa qua một bộ lọc chung; bỏ dòng trùng sau chuẩn hóa khoảng trắng/dấu câu và các dòng được đánh dấu `[TẮT]`, `[OFF]` hoặc `[DISABLED]`. Không dùng gọi AI bổ sung và không gộp các câu khác nghĩa chỉ vì có vài từ giống nhau.
- Current Status hiển thị rõ chương đã xác nhận và tổng chương đã lưu. Nếu status cũ, prompt đánh dấu stale và yêu cầu ưu tiên bằng chứng ở các chương mới hơn thay vì coi status cũ là sự thật hiện tại. Nếu chưa có status, prompt nói rõ không được bịa.
- Thêm kiểm tra xung đột heuristic cho mâu thuẫn rõ ràng về tạo nhân vật mới/sự kiện hoặc tuyến truyện mới; cảnh báo được đưa vào prompt trước khi gọi model. Đây là phát hiện xác suất thấp-rủi-ro, không phải bộ phân tích ngữ nghĩa hoàn hảo.
- Viết tiếp/hoàn tất một chương không còn kéo nhầm Gợi ý chương sau vào ngữ cảnh của chương cũ.
- Đồng bộ code mirrored giữa giao diện và background worker.

#### Giới hạn có chủ đích
- Các quy tắc chung và ngoại lệ được bảo toàn; chỉ loại bỏ trùng văn bản đã chuẩn hóa. Các dòng được ghi tự nhiên là "đã tắt" nhưng không dùng tiền tố `[TẮT]`/`[OFF]` vẫn được giữ để tránh hiểu sai nội dung.
- Không có API/model thật trong unit test; chi phí, độ chính xác đầu ra và Current Status sau phản hồi thật vẫn cần xác minh trên cấu hình người dùng.


##### V12.31.1 — giảm cảnh báo xung đột giả
- Sửa lỗi bộ audit tạo tổ hợp nhiều-mọi-nhiều khiến cảnh báo phình thành hàng chục mục khi có nhiều quy tắc cùng chủ đề.
- Chỉ giữ một cảnh báo cho mỗi cặp nguồn/chủ đề; tối đa 3 cảnh báo chi tiết trong prompt, phần còn lại được gộp thành một dòng tóm tắt.
- Đồng bộ sửa ở giao diện và background worker; thêm regression test với tập quy tắc lớn.

---

## [PATCH_NOTES_V12.30.1_STREAMING_FIX] — Ghi chú bản vá

### V12.30.1 — Fix empty streaming response

#### Root causes addressed
- SSE parser only accepted `data: ` and could drop a final event if no trailing newline.
- Response parsing assumed every `stream=true` response had SSE content type.
- An empty stream failed immediately instead of trying a non-streaming request.

#### Changes
- Accept `data:` with or without a space, CRLF, heartbeat lines, and final unterminated event.
- Check response content type; JSON responses are parsed as normal final responses.
- When SSE ends with no content, retry with `stream` disabled, using the same configured model and prompt. The normal retry limit applies. No empty content is accepted as a successful result.
- No model routing, chapter prompt, postprocessing, Character Database, or Memory merge changes.

#### Tests
- New test simulates final SSE event without newline.
- New test simulates empty SSE then a valid non-streaming JSON response.
- Full `npm test` suite run before packaging. Browser E2E tests are skipped if Playwright/Chromium are unavailable.

---

## [README_V12.30] — Hướng dẫn phát hành

### Xưởng Truyện AI — V12.30

#### Điểm chính

V12.30 gộp **hậu kỳ tự động sau chương** thành một phản hồi AI JSON duy nhất: tóm tắt, cập nhật Character Database, world (địa điểm/vật phẩm/threads), Current Status, long-term memory (Timeline/Foreshadowing/Knowledge Ledger), cảnh báo continuity và gợi ý chương kế tiếp.

- Không đổi model, endpoint, provider hay cơ chế chọn model đã cấu hình trong ứng dụng. Hậu kỳ dùng `job.model` như trước.
- Không chạy extractor AI riêng cho nhân vật/thế giới/status/memory sau khi đã chạy gói tổng hợp.
- Một yêu cầu hậu kỳ chỉ thử một lần. Nếu lỗi mạng/API, JSON không hợp lệ hoặc bị cắt token, hệ thống không gọi AI lần hai để sửa JSON; dữ liệu hậu kỳ cũ được giữ nguyên.
- Dữ liệu nhân vật phải có trích dẫn từ chương; role/occupation/position/faction đã khóa không bị thay chỉ vì AI suy diễn. Nhân vật mới không thể tự nhận tier main/major qua lượt trích xuất này.
- Các trường Current Status chỉ cập nhật khi bằng chứng nằm trong chương và có nội dung hỗ trợ giá trị được đề xuất.
- Bộ nhớ chỉ merge khi đủ ba mảng events/foreshadowing/knowledge. Thiếu schema sẽ bỏ qua toàn bộ phần memory, không tăng con trỏ đồng bộ và không xóa dữ liệu cũ.
- Mục timeline/foreshadowing/knowledge và status lịch sử không bị cắt theo giới hạn số lượng tự động. Foreshadowing/thread đã kết thúc không bị mở lại bởi cập nhật mới thiếu căn cứ.
- `lastMemorySyncChapter` chỉ tăng khi Long-term Memory thực sự được đồng bộ; quét nhân vật hoặc cập nhật Current Status riêng không còn giả báo đã đồng bộ Memory.

#### Những bước vẫn độc lập

Quality Gate vẫn là cổng kiểm tra riêng trước khi ghi Canon; nó không phải extractor hậu kỳ. Các thao tác người dùng bấm riêng như sửa tiếng Việt, quét lại scene, quét lại Character Database/Memory toàn truyện cũng vẫn là thao tác độc lập. Scene Tracker đang tắt theo cấu hình hiện tại và không được tự bật lại.

#### Kiểm thử

Chạy `npm test`. Bộ test V12.30 bao gồm: cập nhật có bằng chứng nhưng giữ hồ sơ cốt lõi, không thêm nhân vật major, giữ status và memory cũ, rollback khi JSON bị cắt, và không merge memory nếu schema thiếu.


#### V12.30.1 — Sửa lỗi phản hồi trống (streaming)
- Đọc đúng SSE có CRLF, `data:` không có dấu cách và event cuối không có newline.
- Nếu endpoint không trả `text/event-stream`, xử lý response JSON bình thường.
- Nếu stream không có nội dung, tự thử lại một lần theo non-streaming trong cùng lượt gọi; không trả/ghi nội dung rỗng.
- Không thay đổi model, prompt viết chương, Quality Gate hoặc pipeline bảo vệ Character/Memory.
- Có test mô phỏng SSE thiếu newline và fallback khi stream rỗng.

---

## [PATCH_NOTES_V12.30_UNIFIED_POSTPROCESS] — Ghi chú bản vá

### V12.30 — Hậu kỳ một lần gọi, bảo vệ Canon và Memory

- Gộp Tóm tắt, Character Database, World, Current Status, Long-term Memory, Continuity warnings và gợi ý chương sau vào một phản hồi JSON duy nhất.
- Chuyển cả hai đường chạy: hậu kỳ job nền thủ công và hậu kỳ sau khi tạo chương nền.
- Dùng model đã cấu hình (`job.model`), không thay model/provider. Không gọi thêm AI để sửa JSON hoặc retry lần hai trong hậu kỳ tổng hợp.
- JSON thiếu/không hợp lệ hoặc bị cắt: không thực hiện merge; nếu một lỗi xảy ra giữa quá trình merge thì khôi phục trạng thái và chương trước lượt hậu kỳ.
- Chỉ nhận trường Character/Status/World/Memory có evidence xuất hiện trong nội dung chương. Giữ role/occupation/position/faction và tier của nhân vật đã có; nhân vật mới không thể tự lên main/major.
- Memory merge nguyên tử theo schema: cần đủ events, foreshadowing, knowledge. Không xóa lịch sử cũ, không cắt giới hạn số mục và không mở lại foreshadowing đã kết thúc.
- Sửa con trỏ `lastMemorySyncChapter`: việc chỉ quét nhân vật hoặc cập nhật Status không còn tự nhận là đã đồng bộ Long-term Memory. Khi hợp nhất job nền, con trỏ không bị lùi.
- Thêm kiểm thử regression và kiểm tra tích hợp số lượt gọi AI hậu kỳ.

#### Các kiểm thử

- `node tests/v12_30_unified_postprocess.test.js`
- `node tests/worker.integration.js`
- `npm test`

Lưu ý: Quality Gate và các thao tác do người dùng gọi riêng (ví dụ: sửa tiếng Việt, quét lại Memory toàn truyện) vẫn là luồng độc lập; V12.30 gộp toàn bộ gói hậu kỳ tự động của chương, không gộp việc viết lại toàn thân chương vào prompt trích xuất dữ liệu.

---

## [README_V12.29] — Hướng dẫn phát hành

### Truyen335 V12.29 — Cost-safe optimization

#### Mục tiêu
Giảm một số lần gọi AI hậu kỳ và token ngữ cảnh lặp lại mà không đổi model, không giảm mục tiêu số từ chương, không bỏ Quality Gate, không đổi Ending Anchor/Auto-continue.

#### Thay đổi
- Summary quá dài được rút gọn cục bộ tại ranh giới câu thay vì gọi AI thêm một lần chỉ để rút gọn. Lượt retry đầu tiên vẫn được giữ nếu bản tóm tắt thiếu tiêu đề/không bám nguồn.
- Trích xuất Character Database tăng kích thước lô từ 9.000 lên 12.000 ký tự và giảm phần chồng lấn từ 700 xuống 400 ký tự để giảm việc gửi lại cùng một đoạn. Không bỏ phần văn bản chương nào.
- Trích xuất World State tăng kích thước lô từ 10.000 lên 13.000 ký tự và giảm phần chồng lấn từ 700 xuống 400 ký tự.
- Danh sách thread trong prompt trích xuất World State giới hạn 20 thread gần nhất và 140 ký tự mô tả mỗi thread. Dữ liệu lưu trong truyện không bị cắt; chỉ ngữ cảnh gửi cho lượt trích xuất được rút gọn.
- Giữ nguyên định tuyến model, prompt viết chương, mục tiêu số từ, giới hạn Auto-continue, Quality Gate, Ending Anchor và thứ tự lưu chương.

#### Lưu ý
Các thay đổi tối ưu hậu kỳ có thể làm AI ít nhìn thấy mô tả rất cũ của thread trong một lượt trích xuất World State; dữ liệu gốc vẫn được bảo toàn. Nếu truyện có rất nhiều thread đang mở, cần theo dõi nhật ký hậu kỳ vài chương đầu.

#### Kiểm thử
Chạy `npm test`. Bốn bài E2E được đánh dấu bỏ qua nếu môi trường không có Playwright/Chromium.

---

## [PATCH_NOTES_V12.29_COST_OPTIMIZATION] — Ghi chú bản vá

### V12.29 — Tối ưu chi phí an toàn

- Không thay đổi model/provider/định tuyến model.
- Không giảm mục tiêu số từ hoặc cắt nội dung chương.
- Summary >450 từ: bỏ lượt gọi AI chỉ để rút gọn; cắt cục bộ ở ranh giới câu quanh 420 từ. Kiểm tra grounded vẫn chạy sau bước này.
- Character extraction: lô 12k ký tự, overlap 400 (trước: 9k/700).
- World extraction: lô 13k ký tự, overlap 400 (trước: 10k/700).
- World extraction prompt chỉ gửi 20 thread gần nhất, mô tả tối đa 140 ký tự; dữ liệu lưu trữ không thay đổi.
- Quality Gate và Auto-continue được giữ nguyên để không làm giảm độ ổn định độ dài/chất lượng.

---

## [PATCH_NOTES_V12.28.3_ENDING_TARGET] — Ghi chú bản vá

### V12.28.3 — Fix `getEndingTarget` thực tế trong ZIP

#### Lỗi
Safari/iOS báo runtime: `Can't find variable: getEndingTarget`.

#### Nguyên nhân
V12.28.2 có các chỗ gọi `getEndingTarget()` trong `index.html` nhưng bản ZIP thực tế lại thiếu **khai báo hàm**. Ghi chú V12.28.1 nói đã khôi phục helper nhưng helper không nằm trong nguồn `shared/core.js`, vì vậy lỗi có thể quay lại khi đồng bộ code.

#### Cách sửa
Đưa `getEndingTarget()` trở lại nguồn sự thật `shared/core.js`, sau đó chạy `node scripts/sync-shared.js` để đồng bộ tự động sang:
- `index.html`
- `netlify/functions/write-chapter-background.js`

Logic:
- ưu tiên Ending Anchor lấy từ `hint`
- nếu không có thì lấy từ `directive`
- dùng lại `extractEndingAnchor()` hiện có

#### Kiểm tra
- `getEndingTarget` helper: 3/3 PASS
- JavaScript syntax `index.html`: PASS
- Shared sync check: PASS
- Unit Quality Gate: 33/33 PASS
- Characters: 11/11 PASS
- Worker: 37/37 PASS
- V12.20: 16/16 PASS
- V12.22b: 8/8 PASS
- V12.23: 9/9 PASS
- Status/Memory soft hậu kỳ: PASS
- Routing 18+: 7/7 PASS
- Security: 12/12 PASS
- Worker integration: PASS
- Gate-fail integration: PASS
- E2E: bỏ qua vì môi trường thiếu Playwright/Chromium

---

## [PATCH_NOTES_V12.28.2_STATUS_MEMORY_FIX] — Ghi chú bản vá

### V12.28.2 — Fix ⚠ Status/Memory sau Viết thường

#### Lỗi
Sau khi Viết thường đã hoàn tất và lưu chương, hậu kỳ Status/Memory có thể lỗi do thiếu ngân sách thời gian hoặc cạnh tranh gọi API. Hai lỗi này bị đưa vào `autoUpdateIssues`, khiến chương hiển thị `⚠ Status/Memory` dù phần viết đã thành công.

#### Đã sửa
- Giữ tối thiểu khoảng 6 phút cho pha Status/Memory bằng cách cho Character/World dừng sớm hơn khi gần hết thời gian nền.
- Status và Memory chạy nối tiếp để giảm khả năng tranh chấp/rate-limit.
- Giảm ngân sách token cho Status/Memory để giảm thời gian và nguy cơ JSON bị cắt.
- Status/Memory trở thành **soft post-process tasks**: thất bại không làm chương đã lưu thành `SYNCED_WITH_WARNINGS`; trạng thái lỗi nằm trong `chapter.postProcess.tasks` và diagnostics để có thể retry.
- Chapter list không còn hiển thị `⚠ Status/Memory`; các cảnh báo cứng khác vẫn giữ nguyên.
- Khôi phục helper `getEndingTarget()` của V12.28.1.

#### Không đổi
- Viết thường vẫn là luồng chính/stream bình thường.
- Lưu chương xảy ra trước khi gửi hậu kỳ server.
- Netlify Background Job tiếp tục chạy hậu kỳ server khi người dùng khóa/rời iPhone.
- Ending Anchor được giữ nguyên.

#### Kiểm thử
- Client JavaScript syntax: PASS
- Worker JavaScript syntax: PASS
- Test hồi quy V12.28.2 Status/Memory soft post-process: PASS
- Toàn bộ `npm test`: PASS
- 4 bộ E2E: SKIP vì môi trường thiếu Playwright/Chromium.

---

## [PATCH_NOTES_V12.28.1_FIX] — Ghi chú bản vá

### V12.28.1 — Fix getEndingTarget

#### Bug
Runtime error: `Can't find variable: getEndingTarget`.

#### Cause
V12.28's client code referenced `getEndingTarget()` from the V12.24 Ending Anchor flow, but the helper was missing after merging the Fast Write + Server Post-Process architecture.

#### Fix
Restored the helper:
- Prefer Ending Anchor extracted from the chapter hint.
- Fall back to the directive.
- Reuses existing `extractEndingAnchor()` logic.

#### Verification
- JavaScript syntax: PASS
- Shared client/worker sync: PASS
- Quality Gate: 33/33
- Characters: 11/11
- Worker: 37/37
- V12.20: 16/16
- V12.22b: 8/8
- V12.23: 9/9
- Background create-job: 5/5
- Routing: 7/7
- Security: 12/12
- Worker integration: PASS
- Gate-fail integration: PASS
- E2E: skipped because Playwright/Python is unavailable in the test environment.

---

## [README_V12.28] — Hướng dẫn phát hành

### Truyen335 V12.28 — Normal Write + Server Post-Process

#### Luồng chính
1. Bấm **Viết chương** bình thường.
2. AI stream nội dung trên app.
3. Quality Gate xử lý như trước.
4. Chương được `persist()` ngay sau PASS.
5. App báo **Đã viết xong**.
6. App tạo một Netlify Background Job với `mode=postprocess`.
7. Netlify Background Function chỉ chạy hậu kỳ: Summary, Character, World, Current Status, Memory, Scene, Next Chapter Hint và Canon Sync.
8. Khi mở app lại, job-status trả kết quả và app merge dữ liệu vào story.

#### Không còn
- Background Job sinh chương.
- `runCanonPostProcess()` chạy trong browser sau khi viết.
- Hậu kỳ làm trình viết phải chờ hoàn thành.

#### Nút thủ công
`☁ Chạy hậu kỳ server (tắt máy được)` chỉ dùng để retry hậu kỳ của chương hiện tại; không sinh chương mới.

#### Kiểm thử
- Unit/worker/security: PASS.
- JavaScript syntax: PASS.
- E2E giao diện/background: chưa chạy do môi trường kiểm thử thiếu Playwright/Chromium.

---

## [PATCH_NOTES_V12.28_POSTPROCESS] — Ghi chú bản vá

### V12.28 — Server-side Post-Process Only

- Normal chapter writing remains client-side: stream -> Quality Gate -> persist chapter -> report completion.
- Removed browser-side `runCanonPostProcess()` from the normal generation path.
- After chapter persistence, the app creates a Netlify Background Job with `mode=postprocess`.
- Netlify Background Function runs summary, character/world updates, Current Status, Memory, Scene, next-chapter hint, and Canon sync.
- Job state is stored in Netlify Blobs and can continue after the iPhone is locked/left, subject to Netlify Background Function limits.
- Existing manual background-write button is converted to a manual post-process retry button; it no longer writes a chapter.
- Existing job polling/merge/security mechanisms are retained.

---

## [PATCH_NOTES_V12.26_FAST_WRITE] — Ghi chú bản vá

### V12.26 — Fast Write + Fast Settings

#### Mục tiêu
- Chương được lưu và hiển thị ngay sau khi hoàn thành phần viết/Quality Gate.
- Canon/Character/Current Status/Memory/Snapshot/Next Chapter Hint chạy hậu kỳ nền, không giữ trạng thái “Đang viết” trong suốt hậu kỳ.
- Thiết lập được ghi vào IndexedDB store `storyMeta` riêng, nhỏ hơn nhiều so với bản ghi toàn bộ truyện.
- Bản ghi truyện đầy đủ vẫn được lưu debounce 1.75s để giữ tương thích backup/import hiện tại.
- Background Job Netlify hiện có tiếp tục được sử dụng; job được lưu trên Netlify Blobs nên không phụ thuộc tab iPhone đang mở.

#### Luồng mới
`Viết → lưu chương → hiển thị → trả UI → hậu kỳ nền`

Thiết lập:
`đổi setting → ghi StoryMetaData nhỏ ngay → full story save debounce`

#### An toàn
- Không xóa Character, Current Status, Memory, Snapshot, Knowledge Ledger hay các dữ liệu Canon.
- Chương mới được đánh dấu `SYNCING` trong lúc hậu kỳ; kiểm tra chuyển chương tiếp theo vẫn chặn cho tới khi Canon sync hoàn tất, tránh race condition.
- Export/full backup vẫn dùng record đầy đủ hiện tại.

#### Kiểm thử
- Unit/integration: PASS.
- JS syntax: PASS.
- Shared client/worker sync: PASS.
- Browser E2E chưa chạy được trong môi trường build vì Playwright Chromium executable chưa được cài.

---

## [PATCH_NOTES_V12.25_BACKGROUND_DIAGNOSTICS] — Ghi chú bản vá

### V12.25 — Background extraction / deadline safety

#### 1. NV bị cắt cụt ở cuối lô
- Khi model trả `finishReason=length` hoặc parser phát hiện JSON bị cắt, hệ thống vẫn salvage các object hoàn chỉnh.
- Sau đó, nếu còn đủ thời gian, worker gọi **một lượt bổ sung riêng** với prompt JSON siêu gọn để lấy các nhân vật còn thiếu.
- Danh sách tên đã lấy được gửi vào lượt bổ sung để tránh lặp.
- Chỉ merge dữ liệu được parse hợp lệ.

#### 2. Từ `nilông`
- Bổ sung `nilông`/`nilon` vào whitelist tiếng Việt để không còn báo nhầm `Từ lạ cần kiểm tra: nilông`.

#### 3. Status / Memory bị bỏ qua vì hết thời gian
- NV và Thế giới không được bắt đầu lô mới khi còn dưới **4 phút**.
- Status và Memory chỉ bỏ qua khi còn dưới **90 giây**.
- Mục tiêu là giữ một cửa sổ thời gian an toàn cho pha Status + Memory thay vì để extraction chiếm hết deadline.

#### 4. Đồng bộ
- Sau sửa đã chạy `node scripts/sync-shared.js`.
- Client và worker dùng cùng `shared/core.js`.

#### 5. Kiểm thử
- Tất cả unit/integration hiện có: PASS.
- 4 E2E bị SKIP do môi trường test không có Playwright/Python.

---

## [PATCH_NOTES_V12.24_ENDING_ANCHOR_GATE] — Ghi chú bản vá

### V12.24 — Ending Anchor Gate

#### Fix chính
- Không còn coi “đủ số từ” là điều kiện duy nhất để kết chương.
- Nếu Gợi ý/Mệnh lệnh có `Ending Anchor` / `Cú chốt` / `Kết chương` hoặc mốc kết tương đương, engine phải đi tới mốc đó trước khi dừng.
- Nếu chương đã đạt mục tiêu từ nhưng chưa tới Ending Anchor, Auto-continue tiếp tục trong giới hạn hardMax.
- Khi đã đủ từ nhưng brief đã kết quá nhanh, engine vẫn ưu tiên chèn diễn biến **trước đoạn kết**, giữ nguyên Ending Anchor.
- Viết nền dùng cùng helper Ending Anchor và cùng logic với viết thường.
- Nút “Viết Tiếp” thủ công được bổ sung một lượt nối tự động nếu lượt đầu vẫn chưa tới Ending Anchor, tránh phải bấm lại.

#### An toàn
- Không mở arc mới chỉ để đủ từ.
- Không thêm biến cố lớn/nhân vật quan trọng mới chỉ để kéo dài.
- Khi đã thực hiện Ending Anchor thì dừng, không kéo hậu cảnh sau điểm kết.
- HardMax vẫn được giữ nguyên.

#### Kiểm thử
- `node --check netlify/functions/write-chapter-background.js`: PASS
- Toàn bộ unit/integration tests: PASS
- 4 bộ E2E bị SKIP vì môi trường test hiện không có Playwright/Python.

---

## [PATCH_NOTES_V12.23_CONTINUE] — Ghi chú bản vá

### V12.23 – Auto-continue đúng số lượt + báo lý do dừng
- Số lượt viết thêm = đúng số "Auto-continue" đã đặt (client + worker; 18+ không còn bị ép tối thiểu 4).
- Bỏ giới hạn cố định 2 lần chèn diễn biến: số lần chèn tự động, chỉ bị giới hạn bởi số lượt Auto-continue.
- Lượt thất bại (AI trả rỗng, lặp, chèn <120 từ, sai ngôn ngữ, API lỗi) không còn làm vòng lặp dừng hẳn: tính là 1 lượt rồi thử lượt kế.
- Khi chương còn thiếu nhiều (<85% mục tiêu): bỏ câu "không kéo dài để đạt chỉ tiêu", yêu cầu viết tiếp diễn biến mới, không kết chương sớm.
- Lượng từ xin mỗi lần chèn/viết tiếp = phần còn thiếu chia cho số lượt còn lại.
- Chưa đạt mục tiêu: status + chẩn đoán chương ghi rõ lý do dừng (hết lượt, AI trả rỗng, lặp, API lỗi, chạm giới hạn từ...).

### V12.23 – Gợi ý chương sau
- Viết thường: gợi ý chương sau giờ HIỆN ở ô Gợi ý (trước đây chỉ lưu vào biến ẩn autoNextChapterHint nên ô luôn trống).
- Ô trống hoặc vẫn là gợi ý đã dùng cho chương vừa viết -> thay bằng gợi ý mới. Nếu bạn đã tự gõ gợi ý khác trong lúc viết -> giữ nguyên.
- Tạo gợi ý thất bại (API lỗi/AI trả rỗng): xóa gợi ý cũ đã dùng, báo ở status + chẩn đoán chương. Bản nền cũng xóa gợi ý cũ khi thất bại.
- Bản nền: lúc gộp kết quả không ghi đè gợi ý nếu bạn đã gõ gợi ý mới trong lúc job chạy.

### V12.23 – Viết thoải mái hơn để đủ số từ
- Thêm "KẾ HOẠCH ĐỘ DÀI" (shared/core.js: buildLengthPlan, dùng chung client + worker): tách gợi ý thành các nhịp, chia ngân sách từ cho từng nhịp (tổng ≈ 105% mục tiêu, nhịp kết chương ≈ nửa ngân sách), đặt ở cuối prompt.
- Dặn AI: mỗi nhịp phải đủ bối cảnh/hành động/thoại/nội tâm/hệ quả, cấm tóm tắt nhịp thành 1–2 đoạn, chỉ viết nhịp cuối khi đã gần đủ từ, nếu thiếu thì mở rộng phần giữa chứ không kết chương.
- Khi có gợi ý/mệnh lệnh: bỏ ràng buộc "chỉ 1–3 sự kiện chính" (mâu thuẫn với gợi ý nhiều nhịp), thay bằng "đúng các nhịp trong gợi ý, không thêm biến cố lớn ngoài gợi ý".

### V12.23 – MỞ RỘNG CUỐI (khi vẫn thiếu từ)
- Sau khi hết lượt Auto-continue mà chương vẫn dưới mục tiêu (95% khi có gợi ý, 100% khi không): app nhờ AI VIẾT LẠI TOÀN BỘ chương dài hơn, giữ nguyên thứ tự/sự kiện/thoại/điểm kết, mở rộng mỗi cảnh (ưu tiên cảnh ngắn nhất). Tối đa 2 lần, cả viết thường và viết nền.
- Chỉ nhận bản mới khi dài hơn bản cũ ít nhất 120 từ, không ngắn hơn 90% bản cũ, đúng tiếng Việt; vượt giới hạn tối đa thì cắt. Không đạt thì giữ nguyên bản cũ và ghi lý do vào status/chẩn đoán.
- Hàm dùng chung: buildExpandPrompt, acceptExpandedChapter (shared/core.js); test mới tests/v12_23.test.js.

### V12.23 – Lỗi 404 khi viết nền (Netlify)
- Client: nếu /create-job trả 404, app dò thêm /job-status để báo đúng nguyên nhân (chưa deploy netlify/functions, mở app ngoài domain Netlify hoặc file://, hay chỉ create-job lỗi build). Poll job-status trả 404 thì báo ngay thay vì im lặng chờ.
- create-job: kích hoạt write-chapter-background bằng URL env trước; nếu 404 thử tiếp host của chính request (domain tùy chỉnh khác env.URL). Nếu vẫn 404, lỗi nêu rõ URL đã thử.
- Test mới tests/v12_23_netlify.test.js (4 ca). package.json -> 12.23.0.

### V12.23 – "Đang tạo job…" quá lâu
- create-job chỉ chờ lệnh kích hoạt background tối đa 8 giây (biến TRIGGER_TIMEOUT_MS); quá hạn thì vẫn trả thành công kèm cảnh báo để app không treo và có thể tắt máy.
- create-job trả và ghi log `timings` (payloadKB, purgeMs, saveMs, triggerMs, totalMs). App hiện các số này khi tổng > 6 giây.
- App đếm giây khi đang tạo job, hiện dung lượng gửi (KB) và tự hủy sau 45 giây với thông báo rõ.
- Sửa nhãn phiên bản ở đầu app thành v12.23.

### V12.23 – "Lỗi gửi job: HTTP 400" trơn
- Lỗi gửi job giờ kèm thân phản hồi của server (nếu có), dung lượng đã gửi và 3 khóa truyện nặng nhất. Các lỗi 404/401 vẫn giữ thông báo riêng.

### V12.23 – Sửa HTTP 400 "đã gửi 9240 KB" (payload quá nặng)
- Nguyên nhân: mỗi chương mang theo tới 7–10 bản chụp trạng thái (stateSnapshots, mỗi bản là bản sao cả thế giới/nhân vật) + versions cũ; truyện 8 chương => ~8,4 MB chỉ riêng chapters, vượt giới hạn 6 MB/request của Netlify.
- Client không gửi stateSnapshots/stateSnapshot/versions của chương cũ lên server (worker không dùng). Khi hợp nhất kết quả job, client khôi phục các trường này từ bản local (khớp theo vị trí + tiêu đề) nên không mất lịch sử snapshot/phiên bản.
- Nếu payload vẫn > 5 MB: báo lỗi rõ ngay tại client (kèm 3 khóa nặng nhất) thay vì gửi rồi nhận HTTP 400.
- Test mới: tests/e2e_bg_slim.py (7 ca).

### V12.23 – Từ báo cáo job: tiếng Anh lẫn vào truyện + mở rộng cuối bị bỏ
- Xóa câu/đoạn tiếng Anh do model "nghĩ to" lẫn giữa truyện (removeEnglishLeaks trong shared/core.js, gắn vào stripForeign nên client + worker đều dùng). Chỉ xóa khi đoạn/câu gần như không có dấu tiếng Việt và chứa ≥ 3 từ khóa tiếng Anh; không đụng lời thoại ngắn hay từ mượn. Worker ghi "Đã xóa N câu/đoạn tiếng Anh…" vào cảnh báo.
- Worker: vòng viết tiếp dừng sớm (khi chương ≥ 60% mục tiêu) nếu thời gian còn dưới 270s để chừa chỗ cho bước mở rộng cuối; bước mở rộng cuối cần ≥ 150s còn lại (trước đây ngưỡng 90s quá thấp so với thời gian thực của 1 lần viết lại cả chương nên luôn bị bỏ qua). Thông báo bỏ qua nay ghi rõ số giây còn lại.

### V12.23 – Viết nền GIỐNG viết thường
- Prompt viết chương chính được tách thành hàm buildMainWritePrompt (index.html) — viết thường gọi hàm này; viết nền cũng gọi đúng hàm đó (proseOnly: không đòi TIÊU ĐỀ/NỘI DUNG vì tên chương do hệ thống tạo).
- Cơ chế mới: scripts/sync-shared.js sao NGUYÊN VĂN 23 hàm dựng ngữ cảnh/prompt từ index.html vào worker (khối CLIENT-MIRROR, nguồn sự thật = index.html). Sửa các hàm đó ở index.html rồi chạy `node scripts/sync-shared.js` (test sync-check sẽ báo lệch nếu quên).
- Worker nay dùng: buildContextBlock (story bible, style, arc, outline, thẻ nhân vật, địa điểm, vật phẩm, threads, foreshadowing, timeline, kiến thức nhân vật, lịch sử cảnh...), buildRecentBlocks, bước lập KẾ HOẠCH CHƯƠNG bằng AI (buildChapterPlanPrompt; cần còn ≥150s), và các quy tắc của viết thường (ngân sách sự kiện, nhân vật phụ, chống lặp, bố cục đoạn ngắn, miêu tả...).
- Tham số lấy mẫu lượt viết chính = viết thường: temperature 0.85, frequency_penalty 0.25/0.45, presence_penalty 0.25/0.35 (18+/thường).
- Giữ lại 2 điểm chỉ có ở viết nền: "cú chốt" Ending Anchor ở cuối prompt, và rào chắn tuổi khi 18+ mà chưa bật mature.
- Worker tự bổ sung các danh sách còn thiếu của truyện (arcs, outlinePlans, locations...) trước khi dùng code của viết thường.
- Test mới: tests/worker.mirror.test.js. Test cũ cập nhật marker nhận diện lượt viết chính ("Bạn đang viết CHƯƠNG THỨ") và bỏ qua lượt lập kế hoạch.
- CÒN KHÁC: vòng viết tiếp/chèn/mở rộng cuối vẫn là 2 đoạn code riêng (đã chỉnh cùng quy tắc); viết nền có quản lý thời gian 13,5 phút; viết thường có streaming.

---

## [PATCH_NOTES_V12.22_FREE_WRITING] — Ghi chú bản vá

### V12.22 — Bỏ "chia đoạn làm dày", AI tự do sáng tác thân chương, chỉ khóa Ending Anchor

#### Ý tưởng
Gợi ý chương là xương sống. AI được thêm cảnh phụ/thoại/nội tâm/giác quan để chương tự nhiên và dài hơn,
nhưng không phá canon, không mở arc lớn, không đổi hướng truyện. Chỉ Ending Anchor là điểm bắt buộc ở cuối chương.

#### Thay đổi
##### Bỏ
- `expandChapterInPlace` (worker) và `expandChapterInPlaceClient` (index.html): bước chia chương thành khối ~900 từ, gọi AI viết lại từng khối. Nhanh hơn (ít lượt gọi AI), không còn rủi ro khối viết lại làm lệch đoạn kết.

##### Prompt (worker + client)
- Bỏ các câu cấm "không thêm cảnh/biến cố", "không tự tạo ... chỉ để kéo dài".
- Thay bằng quyền tự do rõ ràng + giới hạn: 1–3 sự kiện chính, không phá canon, không arc lớn, không nhân vật quan trọng mới, không lộ thông tin chương sau.
- Mỗi nhịp trong gợi ý = một cảnh đầy đủ; cảnh phụ phải có chuyển biến mới, không lặp, không độn chữ.
- Ending Anchor: chỉ chạm ở đoạn cuối, đủ dài mới kết, viết xong thì dừng hẳn. Câu "KẾT THÚC" không còn khuyến khích kết sớm khi có gợi ý.
- `storyControlPrompt` (dùng chung): thêm dòng "ĐƯỢC TỰ DO ... BÊN TRONG sự kiện chính".

##### Cơ chế đạt độ dài mới: "chèn diễn biến trước đoạn kết"
- Trước đây có gợi ý mà chương ngắn thì không viết tiếp (sợ bịa sau cú chốt) → phải dùng bước làm dày.
- Nay: nếu có gợi ý, model đã kết (không bị cắt) mà chương < 95% mục tiêu, hệ thống tách 1–4 đoạn cuối (~150 từ) làm "đoạn kết", nhờ AI viết PHẦN NỐI ở giữa (thêm cảnh phụ, thoại, nội tâm) rồi ghép lại: thân + phần nối + đoạn kết. Ending Anchor luôn nằm cuối, không bị viết đè.
- Tối đa 2 lượt chèn; phần chèn < 120 từ hoặc lặp thì bị bỏ; câu cuối phần chèn cụt thì lùi về câu hoàn chỉnh.
- Nếu model bị cắt giữa chừng (hết token) thì vẫn viết nối như cũ (anchor chưa tới).
- Không có gợi ý: giữ nguyên cách viết tiếp cũ.

##### Nhận diện Ending Anchor
- `extractClosingBeat` nhận thêm "Ending Anchor", "anchor kết", "điểm neo kết".

##### Giới hạn độ dài
- `chapterWordLimits().hardMax`: 1,15× → 1,4× mục tiêu. Chương tự do dài hơn không bị `trimToWordLimit` cắt mất anchor.

#### Không đổi
- Auditor/Quality Gate, Story Control (tối đa 3 sự kiện/4 NV có tên), Knowledge Ledger, No Retcon, rào chắn tuổi 18+, định tuyến model 18+.
- Auditor đã dặn "không đếm scene beat/hành động nhỏ" vào mainEventCount nên cảnh phụ không bị tính là sự kiện chính.

#### Test
- `tests/v12_20.test.js`: viết lại 3 test "mở rộng tại chỗ" thành test chèn diễn biến (anchor ở cuối, chèn ≤2 lượt, ≥95% mục tiêu, không vượt hardMax, phần chèn lặp bị bỏ); thêm test nhận diện "Ending Anchor" và hardMax 1,4×.

#### Lưu ý khi dùng
- Độ dài mục tiêu nên đặt thực tế cho model của bạn; chương tự do có thể dài/ngắn lệch nhau hơn trước.
- Vì AI tự thêm chi tiết, hãy giữ bước cập nhật Character/World/Timeline sau mỗi chương để bắt chi tiết lệch canon sớm.
- Đây là bản kiểm thử bằng test tự động với model giả lập; chất lượng văn thực tế phụ thuộc model bạn dùng. Nên chạy thử 2–3 chương rồi xem anchor có nằm đúng cuối và có bị độn chữ không.

---

### V12.22.1 — Sửa lỗi chương bị viết LẶP 2 LẦN (bản 2 chỉ diễn đạt khác)

#### Triệu chứng
Chương gồm 2 bản cùng diễn biến, khác câu chữ; bản 2 bắt đầu bằng `TIÊU ĐỀ: ... / NỘI DUNG:` dính liền ngay sau câu cuối bản 1 (không xuống dòng).

#### Nguyên nhân
Model viết lại cả chương từ đầu trong lượt viết tiếp (hoặc xuất 2 lần trong một lượt), kèm nhãn tiêu đề. Các bộ lọc cũ chỉ bắt được trường hợp **trùng gần nguyên văn với 3 đoạn mở đầu**; bản 2 diễn đạt lại ngay từ đoạn đầu nên lọt.

#### Sửa (shared/core.js → đồng bộ cho cả app và worker nền)
- `splitByInnerLabels`: nhận diện nhãn `TIÊU ĐỀ:`/`NỘI DUNG:` nằm GIỮA văn bản, kể cả dính liền câu trước. Nếu phần sau lặp phần trước thì bỏ; nếu không lặp (nhãn thừa) thì chỉ bỏ nhãn, giữ cả hai phần.
- `_findRestartIndex`: dò "bản viết lại" theo **đường chéo thứ tự** — các đoạn lần lượt khớp (dù diễn đạt khác) với các đoạn phía trước, cùng trình tự. So khớp theo từ đặc trưng (bỏ từ quá phổ biến như cô/hắn/váy) nên bắt được cả khi viết lại bằng câu chữ khác. Có lùi ngược vài đoạn để cắt đúng điểm bắt đầu bản 2.
- `dedupeRepeatedScene`: chạy 3 tầng — nhãn → trùng nguyên văn → diễn đạt lại. Mặc định giữ **bản 1**; chỉ giữ bản 2 khi bản 1 bị cụt còn bản 2 kết gọn và không ngắn hơn đáng kể.
- `dropRestartedContinuation`: bỏ nhãn đầu lượt viết tiếp; cắt phần viết tiếp nếu nó chỉ kể lại nội dung đã có.
- Lệnh viết tiếp (app + worker): thêm câu cấm xuất `TIÊU ĐỀ:`/`NỘI DUNG:` và cấm viết lại chương từ đầu.

#### Sửa chương CŨ đã bị lặp
Mở chương đó → nhấn nút **¶ Ngắt đoạn** → đồng ý khi app hỏi có cắt phần lặp (dùng cùng `dedupeRepeatedScene`).

#### Test
`tests/v12_22b.test.js` (8 test, dựng từ chính chương bị lỗi): có nhãn dính liền; không nhãn; chương bình thường không bị cắt nhầm; bản 1 cụt thì giữ bản 2; nhãn thừa nhưng nội dung khác; viết tiếp diễn đạt lại; viết tiếp có nhãn; viết tiếp bình thường.

#### Giới hạn
- Ngưỡng nhận diện đã chọn thận trọng (cần ≥3 đoạn khớp liên tiếp đúng thứ tự). Nếu bản 2 chỉ lặp 1–2 đoạn thì không bị cắt.
- Cách chữa tận gốc vẫn là prompt/model: model hay "quên" đã viết rồi viết lại khi chương dài; hạ độ dài mục tiêu hoặc đổi model sẽ giảm tần suất.

---

## [PATCH_NOTES_V12.21_LENGTH] — Ghi chú bản vá

### V12.21 — Sửa chương bị ngắn (2500–3800 từ so với mục tiêu 4500)

#### Nguyên nhân
- Prompt có gợi ý ghi "chấp nhận ngắn hơn" / "không phải chỉ tiêu bắt buộc" -> model dừng ngay khi hết ý.
- Bước mở rộng tại chỗ (V12.20) chia khối quá nhỏ (~550 từ), loại khối nếu không dài hơn 12%, prompt chỉ có 1 câu chung chung -> thường thất bại âm thầm.

#### Thay đổi (giữ nguyên nguyên tắc: KHÔNG bịa thêm sự kiện/cảnh/nhân vật ngoài gợi ý)
- Prompt viết chương (worker + index.html): độ dài tối thiểu 95% mục tiêu, đạt bằng cách sống chậm từng ý với 5 kỹ thuật (giác quan, nội tâm giằng co, lặp có biến tấu, thoại/khoảng lặng, môi trường), mỗi khối có chuyển biến nhỏ, đổi nhịp câu, không tóm tắt/nhảy cóc.
- expandChapterInPlace: khối ~900 từ (trước ~550), tối đa 6 khối; prompt chứa 5 kỹ thuật; ngưỡng giữ khối 12% -> 8%; khối thất bại được thử lại 1 lần với nhắc nhở mạnh hơn.
- Ngưỡng kích hoạt mở rộng và cảnh báo "Thiếu từ": 90% -> 95% mục tiêu.

#### Chưa làm (cần quyết định)
- index.html (chế độ viết thường) vẫn chưa có bước mở rộng tại chỗ; chỉ đổi prompt. Bước mở rộng chỉ chạy ở worker nền.

#### V12.21.1 — Sửa lỗi model thinking nhúng kế hoạch tiếng Anh vào chương
- Thêm stripThinkingOutput(): xóa <think>/<thinking> tags và khối lập kế hoạch tiếng Anh ở đầu output trước câu chuyện tiếng Việt.
- Hàm được gọi bên trong stripForeign() nên tự động áp dụng ở mọi điểm xử lý output trong cả worker lẫn client.

---

## [PATCH_NOTES_V12.20_WRITING_FIXES] — Ghi chú bản vá

### V12.20 — Sửa 3 lỗi viết chương (từ lỗi ghép, câu cuối cụt, bịa thêm sau gợi ý)

#### 1. Từ lỗi kiểu "mươititude", "bọcampo", "bănnton"
- Nguyên nhân: model sinh nhầm token (nhiệt độ 0.82, không top_p). Bộ dò cũ chỉ bắt từ KHÔNG dấu nên các từ lỗi CÓ DẤU lọt hoàn toàn.
- findStrayWords nay kiểm tra cấu trúc âm tiết tiếng Việt (onset + nguyên âm + vần cuối) cho cả từ có dấu.
- Worker: tự sửa — gửi các CÂU chứa từ lỗi cho model, chỉ nhận câu sửa nếu bỏ được từ lỗi, độ dài gần câu gốc và giữ >=70% các từ còn lại (acceptWordFix). Tối đa 2 vòng, lỗi thì giữ nguyên văn bản.
- Viết văn: temperature 0.82 -> 0.7, thêm top_p 0.88 (và top_k 40 với OpenRouter).

#### 2. Chương cụt giữa câu ("... Rồi cô")
- trimToWordLimit: cắt ở câu hoàn chỉnh gần nhất (ngưỡng 70% giới hạn, trước đây chỉ 180 từ cuối nên đoạn dài bị cắt cứng giữa câu).
- Cuối pipeline viết chương: nếu câu cuối chưa có dấu kết thúc -> nhờ model viết nốt 1–3 câu (closeDanglingEnding, biết "cú chốt" của bạn); thất bại -> lùi về câu hoàn chỉnh gần nhất.
- Bản Quality Gate viết lại cũng không được để cụt.

#### 3. Viết thêm cái khác sau khi đã hết gợi ý / không bám gợi ý
- Nguyên nhân: bản nền thấy chưa đủ số từ mục tiêu (mặc định 5000) nên tự gọi "Viết TIẾP"; lệnh đó không chứa gợi ý và còn bảo "viết tiếp sang diễn biến kế tiếp" -> model hết ý nên bịa.
- Nay: có gợi ý/mệnh lệnh thì KHÔNG viết nối thêm ở cuối nữa (chỉ nối khi model bị cắt giữa chừng).
- Chương còn ngắn (<90% mục tiêu) -> MỞ RỘNG TẠI CHỖ THEO TỪNG ĐOẠN (expandChapterInPlace). Model không viết nổi ~4500 từ trong một lần (thường dừng ~3000; bản đầu viết cả chương một lần chỉ tăng 2867 -> 3121 từ nên bị loại), nên chương được chia thành các khối ~550 từ, mỗi khối có chỉ tiêu từ riêng (gốc x hệ số, tối đa x2.2), viết lại song song 3 khối/lượt. Giữ nguyên sự kiện/thứ tự/cú chốt, chỉ làm dày miêu tả, nội tâm, thoại.
- Khối nào không dài hơn >=12%, bị cắt, lạc đề hoặc (khối cuối) đổi đoạn kết thì giữ bản gốc của khối đó; khối làm vượt giới hạn từ cũng giữ bản gốc. Tối đa 2 lượt.
- Thêm 'alô, hello, okay, bye' vào từ mượn hợp lệ.
- Lệnh viết tiếp (khi cần) mang theo kế hoạch + "cú chốt" và dặn dừng ngay khi viết xong ý cuối.
- Prompt viết chương: thêm khối "KẾ HOẠCH CHƯƠNG — NGUỒN SỰ THẬT DUY NHẤT" đặt CUỐI prompt, luật: đúng thứ tự, không thêm sự kiện/nhân vật, ý cuối là điểm kết, câu cuối phải hoàn chỉnh. Dòng có "Cú chốt / Kết thúc chương / Kết chương..." được trích ra nhắc riêng.
- Dòng độ dài khi có gợi ý: mục tiêu chỉ mang tính tham khảo, không bịa thêm để đủ từ.

#### Test
- tests/v12_20.test.js (14 test), đã đăng ký trong tests/run-all.js.

---

## [PATCH_NOTES_V12.19_SFX] — Ghi chú bản vá

### V12.19 — Không báo nhầm tượng thanh là "từ lạ"
- findStrayWords bỏ qua tiếng cười/hét/thở viết không dấu: Aaaa, hahaha, hihi, hehe, huhuhu, kekeke, hmmm, shhh, psst, ahhh...
- Từ tiếng Anh thật (afternoon, Somewhere, until...) vẫn bị báo như cũ.
- Sửa ở shared/core.js, đã sync sang index.html và write-chapter-background.js. Thêm test.
- Thêm từ mượn thường gặp vào danh sách hợp lệ: vest, sofa, mascara, vecni, Chanel, Lelo, Gucci, Dior... (please, Splat vẫn bị báo vì là tiếng Anh thật).

#### Cảnh 18+: dẫn vào / sau cảnh bị ngắn
- EROTIC_STYLE_PROMPT (client + worker) thêm "NHỊP CẢNH 3 PHẦN": dẫn vào (~25%) – diễn biến/cao trào (~50%) – sau cảnh (~25%), mỗi phần đoạn văn riêng.
- Gợi ý chương sau khi là 18+: dài hơn (Chi tiết 600–850 từ, Gọn 230–380) và bắt buộc tách 3 phần dẫn vào / diễn biến / sau cảnh.
- Nhận diện 18+ để chuyển sang model 18+ quét 24.000 ký tự cuối thay vì 6.000.

#### Khóa địa điểm mở chương
- Prompt viết chương (client + worker): có khối "ĐOẠN KẾT CHƯƠNG TRƯỚC" + quy tắc KHÓA CỨNG địa điểm/thời điểm/người có mặt ở cảnh mở đầu.
- Gợi ý chương sau (client + worker): nhịp mở chương phải cùng địa điểm với đoạn kết; chuyển địa điểm phải ghi rõ.
- Quality Auditor nhận thêm đoạn kết chương trước; mở chương lệch địa điểm mà không chuyển cảnh = hard failure (kích hoạt viết lại có mục tiêu).
- Worker: gợi ý 18+ cũng có nhịp 3 phần và nhiều token hơn.
- Nhịp 3 phần chỉ là mặc định: gợi ý/mệnh lệnh người dùng chỉ nêu 1–2 phần thì chỉ viết các phần đó.

#### Nghề/chức vụ nhân vật không tự đổi (thư ký -> giám đốc)
- Hồ sơ nhân vật gửi cho AI cập nhật nay kèm "nghề/chức vụ GỐC (giữ nguyên)" cho MỌI nhân vật (trước đây NV khóa không được hiện hồ sơ nên AI tự suy).
- Prompt thêm quy tắc: không suy nghề từ cách xưng hô/làm việc với sếp; chỉ đổi khi chương kể rõ thăng chức/bổ nhiệm.
- role/occupation/position/faction đã có giá trị chỉ đổi khi explicitCoreChange=true và changeEvidence trích đúng từ chương (>=70% từ có trong chương). Áp dụng cả NV đã mở khóa; client + worker.

#### Hồ sơ nhân vật: trường trống được điền (giới tính, tuổi, nghề...)
- Trước: AI không được hỏi tuổi/giới tính/chức vụ/tóc/mắt... (không có trong schema) và khóa hồ sơ gốc chặn CẢ việc điền trường còn trống (kể cả NV AI mới tạo, vì mặc định coreLocked=true).
- Nay: schema thêm age, gender, position, speech, height, bodyType, hair, eyes, skin; mỗi NV kèm mục "CHƯA CÓ" để AI điền; khóa chỉ chặn GHI ĐÈ giá trị đã có. Đặc điểm thân thể ổn định chỉ điền khi trống.

#### Rà soát toàn bộ hồ sơ nhân vật: trường hiển thị nhưng AI không bao giờ cập nhật
- Thêm vào schema + merge (client & worker): speech (cách nói riêng), strength (điểm mạnh), independentPlot (tuyến truyện riêng, cộng dồn), voice/scent/style/scars/tattoos (điền khi trống), schedule, và nhóm 18+ (sexualExperience, boundaries, taboos, preferences, attractionToMC, tensionWithMC, consentNotes — cộng dồn).
- Quan hệ: thêm respect, affection, attraction, suspicion, tension, boundaries cho cả quan hệ với NVC và quan hệ NV-NV. Bản worker trước đây bỏ sót hoàn toàn relationshipWithMain.
- Rào chắn tuổi: NV dưới 18 (hoặc tuổi không rõ -> vẫn ghi như cũ) không ghi trường 18+ và attraction/boundaries.
- Hồ sơ Nhân Vật Chính do người dùng sở hữu: AI chỉ cập nhật vị trí/thể trạng/tinh thần/bí mật (giữ nguyên thiết kế cũ).

#### Xóa chương kèm bộ nhớ
- Trước: chỉ khi xóa CHƯƠNG CUỐI (và chương trước có snapshot) thì bộ nhớ mới rollback; xóa chương giữa không đụng tới nhân vật/địa điểm/vật phẩm sinh ra từ chương đó, số chương của địa điểm/vật phẩm cũng không được đánh lại.
- Nay: (khi bật "Xoá kèm bộ nhớ") xóa các NV / địa điểm / vật phẩm xuất hiện lần đầu ở chương bị xóa và không xuất hiện ở chương nào sau; giữ mục được dùng lại ở chương sau; đánh lại số chương; dọn quan hệ/tracker trỏ tới NV đã xóa; dọn khỏi snapshot các chương còn lại (để xóa chương cuối sau này không "sống lại"). NV thêm tay (không có chương xuất hiện đầu) không bị xóa.
- Thêm test tests/e2e_delete.py.

#### Viết lại gợi ý theo ý người dùng
- Thêm nút "✍️ Viết lại gợi ý theo ý tôi": gõ ý tưởng (ngắn cũng được) vào ô "Gợi ý chương sau" rồi bấm; AI viết lại thành gợi ý đầy đủ, bám đúng chi tiết/thứ tự/mốc kết chương của bạn, chỉ bổ sung nhịp nối. Có nút "↩ Khôi phục" để quay lại bản bạn gõ.
- Ý tưởng 18+ cũng được tự chuyển sang model 18+; trần độ dài tự nới theo độ dài ý tưởng.
- Nút "Tạo lại gợi ý chương sau" cũ vẫn tạo mới hoàn toàn từ chương vừa viết.

---

## [PATCH_NOTES_V12.18_DUP_CHARACTERS] — Ghi chú bản vá

### V12.18 — Sửa nhân vật bị nhân đôi + công cụ 🧹 Dọn nhân vật trùng

#### Triệu chứng (từ ảnh chụp)
Character Database có thêm mục **"nhân vật chính"** (nhãn chung) và **"Bùi Lạc"** (cùng là nhân vật chính) bên cạnh hồ sơ Nhân Vật Chính đã khai báo.

#### Nguyên nhân (đã tái hiện bằng test)
1. **Worker nền không biết `mainCharProfile`.** `mergeCharacter` chỉ so tên với danh sách `characters` nên mỗi lần AI trả tên nhân vật chính (hoặc nhãn "nhân vật chính") là tạo mục MỚI. Client có xử lý, worker thì không.
2. Prompt trích xuất của worker không nói tên nhân vật chính → AI tự đặt nhãn "nhân vật chính".
3. Client chỉ nhận ra nhân vật chính khi trùng tên tuyệt đối, không nhận nhãn chung hay tên ngắn/bí danh.

#### Đã sửa (client + worker dùng chung trong `shared/core.js`)
- `resolveCharacterTarget`: tên MC, nhãn chung ("nhân vật chính", "main character", "protagonist"...), bí danh của MC → cập nhật hồ sơ có sẵn, KHÔNG tạo mục mới. Bí danh của NV thường cũng được nhận.
- Prompt NV (client + worker) nay nêu tên nhân vật chính và cấm tạo mục "nhân vật chính".
- `saveMainCharFromForm` giữ lại `aliases` khi lưu hồ sơ.

#### Công cụ mới: 🧹 Dọn nhân vật trùng (Cài đặt → Character Database)
- Banner + số lượng khi có mục nghi trùng; mở modal xem từng gợi ý.
- Gợi ý chỉ khi có căn cứ: trùng tên MC, nhãn chung, tên ngắn trùng một phần với đúng 1 ứng viên. Có từ chối: **Giữ riêng**.
- **Gộp** không mất dữ liệu: điền ô trống, nối ý mới, tier cao hơn, khoảng xuất hiện rộng nhất, gộp quan hệ, đổi tên tham chiếu ở NV khác, lưu bí danh để lần sau AI không tạo lại.
- Gộp vào Nhân Vật Chính chỉ điền ô còn trống, không ghi đè nội dung bạn đã nhập.
- ↶ **Hoàn tác** 1 lần gộp gần nhất (trong bộ nhớ, mất khi tải lại trang).
- Không tự xóa/gộp gì nếu bạn không bấm.

#### Kiểm thử
- Mới: `tests/characters.test.js` (11 test, gồm đúng ca trong ảnh: MC=Bùi Lạc, "nhân vật chính", "Ân" → "Ân" không bị đụng).
- E2E giao diện 29 → 33 (banner, modal, gộp, hoàn tác).
- Sửa `worker.integration.js`: test cũ mong NV "Lan" (chính là MC) được tạo thành mục DB — đó chính là lỗi trên.
- `npm test`: tất cả PASS.

#### Lưu ý
- Mục **"Ân"** KHÔNG được gợi ý vì không có căn cứ cho thấy trùng ai. Nếu thực ra "Ân" là tên khác của một nhân vật, hãy tự xóa/sửa tên trong Character Database.
- Sửa này ngăn trùng MỚI; dữ liệu đã có cần bấm 🧹 một lần để dọn.
- Chưa chạy với API thật.

---

## [PATCH_NOTES_V12.17b_HINT_ADULT] — Ghi chú bản vá

### V12.17b — Gợi ý chương sau kiểu "Gọn theo nhịp" + tóm tắt/gợi ý 18+ không né tránh

Mang hai bản vá từ nhánh V12.15 sang V12.17 (bản V12.17 chưa có hai phần này).

#### 1. Kiểu gợi ý "Gọn theo nhịp + điểm kết chương"
- Ô chọn mới **Độ dài & cách viết gợi ý** (dưới "Kiểu gợi ý chương sau"): *Chi tiết (400–600 từ)* (mặc định, như cũ) hoặc *Gọn theo nhịp + điểm kết chương (150–260 từ)*.
- Kiểu Gọn: 1–3 đoạn kể lần lượt các nhịp chính (ai làm gì, ở đâu, đạo cụ/thiết lập nào, hệ quả); dòng cuối "→ Kết chương ở: …".
- `hintFormat` được lưu cùng truyện, gửi kèm job nền (`create-job.js` đã thêm vào danh sách trường cho phép) và dùng cho cả gợi ý tự động sau chương.

#### 2. Tóm tắt/gợi ý chương 18+ dùng model 18+, bớt nói giảm nói tránh
- Chương 18+ → tóm tắt và gợi ý chạy bằng model 18+ (`adultModelFor` ở client, `extractModelFor` ở worker).
- `buildSummaryPrompt(text, n, names, adult)` (shared/core.js): chương 18+ thì thuật lại cụ thể, đúng từ ngữ của chương.
- Prompt gợi ý thêm quy tắc "ĐỘ TRỰC DIỆN" cho chương 18+ (mọi nhân vật là người trưởng thành).

---

## [PATCH_NOTES_V12.17_SHARED_GATE] — Ghi chú bản vá

### V12.17 — Gộp client và worker (Bước 2)

Không đổi kiến trúc. Phần Quality Gate / Story Control / Sync được chuyển vào `shared/core.js` để client và worker dùng chung một bản.

#### 1. Đã chuyển vào shared/core.js
**Gate thuần (phần 1)**
- `evaluateReview` (chuẩn hoá kết quả Auditor, hard failure, verdict theo ngưỡng 90/75), `rewriteInstructionsText`, `checkRewriteAcceptable` (từ chối bản sửa rỗng / ngắn hơn 60%), `backupBeforeRewrite` (giữ tối đa 3 bản gốc), `mergeAiContinuityWarnings`, `gateMaxAttempts`.

**Dựng prompt + vòng lặp + Sync (phần 2)**
- `normalizeStoryControl`, `storyControlPrompt` — trước đây client và worker viết hai bản khác nhau.
- `buildQualityReviewPrompt`, `buildRewritePrompt` — khung, quy tắc, schema dùng chung; ngữ cảnh (outline hay brief, canon) do mỗi bên truyền vào.
- `runGateLoop(chapter, deps, opts)` — vòng chấm → sửa → chấm lại dùng chung; không gọi AI trực tiếp mà nhận hàm `review/rewrite/selfCheck/onStatus/onChange/shouldStop` từ client hoặc worker.
- `gateHardChecks`, `gateKnownNames`, `knownNameMentions` — kiểm tra cứng xác định (ngôn ngữ, đủ nội dung, continuity mức cao) và đếm tên nhân vật đã biết.
- `nextCanonVersion`, `applyCanonSync`, `mergeCanonVersion`, `isGateFailedResult` — tăng canonVersion, đánh dấu Sync, hợp nhất phiên bản, nhận biết kết quả job nền trượt Gate.

Client giữ `normalizeStoryControlClient()` / `storyControlPromptClient()` / `qualityHardCheck()` làm lớp bọc mỏng để các chỗ gọi cũ không phải đổi.

#### 2. Thay đổi hành vi (có chủ đích)
- **Worker nay chạy kiểm tra cứng như client**: bản thảo ≤ 100 từ, có chữ không phải tiếng Việt, hoặc có cảnh báo continuity mức cao → hard failure. Trước đây chỉ client làm.
- **Prompt Auditor của worker** có thêm khối QUY TẮC, kiểm tra cứng và schema giống client; **prompt viết lại của worker** có thêm CANON CONTEXT (cắt 15.000 ký tự).
- **Story Control của client** dùng bản đầy đủ của worker (thêm giới hạn thread mới, danh sách trường khoá, dòng ưu tiên canon khi xung đột). Ảnh hưởng cả prompt lập kế hoạch/viết chương của client.
- `qualityHardCheck`: bỏ hai mục giữ chỗ `events_budget`, `character_budget` (luôn ok, gây hiểu lầm). Ngân sách sự kiện/nhân vật vẫn bị chặn bởi `evaluateReview` dựa trên số Auditor đếm.
- Mới: hệ thống đếm tự động tên nhân vật đã biết xuất hiện trong văn bản, đưa cho Auditor làm bằng chứng tham khảo. Đây chỉ là dữ kiện cho Auditor, không tự gây trượt Gate.
- Worker không cắt/chuẩn hoá mảng warnings/suggestions/rewriteInstructions/dimensions trước đây; nay giống client.
- `chapter.sync` của worker nay giữ các trường có sẵn (như `startedAt`) thay vì ghi đè hoàn toàn; `changes` mặc định `[]`.

#### 3. Kiểm thử (`npm test`: 9 bộ, tất cả PASS)
- `tests/core.test.js`: 14 → **33** (prompt, Story Control, kiểm tra cứng, vòng lặp Gate với 9 tình huống, canonVersion/Sync, nhận biết trượt Gate).
- `tests/worker.test.js`: 29 → **31** (kiểm tra cứng dùng chung ở worker, prompt Auditor chứa quy tắc/schema/tên đã biết).
- `tests/worker.integration.js`: thêm kiểm tra Sync/canonVersion/review sau khi PASS. Đã đối chiếu: cùng bài kiểm tra cũng pass trên bản v12.16b, nên hành vi khi PASS không đổi.
- Mới `tests/worker.gatefail.js`: chạy cả handler với Auditor luôn trượt → đúng 3 lần chấm + 2 lần sửa, lưu bản gốc, **không chạy** cập nhật NV/Thế giới/Tóm tắt/Memory, không Sync, canonVersion không tăng, API key bị xoá.
- `tests/e2e_bg.py`: 11 → 15 (job nền trượt Gate ở client).
- E2E giao diện 29/29 không đổi.

#### 4. Còn lại / chưa kiểm
- Chưa chạy với API thật: tỷ lệ trượt Gate, chi phí và ngưỡng 90/75 chưa được hiệu chỉnh.
- Số sự kiện chính vẫn do Auditor (AI) đếm; chưa có cách xác định bằng code.
- Hai bên vẫn tự dựng phần ngữ cảnh (client: outline + Story Bible; worker: `buildContext`) và tự gọi API — cố ý để nguyên vì khác nền tảng (state toàn cục vs `job.storyState`).
- Hợp nhất state job nền vào local (`mergeBackgroundChapter`) và các bước trích xuất sau chương vẫn tách đôi; phần trích xuất sẽ gộp ở Bước 3 (v12.18).

---

## [PATCH_NOTES_V12.16b_GATE_FIXES] — Ghi chú bản vá

### V12.16b — Sửa lỗi Quality Gate (Bước 1)

Bản vá trên V12.16. Không đổi kiến trúc; chỉ sửa lỗi và bổ sung test cho Quality Gate.

#### Lỗi đã sửa
1. **Hậu xử lý dùng bản nháp cũ.** Sau khi Gate viết lại chương, tóm tắt / NV / Thế giới / Status / Memory / rà chính tả vẫn chạy trên bản TRƯỚC khi sửa. Nay `text` và `rawForPolish` được cập nhật theo bản đã qua Gate.
2. **Bản sửa có thể ghi đè chương bằng nội dung rỗng/ngắn.** Bản sửa ngắn hơn 60% bản gốc (hoặc rỗng) bị từ chối, giữ nguyên bản thảo, ghi cảnh báo vào review (client + worker).
3. **Mất bản gốc khi viết lại.** Bản gốc được lưu vào `versions` (tối đa 3) trước khi thay.
4. **Lỗi API khi viết lại làm mất cả bản nháp (client).** Nay bắt lỗi, giữ bản nháp ở REVISION_REQUIRED; bấm Dừng khi đang sửa cũng giữ bản nháp.
5. **Sửa tay chương đã Sync chặn viết chương kế.** `MODIFIED_AFTER_SYNC` nay chỉ hiện ghi chú, không chặn.
6. **Cảnh báo continuity cộng dồn qua các lượt.** Mỗi lượt thay cảnh báo AI cũ bằng cảnh báo mới (giữ cảnh báo trùng câu).
7. **Client bỏ qua kết quả trượt Gate của job nền.** `job-status` trả thêm `qualityGateFailed`; client báo đúng "chưa vượt Quality Gate — chưa ghi Canon" và hợp nhất `canonVersion`.
8. Giới hạn số lần sửa: client và worker cùng tối đa 3.

#### Tính năng mới
- Nút **🔍 Duyệt lại** (thanh công cụ chương): chấm lại chương hiện tại, KHÔNG tự viết lại.
  - Đạt → đồng bộ Canon (chương cuối) hoặc đánh dấu đã duyệt (chương cũ, dùng 🔄 Rescan nếu cần).
  - Trượt → hỏi có duyệt thủ công (override) không.
- Công tắc **🛡 Quality Gate** trong Cài đặt (bật/tắt theo từng truyện).
- Hậu xử lý Canon tách thành hàm `runCanonPostProcess()` dùng chung cho viết chương và Duyệt lại.

#### Kiểm thử
- Unit worker: 19 → 29 (10 test Gate mới: PASS, hard failure, ngân sách sự kiện/nhân vật, ngưỡng 90/75, viết lại + lưu versions, bản sửa bị từ chối, lỗi API, hết số lần thử, review trả rác, tắt Gate).
- E2E giao diện: 21 → 29 (mock API nay trả review hợp lệ; thêm test PASS/MODIFIED_AFTER_SYNC/không chặn/trượt Gate/bản sửa bị từ chối/chặn chương kế/Duyệt lại/tắt Gate).
- `npm test`: tất cả PASS.

#### Chưa làm / chưa kiểm
- Đường merge job nền khi trượt Gate (client) chưa có test tự động; mới kiểm bằng đọc code.
- Chưa chạy với API thật nên chưa biết tỷ lệ trượt Gate và chi phí thực tế; ngưỡng 90/75 chưa được hiệu chỉnh.
- `qualityHardCheck`: hai kiểm tra ngân sách sự kiện/nhân vật vẫn là chỗ giữ chỗ (do AI chấm) — thuộc Bước 2.
- Logic Gate vẫn nằm ở cả client lẫn worker — thuộc Bước 2.

---

## [PATCH_NOTES_V12.16_QUALITY_GATE] — Ghi chú bản vá

### V12.16 — Quality Gate / Canon Pipeline

#### Thay đổi chính
- Chapter có state: DRAFTED → SELF_CHECKING → REVIEWING → APPROVED → SYNCED.
- Quality Auditor trả JSON, chấm điểm và phát hiện hard-failure.
- Hard rules: tối đa 1–3 sự kiện chính, giới hạn nhân vật có tên, unauthorized important character, knowledge violation, retcon.
- Review fail sẽ rewrite có mục tiêu, tối đa 3 lần.
- Draft không được cập nhật Memory/Canon trước Quality PASS.
- Chương kế tiếp bị chặn nếu chương trước chưa Sync.
- Canon version tăng sau mỗi Sync.
- Manual edit sau Sync đánh dấu MODIFIED_AFTER_SYNC/STALE.
- Background Writer dùng cùng Quality Gate trước khi chạy post-processing.
- Backup JSON giữ review/sync/canonVersion/chapterDrafts.

#### Kiểm thử
- npm test: tất cả unit/integration/security/routing PASS; E2E bỏ qua vì môi trường ZIP không có Playwright/Python.

---

## [PATCH_NOTES_V12.15_PARAGRAPHS] — Ghi chú bản vá

### V12.15 — Tự ngắt đoạn (hết "khối văn đặc")

**Nguyên nhân:** prompt viết chương không có quy tắc bố cục và không có bước hậu xử lý ngắt đoạn, nên model viết chương dài thành một khối liền.

#### Thay đổi
- `shared/core.js`: thêm `formatParagraphs()` — chia khối văn > 500 ký tự thành đoạn 2–3 câu, mỗi lượt thoại (“…”, —) một đoạn riêng, đoạn cách nhau 1 dòng trống. Không đổi/mất chữ, chạy nhiều lần vẫn ổn định.
- Prompt client (mục 9 "BỐ CỤC") và SYSTEM_PROMPT của worker: yêu cầu đoạn ngắn + thoại riêng dòng.
- Áp dụng `formatParagraphs` sau khi AI viết chương / viết tiếp (client + worker nền).
- Nút **¶ Ngắt đoạn** trên thanh công cụ chương: sửa ngay các chương cũ đã có.
- Thêm test hồi quy trong `tests/worker.test.js`.

#### Bổ sung V12.15: chống lặp cảnh + từ lạ
**Triệu chứng:** chương chứa 2 bản của cùng một cảnh (bản 2 viết lại từ đầu, dính liền bản 1) và có từ lạ chen giữa câu ("HttpServletResponse", "czerwony"…).

- Prompt viết tiếp (client + worker): bỏ khối "đoạn đầu chương / STYLE LOCK" (nguyên nhân model chép lại từ đầu), thêm lệnh cấm viết lại từ đầu.
- `dropRestartedContinuation()`: bỏ các đoạn viết tiếp trùng nội dung đã có; nếu trùng toàn bộ thì bỏ lượt đó và dừng.
- `dedupeRepeatedScene()`: nếu chương có bản viết lại phần đầu (kể cả dính liền không dòng trống) thì cắt từ chỗ lặp. Áp dụng khi tạo chương và trong nút ¶ (có hỏi xác nhận).
- `findStrayWords()`: cảnh báo từ Latinh lạ (worker ghi vào issues, nút ¶ hiện ở thanh trạng thái).
- Lượt viết tiếp phía client: temperature 0.9→0.82, frequency_penalty 0.55→0.15, presence_penalty 0.4→0.1 (penalty cao ép model chọn token hiếm nên sinh từ lạ).
- Test hồi quy mới trong `tests/worker.test.js`.

#### Bổ sung V12.15b: sửa từ lạ bằng AI + bớt báo nhầm
- Mở rộng danh sách từ mượn hợp lệ (silicon, latex, temp, remote, camera…) để `findStrayWords` không báo nhầm.
- `fixStrayWordsInText()` (client): chỉ gửi các đoạn có từ lạ cho AI, thay bằng tiếng Việt hợp ngữ cảnh, kiểm tra độ dài/ngôn ngữ trước khi nhận.
- Nút ¶ Ngắt đoạn: nếu phát hiện từ lạ sẽ hỏi "Sửa từ lạ" rồi gọi hàm trên (dùng model chính đang chọn).
- Prompt "Sửa chính tả" (polishVietnamese) nêu rõ danh sách từ lạ cần thay.

#### V12.15c: rà soát cuối
- `formatParagraphs`: đoạn ngắn (<500 ký tự) có thoại xen kẽ (kể cả ngoặc kép thẳng ") giờ cũng được tách thoại.
- `dedupeRepeatedScene`: chỉ cắt khi bản lặp trùng với các đoạn MỞ ĐẦU chương (tránh cắt nhầm câu lặp có chủ ý giữa chương).
- `dropRestartedContinuation`: chặt hơn (đoạn ≥15 từ, độ trùng ≥70%) để không bỏ nhầm phần viết tiếp thật.
- `findStrayWords(text, tên_nhân_vật)`: tên nhân vật đã khai báo không bị báo là từ lạ (client + worker).

---

## [PATCH_NOTES_V12.14_BUGFIX] — Ghi chú bản vá

### V12.14 — Bugfix sau kiểm thử toàn diện

#### Lỗi nghiêm trọng đã sửa
1. **Job nền luôn chết 500** (`ReferenceError: chapter is not defined`, V12.13): dòng gán `chapter.control` nằm trước khi object chương được tạo. Nay `control` được đưa vào object trả về.
2. **Từ khóa 18+ khớp chuỗi con** (`includes`) làm câu thường ngày như "cà phê", "cây bút", "phản kháng", "phê duyệt", "Mông Cổ" bị coi là nội dung 18+ và bị chuyển sang model NSFW + prompt erotic. Nay khớp theo từ nguyên vẹn (Unicode) và bỏ các từ quá chung (bú, phê, thúc, lần đầu, kích thích, ngực, mông; "quan hệ" -> "quan hệ tình dục/xác thịt").
3. **`trimToWordLimit` làm mất toàn bộ xuống dòng/đoạn văn/thoại** khi chương bị cắt do vượt giới hạn. Nay cắt theo vị trí ký tự, giữ nguyên đoạn.
4. **Công tắc "Tự động tạo" không có xử lý** và đổi "Khoảng cách" ném `ReferenceError: scheduleNextAuto`. Đã thêm bộ hẹn giờ (chỉ viết khi nút đang rảnh, không lưu trạng thái bật qua lần mở lại).

#### Test
- Cập nhật `tests/worker.integration.js`, `tests/e2e.py` cho khớp V12/V12.10.
- Thêm `tests/worker.routing.js` (7 ca định tuyến 18+/rào chắn tuổi/Story Control).
- Thêm 3 test hồi quy vào `tests/worker.test.js`.

#### Nâng cấp bảo mật & bảo trì (V12.14)
- **Mã truy cập** `APP_PASSCODE` (tuỳ chọn) cho `create-job`; ô nhập ở giao diện, lưu riêng trên thiết bị.
- **Kiểm tra endpoint**: chỉ https, chặn địa chỉ nội bộ/metadata cloud, có thể giới hạn bằng `ALLOWED_API_HOSTS`.
- **Cảnh báo cấu hình** (thiếu `JOB_SECRET`/`APP_PASSCODE`) hiển thị trong lúc job chạy.
- **Tự dọn job** quá hạn (`JOB_TTL_HOURS`, mặc định 48h) và **xoá job ngay** khi client đã hợp nhất (`job-status?ack=1`).
- `ALLOWED_ORIGIN` để giới hạn CORS.
- **Gộp code dùng chung** client/worker vào `shared/core.js` + `scripts/sync-shared.js` + `tests/sync-check.js`.
- `normalizeName` của client nay cũng gộp khoảng trắng thừa như worker (tránh trùng nhân vật do dấu cách kép).
- Nhãn độ dài ghi rõ đếm theo âm tiết.
- `npm test` chạy toàn bộ; thêm `tests/security.test.js`, `tests/e2e_bg.py`; xem `SECURITY_SETUP.md`.

---

## [PATCH_NOTES_V12.13_STORY_CONTROL] — Ghi chú bản vá

### V12.13 — Story Control / Continuity Hardening

Nâng cấp từ V12.12, giữ nguyên UI và pipeline hiện tại, tập trung vào độ ổn định của prompt/continuity.

#### Đã thay đổi

##### 1. Story Control Layer
- Thêm lớp kiểm soát trước khi viết ở cả client và background writer.
- Giới hạn mặc định: tối đa 3 sự kiện chính/chương.
- Giới hạn mặc định: tối đa 4 nhân vật có tên xuất hiện trực tiếp.
- Giới hạn thread mới: tối đa 3.

##### 2. State Lock / No Retcon
- Thêm danh sách trường canon quan trọng cần giữ ổn định.
- Không tự sửa lịch sử, canon, ký ức, quan hệ, cảnh giới, năng lực, vật phẩm quan trọng, bí mật/lời hứa hoặc luật thế giới chỉ vì chương hiện tại thuận tiện hơn.
- Mâu thuẫn được định hướng để giữ lại và xử lý có chủ đích.

##### 3. Character Agency
- Prompt yêu cầu nhân vật quan trọng phải có mục tiêu, động cơ, phản ứng và lựa chọn riêng.
- Hạn chế việc nhân vật trở thành công cụ để đẩy plot.

##### 4. Chapter Focus
- Giữ nguyên kiến trúc NONE / SECONDARY / PRIMARY của V12.12.
- Story Control xác định rõ Chapter Focus không phải giấy phép mở tuyến truyện mới.

##### 5. Continuation
- Các lượt viết tiếp cũng nhận Story Control Layer để tránh việc phần nối chương tự phá giới hạn và continuity của phần đầu.

##### 6. Diagnostics
- Chapter lưu metadata `control` gồm focus và các giới hạn chính để hỗ trợ kiểm tra/debug.

#### Kiểm tra
- `node --check netlify/functions/write-chapter-background.js`: PASS
- Inline JavaScript trong `index.html`: PASS
- `node tests/worker.test.js`: 12/12 PASS

#### Không thay đổi
- Không thay đổi cấu trúc UI chính.
- Không thay đổi Current Status V2 CHANGE → VALIDATE → MERGE.
- Không thay đổi schema ChapterData hiện có ngoài metadata control.
- Không thay đổi cơ chế API/model routing ngoài việc prompt nhận thêm lớp Story Control.

---

## [PATCH_NOTES_V12.12_CHAPTER_FOCUS] — Ghi chú bản vá

### V12.12 — Chapter Mature Focus: NONE / SECONDARY / PRIMARY

#### Mục tiêu
Tách rõ **quyền cho phép nội dung trưởng thành** (`mature`) khỏi **ý định của từng chương** (`chapterMatureFocus`).

#### Ba chế độ
- `NONE`: chương không có trọng tâm trưởng thành. Không tự chèn hoặc kéo dài nội dung trưởng thành, kể cả khi chương trước có nội dung tương tự.
- `SECONDARY`: nội dung trưởng thành chỉ được dùng khi brief/mệnh lệnh hoặc diễn biến hiện tại yêu cầu rõ; không tự biến thành tuyến chính.
- `PRIMARY`: chủ đề trưởng thành là một trọng tâm của chương; hệ thống vẫn phải bám brief, không tự mở tuyến mới.

#### Thay đổi
##### `index.html`
- Thêm selector `Trọng tâm trưởng thành của chương` với `NONE / SECONDARY / PRIMARY`.
- Thêm `chapterMatureFocus` vào state mặc định, hydrate, persist và backup/background story state.
- Thêm các helper chuẩn hóa/đọc trọng tâm.
- `NONE` chặn force-routing NSFW và auto-routing.
- Cập nhật phần hướng dẫn routing để hiển thị rõ trọng tâm hiện tại.
- Prompt chương nhận chỉ thị trọng tâm để tránh tự chèn nội dung trưởng thành ngoài ý định.

##### `netlify/functions/write-chapter-background.js`
- Đồng bộ `chapterMatureFocus` với background worker.
- `NONE` thắng mọi auto-detection.
- `SECONDARY` chỉ routing khi có tín hiệu rõ từ brief/mệnh lệnh.
- `PRIMARY` có thể dùng thêm heat detection trong chế độ auto.
- Background prompt nhận cùng chỉ thị trọng tâm với luồng local.

#### Tương thích
State cũ không có `chapterMatureFocus` sẽ tự dùng `NONE`.

#### Kiểm tra
- `node --check` cho script trong `index.html`: PASS
- `node --check` cho `write-chapter-background.js`: PASS
- `node tests/worker.test.js`: **12/12 PASS**

---

## [PATCH_NOTES_V12.11] — Ghi chú bản vá

### V12.11 — Current Status V2: CHANGE → VALIDATE → MERGE + Evidence

#### Phạm vi
Chỉ nâng cấp module **Current Status**. Không thay đổi Character Database, Memory Engine, Summary, Snapshot hay các module khác.

#### Thay đổi chính

- Không còn cho AI viết lại/ghi đè toàn bộ `statusState` sau mỗi chương.
- Current Status được xử lý theo pipeline:
  `Chapter → Change Extraction → Validation → Merge → Current Status`.
- AI chỉ trả về các trường thực sự thay đổi.
- Mỗi thay đổi hợp lệ phải có `evidence`.
- Không có bằng chứng thì không merge.
- Thông tin cũ không bị xóa chỉ vì chương mới không nhắc lại.
- Xung đột được giữ trong `statusState.conflicts` thay vì tự ý ghi đè.
- `statusState.changeLog` lưu lịch sử các lần merge gần nhất.
- `statusState.schemaVersion = 2`.
- Danh sách nhân vật hiện có được kiểm kê sau mỗi lần cập nhật; nhân vật không thay đổi hiển thị `Không có thay đổi đáng kể`.
- Current Status không cho AI tự tạo nhân vật mới.
- Các trường nhân vật được hỗ trợ gồm tuổi, ngoại hình, cơ thể, quần áo, dấu vết, tu vi, trạng thái tu vi, cảm xúc, phục tùng, tuân thủ quy tắc, quan hệ xã hội, nghề nghiệp, nơi ở, quan hệ tình cảm, điểm yếu, mục tiêu, vật phẩm, tính cách bên ngoài/bên trong, tâm lý, quan hệ và trạng thái thể chất/tinh thần.

#### Tương thích dữ liệu cũ

`normalizeStatusState()` chuyển dữ liệu `statusState` cũ sang cấu trúc V2 khi Current Status được cập nhật lần đầu. Dữ liệu legacy vẫn được đọc và format nếu chưa được nâng cấp.

#### Kiểm tra an toàn

- JSON lỗi → giữ Current Status cũ.
- Change không có evidence → không merge.
- Character ID/tên không tồn tại → bỏ qua thay đổi nhân vật đó.
- Conflict có evidence → lưu lại, không ghi đè giá trị cũ.

---

## [PATCH_NOTES_V12.11_HINT_FOCUS] — Ghi chú bản vá

### v12.11 — Gợi ý chương sau: Focus tuyến chính

- Giảm dữ liệu Threads/Foreshadowing đưa vào prompt từ tối đa 8+8 xuống 3+3.
- Ưu tiên tuyệt đối: mạch chính hiện tại → brief người dùng → nhân vật chính/quan hệ trung tâm → tuyến trưởng thành đang là trọng tâm (nếu có) → hậu quả trực tiếp → thread/foreshadowing liên quan.
- Tối đa chỉ chọn 1 thread và 1 foreshadowing có liên quan trực tiếp.
- Cấm tự mở tuyến, mục tiêu, nhân vật quan trọng, địa điểm lớn hoặc bí mật mới chỉ để mở rộng truyện.
- Nếu chương hiện tại đang tập trung một tuyến chính, chương sau phải tiếp tục/xử lý hậu quả của tuyến đó trước.
- Nếu bật 18+ nhưng tuyến trưởng thành không phải trọng tâm của chương hiện tại, không tự ép thêm tuyến mới; nếu tuyến trưởng thành đã là trọng tâm thì ưu tiên tiếp nối tuyến đó.
- Giữ giới hạn gợi ý khoảng 400–600 từ, tối đa 600 từ.

---

## [PATCH_NOTES_V12.11_HINT_LENGTH] — Ghi chú bản vá

### V12.11 — Next Chapter Hint length fix

- Giới hạn Gợi ý chương sau ở khoảng **400–600 từ**.
- Prompt yêu cầu rõ không vượt 600 từ.
- Giảm `maxTokens` của lần tạo chính xuống 2800 để tránh sinh quá dài nhưng vẫn đủ chỗ cho reasoning của Aion 3.5 Mini.
- Nếu kết quả vượt 600 từ, app yêu cầu AI nén lại về 400–600 từ.
- Có hard cap cuối cùng ở 600 từ trước khi lưu vào `state.nextChapterHint`.
- Kiểm tra tiếng Việt vẫn được giữ nguyên.

---

## [PATCH_NOTES_V12.10] — Ghi chú bản vá

### V12.10
- Tóm tắt chương: 300-400 từ (trước 350-550), 4-5 đoạn, maxTokens 3500 -> 1400.
- Nếu vẫn >450 từ: tự gọi 1 lần để rút gọn, sau đó cắt cứng theo câu (cả client và worker nền).
- Chống lẫn ngoại ngữ: mở rộng dò thêm chữ Thái/Ả Rập/Hindi; thêm stripForeign() dọn chữ ngoại còn sót sau khi viết (client + worker nền), đổi dấu câu full-width sang dấu thường.
- Character Database: (1) prompt chỉ khóa NV có [KHÓA HỒ SƠ GỐC], NV đã mở khóa được bổ sung appearance/personality/goals; (2) AI nhận hồ sơ hiện có của NV mở khóa để chỉ thêm điểm mới; (3) nới độ dài trường 25 -> 30-60 từ (worker); (4) cộng dồn không còn cắt mất phần mới khi đầy (bỏ đoạn cũ nhất, giới hạn 2500), bỏ đoạn trùng ý; (5) mở khóa thì coreIdentity đồng bộ theo bản mới.
- Tóm tắt chống bịa: prompt viết lại (văn bản chương đặt TRƯỚC, luật ngắn, không còn từ mồi kiểu lệnh/quyền lực/hợp đồng); chỉ đưa AI tên NV có thật trong chương; kiểm tra tên và độ trùng từ với chương, sai thì gọi lại 1 lần kèm danh sách tên bị cấm, vẫn sai thì dùng bản trích tự động từ văn bản (client + worker nền).

---

## [PATCH_NOTES_V12.9] — Ghi chú bản vá

### V12.9
- Gợi ý chương sau: chi tiết theo cảnh, nối từ đoạn kết chương trước, có chọn kiểu (bình thường / chống cự / đảo chiều / leo thang / chậm) + nút tạo lại gợi ý.
- Tóm tắt chương: theo trình tự thời gian, đúng tên nhân vật, giữ chi tiết (giờ, số phòng, lệnh, lời thoại), 350-550 từ.
- Bộ nhớ chương cũ: 3 chương gần nhất giữ 900 ký tự tóm tắt, cũ hơn 350 (trước đây 200-240).

---

## [PATCH_NOTES_V12.7] — Ghi chú bản vá

### V12.7 — Continuity / Canon / Brief Fix
- One shared female-character definition block for all female characters.
- AI builds individual female characters from story evidence; no per-character female form required.
- Full user directive and next-chapter hint are preserved (no 400-character truncation).
- Automatic next-chapter hint is advisory only.
- Main-character core profile is protected from automatic rescans; dynamic state remains updateable.
- Character Database passes canonical fields separately from current state.
- Tier auto-ranking changes only tier.
- Confirmed character identity/role data cannot be overwritten by inference.
- 1–3 main events and limited new-character rules remain active.
- Chapter hard cap remains target x 1.15 (5,000 => 5,750 words).
- Vietnamese-script guard remains active.
- Last-chapter deletion restores prior snapshot including core state and female-definition rules.
- Existing writer/settings two-column arrangement retained.

---

## [PATCH_NOTES_V12.6] — Ghi chú bản vá

### V12.6 — Character Core Identity Lock

#### Problem fixed
Character Database entries such as a character's original personality/identity could be overwritten by automatic character rescans after several chapters. The automatic tier-ranking button only changes `tier`, but the chapter character updater could overwrite core fields when AI returned a new paraphrase.

#### Changes
- Added `coreIdentity` snapshot for `name`, `age`, `gender`, `appearance`, `personality`, and `goals`.
- `coreLocked` defaults to true.
- Automatic chapter character extraction can no longer overwrite core identity fields unless the AI explicitly returns `explicitCoreChange=true` plus concrete `changeEvidence`.
- Manual Save in Character Database is treated as user intent and refreshes the core snapshot.
- Existing characters without a core snapshot are initialized from their current profile once; this prevents future automatic overwrites. If an already-corrupted profile must be restored to an earlier value, restore it manually once and press Save.
- Automatic tier ranking remains limited to `tier`; it does not modify personality, appearance, role, goals, etc.

---

## [PATCH_NOTES] — Ghi chú bản vá

### V12.5 — Xóa chương hoàn nguyên toàn bộ bộ nhớ

- Khi bật **Xóa kèm bộ nhớ**, xóa chương cuối sẽ rollback **Current Status, Status State, Story Clock, Nhân vật, Địa điểm, Vật phẩm, Threads, Timeline, Foreshadowing, Knowledge Ledger, Memory Events và Character State Tracker** về snapshot của chương ngay trước đó.
- Xóa chương cũng loại bỏ dữ liệu Memory/Scene/History thuộc đúng chương bị xóa và đánh lại số chương của dữ liệu phía sau.
- Sau khi xóa chương cuối, giao diện tự chọn lại chương trước; không còn giữ `currentChapterIndex` trỏ vào chương vừa xóa.
- Snapshot mới từ V12.5 lưu thêm trạng thái Memory/Status để các lần rollback sau chính xác hơn.
- Thao tác xóa ghi ngay vào IndexedDB + emergency copy, không chờ debounce 1,75 giây, tránh iOS/Safari giữ lại bản state cũ.
- Nếu xóa chương giữa truyện, dữ liệu của các chương phía sau vẫn được giữ và đánh lại số; chỉ rollback toàn bộ live state khi chương cuối bị xóa vì đó là trường hợp có thể xác định chính xác mốc trạng thái trước đó.

### V12.3 — Khóa độ dài + khóa ngôn ngữ

- Độ dài mục tiêu được chuẩn hóa 500–6.000 từ; mỗi chương không vượt quá 115% mục tiêu. Với mặc định 5.000 từ, hard cap là 5.750 từ.
- Cả local writer và background writer đều dừng continuation khi đạt mục tiêu/hard cap và cắt ở câu gần hoàn chỉnh nếu model trả quá dài.
- Thêm phát hiện chữ Hán/Nhật/Hàn/Cyrillic lẫn vào văn Việt; nếu phát hiện, model được yêu cầu viết lại 100% tiếng Việt có dấu thay vì giữ nguyên đoạn lỗi.
- Sửa auto-continue local: trước đây phát hiện ngôn ngữ khác thì dừng ngay, giờ retry trước.

### V12 — Writing Engine Upgrade

V12 keeps the V11.1 story-state pipeline and upgrades prose generation using the smoother V8-style path: temperature 0.82, no repetition penalties, prose-only output, and continuation style-lock.

### v11.1.0 — Tăng tốc

| Hạng mục | File | Nội dung |
|---|---|---|
| Rà chính tả không chặn lưu | `index.html` | `polishPromise` chạy song song hậu xử lý; chỉ thay văn bản khi `chapterObj.text` chưa đổi và không đang gõ |
| Hậu xử lý theo pha | `index.html` | `runFastPostTasks()`; nhánh tuần tự cũ giữ nguyên khi tắt "Song song" |
| Streaming throttle | `index.html` | `renderStream` giới hạn 120ms |
| Nghỉ hàng đợi | `index.html` | `sleep(600)` → `sleep(250)` |
| Lô trích xuất song song | `write-chapter-background.js` | `runPool()` + `EXTRACT_CONCURRENCY` cho NV/Thế giới |
| Tóm tắt song song | `write-chapter-background.js` | `summaryP` chạy cùng NV/Thế giới; "Gợi ý chương sau" đợi ở pha 2 |
| Test | `tests/` | e2e 21, unit 12, integration worker |

**Đánh đổi cần biết:** Status/Memory vẫn đọc state sau NV/Thế giới (pha 2). Tóm tắt/NV/Thế giới giờ chạy khi bản rà chính tả chưa xong nên dùng văn bản gốc (lỗi chính tả không ảnh hưởng nội dung trích xuất). Chưa kiểm thử với model/Netlify/iOS thật.

---

### v11.0.0 — Tóm tắt thay đổi

| Hạng mục | File | Nội dung |
|---|---|---|
| Lưu ngay khi rời trang | `index.html` | `flushPersist()` gắn vào `visibilitychange`, `pagehide`, `beforeunload` |
| Bản lưu khẩn cấp | `index.html` | `writeEmergencyCopy / clearEmergencyCopy / readEmergencyRecord`; khôi phục ở `initIndexedDBStorage` và `loadStoryStateFromDiskAsync` |
| Dự phòng khi IndexedDB lỗi | `index.html` | `saveStoryStateToDisk` ghi localStorage khi `idbPut` reject (trước đây chỉ hiện toast) |
| Lưu trữ bền | `index.html` | `navigator.storage.persist()` lúc khởi động |
| Rào chắn tuổi 18+ | `index.html`, `write-chapter-background.js` | `underageNames()`, `ageGuardPrompt()` chèn vào prompt khi bật 18+; cảnh báo khi mở truyện |
| Đồng bộ phiên bản | `package.json`, `index.html` | 11.0.0 (trước đó package.json còn ghi 10.2.0, giao diện ghi 10.2.1) |
| Bộ test | `tests/` | `e2e.py` (17), `worker.test.js` (11) |

**Chưa kiểm thử được trong môi trường này:** chạy thật trên Netlify (Background Functions, Blobs), gọi model thật (OpenRouter), và iOS Safari thật. Test dùng API giả và Chromium.

---

### Patch v10.2.3 — Sửa gốc: "Viết chương nền" không tự chuyển NSFW + hết giờ hàng loạt

**Vấn đề báo cáo:** khi bấm "☁ Viết chương nền", (1) chương có cảnh nóng vẫn dùng model
thường thay vì model NSFW dù `nsfwMode = "auto"`; (2) log trả về
`NV: 7/7 lô không đọc được / Thế giới: 7/7 lô không đọc được / Status: bỏ qua vì hết thời
gian / Memory: bỏ qua vì hết thời gian`.

**Nguyên nhân gốc (trong `write-chapter-background.js`):**

1. `generateOneChapter()` chỉ ép NSFW khi bắt được **từ khóa cứng** trong 3 nguồn hạn hẹp
   (Mệnh lệnh, Định hướng chương sau, tiêu đề chương trước) — không có bước **chấm nhiệt độ
   0–10** như bản viết trực tiếp trên client (`detectHeatLevel` trong `index.html`). Cảnh nóng
   phát sinh tự nhiên từ mạch truyện (không có từ khóa tường minh) sẽ bị bỏ qua, job lặng lẽ
   dùng model chính (đây là lý do bạn thấy nó "dùng mode thường" thay vì NSFW).
2. Bước viết chương + "viết tiếp" (`generateOneChapter`) không giới hạn ngân sách thời gian
   riêng — với chương dài (`minChapterWords` lớn) hoặc model trả lời chậm, bước này có thể ăn
   gần hết 13.5 phút của Netlify Background Function, khiến các bước sau (NV, Thế giới,
   Status, Memory) chạy dồn dập trong thời gian rất ngắn còn lại: các lệnh gọi trích xuất JSON
   bị cắt ngang do hết giờ → JSON hỏng → "không đọc được"; Status/Memory thậm chí không kịp
   bắt đầu → "bỏ qua vì hết thời gian".

**Đã sửa:**

- Thêm `detectHeatLevel()` trong worker, đồng bộ với client: nếu không bắt được từ khóa nhưng
  `nsfwMode = "auto"`, chấm nhiệt độ cảnh sắp viết và so với `nsfwAutoThreshold` đã cấu hình.
- Mở rộng nguồn quét từ khóa: thêm đoạn cuối chương trước (giống `tail` ở client), không chỉ
  Mệnh lệnh/Định hướng/tiêu đề.
- Dành riêng **5 phút dự trữ** (`POST_PROCESS_RESERVE_MS`) cho NV/Thế giới/Status/Memory: bước
  viết chương + viết tiếp giờ tự giới hạn `totalMs` và dừng sớm nếu sắp lấn vào phần dự trữ này.
- Nâng ngưỡng "bỏ qua vì hết thời gian" ở từng lô NV/Thế giới từ 60s lên 150s còn lại, để
  Status/Memory (chạy sau) chắc chắn còn cơ hội thay vì luôn bị hết giờ.
- Bỏ qua bước "sửa JSON bằng AI" (tốn thêm 1 lượt gọi model) khi còn dưới 90 giây, tránh vừa
  tốn thời gian vừa vẫn thất bại.

**Lưu ý còn lại:** nếu sau khi cập nhật vẫn thấy NV/Thế giới báo "không đọc được JSON" ngay cả
khi còn nhiều thời gian (không phải do hết giờ), rất có thể do model bạn chọn cho trường
"Model chính" trả lời bằng văn xuôi thay vì JSON thuần (thường gặp ở các model "reasoning" khi
endpoint không phải OpenRouter nên worker không tắt được chế độ suy luận). Trường hợp đó cần
xem đúng đoạn model trả về (mục "Chi tiết cập nhật nền" trong app) để xác định model có tuân
thủ yêu cầu "chỉ trả JSON" hay không.

### Patch v10.2.2 — Sửa lỗi mất dữ liệu IndexedDB

#### Lỗi đã sửa
`index.html`, hàm `openStoryDB()` (dòng ~1142):

```js
// Trước (lỗi):
req.onsuccess = e => { idb = e.target.result; resolve(db); };   // `db` không tồn tại → ReferenceError

// Sau (đã sửa):
req.onsuccess = e => { idb = e.target.result; resolve(idb); };
```

#### Ảnh hưởng của lỗi
- Biến `db` chưa từng được khai báo trong toàn bộ file, nên mỗi lần mở IndexedDB
  đều ném `ReferenceError: db is not defined`.
- Promise `openStoryDB()` bị cache (`idbReady`) nên **reject vĩnh viễn cho cả phiên làm việc**
  ngay từ lần gọi đầu tiên.
- Mọi thao tác `idbPut/idbGet/idbDelete/idbGetAll` — tức toàn bộ việc lưu/tải truyện,
  snapshot chương, draft khi streaming — đều thất bại âm thầm (bị `.catch(()=>{})` nuốt lỗi).
- Vì `saveStoryStateToDisk()` không có phương án dự phòng ghi vào `localStorage`,
  dữ liệu chỉ tồn tại trong bộ nhớ RAM của tab đang mở. Đóng tab / tắt màn hình iPhone
  (đúng kịch bản chính mà README v10.2 mô tả) sẽ **mất toàn bộ truyện chưa export**.

#### Đã kiểm tra lại sau khi vá
- `node --check` cho cả 3 Netlify Functions và toàn bộ script trong `index.html`: hợp lệ.
- Chạy thử bằng trình duyệt headless (Playwright): tạo truyện mới → không còn lỗi console,
  và bản ghi truyện xuất hiện thật trong object store `stories` của IndexedDB (trước đó luôn là 0).

---

### Patch v10.2.3 — Sửa lỗi job nền bị "treo" vĩnh viễn

#### Lỗi đã sửa
Hàm `checkPendingBackgroundJob()` (dùng để tự động kiểm tra lại job nền còn dang dở
mỗi khi mở lại trang) được định nghĩa nhưng **không bao giờ được gọi** trong `bootV102()`.

#### Ảnh hưởng của lỗi
- Nếu đóng tab / mất mạng / tắt máy trong lúc job nền đang chạy, việc polling
  (kiểm tra tiến độ mỗi 12 giây) dừng hẳn.
- Mở lại trang: cờ "đang có job" vẫn còn trong `localStorage`, nhưng không có gì
  chạy lại để xác nhận job đã xong/lỗi → **job bị coi là đang chạy vĩnh viễn**,
  chặn mọi job mới ("Đã có job nền đang theo dõi..."), dù job thật trên server
  có thể đã xong hoặc lỗi từ lâu.

#### Cách sửa
Thêm 1 dòng gọi hàm vào cuối `bootV102()`:
```js
checkForRecoverableDraft();
checkPendingBackgroundJob();   // ← dòng mới
```

#### Đã kiểm tra lại sau khi vá
Giả lập 1 job cũ còn sót trong `localStorage` rồi tải lại trang bằng trình duyệt headless:
app tự hiện "☁ Phát hiện job nền đang chờ đồng bộ..." và tiếp tục polling ngay khi boot,
thay vì im lặng bỏ qua như trước.

#### Khuyến nghị tiếp theo (chưa phải lỗi, nhưng nên làm trước khi phát hành)
1. Test thủ công đầy đủ luồng: viết chương → tắt/mở lại trình duyệt → kiểm tra truyện còn nguyên.
2. Cân nhắc thêm fallback ghi `localStorage` ngay trong `saveStoryStateToDisk()` phòng khi
   IndexedDB lỗi ở môi trường khác (Safari riêng tư, dung lượng đầy, trình duyệt cũ...),
   thay vì chỉ hiện toast cảnh báo.
3. Xác nhận gói Netlify đang dùng hỗ trợ Background Functions (cần gói Pro trở lên) nếu
   muốn dùng tính năng "☁ Viết chương nền".
4. Đặt biến môi trường `JOB_SECRET` trên Netlify để mã hóa API key khi lưu job Blobs.


#### V12.4 — Background continuation length fix
- Mature/NSFW writing branch gets a larger initial output budget (24k tokens) and continuation budget (12k).
- Mature branch can use up to 8 continuation passes (minimum 4 when auto-continuation is enabled).
- Mature branch reserves 90s instead of 5 minutes for post-processing, reducing premature truncation.
- Every continuation reuses the exact routed model selected for the chapter; it does not fall back to the primary model.
- Mature continuation prompt explicitly continues the same scene/momentum instead of ending early.
- Normal writing behavior remains unchanged.

## [V14.0.4] — Age guard trong pipeline cảnh, prompt văn phong, sửa E2E

- **Bảo mật nội dung:** rào chắn tuổi 18+ trước đây chỉ có ở bước lập kế hoạch; nay được đặt ĐẦU Style Lock của mọi lượt viết scene và top-up. System prompt không còn cho chỉ dẫn 18+ của người dùng đè lên rào chắn tuổi.
- Prompt hệ thống/scene bổ sung quy tắc chống sáo ngữ lặp, lời thoại đúng giọng, nhịp truyện và yêu cầu có đồng thuận/động lực rõ cho cảnh người lớn.
- Sửa E2E: mock API theo pipeline Scene Graph (plan → scene → top-up → vá cục bộ); nhãn phiên bản kiểm tra v13/v14. 34/34 PASS.
- Thêm `tests/v14_age_guard_scene.test.js` và `DEPLOY.md`.

## [V14.0.5] — Định tuyến model 18+ theo từng scene

- Sửa lỗi: model NSFW chỉ được chọn một lần cho cả chương (dựa vào đoạn cuối chương trước + mệnh lệnh), nên cảnh sex nằm trong Scene Graph/Outline của chương mới vẫn bị viết bằng model chính. Nay mỗi scene tự chọn model theo beat/purpose/mustChange/handoff của nó và đoạn cuối scene trước (cảnh nóng kéo dài không bị tụt về model chính giữa chừng). Top-up dùng model của scene cuối.
- Chương có scene 18+ được đánh dấu `isNsfw` để hậu kỳ (tóm tắt chế độ người lớn) chạy đúng.
- Pre-flight từ khóa tính thêm `nextChapterHint`.
- Mức 18+ người dùng chọn (`explicitLevel`) nay thực sự tới prompt scene (trước đây chỉ có tên mức). Mức `wild` dùng chỉ dẫn của mức `strong`.
- E2E #36 kiểm tra định tuyến theo scene.

## [V14.0.6] — Viết nháp nền + sửa PLAN_REJECTED nhầm

- **Sửa lỗi "V14 từ chối kế hoạch… vệ sĩ, khách sạn, shop váy cưới":** validator forbidden-drift trước đây tách luật thành từng âm tiết (`vệ`, `sĩ`, `khách`…) và chặn plan khi khớp ≥ 2 âm tiết, nên "bảo vệ", "bác sĩ", "khách" làm chương nào cũng bị từ chối. Nay so khớp theo cụm chủ đề nguyên vẹn (vệ sĩ / khách sạn / váy cưới / Kim Chi) và cho phép khi Outline/Arc/Required Beat của chương đã ghi rõ.
- **Viết nháp nền (nút ☁ Viết nháp nền):** worker chạy ĐÚNG pipeline "Tạo Chương Hoàn Chỉnh" (`runAdaptiveChapterPipeline` trong `shared/core.js`, dùng chung client + worker): Chapter Contract → Scene Graph → từng scene → top-up. Lưu chương ở trạng thái "Bản nháp"; KHÔNG chạy Quality Gate/hậu kỳ. Người dùng đọc, ổn thì bấm ☁ Chạy hậu kỳ server (hoặc 🔍 Duyệt lại).
- Chương nháp chưa hậu kỳ chặn viết chương kế tiếp (nháp hoặc thường) để không mất continuity.
- Worker không còn lặng lẽ lùi về writer cũ: plan bị từ chối → job lỗi `PLAN_REJECTED`; lỗi API ở scene → `SCENE_FAILED`. Worker dùng `DEADLINE` để dừng top-up khi hết giờ.
- Job viết thường (không draftOnly) cũng đi qua adaptive; tắt bằng `adaptiveScenePipeline:false` để quay lại writer cũ.
- Test mới: `tests/v14_worker_draft.test.js`, `tests/e2e_bg.py` (mục 15–21).
- **Chấm nhanh sau khi nháp** (ô tick mặc định bật): đúng MỘT lần Quality Review, không tự sửa, không hậu kỳ. Kết quả hiện dạng 🟢 ĐẠT / 🟡 CÓ CẢNH BÁO / 🔴 LỖI NẶNG kèm điểm và số lỗi; chi tiết nằm trong khung Quality. Review lỗi/hết giờ không làm fail nháp, chỉ báo "chưa chấm được".

## [V14.0.7–V14.0.8] — Forbidden drift tôn trọng Brief/chương trước; contract gọn; chống scene viết lặp

- V14.0.7: chủ đề bị cấm (vệ sĩ/khách sạn/váy cưới/Kim Chi) được phép nếu đã có trong Outline, Arc, Mệnh lệnh, Gợi ý hoặc đoạn kết chương trước. Thông báo lỗi nêu rõ cụm bị chạm và cách xử lý.
- V14.0.8: **sửa lỗi V14.0.7** — `userBrief` (Mệnh lệnh/Gợi ý, tới 2.000 ký tự) bị đưa vào JSON contract của MỌI prompt plan/scene/top-up và khung "Kế hoạch". Nay contract đưa vào prompt/hiển thị dùng `promptChapterContract` (không có `userBrief`); `userBrief` chỉ dùng để validator đối chiếu.
- Scene/top-up mở đầu lại cảnh đã viết: các đoạn gần trùng nguyên văn (≥ 70% trigram) bị bỏ, giữ phần mới (`dropRepeatedParagraphs`); scene chỉ còn < 80 từ thì bỏ qua và để top-up bù.
- Telemetry trong cảnh báo chương nháp: "Adaptive: x/y scene, n lượt bù từ, [cắt k đoạn lặp,] t giây" (kèm "DỪNG SỚM" nếu hết giờ job) để biết vì sao chương thiếu từ.

## [V14.0.9] — Chương Adaptive không còn tụt xuống ~4.100 từ

- **Nguyên nhân:** `dedupeRepeatedScene` (viết cho trường hợp model xuất lại cả chương, cắt từ chỗ lặp trở đi) bị áp lên chương do code tự ghép scene. Chỉ cần vài đoạn lặp lẻ là nó cắt cụt hàng nghìn từ SAU khi bước bù từ đã coi chương "đủ 4.500" (tái hiện: 5.034 từ thô → 1.660 từ).
- Thêm `safeDedupeRepeatedScene`: nếu cắt mất > 20% số từ thì giữ nguyên; dùng cho chương Adaptive ở client và worker. Đoạn lặp lẻ được xử lý ở từng scene bằng `dropRepeatedParagraphs` (ngưỡng đoạn ≥ 8 từ).
- Vòng bù từ: đếm từ SAU khi dọn (`deps.clean`), nhắm 4.500 + đệm ≤ 200 từ (bước khép câu cuối/khóa độ dài có thể bớt vài chục từ), tối đa 8 lượt; lượt hỏng (quá ngắn/lặp/không tăng) không làm dừng ngay, chỉ dừng sau 2 lượt hỏng liên tiếp.
- Telemetry: "Adaptive: x/y scene (a từ thô → b sau dọn), n lượt bù từ…".

## [V14.0.10] — PLAN_REJECTED "Không parse được JSON Scene Graph"

- Parser Scene Graph chịu được: khối `<think>…</think>`, lời dẫn chứa dấu `{`, JSON bị cắt giữa chừng (tự đóng ngoặc/chuỗi rồi để validator báo thiếu trường).
- Lần plan đầu 2.600 token, lần thử lại 3.600 token (trước đây 1.900 → dễ bị cắt với model dài dòng); worker gọi plan qua `callExtract` (rỗng/bị cắt → tự gọi lại với ngân sách gấp đôi).
- Thông báo lỗi nay kèm số ký tự, `finish_reason` và 140 ký tự đầu model trả về (vd model từ chối/để trống) để biết nguyên nhân thật.

## [V14.0.11] — "Nhân vật ngoài Canon Cast" bớt chặn nhầm

- So khớp tên theo từng tiếng: "Mỹ Duyên" hợp lệ nếu cast có "Trần Mỹ Duyên" (và ngược lại); alias của nhân vật/nhân vật chính được tính vào Canon Cast.
- Lỗi gộp thành MỘT dòng kèm tên và hướng xử lý: `Nhân vật ngoài Canon Cast: A, B (nếu là nhân vật thật thì thêm vào Story Bible/Outline…)` (trước đây lặp theo từng scene và dễ bị cắt mất tên).
- Sau 2 lượt plan, nếu lỗi DUY NHẤT là tên ngoài Canon Cast và tên đó chỉ nằm ở danh sách `characters` (không xuất hiện trong beats/purpose/mustChange/handoff/goal) thì gỡ tên khỏi plan và chạy tiếp (ghi chú "đã gỡ vai ngoài Story Bible"). Tên gắn vào tình tiết vẫn bị từ chối.

## [V14.0.12] — Canon Cast đối chiếu cả Outline + chương trước

- Validator Canon Cast nhận tên nhân vật nếu tên đó xuất hiện trong Outline/Arc, Mệnh lệnh/Gợi ý hoặc 6.000 ký tự cuối của 2 chương gần nhất (`nameSource`, không đưa vào prompt) — kể cả khi Character Database chưa được hậu kỳ cập nhật.
- Nhân vật như vậy được thêm vào `allowedCharacters` của contract cho các scene sau, nên prompt scene không còn cấm đúng người mà Outline yêu cầu; chương ghi chú "nhân vật có trong Outline/chương trước nhưng chưa có trong Character Database: …".

## [V14.0.13] — Hậu kỳ nhân vật: nói rõ vì sao bỏ qua

- Ghi chú hậu kỳ nay liệt kê TÊN và LÝ DO khi một nhân vật không được thêm vào Character Database (evidence không khớp chương / tên không xuất hiện nguyên văn / thiếu chapterEvent / AI xếp hạng main-major nên không tự tạo). Trước đây chỉ có số "bỏ qua".
