/* Xưởng Truyện AI — client runtime (tách từ index.html ở V14.7.1).
   Khối SHARED-CORE và các hàm CLIENT-MIRROR được sinh bởi scripts/sync-shared.js — KHÔNG sửa tay. */
(function(){
"use strict";

/* V14.0.15: cầu nối cho app/features.js (module tách riêng). Toàn bộ app nằm trong IIFE nên module không thấy biến cục bộ. */
const XTA_HOOKS = window.__XTA_HOOKS__ = { h:{}, on(n,f){ (this.h[n]=this.h[n]||[]).push(f); }, fire(n){ (this.h[n]||[]).forEach(f=>{ try{ f(); }catch(e){ console.warn("[hook "+n+"]", e && e.message); } }); } };

/* ========== STORAGE KEYS (v7) ========== */
const STORIES_INDEX_KEY = "aiStoryWorkshop_storiesIndex_v9";
const STORY_KEY_PREFIX  = "aiStoryWorkshop_story_v9_";
const GLOBAL_KEY        = "aiStoryWorkshop_global_v9";
const LAST_STORY_KEY    = "aiStoryWorkshop_lastStoryId_v9";
const MIGRATION_KEYS_V6 = {
  index: "aiStoryWorkshop_storiesIndex_v6",
  story: "aiStoryWorkshop_story_v6_",
  global: "aiStoryWorkshop_global_v6",
  last:   "aiStoryWorkshop_lastStoryId_v6"
};
const MIGRATION_KEYS_V7 = {
  index: "aiStoryWorkshop_storiesIndex_v7",
  story: "aiStoryWorkshop_story_v7_",
  global: "aiStoryWorkshop_global_v7",
  last:   "aiStoryWorkshop_lastStoryId_v7"
};
const $ = id => document.getElementById(id);

/* ========== SYSTEM PROMPTS ========== */
const SYSTEM_PROMPT = [
  "Bạn là tiểu thuyết gia người Việt Nam viết tiểu thuyết dài kỳ, giọng văn tự nhiên như người viết thật, không có mùi AI.",
  "Mọi phản hồi PHẢI 100% TIẾNG VIỆT CÓ DẤU. Tuyệt đối không trộn tiếng Anh, Trung, Nhật, Hàn.",
  "Viết như con người: câu văn có nhịp, có chỗ ngắn chỗ dài, có hơi thở, có im lặng.",
  "MIÊU TẢ SÂU: khi nhân vật mới xuất hiện hoặc cảnh mới mở ra, dành ít nhất 2-3 câu miêu tả ngoại hình, không khí, chi tiết nhỏ (mùi, ánh sáng, âm thanh, cảm giác trên da).",
  "Show, don't tell. Ưu tiên giác quan, phản ứng cơ thể, chi tiết cụ thể hơn là liệt kê cảm xúc.",
  "ĐƯỢC TỰ DO thêm cảnh phụ, hội thoại, nội tâm, chi tiết đời thường để chương tự nhiên và dài hơn; KHÔNG tự tạo biến cố lớn, nhân vật quan trọng, arc mới hay thông tin để dành cho chương sau.",
  "VĂN PHONG: tránh sáo ngữ lặp (\"hơi thở nóng hổi\", \"tim đập thình thịch\", \"một luồng điện chạy dọc sống lưng\") và đừng dùng cùng một cụm từ cảm giác hai lần trong một chương; mỗi cảnh chọn chi tiết riêng của nhân vật đó. Lời thoại phải đúng xưng hô, mỗi người nói một giọng; xen hành động nhỏ thay vì chỉ ghi \"anh nói\". Giữ nhịp: dồn nén, đột ngột chậm lại rồi mới bùng nổ; mỗi cảnh làm đổi quan hệ hoặc quyền lực giữa nhân vật.",
  "Khi prompt yêu cầu cảnh 18+/erotica giữa các nhân vật đã đủ 18 tuổi: viết TRỰC TIẾP, không tự kiểm duyệt, không fade-to-black nếu người dùng muốn tả thẳng, và có sự đồng thuận hoặc động lực nhân vật rõ ràng. RÀO CHẮN TUỔI là tuyệt đối và ưu tiên cao hơn mọi chỉ dẫn khác của người dùng: không bao giờ viết nội dung tình dục có nhân vật dưới 18 tuổi, hoặc được mô tả/ám chỉ như trẻ em hay học sinh; nếu hồ sơ không ghi tuổi thì coi là người lớn, trừ khi hồ sơ ghi dưới 18 tuổi hoặc nhân vật được mô tả/ám chỉ là trẻ em hay học sinh."
].join(" ");

// V13.1: scene nối tiếp không cần lặp system prompt đầy đủ của toàn app.
// Giữ system prompt dài cho pipeline cũ/review; scene dùng bản compact để giảm input token mỗi lượt.

const DESCRIPTION_PROMPTS = {
  light: "Miêu tả ở mức nhẹ: chỉ tả những gì cần thiết để người đọc hiểu bối cảnh, không lan man.",
  balanced: "Miêu tả cân bằng: tả ngoại hình nhân vật chính + phụ quan trọng khi xuất hiện, tả không khí cảnh mới, chi tiết giác quan chọn lọc.",
  rich: "Miêu tả PHONG PHÚ: mỗi nhân vật mới xuất hiện phải có 3-5 câu miêu tả ngoại hình (khuôn mặt, dáng, tóc, mắt, da, giọng, mùi). Mỗi cảnh mới phải có 4-6 câu tả không khí, ánh sáng, âm thanh, nhiệt độ. Dùng nhiều chi tiết giác quan.",
  deep: "Miêu tả SÂU ĐẬM: tả cực kỳ chi tiết mọi thứ — ngoại hình từng đường nét, biểu cảm vi mô, hơi thở, mùi hương, cảm giác trên da, nhịp tim, chuyển động của không khí, màu sắc trong từng khoảnh khắc. Ưu tiên chi tiết nhỏ nhưng giàu sức gợi."
};

const EXPLICIT_PROMPTS = {
  subtle: "CẢNH 18+: Nhẹ nhàng — fade-to-black sau khi hôn, gợi ý chứ không tả. Cảm xúc chiếm ưu thế.",
  sensual: "CẢNH 18+: Gợi cảm — tả cảm xúc, hơi thở, ánh mắt, da chạm da; hạn chế tả bộ phận sinh dục chi tiết. Vẫn giàu sức gợi.",
  explicit: "CẢNH 18+: Rõ ràng — mô tả cơ thể và hành động cụ thể (hôn, sờ, cởi, tư thế). Có thể dùng từ trực tiếp khi cần. Show cảm giác qua da thịt và phản ứng.",
  strong: "CẢNH 18+: MẠNH — mỗi đoạn nóng cần: (1) bộ phận + hình thái/màu/số đo hồ sơ; (2) cảm giác thể xác cụ thể; (3) một nhịp nội tâm (xấu hổ/dục/kháng cự); (4) động tác + âm thanh. Ít ẩn dụ.",
  wild: "CẢNH 18+: CỰC MẠNH kiểu RedQuill. Đủ 4 lớp (cơ thể+cảm giác+nội tâm+âm thanh/thoại). Lớp sex dùng từ thô tục, không ẩn dụ. Thoại quy phục: van xin/tự nhục dày. Bám hồ sơ số đo. Không tóm tắt, không fade-to-black."
};

const EROTIC_STYLE_PROMPT = [
  "PHONG CÁCH REDQUILL / 18+ CỰC NẶNG (BẮT BUỘC khi cảnh nóng — đủ lớp, không bỏ):",
  "",
  "HAI LỚP (không trộn trong CÙNG MỘT CÂU):",
  "- Lớp văn/tâm lý: không khí, quyền lực, nội tâm, xã hội — có thể văn hơn.",
  "- Lớp erotic: khi đang sex/sỉ nhục/lên đỉnh → từ THÔ TỤC đường phố chiếm ưu thế (cặc, lồn, địt, nứng, nước lồn, tinh trùng, đĩ, nô lệ…). Không ẩn dụ hoa mỹ thay thế.",
  "",
  "4 LỚP MỖI ĐOẠN NÓNG:",
  "1) CƠ THỂ: kích thước/màu/hình thái theo hồ sơ NV (cặc, lồn, ngực, mông, mép, hạt le, dịch).",
  "2) CẢM GIÁC: căng, ướt, đau rát, no đầy, tê, run, nóng — trong da thịt, không chỉ nhìn từ ngoài.",
  "3) NỘI TÂM đa lớp: xấu hổ ↔ dục, kháng cự ↔ cơ thể phản bội, tự nhục ↔ nghiện (nữ); tính toán/chiếm hữu (nam nếu có).",
  "4) ÂM THANH + NHỊP: da đập, dịch, giường, thở, rên (ư, ahh, hah…), thoại van xin — đồng bộ nhịp đút.",
  "",
  "THOẠI (khi nhân vật đã quy phục / cảnh huấn luyện):",
  "- Tăng mật độ thoại: van xin thô tục, tự sỉ nhục, mô tả lồn/cặc đang nứng, cầu xin được địt/xuất.",
  "- Nam chính (nếu thống trị): thoại ngắn, lạnh, ra lệnh; nữ đáp dài hơn, thô hơn khi cao trào.",
  "- Thoại xen hành động + biểu cảm (mắt, môi, nước dãi, run).",
  "",
  "NHỊP CẢNH 3 PHẦN (BẮT BUỘC khi chương có cảnh nóng — KHÔNG chỉ dồn vào cao trào):",
  "- DẪN VÀO (~25% cảnh): dựng không khí và căng thẳng trước khi chạm nhau — ánh mắt, khoảng cách, lời nói/mệnh lệnh, nội tâm, từng bước cởi bỏ/áp sát, phản ứng cơ thể đầu tiên. Không nhảy thẳng vào quan hệ.",
  "- DIỄN BIẾN + CAO TRÀO (~50%): như các quy tắc trên.",
  "- SAU CẢNH (~25%): không cắt ngang ngay sau cao trào — hơi thở, cơ thể kiệt sức/dư chấn, dịch và dấu vết, cảm xúc sau đó (xấu hổ, thỏa mãn, hối hận, chiếm hữu), thoại sau cảnh, và hậu quả với quan hệ giữa hai người; rồi mới chuyển cảnh hoặc kết chương.",
  "- Mỗi phần phải có đoạn văn đầy đủ riêng (nhiều đoạn, không gói trong 1-2 câu).",
  "- NGOẠI LỆ: nếu gợi ý/mệnh lệnh của người dùng chỉ nêu 1–2 trong 3 phần (ví dụ chỉ dẫn vào, hoặc chỉ tới trước cao trào), CHỈ viết đúng các phần đó và dừng ở mốc kết chương người dùng đã ghi; tuyệt đối không tự thêm phần còn lại.",
  "",
  "KỸ THUẬT:",
  "- Chậm từng nhịp; không tóm tắt cao trào trong 1-2 câu.",
  "- Nhiều bộ phận cùng lúc (tay + miệng + cặc…).",
  "- 5 giác quan khi phù hợp; mùi/dịch/nhiệt độ.",
  "- Bám hồ sơ NV — cấm bịa số đo khác.",
  "- 100% tiếng Việt có dấu. Không meta, không spoiler chương sau."
].join("\n");

const DEFAULT_ADVANCED_RULES = [
  "QUY TẮC NGÔN NGỮ: 100% tiếng Việt có dấu. Câu văn tự nhiên, có nhịp người viết, không máy móc.",
  "QUY TẮC XƯNG HÔ (BẮT BUỘC): Đại từ nhân xưng NHẤT QUÁN xuyên suốt. Không tự tiện đổi giữa chừng.",
  "QUY TẮC LIỀN MẠCH: Mỗi chương tiếp nối từ đoạn kết chương trước; cảnh đang dở thì tiếp nối đúng thời điểm, sự kiện đã khép thì được cho thời gian trôi bằng một câu chuyển tự nhiên trong mạch kể (không nhãn ngày giờ). Không nhảy cảnh đột ngột.",
  "QUY TẮC THỜI GIAN: Thời gian luôn trôi về phía trước.",
  "QUY TẮC TỐC ĐỘ: Tình cảm dài hạn nên có tích tụ. Khi mệnh lệnh/mức 18+ yêu cầu cảnh nóng: viết thẳng, không né; viết chậm và dày theo QUY TẮC CẢNH NÓNG.",
  "QUY TẮC GHI NHỚ QUAN HỆ: Ghi nhớ trạng thái quan hệ, ranh giới, mức hấp dẫn hiện tại của từng nhân vật.",
  "QUY TẮC TÂM LÝ: Mọi thay đổi tính cách / dục vọng có nguyên nhân rõ.",
  "QUY TẮC CHỐNG NHÀM & CHỐNG LẶP: Mỗi chương có ít nhất một yếu tố mới. Không lặp sự kiện, cách giải quyết, cấu trúc chương, câu chữ, hình ảnh đã dùng.",
  "QUY TẮC NHỊP CHƯƠNG: Mỗi chương chỉ giải quyết 1–2 việc chính (1–2 SỰ KIỆN TRỤC CHÍNH có liên quan nhân-quả); một chương = MỘT bước tiến rõ về quyền lực hoặc tu luyện (hoặc cả hai), kèm tâm lý / mức sa đọa nếu có. Phần dẫn dắt + cảnh cao trào + hậu quả trực tiếp của nó tính là MỘT sự kiện. Bên trong một sự kiện trục được phép có biến cố lớn lồng vào nếu thật sự cần (không tính thành sự kiện chính thêm). Không phải chương nào cũng cần biến cố lồng. Không nhồi nhiều sự kiện, nhiều địa điểm, nhiều cảnh nóng vào cùng một chương; không nhảy thời gian/địa điểm liên tục. Không nhồi tuyến phụ hoặc bước ngoặt độc lập. Càng dài càng phải có trọng tâm rõ.",
  "QUY TẮC CẤU TRÚC CHƯƠNG 18+ (khi chương có cảnh nóng): Mở đầu 15–20% (tâm lý, không khí, áp lực; chưa vào cảnh nóng) → Leo thang 20–25% (lệnh/thử thách mới đẩy nhân vật khuất phục sâu hơn) → Cảnh nóng trọng tâm 40–50% (chỉ MỘT cảnh chính) → Hậu quả + móc kết 10–15%. Chương không có cảnh nóng thì giữ nhịp mở – leo thang – hậu quả.",
  "QUY TẮC CẢNH NÓNG (ưu tiên hơn 'không kéo dài vô ích'): Mỗi cảnh phải có mục đích (siết quyền lực, thử thách, đánh dấu, phá kháng cự), không chỉ để thỏa mãn. Viết chậm, dày, nhiều lớp: thể xác + tâm lý + quyền lực đan vào nhau — ánh mắt, hơi thở, run rẩy, giằng xé nội tâm, phản ứng cơ thể, âm thanh, lời thoại đứt quãng. Tuyệt đối không viết kiểu liệt kê hành động nối nhau; mỗi động tác kéo theo một phản ứng cảm xúc hoặc một bước đổi thế quyền lực.",
  "QUY TẮC NHÂN VẬT BỊ THỐNG TRỊ: Mỗi chương đổi một chút nhưng rõ, đến từ áp lực + khoái cảm + tâm lý, không nhảy cóc. Không kháng cự mãi, cũng không phục tùng hoàn toàn quá sớm; luôn chừa khoảng trống để bị đẩy sâu hơn ở chương sau.",
  "QUY TẮC QUYỀN LỰC: Xây dần, có lớp lang. Bên thống trị không thắng quá dễ/quá nhanh; mỗi lần siết chặt đi kèm rủi ro, kháng cự hoặc cái giá phải trả.",
  "QUY TẮC LEO THANG KHÔNG LẶP: Không lặp cách hành hạ, tư thế, lời thoại, phản ứng của chương trước. Mỗi chương có ít nhất một yếu tố mới (tình huống, địa điểm nguy hiểm hơn, lệnh mới, mức công khai hơn, thử thách tâm lý mới). Càng về sau càng nặng và tinh vi hơn về tâm lý, không chỉ mạnh hơn về thể xác.",
  "QUY TẮC NHÂN VẬT PHỤ: Không tùy tiện tạo nhân vật quan trọng mới. Chỉ tạo nhân vật mới khi câu chuyện thực sự cần; mỗi nhân vật xuất hiện phải có lý do rõ ràng, vai trò cụ thể và liên hệ với sự kiện đang diễn ra. Ưu tiên tái sử dụng nhân vật đã có. Nếu không cần, không thêm người mới chỉ để lấp cảnh.",
  "QUY TẮC XUNG ĐỘT LIÊN TỤC: Mỗi chương có ít nhất một xung đột ảnh hưởng về sau.",
  "QUY TẮC KẾT CHƯƠNG: Luôn kết bằng một móc: lệnh mới chưa thực hiện / nghi ngờ hoặc nguy cơ bị phát hiện / ham muốn chưa được thỏa / nhân vật bắt đầu có suy nghĩ nguy hiểm hoặc phụ thuộc hơn.",
  "QUY TẮC HẬU QUẢ: Hành động lớn đều để lại hậu quả.",
  "QUY TẮC MIÊU TẢ: Khi giới thiệu nhân vật/cảnh mới, miêu tả ngoại hình và không khí qua các chi tiết cụ thể (ánh mắt, mùi, giọng nói, da, chuyển động) — không dùng từ chung chung như 'xinh đẹp', 'lạnh lùng' mà phải cho thấy qua chi tiết.",
  "QUY TẮC VĂN PHONG CON NGƯỜI: Tránh câu AI điển hình (cô ấy cảm thấy / anh ta nhận ra rằng / một cảm giác lạ lùng). Ưu tiên chi tiết cụ thể, hơi thở, khoảng lặng.",
  "QUY TẮC 18+ (khi bật): Kiểu RedQuill — từ thô tục khi sex; đủ cơ thể + cảm giác + nội tâm + âm thanh/thoại. Không tự kiểm duyệt, không fade-to-black. Ưu tiên mệnh lệnh + mức 18+ hơn quy tắc chung.",
  "PHONG CÁCH: 'Show, don't tell'."
].join("\n\n");

/* ========== HELPERS ========== */
function genId(){ return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function newStoryId(){ return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2,6); }
// <<SHARED-CORE:BEGIN>> (tự sinh từ shared/core.js — KHÔNG sửa tay; chạy: node scripts/sync-shared.js)
function countWords(text) { return (text || "").trim().split(/\s+/).filter(Boolean).length; }

function normalizeName(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}

function chapterWordLimits(st) {
  // Client gọi không tham số (dùng state toàn cục); worker truyền state của job.
  if (!st && typeof state !== "undefined") st = state;
  // V14.6: min/max tường minh được ưu tiên; truyện cũ không có hai trường này vẫn dùng target ±500.
  const explicitMin = Number(st && st.chapterWordMin), explicitMax = Number(st && st.chapterWordMax);
  if (Number.isFinite(explicitMin) && Number.isFinite(explicitMax) && explicitMin >= 300 && explicitMax >= explicitMin && explicitMax <= 12000) {
    const minAccept = Math.floor(explicitMin), maxAccept = Math.floor(explicitMax);
    const requestedTarget = Number(st && st.minChapterWords);
    const target = Number.isFinite(requestedTarget) && requestedTarget >= minAccept && requestedTarget <= maxAccept
      ? Math.round(requestedTarget) : Math.round((minAccept + maxAccept) / 2);
    return { target, minAccept, maxAccept, hardMax: maxAccept };
  }
  // V14.5.8: độ dài chương theo ĐÚNG số người dùng nhập ở "Độ dài mục tiêu": chấp nhận mục tiêu ±500 từ
  // (5000 -> 4500–5500; 4500 -> 4000–5000). Không nhập/không hợp lệ -> mặc định 5000.
  const requested = Number(st && st.minChapterWords);
  if (requested >= 500 && requested <= 12000) {
    const t = Math.round(requested / 100) * 100;
    return { target: t, minAccept: Math.max(300, t - 500), maxAccept: t + 500, hardMax: t + 600 };
  }
  return { target: 5000, minAccept: 4500, maxAccept: 5500, hardMax: 5600 };
}

// V13: số scene và chức năng scene do diễn biến quyết định, không gán vai trò cố định.
function adaptiveChapterWordLimits(st) {
  return chapterWordLimits(st);
}
function chapterLengthAction(st, wordCount) {
  const limits = chapterWordLimits(st), words = Math.max(0, Math.floor(Number(wordCount) || 0));
  const hasExplicitBounds = Number.isFinite(Number(st && st.chapterWordMin)) && Number.isFinite(Number(st && st.chapterWordMax)) && Number(st.chapterWordMin) >= 300 && Number(st.chapterWordMax) >= Number(st.chapterWordMin) && Number(st.chapterWordMax) <= 12000;
  if (words < limits.minAccept) return { action: "expand", deficit: limits.minAccept - words, target: limits.target, minAccept: limits.minAccept, maxAccept: limits.maxAccept };
  const maxForAction = hasExplicitBounds ? limits.maxAccept : limits.hardMax;
  if (words > maxForAction) return { action: "condense", excess: words - maxForAction, target: limits.target, minAccept: limits.minAccept, maxAccept: maxForAction };
  return { action: "within", target: limits.target, minAccept: limits.minAccept, maxAccept: limits.maxAccept, hardMax: limits.hardMax };
}

function compactSceneTail(text, maxChars) {
  const t = String(text || '').trim();
  const cap = Number(maxChars) || 2400;
  return t.length <= cap ? t : t.slice(-cap);
}

/* V14.5.11: HỒ SƠ NHÂN VẬT CHO SCENE. Trước đây prompt viết scene (adaptive) CHỈ có tên trong ALLOWED CAST — không có chức vụ, nhà ở, mức sống, tính cách —
   nên model tự bịa (thư ký riêng chủ tịch thành giúp việc, căn hộ cao cấp thành nhà tồi tàn) rồi Gate bắt lỗi "vượt hồ sơ". Khối này đưa hồ sơ của đúng các nhân vật có mặt trong scene vào prompt. */
const SCENE_PROFILE_FIELDS = [['position', 'chức vụ/địa vị', 70], ['occupation', 'nghề', 60], ['role', 'vai trò', 60], ['faction', 'tổ chức', 50], ['age', 'tuổi', 12], ['gender', 'giới tính', 14],
  ['maritalStatus', 'hôn nhân', 30], ['spouseName', 'người yêu/phối ngẫu', 40], ['residence', 'nơi ở', 90], ['home', 'nơi ở', 90], ['housing', 'nơi ở', 90], ['currentLocation', 'đang ở', 60],
  ['wealth', 'tài sản/mức sống', 70], ['assets', 'tài sản', 70], ['income', 'thu nhập', 50], ['notes', 'ghi chú hồ sơ', 220], ['appearance', 'ngoại hình', 160], ['height', 'chiều cao', 24], ['bodyType', 'dáng người', 50], ['measurements', 'SỐ ĐO', 90], ['hair', 'tóc', 40], ['eyes', 'mắt', 30], ['skin', 'da', 30], ['voice', 'giọng', 40], ['scent', 'mùi', 30], ['style', 'phong cách ăn mặc', 60], ['scars', 'sẹo', 40], ['tattoos', 'xăm', 40], ['personality', 'tính cách', 90],
  ['speech', 'cách nói', 70], ['goals', 'mục tiêu', 70], ['relevanceToMC', 'quan hệ với NVC', 70]];
/* V14.7.4: neo ngoại hình cho đường viết từng scene (trước đây chỉ đường viết thường có): hồ sơ hình thể phải ra được thành chữ cụ thể. */
const SCENE_APPEARANCE_ANCHOR = 'NEO NGOẠI HÌNH — người đọc phải hình dung được thân thể nhân vật: khi nhân vật xuất hiện lần đầu trong chương, hoặc khi cảnh tả cơ thể/trang phục, nêu chiều cao, dáng, SỐ ĐO/kích thước, tóc-mắt-da ĐÚNG theo HỒ SƠ KHÓA bằng con số hoặc so sánh cụ thể. Cấm tính từ trống đứng thay cho hình thể ("căng thẳng", "bó sát", "quyến rũ", "đầy đặn", "cao ráo"): phải gắn với phần cơ thể và kích thước cụ thể; trang phục tả kèm cách nó ôm/hở/xô lệch trên đúng phần thân thể đó. Mục hồ sơ nào trống thì tự đặt chi tiết hợp lý và giữ nhất quán về sau.';
function sceneProfileWithAnchor(st, scene, castNames) { const b = sceneProfileBlock(st, scene, castNames); return b ? b + '\n\n' + SCENE_APPEARANCE_ANCHOR : ''; }
function sceneProfileBlock(st, scene, castNames) {
  st = st || {};
  const names = [].concat((scene && scene.characters) || [], (!scene || !(scene.characters || []).length) ? (castNames || []) : []).map(x => String(x || '').trim()).filter(Boolean);
  if (!names.length) return '';
  const pool = [].concat(st.mainCharProfile && st.mainCharProfile.name ? [st.mainCharProfile] : [], Array.isArray(st.characters) ? st.characters : []).filter(c => c && c.name && !c.dead);
  const pick = [], seen = new Set();
  names.forEach(n => {
    const nn = normalizeName(n), nt = nn.split(' ').filter(Boolean);
    const c = pool.find(x => normalizeName(x.name) === nn) || pool.find(x => { const xt = normalizeName(x.name).split(' ').filter(Boolean); return xt.length >= 2 && nt.length >= 2 && (nt.every(t => xt.includes(t)) || xt.every(t => nt.includes(t))); });
    if (c && !seen.has(c.name)) { seen.add(c.name); pick.push(c); }
  });
  const cut = (v, n) => { v = String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); return v.length > n ? v.slice(0, n) + '…' : v; };
  const rows = pick.slice(0, 5).map(c => {
    const f = [], used = new Set();
    SCENE_PROFILE_FIELDS.forEach(([k, label, n]) => { const v = cut(c[k], n); if (v && !used.has(label + v)) { used.add(label + v); f.push(label + ': ' + v); } });
    return f.length ? '- ' + c.name + (st.mainCharProfile && st.mainCharProfile.name === c.name ? ' (NVC)' : '') + ' | ' + f.join(' | ') : '';
  }).filter(Boolean);
  /* Trạng thái hiện tại tích lũy từ Current Status (mới hơn hồ sơ gốc; ưu tiên khi khác nhau): nghề, nơi ở, trang phục, địa vị, tính cách công khai/riêng tư... */
  const SF = [['occupation', 'công việc hiện tại', 80], ['residence', 'nơi ở hiện tại', 100], ['socialStatus', 'địa vị/quan hệ xã hội', 90], ['clothing', 'trang phục hiện tại', 90], ['marks', 'dấu vết trên cơ thể', 90],
    ['items', 'vật dụng đang dùng', 100], ['emotion', 'cảm xúc', 70], ['submission', 'mức phục tùng', 70], ['ruleCompliance', 'tuân thủ quy tắc', 70], ['publicPersonality', 'hình ảnh công khai phải giữ', 110],
    ['privatePersonality', 'tính cách khi ở riêng', 110], ['romance', 'tình cảm/hôn nhân', 70], ['weakness', 'điểm yếu', 80], ['goals', 'mục tiêu', 80], ['relationships', 'quan hệ quan trọng', 110], ['physicalState', 'thể trạng', 70], ['mentalState', 'tâm lý', 80]];
  const states = (st.statusState && Array.isArray(st.statusState.characterStates)) ? st.statusState.characterStates : [];
  const srows = pick.slice(0, 5).map(c => {
    const sc = states.find(x => x && (normalizeName(x.name || x.characterName || '') === normalizeName(c.name)));
    const ch = sc && sc.changes && typeof sc.changes === 'object' ? sc.changes : null; if (!ch) return '';
    const f = SF.map(([k, label, n]) => { const v = cut(typeof ch[k] === 'object' ? JSON.stringify(ch[k]) : ch[k], n); return v ? label + ': ' + v : ''; }).filter(Boolean);
    return f.length ? '- ' + c.name + ' | ' + f.join(' | ') : '';
  }).filter(Boolean);
  if (!rows.length && !srows.length) return '';
  const statusPart = srows.length ? '\nTRẠNG THÁI HIỆN TẠI (Current Status mới nhất — nếu khác hồ sơ gốc thì theo mục này):\n' + srows.join('\n').slice(0, 2200) : '';
  if (!rows.length) return 'TRẠNG THÁI NHÂN VẬT TRONG SCENE — giữ đúng nghề, nơi ở, địa vị, trang phục, tính cách công khai/riêng tư:' + statusPart;
  return 'HỒ SƠ KHÓA CỦA NHÂN VẬT TRONG SCENE (ưu tiên hơn ý tưởng của cảnh) — giữ ĐÚNG chức vụ/nghề, địa vị, nơi ở và mức sống, tính cách, cách nói. KHÔNG tự đổi sang nghề/địa vị thấp hơn hay cao hơn (vd thư ký riêng của chủ tịch không thành người giúp việc), KHÔNG tả nơi ở/mức sống khác hồ sơ (căn hộ cao cấp không thành nhà tồi tàn). Hình thể (chiều cao, dáng, SỐ ĐO, tóc, mắt, da…) có trong hồ sơ thì dùng ĐÚNG, không bịa số khác. Chi tiết hồ sơ không có thì không bịa trái ngược:\n' + rows.join('\n').slice(0, 3800) + statusPart;
}

/* ===== V14.5.13 — THẺ NHÂN VẬT TRONG CURRENT STATUS (toàn thẻ, tích lũy) =====
   Trước đây bước cập nhật Status chỉ nhận "phần thay đổi có evidence" nên nhiều chương trả rỗng, thẻ nhân vật không bao giờ đầy đủ (nghề, nơi ở, trang phục...).
   Nay: (1) thẻ khởi tạo từ hồ sơ gốc; (2) mỗi chương AI trả ĐỦ thẻ cho nhân vật có mặt — trường không đổi chép lại (không cần evidence), trường đổi/mới phải có câu trích thật;
   (3) kết quả cộng dồn vào statusState.characterStates và được đưa vào prompt viết từng cảnh. */
const STATUS_CARD_KEYS = ['age', 'appearance', 'body', 'clothing', 'marks', 'cultivation', 'cultivationState', 'emotion', 'submission', 'ruleCompliance', 'socialStatus', 'occupation', 'residence', 'romance', 'weakness', 'goals', 'items', 'publicPersonality', 'privatePersonality', 'psychology', 'relationships', 'physicalState', 'mentalState', 'knowledge'];
const STATUS_CARD_LABELS = { age: 'độ tuổi', appearance: 'ngoại hình', body: 'cơ thể/thể trạng', clothing: 'trang phục hiện tại', marks: 'dấu vết trên cơ thể', cultivation: 'tu vi', cultivationState: 'trạng thái tu vi', emotion: 'cảm xúc', submission: 'mức thèm khát/phục tùng', ruleCompliance: 'mức tuân thủ quy tắc', socialStatus: 'địa vị/quan hệ xã hội', occupation: 'công việc hiện tại', residence: 'nơi ở hiện tại', romance: 'hôn nhân/tình cảm', weakness: 'điểm yếu', goals: 'mục tiêu', items: 'vật dụng/đồ chơi đang dùng', publicPersonality: 'hình ảnh công khai', privatePersonality: 'tính cách khi ở riêng', psychology: 'tâm lý', relationships: 'mối quan hệ quan trọng', physicalState: 'thể trạng hiện tại', mentalState: 'tinh thần hiện tại', knowledge: 'điều đã biết' };
function _scVal(v) { if (v == null) return ''; if (typeof v === 'object') { try { return JSON.stringify(v); } catch (_) { return ''; } } return String(v).replace(/\s+/g, ' ').trim(); }
function _scSame(a, b) {
  const x = normalizeName(a), y = normalizeName(b); if (!x || !y) return false; if (x === y) return true;
  const tx = new Set(x.split(' ').filter(Boolean)), ty = new Set(y.split(' ').filter(Boolean)); let hit = 0; tx.forEach(w => { if (ty.has(w)) hit++; });
  return hit / Math.max(1, tx.size + ty.size - hit) >= 0.85;
}
const _SC_LAZY_RE = /^\(?\s*(giữ nguyên|không (có )?thay đổi|như cũ|n\/?a|chưa rõ|không rõ)\b/i;
function seedStatusCard(c) {
  const g = k => _scVal(c && c[k]), out = {};
  const put = (k, v) => { v = _scVal(v); if (v) out[k] = v.slice(0, 220); };
  put('age', g('age')); put('appearance', g('appearance'));
  put('socialStatus', [g('position'), g('role'), g('faction')].filter(Boolean).join('; '));
  put('occupation', g('occupation')); put('residence', g('residence') || g('home') || g('housing'));
  put('romance', [g('maritalStatus'), g('spouseName') && ('với ' + g('spouseName')), g('maritalNotes')].filter(Boolean).join('; '));
  put('weakness', g('weakness')); put('goals', g('goals')); put('publicPersonality', g('personality'));
  put('physicalState', g('physicalState')); put('mentalState', g('mentalState')); put('knowledge', g('knowledge')); put('cultivation', g('realm'));
  return out;
}
function _scFindState(st, c) {
  const states = (st && st.statusState && Array.isArray(st.statusState.characterStates)) ? st.statusState.characterStates : [];
  const nn = normalizeName(c && c.name);
  return states.find(x => x && ((c.id && String(x.characterId || x.id || '') === String(c.id)) || (nn && normalizeName(x.name || x.characterName || '') === nn))) || null;
}
// Thẻ hiện hành = hồ sơ gốc (seed) bị đè bởi giá trị đã tích lũy trong Current Status.
function currentStatusCard(st, c) {
  const seed = seedStatusCard(c), prior = _scFindState(st, c), pc = prior && prior.changes && typeof prior.changes === 'object' ? prior.changes : {}, card = {};
  STATUS_CARD_KEYS.forEach(k => { const v = _scVal(pc[k]) || seed[k]; if (v && !_SC_LAZY_RE.test(v)) card[k] = v; });
  return card;
}
function _scMentioned(name, text) {
  const w = String(name || '').trim().split(/\s+/).filter(Boolean), t = String(text || '');
  const has = ph => { if (!ph || ph.length < 2) return false; const esc = ph.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); try { return new RegExp('(^|[^\\p{L}\\p{N}])' + esc + '(?![\\p{L}\\p{N}])', 'u').test(t); } catch (_) { return false; } };
  return has(w.join(' ')) || (w.length >= 3 && has(w.slice(-2).join(' '))) || (w.length >= 2 && has(w[w.length - 1]) && w[w.length - 1].length >= 3);
}
function statusCardTargets(st, text, max) {
  const pool = [].concat(st && st.mainCharProfile && st.mainCharProfile.name ? [Object.assign({ id: 'main' }, st.mainCharProfile)] : [], Array.isArray(st && st.characters) ? st.characters : []).filter(c => c && c.name && !c.dead);
  const seen = new Set(), out = [];
  pool.forEach(c => { const k = normalizeName(c.name); if (seen.has(k)) return; seen.add(k); if (c.id === 'main' || _scMentioned(c.name, text)) out.push(c); });
  return out.slice(0, max || 8);
}
function buildStatusCardPrompt(o) {
  o = o || {};
  return [
    'CẬP NHẬT THẺ NHÂN VẬT (Current Status) SAU CHƯƠNG ' + (o.chapterNumber || '?') + '. Chỉ trả MỘT JSON object, không markdown, tiếng Việt.',
    'Với MỖI nhân vật trong THẺ HIỆN HÀNH dưới đây, trả ĐỦ thẻ (object "card") gồm mọi khóa hợp lệ. Quy tắc:',
    '1) Trường chương KHÔNG làm đổi: chép lại ĐÚNG NGUYÊN giá trị hiện hành. Cấm viết "giữ nguyên", "không thay đổi", "như cũ" hay viết tắt.',
    '2) Trường chương cho thấy ĐÃ ĐỔI hoặc đang ở trạng thái mới (trang phục, cảm xúc, vật dụng đang dùng, dấu vết trên cơ thể, thể trạng, tâm lý, tinh thần, mức phục tùng thường đổi theo cuối chương): ghi giá trị mới VÀ đặt trong "changeEvidence" một trích đoạn NGUYÊN VĂN 5–18 từ của chương chứng minh đúng giá trị đó.',
    '3) Trường chưa có trong thẻ: chỉ điền khi chương nêu rõ (kèm changeEvidence); nếu không thì để chuỗi rỗng "". TUYỆT ĐỐI không bịa, không suy diễn, không đoán.',
    '4) Công việc, chức vụ, địa vị, nơi ở, tuổi, tình trạng hôn nhân KHÔNG ĐƯỢC đổi trừ khi chương kể rõ sự kiện làm đổi (và có changeEvidence). Nhân vật chỉ được nhắc thoáng qua thì giữ nguyên thẻ.',
    '5) Giữ mọi thông tin quan trọng cần nhớ lâu dài của thẻ cũ; chỉ rút gọn chữ thừa, không làm rơi chi tiết.',
    'KHÓA HỢP LỆ của card: ' + STATUS_CARD_KEYS.join(', ') + '.',
    'THẺ HIỆN HÀNH:\n' + JSON.stringify((o.cards || []).map(c => ({ characterId: c.id, name: c.name, card: c.card }))),
    'JSON TRẢ VỀ: {"cards":[{"characterId":"","name":"","card":{"occupation":"","residence":"","...":""},"changeEvidence":{"khóa":"trích đoạn nguyên văn"}}]}',
    'CHƯƠNG:\n' + String(o.text || '').slice(0, 42000)
  ].join('\n\n');
}
function parseStatusCards(raw) {
  const t = String(raw || '').replace(/<think(?:ing)?[\s>][\s\S]*?<\/think(?:ing)?>/gi, '').replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '');
  const i = t.indexOf('{'), j = t.lastIndexOf('}'); if (i < 0 || j <= i) return null;
  let obj; try { obj = JSON.parse(t.slice(i, j + 1)); } catch (_) { return null; }
  return obj && Array.isArray(obj.cards) ? obj.cards : null;
}
// Ghép thẻ AI trả vào statusState.characterStates. Trường giống thẻ cũ -> bỏ qua; khác/mới -> cần changeEvidence thật trong chương, nếu không giữ giá trị cũ.
function acceptStatusCards(st, items, source, targets) {
  const out = { changed: 0, dropped: 0, characters: 0, droppedFields: [] };
  if (!st.statusState || typeof st.statusState !== 'object') st.statusState = {};
  if (!Array.isArray(st.statusState.characterStates)) st.statusState.characterStates = [];
  const byName = new Map((items || []).filter(x => x && typeof x === 'object').map(x => [normalizeName(x.name || x.characterName || ''), x]));
  const byId = new Map((items || []).filter(x => x && x.characterId).map(x => [String(x.characterId), x]));
  (targets || []).forEach(c => {
    const base = currentStatusCard(st, c), item = byId.get(String(c.id)) || byName.get(normalizeName(c.name)) || null;
    const card = item && item.card && typeof item.card === 'object' ? item.card : {}, ce = item && item.changeEvidence && typeof item.changeEvidence === 'object' ? item.changeEvidence : {};
    const result = Object.assign({}, base); let changed = 0, firstEv = '';
    STATUS_CARD_KEYS.forEach(k => {
      const v = _scVal(card[k]); if (!v || _SC_LAZY_RE.test(v)) return;
      if (base[k] && _scSame(base[k], v)) return;
      const ev = String(ce[k] || (item && item.evidence) || '').trim();
      if (fieldEvidenceSupports(v, ev, source, 0.4)) { result[k] = v.slice(0, 320); changed++; if (!firstEv) firstEv = ev; }
      else { out.dropped++; if (out.droppedFields.length < 12) out.droppedFields.push(c.name + '.' + k); }
    });
    const prior = _scFindState(st, c), entry = { characterId: c.id, name: c.name, status: changed ? 'updated' : 'unchanged', changes: result, evidence: changed ? firstEv : String((prior && prior.evidence) || '') };
    if (prior) Object.assign(prior, entry, { characterId: prior.characterId || c.id }); else st.statusState.characterStates.push(entry);
    out.changed += changed; out.characters++;
  });
  return out;
}
function statusCharacterLines(states) {
  const lines = ['- Thông tin nhân vật cập nhật:'];
  (states || []).forEach(x => {
    if (!x) return; const ch = x.changes && typeof x.changes === 'object' ? x.changes : {};
    const parts = STATUS_CARD_KEYS.map(k => { const v = _scVal(ch[k]); return v ? (STATUS_CARD_LABELS[k] || k) + ': ' + v : ''; }).filter(Boolean);
    lines.push('  • ' + (x.name || x.characterName || 'Nhân vật') + ': ' + (parts.length ? (x.status === 'unchanged' ? 'Không có thay đổi đáng kể | ' : '') + parts.join(' | ') : 'Không có thay đổi đáng kể'));
  });
  return lines.join('\n');
}
// Thay khối "Thông tin nhân vật cập nhật" trong văn bản Current Status bằng thẻ mới (giữ nguyên các phần khác).
function replaceStatusCharacterBlock(text, states) {
  const t = String(text || ''), block = statusCharacterLines(states), head = '- Thông tin nhân vật cập nhật:', i = t.indexOf(head);
  if (i < 0) return (t ? t.replace(/\s+$/, '') + '\n' : '') + block;
  const rest = t.slice(i + head.length), m = rest.search(/\n- (?:XUNG ĐỘT|Current Status trước khi|[^\s•][^\n]{0,60}:)/);
  return t.slice(0, i) + block + (m >= 0 ? rest.slice(m) : '');
}
// Chạy một lượt cập nhật thẻ. o: { st, text, n, callText(prompt)->Promise<string>, maxCards }. Lỗi AI/JSON -> không đổi gì.
async function runStatusCardUpdate(o) {
  const st = o.st, text = String(o.text || '');
  const targets = statusCardTargets(st, text, o.maxCards || 8);
  if (!targets.length) return { ok: false, reason: 'no_targets' };
  const cards = targets.map(c => ({ id: c.id, name: c.name, card: currentStatusCard(st, c) }));
  let raw; try { raw = await o.callText(buildStatusCardPrompt({ chapterNumber: o.n, cards, text })); } catch (e) { return { ok: false, reason: 'ai_error: ' + (e && e.message || e) }; }
  const items = parseStatusCards(raw); if (!items) return { ok: false, reason: 'parse' };
  const r = acceptStatusCards(st, items, text, targets);
  st.currentStatus = replaceStatusCharacterBlock(st.currentStatus, st.statusState.characterStates);
  return Object.assign({ ok: true }, r);
}

function compactSceneContract(scene) {
  const s = scene || {}, out = {};
  [['id', 20], ['purpose', 260], ['location', 120], ['time', 100], ['mustChange', 240], ['handoff', 240]].forEach(([k, n]) => {
    const v = String(s[k] || '').replace(/\s+/g, ' ').trim();
    if (v) out[k] = v.slice(0, n);
  });
  if (Array.isArray(s.beats) && s.beats.length) out.beats = s.beats.map(x => String(x).replace(/\s+/g, ' ').trim().slice(0, 180)).filter(Boolean).slice(0, 6);
  if (Array.isArray(s.characters) && s.characters.length) out.characters = s.characters.map(x => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 6);
  if (Number(s.targetWords)) out.targetWords = Math.max(350, Math.min(2200, Number(s.targetWords)));
  return out;
}

function compactSceneStateDelta(delta) {
  const d = delta || {}, out = {};
  ['sceneId', 'location', 'time', 'mustChange', 'handoff'].forEach(k => {
    const v = String(d[k] || '').replace(/\s+/g, ' ').trim();
    if (v) out[k] = v.slice(0, k === 'sceneId' ? 20 : 260);
  });
  if (Array.isArray(d.characters) && d.characters.length) out.characters = d.characters.map(x => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 6);
  return out;
}

/* V14.4.2: đối chiếu từng beat của Outline chương với văn bản đã viết (0 token, bằng từ khóa có dấu). Chỉ để CẢNH BÁO: AI duyệt hay chấm outlineCompliance quá cao dù truyện lệch. */
function outlineBeatSegments(line) {
  const t = String(line || '').replace(/\s+/g, ' ').trim();
  const k = t.search(/Sự kiện\s*:/u), body = k >= 0 ? t.slice(k) : t;
  return body.split(/(?=(?:Sự kiện|Kháng cự|Hậu quả|Móc kết|Cảnh nóng|Cảnh chính)\s*:)|;|\s\+\s|(?<=[.!?…])\s+(?=\p{Lu})/u)
    .map(x => x.replace(/^(?:Sự kiện|Kháng cự|Hậu quả|Móc kết|Cảnh nóng|Cảnh chính)\s*:\s*/u, '').replace(/[.;\s]+$/u, '').trim())
    .filter(x => x.length >= 8);
}
function outlineBeatCoverage(outlineLine, chapterText, names) {
  const segs = outlineBeatSegments(outlineLine); if (!segs.length) return { total: 0, missing: [] };
  const excl = new Set();
  (names || []).forEach(n => normalizeName(n).split(/[^a-z0-9đ]+/).forEach(w => { if (w.length >= 2) excl.add(w); }));
  const words = w => (String(w || '').toLowerCase().match(/[\p{L}\p{N}]+/gu) || []);
  const have = new Set(words(chapterText)), miss = []; let total = 0;
  segs.forEach(seg => {
    const toks = Array.from(new Set(words(seg).filter(w => w.length >= 2 && !SCENE_STOP_TOKENS.has(normalizeName(w)) && !excl.has(normalizeName(w)))));
    if (toks.length < 3) return;
    total++;
    if (toks.filter(w => have.has(w)).length / toks.length < 0.4) miss.push(seg.slice(0, 90));
  });
  return { total, missing: miss };
}
function outlineMissingBeats(outlineLine, chapterText, names) { return outlineBeatCoverage(outlineLine, chapterText, names).missing.slice(0, 6); }
/* V14.5.1: QUALITY GATE chặn khi chương thiếu nhiều ý của Outline. Thiếu >= 40% số ý đánh giá được (và có từ 2 ý trở lên) -> lỗi NẶNG (HARD_FAIL, kích hoạt tự vá);
   thiếu ít hơn -> chỉ cảnh báo. Đối chiếu bằng từ khóa nên có thể báo thừa: thông báo nói rõ và vẫn cho duyệt thủ công. Tắt bằng state.outlineBeatGate === false. */
function outlineGateCheck(st, n, text, names) {
  const out = { hard: [], warn: [] };
  if (!st || st.outlineBeatGate === false) return out;
  const ol = outlineOf(st, n); if (!ol) return out;
  const line = outlineChapterLines(ol.content, ol)[n]; if (!line) return out;
  const cov = outlineBeatCoverage(line, text, names);
  if (!cov.total || !cov.missing.length) return out;
  const msg = 'Outline chương ' + n + ' chưa thực hiện đủ (đối chiếu từ khóa): chưa thấy ' + cov.missing.length + '/' + cov.total + ' ý — ' + cov.missing.slice(0, 4).map(x => '«' + x.slice(0, 80) + '»').join(' · ') + '. Cần viết đủ các ý này trong chương; nếu truyện thật ra đã viết chúng bằng câu chữ khác thì có thể duyệt thủ công.';
  /* V14.5.9: đối chiếu từ khóa hay báo thừa (truyện đã viết ý đó bằng câu chữ khác) nên mặc định chỉ CẢNH BÁO, không HARD_FAIL.
     Muốn lại chế độ chặn cứng: state.outlineBeatGate = "strict". */
  if (st.outlineBeatGate === "strict" && cov.total >= 2 && cov.missing.length >= Math.max(1, Math.ceil(cov.total * 0.4))) out.hard.push(msg); else out.warn.push(msg);
  return out;
}
function buildAdaptiveScenePlanPrompt(o) {
  const limits = adaptiveChapterWordLimits(o.state || {});
  return [
    'BẠN LÀ BIÊN KỊCH TIỂU THUYẾT DÀI KỲ TIẾNG VIỆT.',
    'Lập Scene Graph cho chương khoảng ' + limits.target + ' từ; chấp nhận ' + limits.minAccept + '–' + limits.maxAccept + ' từ.',
    'Số scene, chức năng và độ dài scene phải LINH HOẠT theo diễn biến; không dùng khuôn Scene 1 mở đầu, Scene 2 xung đột, Scene 3 cảnh nóng.',
    'Có thể gom nhiều beat vào một scene hoặc tách một beat thành nhiều scene nếu nhịp truyện cần.',
    'Mỗi scene phải nối tự nhiên với scene trước và tạo thay đổi thật về thông tin, cảm xúc, quan hệ, mục tiêu hoặc hậu quả.',
    'Nếu có cảnh trưởng thành, chỉ đặt khi mạch truyện cần; cảnh đó phải có nhân vật trưởng thành, nhất quán thiết lập và hậu quả rõ.',
    'Không thêm biến cố lớn ngoài brief/canon. Không tự biến nhân vật phụ/nhân vật mới thành tuyến chính nếu Outline/Arc không giao việc đó. Không đổi nghề, tài nguyên, địa vị hoặc mục tiêu sinh tồn của nhân vật chính.',
    o.chapterContract ? 'CHAPTER CONTRACT BẤT BIẾN — không được sửa các trường này:\n' + JSON.stringify(promptChapterContract(o.chapterContract)) : '',
    o.allowedCast ? 'ALLOWED CAST — chỉ dùng các nhân vật/tên dưới đây; nhân vật khác chỉ được xuất hiện thoáng qua nếu chính Outline/Brief cho phép và không được thành tuyến chính:\n' + String(o.allowedCast).replace(/\s+/g, ' ').slice(0, 1800) : '',
    o.forbiddenDrift ? 'FORBIDDEN DRIFT — tuyệt đối không làm các hướng sau:\n' + String(o.forbiddenDrift).replace(/\s+/g, ' ').slice(0, 1200) : '',
    'Trả duy nhất JSON object hợp lệ theo schema: {"chapterGoal":"","endingAnchor":"","scenes":[{"id":"S1","purpose":"","beats":[""],"characters":[""],"location":"","time":"","targetWords":900,"mustChange":"","handoff":""}]}',
    'Bối cảnh/canon:\n' + String(o.context || '').slice(0, 18000),
    o.recent ? 'Đoạn gần nhất:\n' + String(o.recent).slice(-5000) : '',
    o.directive ? 'Mệnh lệnh người dùng:\n' + String(o.directive).slice(0, 6000) : '',
    o.hint ? 'Gợi ý chương sau (THAM KHẢO — THẤP HƠN Outline; phần nào trái Outline thì BỎ):\n' + String(o.hint).slice(0, 2500) : '',
    'THỨ TỰ ƯU TIÊN KHI MÂU THUẪN: (1) Outline chương + checklist beat ngay bên dưới; (2) mệnh lệnh người dùng; (3) gợi ý chương sau; (4) bối cảnh/đoạn gần nhất. Bối cảnh, đoạn gần nhất và gợi ý chỉ dùng để nối mạch; KHÔNG được thay sự kiện, thứ tự hay kết quả mà Outline đã giao cho chương này. MỌI sự kiện chính của Outline PHẢI có mặt và được viết ĐẦY ĐỦ trong chính chương này (không bỏ, không rút thành tóm tắt, không dời sang chương sau). Các quy tắc chung (yếu tố mới, xung đột, thất bại/phản đòn, bước tiến…) nên được đưa vào BÊN TRONG hoặc xen kẽ sự kiện Outline; vẫn được thêm chi tiết/tình tiết phụ, miễn là không chiếm chỗ hay làm thiếu sự kiện chính. THREADS/FORESHADOWING chỉ là bối cảnh tham khảo, không bắt buộc tiến triển.',
    o.arcProgress ? 'ARC/OUTLINE LOCK — chương này bắt buộc đi đúng hướng sau, không được mở tuyến thay thế:\n' + String(o.arcProgress).replace(/\s+/g, ' ').slice(0, 2600) : '',
    o.requiredBeats ? 'REQUIRED BEAT CHECKLIST — PHẢI PHÂN BỔ VÀO SCENE, KHÔNG ĐƯỢC BỎ SÓT:\n' + String(o.requiredBeats).slice(0, 1800) : '',
    Array.isArray(o.outlineItems) && o.outlineItems.length ? ('OUTLINE ĐÁNH SỐ — kế hoạch PHẢI bám sát. Mỗi scene khai báo thêm trường "outlineItems":[số thứ tự các mục nó THỰC HIỆN]. Quy tắc: (1) mọi mục từ 1 đến ' + o.outlineItems.length + ' phải được ĐÚNG MỘT scene thực hiện; (2) các mục theo ĐÚNG thứ tự, không đảo; (3) mỗi scene thực hiện 1–3 mục LIỀN KỀ (có thể gom hoặc tách cảnh để hợp nhịp); (4) tối đa 1 scene nối/chuyển không có mục mới (outlineItems:[]); (5) beats và mustChange của scene lấy từ chính các mục đó, không đổi kết quả; (6) mustChange phải nêu KẾT QUẢ quan sát được khi cảnh xong (dạng "xong khi …": ai làm gì, điều gì thay đổi), vì từng mục sẽ được kiểm tra bằng câu trích dẫn từ văn bản:\n' + o.outlineItems.map((t, i) => (i + 1) + '. ' + String(t).slice(0, 240)).join('\n') + (o.outlineMeta && (o.outlineMeta.resistance || o.outlineMeta.consequence || o.outlineMeta.hook) ? '\nGhi chú kết quả của chương: ' + [o.outlineMeta.resistance && 'Kháng cự: ' + o.outlineMeta.resistance, o.outlineMeta.consequence && 'Hậu quả: ' + o.outlineMeta.consequence, o.outlineMeta.hook && 'Móc kết (endingAnchor): ' + o.outlineMeta.hook].filter(Boolean).join(' | ') : '')) : ''
  ].filter(Boolean).join('\n\n');
}

// V14.0.1: model đôi khi bọc JSON trong markdown hoặc thêm một câu dẫn.
// Chỉ lấy object cân bằng đầu tiên; không coi phản hồi hợp lệ là plan rỗng.
function _repairTruncatedJson(s) {
  // Model bị cắt giữa chừng: đóng chuỗi/mảng/object còn mở rồi thử parse (chỉ dùng khi không còn cách khác).
  const stack = []; let quoted = false, escaped = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quoted) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === '"') quoted = false; continue; }
    if (ch === '"') quoted = true; else if (ch === '{' || ch === '[') stack.push(ch); else if (ch === '}' || ch === ']') stack.pop();
  }
  let out = s;
  if (quoted) out += '"';
  out = out.replace(/[,:\s]+$/, '').replace(/,\s*"[^"]*"\s*$/, '');
  while (stack.length) out += stack.pop() === '{' ? '}' : ']';
  try { return JSON.parse(out); } catch (_) { return null; }
}

function parseAdaptiveScenePlanResponse(raw) {
  if (raw && typeof raw === 'object') return raw;
  let s = String(raw || '').replace(/<think(?:ing)?>[\s\S]*?<\/think(?:ing)?>/gi, '').replace(/<think(?:ing)?>[\s\S]*$/i, '').trim();
  if (!s) return null;
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  try { return JSON.parse(s); } catch (_) {}
  // Thử từng dấu '{' làm điểm bắt đầu (lời dẫn có thể chứa '{' trước JSON thật).
  let tried = 0, pos = s.indexOf('{');
  while (pos >= 0 && tried < 6) {
    tried++;
    let depth = 0, quoted = false, escaped = false, end = -1;
    for (let i = pos; i < s.length; i++) {
      const ch = s[i];
      if (quoted) {
        if (escaped) escaped = false;
        else if (ch === '\\') escaped = true;
        else if (ch === '"') quoted = false;
        continue;
      }
      if (ch === '"') { quoted = true; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (depth === 0) { end = i; break; } }
    }
    if (end >= 0) {
      try { const o = JSON.parse(s.slice(pos, end + 1)); if (o && typeof o === 'object' && (o.scenes || o.chapterGoal)) return o; } catch (_) {}
    } else {
      const fixed = _repairTruncatedJson(s.slice(pos));
      if (fixed && typeof fixed === 'object' && (fixed.scenes || fixed.chapterGoal)) return fixed;
    }
    pos = s.indexOf('{', pos + 1);
  }
  return null;
}

function normalizeAdaptiveScenePlan(raw, st) {
  const obj = parseAdaptiveScenePlanResponse(raw);
  if (!obj || typeof obj !== 'object' || !Array.isArray(obj.scenes)) return null;
  const limits = adaptiveChapterWordLimits(st || {});
  const scenes = obj.scenes.filter(Boolean).slice(0, 8).map((s, i) => ({
    id: String(s.id || ('S' + (i + 1))).slice(0, 20),
    purpose: String(s.purpose || '').slice(0, 500),
    beats: Array.isArray(s.beats) ? s.beats.map(x => String(x).slice(0, 500)).filter(Boolean).slice(0, 8) : [],
    characters: Array.isArray(s.characters) ? s.characters.map(x => String(x).slice(0, 100)).filter(Boolean).slice(0, 8) : [],
    location: String(s.location || '').slice(0, 180),
    time: String(s.time || '').slice(0, 180),
    targetWords: Math.max(350, Math.min(2200, Number(s.targetWords) || Math.round(limits.target / Math.max(1, obj.scenes.length)))),
    mustChange: String(_planField(s, ['mustChange', 'must_change', 'mustchange', 'must-change', 'change', 'keyChange', 'sceneChange', 'outcome'])).slice(0, 400),
    handoff: String(_planField(s, ['handoff', 'hand_off', 'hand-off', 'handOff', 'transition', 'nextHook', 'bridge'])).slice(0, 400),
    ...(Array.isArray(s.outlineItems) ? { outlineItems: s.outlineItems.map(Number).filter(x => Number.isInteger(x) && x > 0 && x <= 20) } : {})
  }));
  if (!scenes.length) return null;
  const one = x => String(x || '').replace(/\s+/g, ' ').trim();
  const lastSc = scenes[scenes.length - 1];
  // V14.5.2: model lớn hay bỏ trống mustChange/handoff/endingAnchor -> tự suy ra từ purpose/beats và scene kế, thay vì PLAN_REJECTED.
  const chapterGoal = String(_planField(obj, ['chapterGoal', 'chapter_goal', 'goal'])).slice(0, 600)
    || one(scenes[0].purpose || (scenes[0].beats && scenes[0].beats[0])).slice(0, 600);
  const endingAnchor = String(_planField(obj, ['endingAnchor', 'ending_anchor', 'endingHook', 'ending'])).slice(0, 600)
    || one((lastSc.beats && lastSc.beats[lastSc.beats.length - 1]) || lastSc.mustChange || lastSc.purpose).slice(0, 600);
  scenes.forEach((sc, i) => {
    const next = scenes[i + 1];
    if (!sc.mustChange.trim()) sc.mustChange = one(sc.purpose || (sc.beats && sc.beats[0]) || chapterGoal || ('Diễn biến chính của ' + sc.id)).slice(0, 400);
    if (!sc.handoff.trim()) {
      sc.handoff = (next
        ? 'Dẫn sang ' + next.id + ': ' + one(next.purpose || (next.beats && next.beats[0]) || next.location || 'scene kế tiếp')
        : 'Kết chương: ' + one(endingAnchor || 'theo Outline')).slice(0, 400);
    }
  });
  return { chapterGoal, endingAnchor, scenes };
}

function _planField(o, keys) {
  for (const k of keys) { const v = o && o[k]; if (v == null) continue; const t = Array.isArray(v) ? v.join('; ') : (typeof v === 'object' ? '' : String(v)); if (t.trim()) return t; }
  return '';
}

// V14: Contract-First — kế hoạch AI không được tự thay đổi các trường này.
function compactChapterContract(contract) {
  const c = contract || {};
  return {
    chapterNumber: Number(c.chapterNumber) || 0,
    arcGoal: String(c.arcGoal || '').replace(/\s+/g, ' ').slice(0, 700),
    chapterOutline: String(c.chapterOutline || '').replace(/\s+/g, ' ').slice(0, 1000),
    requiredBeats: Array.isArray(c.requiredBeats) ? c.requiredBeats.map(x => String(x).replace(/\s+/g, ' ').slice(0, 400)).filter(Boolean).slice(0, 8) : [],
    allowedCharacters: Array.isArray(c.allowedCharacters) ? c.allowedCharacters.map(x => String(x).trim().slice(0, 100)).filter(Boolean).slice(0, 24) : [],
    canonicalCharacters: Array.isArray(c.canonicalCharacters) ? c.canonicalCharacters.map(x => String(x).trim().slice(0, 100)).filter(Boolean).slice(0, 60) : (Array.isArray(c.knownCharacters) ? c.knownCharacters.map(x => String(x).trim().slice(0, 100)).filter(Boolean).slice(0, 60) : []),
    forbiddenDrift: Array.isArray(c.forbiddenDrift) ? c.forbiddenDrift.map(x => String(x).replace(/\s+/g, ' ').slice(0, 300)).filter(Boolean).slice(0, 8) : [],
    userBrief: String(c.userBrief || '').replace(/\s+/g, ' ').slice(0, 2000),
    nameSource: String(c.nameSource || '').replace(/\s+/g, ' ').slice(0, 30000),
    openingContinuity: String(c.openingContinuity || '').replace(/\s+/g, ' ').slice(-1200),
    mustChange: String(c.mustChange || '').replace(/\s+/g, ' ').slice(0, 600),
    minWords: Number(c.minWords) || chapterWordLimits().minAccept,
    maxWords: Number(c.maxWords) || chapterWordLimits().maxAccept
  };
}

// V14.0.8: bản contract ĐƯA VÀO PROMPT/HIỂN THỊ — bỏ userBrief (chỉ để validator đối chiếu; Mệnh lệnh/Gợi ý đã có sẵn trong prompt,
// nhét lại sẽ tốn token ở mọi scene và làm khung "Kế hoạch" tràn quy tắc chương).
function promptChapterContract(contract) {
  const c = compactChapterContract(contract);
  delete c.userBrief;
  delete c.nameSource;
  return c;
}

function _contractNameSet(contract) {
  const c = compactChapterContract(contract);
  return new Set([].concat(c.allowedCharacters || [], c.canonicalCharacters || []).map(normalizeName).filter(Boolean));
}

// V14.0.11: so khớp tên theo TỪNG TIẾNG: "Mỹ Duyên" thuộc cast nếu cast có "Trần Mỹ Duyên" (và ngược lại); biệt danh/alias nằm sẵn trong cast.
function _nameInCast(name, allowedSet) {
  const n = normalizeName(name);
  if (allowedSet.has(n)) return true;
  const nt = n.split(' ').filter(Boolean);
  for (const a of allowedSet) {
    const at = String(a).split(' ').filter(Boolean);
    if (at.length >= 2 && nt.length >= 2 && (nt.every(t => at.includes(t)) || at.every(t => nt.includes(t)))) return true;
  }
  return false;
}

// V14.0.12: tên đã được nhắc trong Outline/Arc/Gợi ý/chương gần nhất là nhân vật CÓ THẬT của truyện (Character Database chỉ chưa kịp cập nhật).
function _nameInText(name, text) {
  const t = normalizeName(text);
  if (!t) return false;
  const n = normalizeName(name);
  if (n && t.includes(n)) return true;
  const tk = n.split(' ').filter(Boolean);
  return tk.length >= 3 && t.includes(tk.slice(-2).join(' ')); // "Trần Văn Hải" ~ "Văn Hải"
}

function _looksLikeNamedCharacter(value) {
  const s = String(value || '').trim();
  return /^[A-ZÀ-ỸĐ][\p{L}]+(?:\s+[A-ZÀ-ỸĐ][\p{L}]+)+$/u.test(s);
}

function validateAdaptiveScenePlan(plan, contract) {
  const p = plan || {}, c = compactChapterContract(contract), errors = [];
  if (!p || !Array.isArray(p.scenes) || !p.scenes.length) errors.push('Scene Graph không có scene.');
  if (!String(p.chapterGoal || '').trim()) errors.push('Scene Graph thiếu chapterGoal.');
  if (!String(p.endingAnchor || '').trim()) errors.push('Scene Graph thiếu endingAnchor.');
  const allowed = _contractNameSet(c), outsiders = [];
  (p.scenes || []).forEach(s => {
    if (!String(s.mustChange || '').trim()) errors.push((s.id || 'scene') + ' thiếu mustChange.');
    if (!String(s.handoff || '').trim()) errors.push((s.id || 'scene') + ' thiếu handoff.');
    (s.characters || []).forEach(name => {
      if (_looksLikeNamedCharacter(name) && allowed.size && !_nameInCast(name, allowed) && !_nameInText(name, c.nameSource) && !outsiders.includes(String(name).trim())) outsiders.push(String(name).trim());
    });
  });
  if (outsiders.length) errors.push('Nhân vật ngoài Canon Cast: ' + outsiders.join(', ') + ' (nếu là nhân vật thật thì thêm vào Story Bible/Outline; nếu không thì bỏ khỏi plan)');
  // V14.0.6: so khớp THEO CỤM CHỦ ĐỀ nguyên vẹn (vệ sĩ, khách sạn, váy cưới...) thay vì từng âm tiết rời
  // ("vệ", "sĩ", "khách"... trùng "bảo vệ", "bác sĩ", "khách" thông thường nên chương nào cũng bị từ chối).
  // Chủ đề nào Outline/Arc/requiredBeats của chương ĐÃ ghi rõ thì được phép xuất hiện trong plan.
  const allPlan = JSON.stringify(p).toLowerCase();
  // Chủ đề được phép nếu đã có trong: Outline/Arc/beat, MỆNH LỆNH + GỢI Ý của người dùng, hoặc đoạn kết chương trước
  // (cảnh đang diễn ra ở khách sạn thì chương sau nối tiếp ở đó là liên tục, không phải lệch tuyến).
  const allowedSource = [c.chapterOutline, c.arcGoal, c.mustChange, c.userBrief, c.openingContinuity].concat(c.requiredBeats || []).join(' ').toLowerCase();
  const DRIFT_TOPICS = [
    { rule: /vệ sĩ/i, plan: /vệ sĩ/ },
    { rule: /khách sạn/i, plan: /khách sạn/ },
    { rule: /váy cưới/i, plan: /váy cưới|shop váy|tiệm váy|cửa hàng váy/ },
    { rule: /kim chi/i, plan: /kim chi/ }
  ];
  (c.forbiddenDrift || []).forEach(rule => {
    DRIFT_TOPICS.forEach(t => {
      if (t.rule.test(String(rule)) && t.plan.test(allPlan) && !t.plan.test(allowedSource)) {
        errors.push('Plan nhắc tới "' + (allPlan.match(t.plan) || [''])[0] + '" nhưng Outline/Brief/Gợi ý/đoạn kết chương trước không có — bỏ tuyến này hoặc ghi rõ vào Outline/Gợi ý. Luật: ' + String(rule).slice(0, 140));
      }
    });
  });
  return { ok: errors.length === 0, errors: errors.slice(0, 20), contract: c, outsiders };
}

function validateSceneTextAgainstContract(text, contract) {
  const c = compactChapterContract(contract), t = String(text || ''), errors = [];
  if (t.trim().length < 80) errors.push('scene quá ngắn');
  const allowed = _contractNameSet(c);
  const names = (c.allowedCharacters || []).map(String).filter(Boolean);
  // Chỉ chặn các nhân vật đã biết trong Story Bible nhưng không được phép ở chương này;
  // không cố đoán mọi danh từ chung trong văn xuôi.
  const known = Array.isArray(contract && contract.knownCharacters) ? contract.knownCharacters : [];
  known.forEach(name => {
    if (!name || allowed.has(normalizeName(name))) return;
    const re = new RegExp('(^|[^\\p{L}])' + String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^\\p{L}]|$)', 'iu');
    if (re.test(t)) errors.push('scene dùng nhân vật ngoài allowed cast: ' + name);
  });
  return { ok: errors.length === 0, errors: errors.slice(0, 10) };
}

/* ===== V14.0.16 — KIỂM TRA TỪNG SCENE (code, 0 token) + rà AI tùy chọn =====
   Lỗi NẶNG (errors) -> viết lại ĐÚNG scene đó ngay (không ghép tiếp scene sai vào chương).
   Cảnh báo (warnings) -> chỉ ghi telemetry, không tốn thêm lượt gọi AI. */
const SCENE_STOP_TOKENS = new Set(['va','la','cua','mot','cac','nhung','trong','khi','cho','voi','duoc','nay','kia','the','nao','thi','den','tu','ra','vao','len','xuong','nhu','nen','ma','cung','da','dang','se','con','chi','rat','hon','nhieu','khong','co','nguoi','viec','dieu','luc','sau','truoc','nhau','lai','roi','ve','di','de','tren','duoi','giua','ngoai','minh','ho','no','anh','chi','em','ong','ba','cau','phai','biet','thay','muon','can','moi','van','vua','cung','hay','hoac','neu','vi','nen','boi','tai','theo','sang','qua']);
const SCENE_LEAK_RE = /(^|\n)\s*(?:\*\*|#{1,4}\s*)?(?:scene|cảnh|canh)\s*\d+\s*[:.\-—)]|\b(?:CONTRACT COMPACT|STATE DELTA|ALLOWED CAST|STYLE LOCK|REQUIRED CHECKLIST|ĐIỂM KẾT BẮT BUỘC|RÀO_CHẮN_TUỔI)\b/i;
// V14.5.4: model lớn hay tự thêm tiêu đề "Scene 2:" / "**Cảnh 2.**" hoặc nhắc tên khối chỉ dẫn -> gỡ các dòng đó thay vì loại cả scene.
const SCENE_LEAK_KW_RE = /\b(?:CONTRACT COMPACT|STATE DELTA|ALLOWED CAST|STYLE LOCK|REQUIRED CHECKLIST|ĐIỂM KẾT BẮT BUỘC|RÀO_CHẮN_TUỔI)\b/i;
const SCENE_HEAD_RE = /^\s*(?:\*\*|__|#{1,4}\s*)?\s*(?:scene|cảnh|canh)\s*\d+\s*(?:\*\*|__)?\s*[:.\-—–)]\s*(?:\*\*|__)?\s*/i;
function stripSceneLeaks(text) {
  const out = [];
  String(text || '').split('\n').forEach(line => {
    if (SCENE_LEAK_KW_RE.test(line)) return;                        // dòng nhắc khối chỉ dẫn -> bỏ
    const m = line.match(SCENE_HEAD_RE);
    if (m) { const rest = line.slice(m[0].length).replace(/^\s*(?:\*\*|__)\s*/, '').trim(); if (rest.length < 25) return; line = rest; } // tiêu đề trơ -> bỏ; "Scene 2: văn xuôi…" -> giữ phần văn xuôi
    out.push(line);
  });
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
function _sceneTokens(text) {
  return normalizeName(text).split(/[^a-z0-9đ]+/).filter(t => t.length >= 3 && !SCENE_STOP_TOKENS.has(t));
}
// Tỉ lệ từ khóa của `phrase` xuất hiện trong `text` (null nếu phrase quá ít từ khóa để so sánh).
function sceneKeywordCoverage(text, phrase) {
  const pt = Array.from(new Set(_sceneTokens(phrase)));
  if (pt.length < 3) return null;
  const tt = new Set(_sceneTokens(text));
  return pt.filter(t => tt.has(t)).length / pt.length;
}
function checkSceneQuality(text, scene, ctx) {
  ctx = ctx || {}; scene = scene || {};
  const t = String(text || ''), words = countWords(t), target = Number(scene.targetWords) || 0;
  const base = validateSceneTextAgainstContract(t, ctx.contract);
  const errors = base.errors.slice(), warnings = [];
  if (words < 80 && !errors.includes('scene quá ngắn')) errors.push('scene quá ngắn');
  if (SCENE_LEAK_RE.test(t)) errors.push('scene lộ chỉ dẫn/tiêu đề (vd "Scene 2:", CONTRACT, STATE DELTA) — chỉ được trả văn xuôi');
  if (target && words >= 80 && words < target * 0.5) warnings.push('scene ngắn hơn 50% ngân sách (' + words + '/' + target + ' từ) — dựa vào bước bù từ');
  if (target && words > target * 2.2) warnings.push('scene dài gấp ' + (words / target).toFixed(1) + ' lần ngân sách (' + words + '/' + target + ' từ)');
  if (words >= 80 && !/[.!?…"”»)\]]\s*$/.test(t.trim())) warnings.push('scene kết thúc giữa câu (có thể bị cắt)');
  if (words >= 80 && scene.mustChange) {
    const cov = sceneKeywordCoverage(t, scene.mustChange);
    if (cov !== null && cov < 0.2) warnings.push('mustChange có vẻ chưa thực hiện: "' + String(scene.mustChange).slice(0, 90) + '"');
  }
  if (words >= 80 && Array.isArray(scene.characters) && scene.characters.length) {
    const nt = ' ' + normalizeName(t).replace(/[^a-z0-9\u0111]+/g, ' ') + ' ';
    const mentioned = scene.characters.some(n => {
      const full = normalizeName(n).replace(/[^a-z0-9\u0111]+/g, ' ').trim(), toks = full.split(' ').filter(x => x.length >= 2);
      return toks.length && (nt.includes(' ' + full + ' ') || nt.includes(' ' + toks[toks.length - 1] + ' '));
    });
    if (!mentioned) warnings.push('không nhắc tên nhân vật nào trong kế hoạch scene (' + scene.characters.slice(0, 3).join(', ') + ')');
  }
  if (words >= 80 && ctx.isFinal && ctx.endingAnchor) {
    const tail = t.slice(Math.floor(t.length * 0.6)), cov = sceneKeywordCoverage(tail, ctx.endingAnchor);
    if (cov !== null && cov < 0.2) warnings.push('đoạn cuối chưa chạm điểm kết dự kiến: "' + String(ctx.endingAnchor).slice(0, 90) + '"');
  }
  return { ok: errors.length === 0, errors: errors.slice(0, 8), warnings: warnings.slice(0, 6), words };
}
// Rà AI nhỏ cho MỘT scene (tùy chọn, mặc định tắt): chỉ gửi contract scene + văn bản scene, không gửi cả chương.
function buildSceneReviewPrompt(o) {
  o = o || {}; const s = o.scene || {};
  const cc = o.chapterContract ? promptChapterContract(o.chapterContract) : null;
  return [
    'KIỂM TRA MỘT SCENE tiểu thuyết so với kế hoạch. Chỉ trả JSON: {"ok":true|false,"issues":[{"code":"MUST_CHANGE|LOCATION_TIME|NEW_THREAD|CAST|HANDOFF","msg":"ngắn gọn, nêu cách sửa"}]}',
    'Chỉ báo lỗi CHẮC CHẮN. Văn phong, nhịp, từ ngữ KHÔNG phải lỗi. HANDOFF chỉ là gợi ý và KHÔNG báo vì scene sau khác địa điểm/thời điểm (scene sau sẽ tự có câu chuyển cảnh). KHÔNG tự nghĩ thêm yêu cầu: chỉ đối chiếu với chữ trong SCENE CONTRACT; ví dụ hay cách làm bạn hình dung KHÔNG phải điều bắt buộc.',
    '- MUST_CHANGE: thay đổi cốt lõi trong mustChange HOÀN TOÀN vắng trong văn bản. Thực hiện một phần, hoặc bằng hành động khác với cách bạn hình dung, vẫn là ĐẠT. Không đòi hành động/kết quả cụ thể mà mustChange không nêu; thiếu một chi tiết nhỏ thì KHÔNG báo.\n- LOCATION_TIME: địa điểm/thời điểm trái kế hoạch mà không có câu chuyển cảnh.\n- NEW_THREAD: tự mở tuyến/biến cố lớn hoặc nhân vật quan trọng mới ngoài kế hoạch.\n- CAST: dùng nhân vật ngoài allowed cast làm vai chính của cảnh.\n- HANDOFF: phần cuối không dẫn tới scene sau.',
    'SCENE CONTRACT:\n' + JSON.stringify(compactSceneContract(s)),
    cc ? 'CHAPTER CONTRACT:\n' + JSON.stringify({ allowedCharacters: cc.allowedCharacters, forbiddenDrift: cc.forbiddenDrift }) : '',
    o.nextScene ? 'SCENE SAU (để xét handoff): ' + JSON.stringify({ location: o.nextScene.location, time: o.nextScene.time, purpose: String(o.nextScene.purpose || '').slice(0, 160) }) : '',
    'VĂN BẢN SCENE:\n' + String(o.text || '').slice(0, 9000)
  ].filter(Boolean).join('\n\n');
}
function parseSceneReviewResponse(raw) {
  // Không dùng stripThinkingOutput: JSON thuần ASCII sẽ bị coi là "khối tiếng Anh" và bị xóa.
  const t = String(raw || '').replace(/<think(?:ing)?[\s>][\s\S]*?<\/think(?:ing)?>/gi, '');
  const i = t.indexOf('{'), j = t.lastIndexOf('}');
  if (i < 0 || j <= i) return null;
  let obj; try { obj = JSON.parse(t.slice(i, j + 1)); } catch (_) { return null; }
  if (!obj || typeof obj !== 'object') return null;
  const issues = Array.isArray(obj.issues) ? obj.issues : [];
  const errors = [], warnings = [];
  issues.slice(0, 6).forEach(x => {
    const code = String(x && x.code || '').toUpperCase(), msg = String(x && (x.msg || x.message) || '').replace(/\s+/g, ' ').slice(0, 360);
    if (!msg) return;
    (code === 'HANDOFF' ? warnings : errors).push((code || 'ISSUE') + ': ' + msg);
  });
  return { ok: obj.ok !== false && !errors.length, errors, warnings };
}

/* ===== V14.5.9 — SỔ BẰNG CHỨNG SỰ KIỆN OUTLINE =====
   Mỗi mục Outline được giao cho một scene; scene viết xong thì AI phải TRÍCH CÂU NGUYÊN VĂN làm bằng chứng cho từng mục.
   Code kiểm tra câu trích có thật trong văn bản (chống bịa). Mục thiếu -> vá CỤC BỘ đúng scene đó; cuối chương chỉ chốt lại bằng sổ này
   (thay cho đối chiếu từ khóa vốn hay báo thừa khi truyện viết ý đó bằng câu chữ khác). */
function _evNorm(x) { return String(x || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').replace(/\s+/g, ' ').trim(); }
function beatEvidenceInText(evidence, text) {
  const e = _evNorm(evidence), t = _evNorm(text);
  if (e.split(' ').filter(Boolean).length < 3) return false;
  if (t.includes(e)) return true;
  const et = e.split(' ').filter(w => w.length >= 2), tt = new Set(t.split(' '));
  return et.length >= 4 && et.filter(w => tt.has(w)).length / et.length >= 0.7;
}
/* V14.5.14: MỤC OUTLINE GHÉP (liệt kê >= 3 hành động: "Còng tay, đeo vòng cổ, bắt quỳ và …") được tách thành Ý CON.
   Trước đây chỉ cần một câu trích cho cả mục là qua kiểm tra, nên chỉ một ý con xuất hiện (đâu đó trong cảnh) vẫn "done"; bộ chấm cuối chương mới bắt lỗi -> viết xong mới biết thiếu. */
function outlineItemParts(text) {
  const parts = String(text || '').replace(/\s+/g, ' ').trim()
    .split(/\s*(?:,|;|\s\+\s|\s+và\s+|\.\s+(?=\p{Lu}))\s*/u)
    .map(s => s.replace(/[.\s]+$/u, '').trim()).filter(s => s.length >= 4);
  return parts.length >= 3 && parts.length <= 7 ? parts : [];
}
function outlineItemIsCompound(text) { return outlineItemParts(text).length >= 3; }
function buildBeatEvidencePrompt(o) {
  o = o || {}; const items = Array.isArray(o.items) ? o.items : [];
  const itemLine = x => {
    const t = String(x.text || '').replace(/\s+/g, ' ').slice(0, 300), parts = outlineItemParts(t);
    return x.n + '. ' + t + (parts.length ? '  [GỒM ' + parts.length + ' Ý CON, phải có ĐỦ TẤT CẢ: ' + parts.map((p, k) => (k + 1) + ') ' + p).join(' · ') + ']' : '');
  };
  const hasParts = items.some(x => outlineItemParts(x.text).length);
  return [
    'KIỂM TRA SỰ KIỆN BẮT BUỘC của ' + (o.scope === 'chapter' ? 'CHƯƠNG' : 'MỘT SCENE') + ' tiểu thuyết. Với MỖI sự kiện dưới đây, quyết định văn bản đã THỰC HIỆN nó chưa.',
    'Chỉ trả JSON: {"items":[{"n":1,"done":true,"evidence":"trích NGUYÊN VĂN 6–25 từ liên tục từ văn bản"}]} — evidence để rỗng nếu done=false.',
    'QUY TẮC: done=true khi sự kiện thực sự DIỄN RA trong truyện (hành động/lời thoại/thông tin/hậu quả cụ thể), kể cả viết bằng câu chữ khác hay thứ tự khác. done=false khi hoàn toàn vắng, chỉ được nhắc thoáng qua/tóm tắt một câu, hoặc diễn ra ngược lại. Không đòi chi tiết mà sự kiện không nêu. evidence PHẢI chép đúng từng chữ từ văn bản, không viết lại.',
    hasParts ? 'MỤC CÓ Ý CON: done=true CHỈ KHI TẤT CẢ các ý con đều thực sự diễn ra (không đòi từng chữ), và chúng thuộc MỘT đoạn cảnh liền mạch chứ không rải ở những cảnh/đoạn xa nhau. Thiếu dù một ý con -> done=false.' : '',
    'SỰ KIỆN CẦN KIỂM TRA:\n' + items.map(itemLine).join('\n'),
    'VĂN BẢN:\n' + String(o.text || '').slice(0, o.scope === 'chapter' ? 42000 : 12000)
  ].join('\n\n');
}
// Trả { results:[{n,done,evidence}], missing:[n], unknown:[n] } hoặc null nếu không đọc được. done=true mà câu trích không có trong văn bản -> coi là CHƯA (chống bịa).
function parseBeatEvidence(raw, ns, text) {
  const t = String(raw || '').replace(/<think(?:ing)?[\s>][\s\S]*?<\/think(?:ing)?>/gi, '');
  const i = t.indexOf('{'), j = t.lastIndexOf('}');
  if (i < 0 || j <= i) return null;
  let obj; try { obj = JSON.parse(t.slice(i, j + 1)); } catch (_) { return null; }
  const arr = obj && Array.isArray(obj.items) ? obj.items : null;
  if (!arr) return null;
  const want = new Set((ns || []).map(Number)), by = {};
  arr.forEach(x => { const n = Number(x && x.n); if (want.has(n) && !by[n]) by[n] = x; });
  const results = [], missing = [], unknown = [];
  (ns || []).forEach(n => {
    const x = by[n];
    if (!x) { unknown.push(n); return; }
    const ev = String(x.evidence || '').replace(/\s+/g, ' ').trim();
    const done = x.done === true && beatEvidenceInText(ev, text);
    results.push({ n, done, evidence: done ? ev.slice(0, 200) : '' });
    if (!done) missing.push(n);
  });
  return { results, missing, unknown };
}
function beatMissingError(texts) {
  /* V14.5.14: mục ghép thiếu ý con -> KHÔNG vá chèn (chèn rải ý con ra nhiều chỗ, gây cảnh rời rạc/lặp); lỗi này không thuộc diện "vá được" nên scene được VIẾT LẠI liền mạch. */
  const compound = (texts || []).filter(outlineItemIsCompound);
  if (compound.length) return 'THIẾU TRÌNH TỰ BẮT BUỘC (SỰ KIỆN BẮT BUỘC chưa đủ ý con): ' + compound.map(x => '«' + String(x).replace(/\s+/g, ' ').slice(0, 200) + '»').join(' · ') + ' — viết lại scene thành MỘT cảnh liên tục: các ý theo đúng thứ tự, mỗi ý có hành động/lời thoại/phản ứng riêng, kể mỗi ý đúng MỘT lần, không rải sang đoạn khác và không tóm tắt.' + ((texts || []).length > compound.length ? ' Đồng thời còn thiếu: ' + (texts || []).filter(x => !outlineItemIsCompound(x)).map(x => '«' + String(x).replace(/\s+/g, ' ').slice(0, 160) + '»').join(' · ') : '');
  return 'MUST_CHANGE: thiếu SỰ KIỆN BẮT BUỘC (chưa thấy diễn ra trong văn bản): ' + texts.map(x => '«' + String(x).replace(/\s+/g, ' ').slice(0, 160) + '»').join(' · ') + ' — chèn hành động/lời thoại cụ thể cho sự kiện này, không tóm tắt một câu.';
}

/* V14.3: VÁ CỤC BỘ SCENE. Lỗi rà AI kiểu "thiếu chi tiết / thiếu câu chuyển cảnh" (MUST_CHANGE, LOCATION_TIME) sửa được bằng vài câu CHÈN,
   không cần viết lại cả scene. NEW_THREAD / CAST cần gỡ nội dung nên không thuộc diện vá chèn. */
const SCENE_FIX_MAX_ADD = 320;
function sceneErrorsPatchable(errors) {
  const a = Array.isArray(errors) ? errors : [];
  return a.length > 0 && a.every(e => /^(MUST_CHANGE|LOCATION_TIME)\b/i.test(String(e)));
}
function buildSceneFixPrompt(o) {
  o = o || {}; const s = o.scene || {}, wc = countWords(o.text || ''), maxAdd = Number(o.maxAdd) || SCENE_FIX_MAX_ADD;
  const beatNote = (o.errors || []).some(e => /SỰ KIỆN BẮT BUỘC/.test(String(e))) ? 'SỰ KIỆN BẮT BUỘC là việc Outline giao nên ĐƯỢC chèn (không tính là "sự kiện ngoài kế hoạch"): viết thành khoảnh khắc đầy đủ (hành động, lời thoại, phản ứng), đặt ở chỗ hợp lý theo thứ tự nhân quả, TRƯỚC đoạn kết. TUYỆT ĐỐI giữ đúng nhân vật, tên gọi, địa điểm và thời điểm CỦA SCENE NÀY (' + [].concat(s.characters || []).slice(0, 6).join(', ') + (s.location ? ' @ ' + s.location : '') + '): nếu câu sự kiện nhắc nhân vật/nơi chốn khác với scene thì KHÔNG đem tên hay nơi đó vào, chỉ thực hiện phần hành động cho đúng nhân vật có mặt trong scene.' : '';
  return [
    'VÁ CỤC BỘ MỘT SCENE tiểu thuyết bằng cách CHÈN thêm vài câu/đoạn ngắn. KHÔNG viết lại scene, KHÔNG replace/delete, KHÔNG đổi đoạn kết.',
    'LỖI CẦN KHẮC PHỤC (từ bước rà scene):\n' + (o.errors || []).map(e => '- ' + e).join('\n'),
    'SCENE CONTRACT:\n' + JSON.stringify(compactSceneContract(s)),
    o.profile || '',
    'ĐỊNH DẠNG — chỉ trả các khối sau, không giải thích, không markdown:',
    '>>> SAU: <chép NGUYÊN VĂN 6–20 từ CUỐI của một đoạn có sẵn, đúng từng chữ>',
    '<1–3 câu hoặc một đoạn ngắn văn xuôi tiếng Việt thuần, nối mượt với đoạn trước/sau>',
    '>>> TRƯỚC: <chép NGUYÊN VĂN 6–20 từ ĐẦU của một đoạn có sẵn>',
    '<đoạn chèn>',
    beatNote,
    'QUY TẮC: tối đa 3 chỗ chèn, tổng thêm không quá ' + maxAdd + ' từ; mỗi cụm neo khác nhau và duy nhất trong scene; không chèn sau đoạn cuối; không thêm sự kiện lớn, tuyến hay nhân vật mới ngoài kế hoạch; không nhãn, tiêu đề hay ghi chú.',
    'Với MUST_CHANGE: chèn đúng chi tiết/hành động còn thiếu vào chỗ hợp lý. Với LOCATION_TIME: chèn 1–2 câu cầu nối (rời nơi cũ, đến nơi mới, thời điểm mới).',
    '===== VĂN BẢN SCENE (' + wc + ' từ) =====\n' + String(o.text || '').slice(0, 12000) + '\n===== HẾT ====='
  ].filter(Boolean).join('\n\n');
}
// Ghép các khối chèn vào scene. Trả { ok, text, added, reason }.
function applySceneFixInserts(text, raw, maxAdd) {
  const blocks = parseInsertBlocks(raw);
  if (!blocks.length) return { ok: false, reason: 'AI không trả khối chèn hợp lệ' };
  const base = String(text || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim(); // cùng cách chuẩn hóa với applyChapterPatches, để kiểm tra 'không đổi đoạn kết' không lệch vì khoảng trắng thừa
  const res = applyExpandInserts(base, blocks, countWords(base) + (Number(maxAdd) || SCENE_FIX_MAX_ADD));
  if (!res.applied) return { ok: false, reason: 'không ghép được khối chèn nào' + (res.skipped && res.skipped[0] ? ' (' + res.skipped[0].reason + ')' : '') };
  if (res.added < 8) return { ok: false, reason: 'đoạn chèn quá ít (+' + res.added + ' từ)' };
  return { ok: true, text: res.text, added: res.added, applied: res.applied };
}
// Tóm tắt cảnh báo scene cho người dùng: scene bị "giữ dù AI chê" luôn hiện đầy đủ, rồi tới cảnh báo khác; báo rõ phần bị ẩn.
function summarizeSceneWarnings(stats, maxOther) {
  const st = stats || {}, all = Array.isArray(st.sceneWarnings) ? st.sceneWarnings : [], lim = maxOther == null ? 4 : maxOther;
  const important = all.filter(w => /GIỮ BẢN CUỐI|ĐÃ VÁ/.test(w)), rest = all.filter(w => !/GIỮ BẢN CUỐI|ĐÃ VÁ/.test(w));
  /* V14.3.8: HANDOFF chỉ là gợi ý — gộp thành MỘT dòng ngắn thay vì liệt kê từng câu dài trên thẻ chương. */
  const hand = rest.filter(w => /\bHANDOFF\b/.test(w)), others = rest.filter(w => !/\bHANDOFF\b/.test(w));
  const handIds = Array.from(new Set(hand.map(w => (String(w).match(/^(S\d+)/) || [])[1]).filter(Boolean)));
  const shown = important.concat(others.slice(0, lim)).concat(handIds.length ? ['gợi ý nối scene (HANDOFF, không phải lỗi): ' + handIds.join(', ')] : []), hidden = others.length - Math.min(others.length, lim);
  return { shown, hidden, kept: Array.isArray(st.sceneKept) ? st.sceneKept : [], patched: Array.isArray(st.scenePatched) ? st.scenePatched : [], total: all.length };
}

// Một dòng tóm tắt cho người dùng (đường viết thường hiển thị ở dòng trạng thái). '' nếu không có gì đáng báo.
function formatSceneNote(stats) {
  const st = stats || {}, kept = Array.isArray(st.sceneKept) ? st.sceneKept : [], patched = Array.isArray(st.scenePatched) ? st.scenePatched : [];
  const warnN = Array.isArray(st.sceneWarnings) ? st.sceneWarnings.length : 0;
  const parts = [];
  if (kept.length) parts.push('⚠ scene giữ dù AI rà báo lỗi: ' + kept.join(', ') + ' (nên đọc lại)');
  if (patched.length) parts.push('đã vá cục bộ: ' + patched.join(', '));
  const other = warnN - kept.length - patched.length;
  if (other > 0) parts.push(other + ' cảnh báo scene khác');
  return parts.join(' · ');
}

// V14.0.20: quality contract for Vietnamese-native fiction. Keep this shared so
// normal writing, background writing and adaptive scenes do not drift stylistically.
function vietnameseNovelWritingPrompt() {
  return [
    'CHẤT LƯỢNG VĂN XUÔI TIẾNG VIỆT:',
    '- Viết như tác phẩm được sáng tác trực tiếp bằng tiếng Việt, không dịch từng chữ từ tiếng Anh/Trung; ưu tiên collocation và trật tự từ tự nhiên.',
    '- Giữ POV, thì kể, xưng hô, địa vị xã hội, kiến thức và giọng riêng của từng nhân vật; không để mọi người nói cùng một giọng.',
    '- Mỗi lượt thoại phải có mục đích: bộc lộ ý định, quan hệ, xung đột, cảm xúc hoặc thông tin cần thiết; không lặp lại nguyên văn điều phần kể đã nói.',
    '- Tách người nói thành đoạn riêng; khi đổi người nói, đổi hành động trọng tâm hoặc đổi nhịp cảm xúc thì xuống đoạn. Ưu tiên đoạn ngắn-vừa dễ đọc trên điện thoại.',
    '- Thể hiện cảm xúc bằng hành động, phản ứng cơ thể, lựa chọn và chi tiết quan sát được; tránh liên tục gọi tên cảm xúc hoặc dùng tính từ chung chung.',
    '- Xen kẽ câu ngắn và câu dài có kiểm soát; không dồn quá nhiều mệnh đề, không mở liên tiếp nhiều câu bằng cùng một chủ ngữ/cấu trúc.',
    '- Mỗi scene phải có điều nhân vật muốn, vật cản, một lựa chọn có giá phải trả và một thay đổi (quyền lực, hiểu biết, niềm tin, nguy hiểm hoặc quan hệ); không viết thành chuỗi sự kiện liệt kê.',
    '- Thoại có ẩn ý: người nói né tránh, ngắt lời, nói lệch hoặc im lặng khi bị dồn; không giải thích cốt truyện hay cảm xúc thành lời thoại diễn thuyết.',
    '- Chi tiết cảm giác phải cụ thể và riêng của cảnh (mùi, âm thanh, xúc giác, nhiệt độ, vật cản trong tay), không chỉ thị giác; không dùng sáo ngữ cảm giác có sẵn.',
    '- Chậm nhịp ở khoảnh khắc nặng (phản bội, mất mát, thú nhận, thân mật, quyết định không đảo ngược) và để lại dư âm trước khi chuyển cảnh; nén nhịp ở phần chuyển tiếp.',
    '- Kết cảnh bằng bước ngoặt, câu hỏi mở hoặc hậu quả đang tới; không kết bằng đoạn tóm tắt cảm xúc, bài học hay lời bình của người kể.',
    '- Không recap đầu chương nếu không cần; không chèn nhãn ngày giờ, tiêu đề scene, metadata, lời giải thích hay ghi chú của AI vào văn xuôi.'
  ].join('\n');
}

// V14.3.2: scene prompt CHỈ nhận checklist của chính scene đó (trước đây cả outline chương bị lặp 3 lần trong mọi scene prompt -> model kể lại toàn bộ chuỗi sự kiện ở từng scene).
/* V14.5.14: meta = ghi chú Kháng cự/Hậu quả của Outline chương; items = các mục Outline đánh số. Trước đây prompt VIẾT scene không thấy "Kháng cự" (chỉ prompt lập kế hoạch thấy)
   nên writer tước dao ngay dù Outline đòi "chống trả quyết liệt"; mục ghép cũng không có "trình tự liên tục" để writer giữ trong MỘT cảnh. */
function sceneScopeOf(scenes, i, meta, items) {
  const list = Array.isArray(scenes) ? scenes : [];
  const pick = sc => [sc && sc.id, String((sc && sc.mustChange) || '').replace(/\s+/g, ' ').trim().slice(0, 220)].filter(Boolean).join(': ');
  const scope = { index: i, total: list.length, done: list.slice(0, i).map(pick).filter(Boolean), later: list.slice(i + 1).map(pick).filter(Boolean), notes: [], sequences: [] };
  const cur = list[i], own = cur && Array.isArray(cur.outlineItems) ? cur.outlineItems.map(Number).filter(n => n >= 1) : [];
  if (!own.length) return scope;
  const m = meta || {}, clean = v => String(v || '').replace(/\s+/g, ' ').trim().slice(0, 260);
  if (clean(m.resistance)) scope.notes.push('KHÁNG CỰ CỦA CHƯƠNG (diễn tiến xuyên suốt các scene; scene này chỉ thể hiện phần hợp với vị trí của nó, không kể lại phần đã có, không rút ngắn thành một câu. Nếu mục của scene là kháng cự rồi bị khống chế/tước vũ khí thì phải viết cuộc giằng co thật — nhiều nhịp đòn/đỡ/phản ứng — TRƯỚC khi bị khống chế, không tước ngay): ' + clean(m.resistance));
  if (clean(m.consequence)) {
    const idxs = []; list.forEach((sc, k) => { if (sc && Array.isArray(sc.outlineItems) && sc.outlineItems.length) idxs.push(k); });
    let owner = idxs.length ? idxs[idxs.length - 1] : -1, best = 0;
    const ct = _beatToks(m.consequence);
    idxs.forEach(k => {
      const pool = new Set(); list[k].outlineItems.forEach(n => _beatToks((items || [])[n - 1] || '').forEach(w => pool.add(w)));
      const hit = ct.filter(w => pool.has(w)).length;
      if (hit > best) { best = hit; owner = k; }
    });
    if (owner === i) scope.notes.push('HẬU QUẢ CẦN THỂ HIỆN (một lần, ở scene này): ' + clean(m.consequence));
  }
  own.forEach(n => {
    const parts = outlineItemParts((items || [])[n - 1] || '');
    if (parts.length >= 3) scope.sequences.push(parts);
  });
  return scope;
}
// V14.5.14: tách mệnh đề Hậu quả đã được một mục Outline nêu -> bỏ khỏi ghi chú, tránh một sự kiện bị yêu cầu hai lần (nguồn của cảnh lặp ba lần).
function _beatToks(t) { return Array.from(new Set(normalizeName(t).split(/[^a-z0-9đ]+/).filter(w => w.length >= 2 && !SCENE_STOP_TOKENS.has(w)))); }
function outlineClauseCovered(clause, items) {
  const ct = _beatToks(clause); if (ct.length < 2) return false;
  const pool = new Set(); (items || []).forEach(it => _beatToks(it).forEach(w => pool.add(w)));
  return ct.filter(w => pool.has(w)).length / ct.length >= 0.6;
}
function dedupeOutlineMeta(meta, items) {
  const out = Object.assign({}, meta || {});
  if (out.consequence) {
    const keep = String(out.consequence).split(/\s*(?:\s\+\s|;)\s*/).map(s => s.trim()).filter(Boolean).filter(c => !outlineClauseCovered(c, items));
    if (keep.length) out.consequence = keep.join(' + '); else delete out.consequence;
  }
  return out;
}
function sceneScopedContract(contract) {
  const c = promptChapterContract(contract);
  delete c.chapterOutline; delete c.requiredBeats; delete c.mustChange;
  c.arcGoal = String(c.arcGoal || '').slice(0, 240);
  return c;
}
function sceneScopedChecklistBlock(scene, scope) {
  const s = scene || {}, sc = scope || {};
  const mine = [String(s.mustChange || '')].concat(Array.isArray(s.beats) ? s.beats : []).map(x => String(x).replace(/\s+/g, ' ').trim().slice(0, 220)).filter(Boolean);
  const perBeat = (Number(s.targetWords) && Array.isArray(s.beats) && s.beats.length) ? Math.round(Number(s.targetWords) / s.beats.length / 10) * 10 : 0;
  const out = ['CHECKLIST RIÊNG CỦA SCENE ' + (s.id || '') + ' (' + ((sc.index || 0) + 1) + '/' + (sc.total || '?') + ') — chỉ thực hiện các mục này rồi dừng ở handoff' + (perBeat >= 150 ? '; mỗi mục viết thành cảnh đầy đủ (hành động, lời thoại, phản ứng), khoảng ' + perBeat + ' từ/mục, không tóm tắt' : '') + ':\n- ' + mine.join('\n- ')];
  if (sc.done && sc.done.length) out.push('ĐÃ KỂ XONG Ở SCENE TRƯỚC — TUYỆT ĐỐI KHÔNG kể lại hay diễn đạt lại (chỉ được nhắc hậu quả bằng một mệnh đề ngắn):\n- ' + sc.done.join('\n- '));
  if (sc.later && sc.later.length) out.push('DÀNH CHO SCENE SAU — KHÔNG kể diễn biến ở scene này; chỉ được gợi sang bằng 1–2 câu cuối theo handoff:\n- ' + sc.later.join('\n- '));
  (sc.sequences || []).forEach(parts => out.push('TRÌNH TỰ LIÊN TỤC BẮT BUỘC — viết trong MỘT cảnh liền mạch, đúng thứ tự, mỗi bước kể ĐÚNG MỘT LẦN (không tách sang đoạn khác, không nhắc lại như hậu quả, không bỏ bước): ' + parts.join(' → ')));
  (sc.notes || []).forEach(n => out.push(n));
  return out.join('\n\n');
}
// V14.3.2: phát hiện scene mới KỂ LẠI sự kiện đã có ở scene trước bằng câu chữ khác (so theo từ đặc trưng của từng đoạn, không cần trùng nguyên văn).
function sceneParaphraseOverlap(priorText, newText) {
  const pri = _splitParas(priorText), cur = _splitParas(newText);
  if (pri.length < 2 || cur.length < 3) return { hit: 0, total: 0 };
  const all = pri.concat(cur), prof = _paraProfiles(all);
  let hit = 0, total = 0;
  for (let k = pri.length; k < all.length; k++) {
    if (prof[k].size < 5) continue; total++;
    for (let j = 0; j < pri.length; j++) if (_setSim(prof[k], prof[j]) >= 0.45) { hit++; break; }
  }
  return { hit, total };
}

/* V14.3.8: scene bị cắt giữa câu (hết token) -> lùi về câu hoàn chỉnh gần nhất ngay khi nhận, thay vì để câu cụt nằm giữa chương. Chỉ cắt khi phần dở ngắn (<= 60 từ). */
function trimDanglingSceneEnd(text) {
  const t = String(text || '').replace(/\s+$/, '');
  if (!t || /[.!?…"”»)\]*]\s*$/.test(t)) return t;
  const paras = t.split(/\n{2,}/), last = paras.pop() || '';
  const ends = Array.from(last.matchAll(/[.!?…]["”»)\]]*(?=\s|$)/g));
  if (ends.length) {
    const e = ends[ends.length - 1], idx = e.index + e[0].length;
    if (countWords(last.slice(idx)) <= 60) return paras.concat([last.slice(0, idx).trimEnd()]).join('\n\n');
    return t;
  }
  if (paras.length && countWords(last) <= 40) return paras.join('\n\n');
  return t;
}
/* V14.3.8: scene khác địa điểm/thời điểm so với scene trước -> BẮT BUỘC mở bằng câu chuyển cảnh (nguyên nhân phổ biến của cảnh báo HANDOFF "scene sau diễn ra buổi tối tại tầng hầm nhưng scene này kết thúc vào buổi sáng..."). */
function _sceneNorm(x) { return String(x || '').toLowerCase().replace(/\s+/g, ' ').trim(); }
function _sceneSame(a, b) { const x = _sceneNorm(a), y = _sceneNorm(b); return !x || !y || x === y || x.includes(y) || y.includes(x) || /^tiếp nối|^ngay sau/.test(x) || /^tiếp nối|^ngay sau/.test(y); }
function sceneBridgeBlock(scene, prev) {
  if (!scene || !prev) return '';
  const locDiff = !_sceneSame(scene.location, prev.location), timeDiff = !_sceneSame(scene.time, prev.time);
  if (!locDiff && !timeDiff) return '';
  return 'CẦU NỐI BẮT BUỘC: scene trước kết thúc ở "' + String(prev.location || '?').slice(0, 80) + '" (' + String(prev.time || '?').slice(0, 60) + '), scene này diễn ra ở "' + String(scene.location || '?').slice(0, 80) + '" (' + String(scene.time || '?').slice(0, 60) + '). Câu/đoạn ĐẦU TIÊN phải là 1–2 câu chuyển cảnh nêu rõ nhân vật rời đâu, đến đâu và thời điểm nào, rồi mới vào nội dung scene.';
}
function buildAdaptiveSceneWritePrompt(o) {
  const s = o.scene || {}, limits = adaptiveChapterWordLimits(o.state || {});
  return [
    'VIẾT SCENE TIẾP NỐI bằng tiếng Việt; chỉ trả văn xuôi, không tiêu đề/giải thích.',
    vietnameseNovelWritingPrompt(),
    'Tổng chương ' + limits.minAccept + '–' + limits.maxAccept + ' từ; scene khoảng ' + s.targetWords + ' từ. Ưu tiên nhịp tự nhiên, không độn.',
    'CONTRACT:\n' + JSON.stringify(compactSceneContract(s)),
    o.chapterGoal ? 'MỤC TIÊU CHƯƠNG: ' + String(o.chapterGoal).replace(/\s+/g, ' ').slice(0, 300) : '',
    sceneBridgeBlock(s, o.prevScene),
    o.sceneScope ? sceneScopedChecklistBlock(s, o.sceneScope) : o.requiredBeats ? 'REQUIRED CHECKLIST — scene này phải thực hiện hoặc bàn giao rõ một mục; cuối chương mọi mục phải có bằng chứng:\n' + String(o.requiredBeats).replace(/\s+/g, ' ').slice(0, 1200) : '',
    o.chapterContract ? 'CONTRACT COMPACT — scene chỉ được dùng cast, Arc và hướng đi trong contract:\n' + JSON.stringify(o.sceneScope ? sceneScopedContract(o.chapterContract) : promptChapterContract(o.chapterContract)) : '',
    sceneProfileWithAnchor(o.state, s, String(o.allowedCast || '').split(/\s*,\s*/)),
    o.allowedCast ? 'ALLOWED CAST — không biến tên ngoài danh sách thành nhân vật chính: ' + String(o.allowedCast).replace(/\s+/g, ' ').slice(0, 1200) : '',
    o.forbiddenDrift ? 'CẤM DRIFT KHỎI ARC: ' + String(o.forbiddenDrift).replace(/\s+/g, ' ').slice(0, 900) : '',
    o.endingAnchor && o.isFinalScene ? 'ĐIỂM KẾT BẮT BUỘC: ' + String(o.endingAnchor).replace(/\s+/g, ' ').slice(0, 360) : '',
    o.previousTail ? (o.isOpeningScene
      ? 'ĐOẠN KẾT CHƯƠNG TRƯỚC — KHÓA CẢNH MỞ: phải nối đúng địa điểm, thời điểm và người đang có mặt. Nếu muốn chuyển từ đường phố/phòng/xe sang nơi khác, bắt buộc viết hành động di chuyển hoặc câu chuyển tự nhiên trước khi đổi cảnh; tuyệt đối không nhảy thẳng vào địa điểm mới:\n'
      : 'ĐUÔI SCENE TRƯỚC — nối tiếp, không lặp:\n') + compactSceneTail(o.previousTail, 2400) : 'Mở scene đầu chương.',
    o.stateDelta ? 'STATE DELTA:\n' + JSON.stringify(compactSceneStateDelta(o.stateDelta)) : '',
    o.style ? 'STYLE LOCK:\n' + String(o.style).replace(/\s+/g, ' ').slice(0, 2800) : '',
    'Giữ nhân vật/địa điểm/thời gian và thay đổi trong contract; không thêm arc hay biến cố lớn. Cảnh trưởng thành (nếu contract có) chỉ dùng người trưởng thành và giữ nhất quán thiết lập.',
    o.correction ? 'BẢN VIẾT TRƯỚC CỦA SCENE NÀY BỊ TỪ CHỐI — viết lại scene từ đầu, giữ đúng contract và SỬA các lỗi sau (không nhắc tới lỗi trong văn bản):\n' + String(o.correction).replace(/\s+/g, ' ').slice(0, 900) : '',
    'Chỉ trả văn xuôi scene.'
  ].filter(Boolean).join('\n\n');
}

function buildAdaptiveSceneTopUpPrompt(o) {
  const p = o || {}, need = Math.max(200, Math.min(1800, Number(p.needWords) || 800));
  return [
    'VIẾT BỔ SUNG TIẾP NỐI bằng tiếng Việt; chỉ trả văn xuôi, không tiêu đề/giải thích.',
    p.completeOnly ? 'Chương đã đủ độ dài (' + (Number(p.currentWords) || '?') + ' từ). Lượt này CHỈ để viết nốt các sự kiện chính của Outline còn thiếu, khoảng ' + need + ' từ; không kể thêm gì khác.' : 'Chương hiện mới khoảng ' + (Number(p.currentWords) || '?') + ' từ và còn thiếu khoảng ' + need + ' từ để đạt tối thiểu 4.500 từ.',
    p.completeOnly ? '' : 'BẮT BUỘC viết ít nhất ' + need + ' từ (mục tiêu ' + Math.ceil(need * 1.15) + ' từ) diễn biến MỚI, tự nhiên; không tóm tắt, không lặp, không kéo dài rỗng.',
    p.missingBeats && p.missingBeats.length ? 'SỰ KIỆN CHÍNH CỦA OUTLINE CÒN THIẾU TRONG CHƯƠNG — PHẢI viết ĐỦ (có hành động, lời thoại, phản ứng; không tóm tắt). Nếu một sự kiện dưới đây thực ra ĐÃ được viết (dù bằng câu chữ khác) thì BỎ QUA, không viết lại:\n- ' + p.missingBeats.map(x => String(x).slice(0, 160)).join('\n- ') : '',
    'Đây chưa phải điểm kết: nếu đoạn cuối hiện tại có vẻ đã khép, coi đó là chuyển nhịp và tiếp tục hợp lý; chỉ dừng sau khi tạo thêm diễn biến, phản ứng, thông tin, quyết định hoặc hậu quả có thật.',
    p.chapterGoal ? 'MỤC TIÊU CHƯƠNG: ' + String(p.chapterGoal).replace(/\s+/g, ' ').slice(0, 500) : '',
    p.doneList && p.doneList.length ? 'ĐÃ KỂ ĐỦ TRONG CHƯƠNG — TUYỆT ĐỐI không kể lại hay diễn đạt lại các sự kiện này; chỉ mở rộng phản ứng, nội tâm, hậu quả, chi tiết bối cảnh tại điểm hiện tại:\n- ' + p.doneList.join('\n- ') : p.requiredBeats ? 'REQUIRED BEATS CÒN PHẢI ĐẢM BẢO:\n' + String(p.requiredBeats).replace(/\s+/g, ' ').slice(0, 1200) : '',
    p.chapterContract ? 'CONTRACT COMPACT — top-up chỉ mở rộng diễn biến đã hợp lệ, không mở tuyến mới:\n' + JSON.stringify((p.doneList && p.doneList.length ? sceneScopedContract : promptChapterContract)(p.chapterContract)) : '',
    p.allowedCast ? 'ALLOWED CAST — không biến tên ngoài danh sách thành nhân vật chính: ' + String(p.allowedCast).replace(/\s+/g, ' ').slice(0, 1200) : '',
    p.forbiddenDrift ? 'CẤM DRIFT KHỎI ARC: ' + String(p.forbiddenDrift).replace(/\s+/g, ' ').slice(0, 900) : '',
    p.endingAnchor ? 'ĐIỂM KẾT DỰ KIẾN: ' + String(p.endingAnchor).replace(/\s+/g, ' ').slice(0, 400) : '',
    p.previousTail ? 'ĐUÔI HIỆN TẠI — nối ngay từ đây, không lặp:\n' + compactSceneTail(p.previousTail, 2400) : '',
    p.stateDelta ? 'STATE DELTA:\n' + JSON.stringify(compactSceneStateDelta(p.stateDelta)) : '',
    p.style ? 'STYLE LOCK: ' + String(p.style).replace(/\s+/g, ' ').slice(0, 2800) : '',
    'Giữ đúng canon, nhân vật, địa điểm, thời gian và ngôi kể. Không thêm nhân vật quan trọng, arc mới hoặc biến cố lớn ngoài kế hoạch.'
  ].filter(Boolean).join('\n\n');
}

// V12.23: ĐỒNG BỘ viết thường ↔ viết nền — các khối prompt dùng chung (cùng một bản chữ cho cả hai nơi).
function buildVocabularyBlockFrom(state) {
  const v = (state && state.vocabulary) || {};
  const parts = [];
  if (v.preferred) parts.push("TỪ MUỐN DÙNG: " + v.preferred.replace(/\n/g, ", "));
  if (v.banned) parts.push("TỪ CẦN TRÁNH: " + v.banned.replace(/\n/g, ", "));
  if (v.overused) parts.push("CỤM ĐÃ LẶP NHIỀU (tránh dùng lại): " + v.overused.replace(/\n/g, " · "));
  if (v.anatomy) parts.push("CÁCH GỌI BỘ PHẬN: " + v.anatomy);
  return parts.length ? parts.join("\n") : "";
}

function _clipChapterText(t, maxChars) {
  t = t || "";
  if (t.length <= maxChars) return t;
  return t.slice(0, Math.floor(maxChars * 0.3)) + "\n\n[...]\n\n" + t.slice(-Math.floor(maxChars * 0.6));
}
// V14.0.17: active-record filter — deleted/invalidated chapters must never become continuity input.
function isActiveStoryChapter(chapter) {
  if (!chapter || typeof chapter !== "object") return false;
  const status = String(chapter.status || "").toLowerCase();
  return status !== "deleted" && status !== "invalidated" && chapter.deleted !== true && chapter.invalidated !== true;
}
function activeStoryChapters(chapters) {
  return (Array.isArray(chapters) ? chapters : []).filter(isActiveStoryChapter);
}
// Draft/soft-fail material must not outrank an accepted chapter when canon exists.
// Legacy chapters without a status are treated as accepted for backward compatibility.
function isAcceptedStoryChapter(chapter) {
  if (!isActiveStoryChapter(chapter)) return false;
  const status = String(chapter.status || (chapter.sync && chapter.sync.status) || "").toLowerCase();
  if (!status) return true;
  return /^(accepted|approved|synced|synced_with_warnings|complete|completed)$/.test(status) || !!(chapter.sync && /^(synced|synced_with_warnings)$/.test(String(chapter.sync.status || "").toLowerCase()));
}
function acceptedStoryChapters(chapters) {
  const active = activeStoryChapters(chapters);
  const accepted = active.filter(isAcceptedStoryChapter);
  return accepted.length ? accepted : active;
}
// Invalidate metadata whose chapter identity is removed; callers still own array cleanup/remapping.
function invalidateChapterDependentRecords(st, removedChapter) {
  if (!st || typeof st !== "object") return st;
  const removed = Number(removedChapter);
  if (!Number.isFinite(removed) || removed < 1) return st;
  const meta = st.nextChapterHintMeta;
  if (meta && typeof meta === "object") {
    const target = Number(meta.targetChapter);
    if (target === removed) {
      st.nextChapterHint = "";
      st.nextChapterHintMeta = Object.assign({}, meta, { targetChapter: 0, status: "invalidated", invalidated: true, invalidatedByChapter: removed, updatedAt: Date.now() });
    } else if (target > removed) {
      st.nextChapterHintMeta = Object.assign({}, meta, { targetChapter: target - 1, updatedAt: Date.now() });
    }
  }
  const statusChapter = Number(st.lastStatusChapter);
  if (statusChapter === removed) {
    st.currentStatus = "";
    st.statusState = {};
    st.lastStatusChapter = Math.max(0, removed - 1);
  } else if (statusChapter > removed) st.lastStatusChapter = statusChapter - 1;
  const memoryChapter = Number(st.lastMemorySyncChapter);
  st.lastMemorySyncChapter = memoryChapter === removed ? Math.max(0, removed - 1) : (memoryChapter > removed ? memoryChapter - 1 : st.lastMemorySyncChapter);
  return st;
}
// V14.0.17: hint provenance. Missing metadata is intentionally unverified, never guessed as active.
function chapterHintVerification(state, targetChapter) {
  const text = String(state && state.nextChapterHint || "").trim();
  const meta = state && state.nextChapterHintMeta;
  const target = Number(targetChapter) || 0;
  if (!text) return { text: "", verified: false, reason: "empty" };
  if (!meta || typeof meta !== "object") return { text: "", verified: false, reason: "missing_metadata" };
  const metaTarget = Number(meta.targetChapter) || 0;
  const status = String(meta.status || "").toLowerCase();
  const verified = metaTarget === target && (status === "active" || status === "confirmed") && meta.invalidated !== true && meta.superseded !== true;
  return verified ? { text, verified: true, targetChapter: metaTarget, version: Number(meta.version) || 1 } : { text: "", verified: false, reason: metaTarget !== target ? "target_mismatch" : "inactive_status" };
}
// V12.32: chỉ gửi tóm tắt ngắn của chương gần nhất + đoạn cuối để nối mạch.
// Không tự động gửi tóm tắt các chương xa; canon dài hạn lấy từ Story Bible/Memory có chọn lọc.
function buildRecentBlocks(priorChapters) {
  const pc = acceptedStoryChapters(priorChapters);
  if (!pc.length) return { recentFullText: "", olderSummaries: "" };
  const last = pc[pc.length - 1];
  const summary = String(last.summary || "").trim();
  const compactSummary = summary
    ? (summary.length > 1100 ? summary.slice(0, 1100).trimEnd() + "…" : summary)
    : _clipChapterText(last.text || "", 700);
  const ending = String(last.text || "").trim().slice(-1400);
  const recentFullText = [
    "--- CHƯƠNG GẦN NHẤT: TÓM TẮT SỰ KIỆN QUAN TRỌNG ---",
    compactSummary || "(Chưa có tóm tắt; chỉ dùng đoạn kết bên dưới để nối tiếp.)",
    ending ? "--- ĐOẠN CUỐI ĐỂ NỐI TIẾP ---\n" + ending : ""
  ].filter(Boolean).join("\n\n");
  return { recentFullText, olderSummaries: "" };
}

// Prompt lập KẾ HOẠCH chương. Có brief của người dùng: giữ ĐỦ mọi nhịp (không còn giới hạn 3 sự kiện / 5 beat làm nén gợi ý nhiều nhịp).
// V14.7.7: kế hoạch chương phải LÊN LỊCH cảnh nóng theo Trọng tâm trưởng thành. Trước đây mục 8 chỉ ghi "nếu có cảnh trưởng thành" và brief
// của người dùng cấm thêm sự kiện, nên AI bỏ cảnh nóng ở mọi chương không được brief nhắc tới (truyện PRIMARY vẫn 0 cảnh 18+ từ chương 3).
function matureChapterPlanBlock(o) {
  if (!o || !o.mature) return "";
  const mf = normalizeChapterMatureFocus(o.matureFocus);
  if (mf === "none") return "";
  const streak = Math.max(0, Number(o.heatFreeStreak) || 0), primary = mf === "primary";
  const must = primary || streak >= 3;
  return [
    "LỊCH CẢNH NÓNG (truyện người lớn, Trọng tâm trưởng thành = " + mf.toUpperCase() + (streak ? "; " + streak + " chương gần nhất chưa có cảnh nóng" : "") + "):",
    must
      ? "- Kế hoạch PHẢI có ít nhất MỘT beat là CẢNH NÓNG. Ghi đúng cụm \"cảnh nóng\" trong beat, nêu 2 nhân vật tham gia (đều từ 18 tuổi, theo tên trong hồ sơ), địa điểm, tình huống đưa tới cảnh, và điều cảnh đó làm đổi (quan hệ/quyền lực/bí mật/hậu quả)."
      : "- Nên có một beat CẢNH NÓNG nếu quan hệ/tình huống đã tích tụ đủ; nếu có, ghi đúng cụm \"cảnh nóng\" trong beat và nêu 2 nhân vật tham gia (đều từ 18 tuổi).",
    "- Nếu brief/mệnh lệnh của người dùng không nhắc cảnh nóng: vẫn thêm beat này dưới dạng [S] (beat hỗ trợ, bám đúng tình huống và nhân vật đang có), KHÔNG tính là sự kiện chính thứ 4 và KHÔNG làm lệch các mốc A/B của brief. Cảnh nóng đặt SAU các mốc bắt buộc hoặc xen vào nhịp phù hợp.",
    "- Mỗi cảnh nóng phải đổi hướng quan hệ hoặc thế lực, không lặp lại cảnh trước (đổi bối cảnh, tư thế, động lực, cảm xúc)."
  ].join("\n");
}
function buildChapterPlanPrompt(o) {
  const userDirective = String(o.directive || "").trim(), userHint = String(o.hint || "").trim();
  const hintVerified = o.hintVerified !== false;
  const effectiveHint = hintVerified ? userHint : "";
  const maxNamedCharacters = Math.max(1, Math.min(12, Number(o.maxNamedCharacters) || 6));
  const hasUserBrief = !!(userDirective || effectiveHint);
  return [
    "BẮT BUỘC: TIẾNG VIỆT 100%.", "",
    "Bạn là biên kịch cho tiểu thuyết dài kỳ. Lập KẾ HOẠCH cho CHƯƠNG " + o.chapterNumber + ".",
    "",
    "Bối cảnh:", o.context, "",
    o.storyControl || "", "",
    o.recent ? ("Chương gần nhất:\n" + String(o.recent).slice(0, 8000)) : "Chương đầu tiên.", "",
    o.mainCharName ? ("NHÂN VẬT CHÍNH: " + o.mainCharName + " — là TRỤC của kế hoạch này và phải có mặt trong chương, nhưng KHÔNG cần có mặt ở mọi cảnh: nhân vật phụ quan trọng có thể có cảnh/nhịp riêng (việc riêng, mục tiêu riêng, hành động chủ động) rồi giao với tuyến của nhân vật chính. Ghi rõ nhịp nào theo góc nhìn nhân vật nào.") : "",
    hasUserBrief ? [
      "===== YÊU CẦU/GỢI Ý DO NGƯỜI DÙNG VIẾT — NGUỒN SỰ KIỆN ƯU TIÊN CAO =====",
      userDirective ? ("MỆNH LỆNH:\n" + userDirective) : "",
      effectiveHint ? ("GỢI Ý:\n" + effectiveHint) : "",
      "===== HẾT YÊU CẦU NGƯỜI DÙNG =====",
      "QUY TẮC ĐẶC BIỆT: Phải chuyển ĐẦY ĐỦ mọi chi tiết, hành động, mốc mở đầu, diễn biến và mốc kết thúc mà người dùng đã nêu thành kế hoạch. Không được bỏ sót, rút gọn, gộp nhịp hoặc thay thế chi tiết quan trọng.",
      "Không tự thêm tuyến truyện, mục tiêu, nhân vật quan trọng, địa điểm mới hoặc biến cố lớn không có trong yêu cầu người dùng. Nếu cần nối các mốc, chỉ dùng diễn biến cầu nối tối thiểu để giữ liền mạch.",
      "Nếu yêu cầu có ghi rõ bắt đầu tại A và kết thúc tại B, A và B là hai ANCHOR BẮT BUỘC; kế hoạch phải đi từ A đến B và không mở tuyến khác làm lệch trọng tâm.",
      "CANON/CONFLICT POLICY: Canon đã xác nhận trong chương đã Sync và hồ sơ khóa là bất biến. Nếu Directive/Gợi ý yêu cầu retcon hoặc thay đổi canon, ghi mục CONFLICT, giữ canon cũ và chỉ áp dụng thay đổi khi người dùng xác nhận rõ đó là retcon có chủ đích.",
      "THỨ TỰ ƯU TIÊN: (1) canon đã xác nhận và hồ sơ khóa; (2) mệnh lệnh người dùng hiện tại nếu không retcon canon; (3) dòng Outline đúng chương; (4) gợi ý đã xác minh; (5) đề xuất riêng của AI. Khi hai nguồn cùng cấp mâu thuẫn, ghi CONFLICT và nêu phương án bị loại.",
      "Không được đưa một chi tiết do AI tự nghĩ ra vào [R] hoặc coi là canon. Mọi chi tiết không đến từ nguồn (1)-(4) phải đánh [S] và chỉ là vật liệu cầu nối."
    ].filter(Boolean).join("\n") : "",
    hasUserBrief ? "Lập kế hoạch BÁM SÁT BRIEF — số nhịp bằng đúng số nhịp trong brief:" : "Lập kế hoạch theo NGÂN SÁCH SỰ KIỆN — không vượt quá 3 sự kiện chính:",
    "1. Mục tiêu chương", "2. Xung đột chính",
    hasUserBrief ? "3. DANH SÁCH CÁC NHỊP/SỰ KIỆN THEO ĐÚNG THỨ TỰ BRIEF (mỗi nhịp ghi: mục đích + diễn biến + hậu quả); KHÔNG gộp, KHÔNG bỏ nhịp nào"
                 : "3. DANH SÁCH 1-3 SỰ KIỆN CHÍNH (mỗi sự kiện ghi: mục đích + diễn biến + hậu quả). Mỗi sự kiện có thể có biến cố lớn lồng bên trong nếu thật sự cần cho nhân-quả hoặc cao trào; biến cố lồng không tính thành sự kiện chính thứ 4 và không bắt buộc chương nào cũng phải có.",
    "3a. BEAT LEDGER — phân loại rõ để không biến đề xuất của AI thành canon: đánh mã [R1], [R2]... cho BEAT BẮT BUỘC xuất phát từ brief người dùng, dòng Outline của đúng chương hoặc canon đã xác nhận; đánh mã [S1], [S2]... cho BEAT HỖ TRỢ/CẦU NỐI do AI đề xuất để nối mạch. Mỗi beat ghi: MỤC TIÊU | HÀNH ĐỘNG/THÔNG TIN | NHÂN VẬT/ĐỊA ĐIỂM | BẰNG CHỨNG | HẬU QUẢ. Chỉ [R] mới là điều kiện bắt buộc; [S] được phép thay đổi hoặc bỏ nếu làm truyện mượt hơn.",
    "4. Nhân vật xuất hiện: BẮT BUỘC có nhân vật chính; TỐI ĐA " + maxNamedCharacters + " NHÂN VẬT CÓ TÊN RIÊNG xuất hiện trực tiếp trong cả chương; ưu tiên nhân vật đã có.",
    "5. Địa điểm + DÒNG THỜI GIAN (ghi chú NỘI BỘ để giữ nhất quán, KHÔNG phải để in thành nhãn trong văn): thời điểm tương đối khi mở chương, quãng đã trôi từ chương trước (nếu có nhảy), các beat nối nhau theo thời gian thế nào, cảnh nào thời gian thật sự quan trọng (hạn chót/khẩn cấp); nêu cách thể hiện tự nhiên trong văn (ánh sáng, việc đang làm, một câu chuyển trong mạch kể)",
    "5b. CẢNH & NGƯỜI CÓ MẶT: với MỖI beat ghi: địa điểm | ai có mặt | ai VÀO cảnh (cách vào) | ai RỜI cảnh (cách rời). Người không được ghi có mặt thì không được nói/hành động trong beat đó.",
    hasUserBrief ? "6. SCENE BEATS: MỖI nhịp của brief là MỘT beat (không giới hạn số beat), ghi gợi ý độ dài từng beat để cả chương đạt mục tiêu từ; KHÔNG tự sinh thêm sự kiện lớn ngoài brief"
                 : "6. SCENE BEATS (tối đa 5 beat) — chỉ triển khai 1-3 sự kiện trên, KHÔNG tự sinh thêm sự kiện lớn",
    "7. Kết chương — phải khớp mốc kết thúc người dùng yêu cầu nếu có",
    "7a. TIẾN ĐỘ ARC/OUTLINE: nếu bối cảnh có mục TIẾN ĐỘ ARC/OUTLINE, ghi rõ chương này thực hiện VIỆC BẮT BUỘC/bước tiến nào của Arc hoặc Outline (đúng dòng của chương nếu Outline có), và mỗi sự kiện chính phải là một BƯỚC TIẾN thật, không phải cảnh độn",
    "7b. THAY ĐỔI/TIẾN TRIỂN: ghi rõ điều gì ĐÃ ĐỔI giữa đầu và cuối chương (quan hệ/thông tin/quyền lực/mục tiêu/hậu quả); không được để trống",
    "9. DÒNG TỰ KIỂM TRA CUỐI KẾ HOẠCH: LEDGER_ORDER: R1 -> S1 -> R2 -> ... -> END | REQUIRED_DONE: R1,R2,... | STOP_AFTER: mã beat cuối cùng. Không được kết chương trước khi mọi [R] đã có bằng chứng; beat [S] không được dùng để tạo hard failure.",
    "8. Nếu có cảnh trưởng thành: mức intensity + structure + cảnh đó làm đổi điều gì (quan hệ/quyền lực/bí mật/hậu quả) và dẫn tới bước nào kế tiếp; không thay đổi phạm vi sự kiện người dùng đã chỉ định",
    "",
    hasUserBrief ? "QUY TẮC CỨNG: Không thêm sự kiện lớn ngoài brief. Không tạo nhân vật quan trọng mới nếu không có lý do cốt truyện rõ ràng. Nếu có thể dùng nhân vật hiện có thì phải dùng nhân vật hiện có."
                 : "QUY TẮC CỨNG: Không thêm sự kiện lớn thứ 4. Không tạo nhân vật quan trọng mới nếu không có lý do cốt truyện rõ ràng. Nếu có thể dùng nhân vật hiện có thì phải dùng nhân vật hiện có.",
    hasUserBrief ? "ƯU TIÊN ĐỘ TRUNG THÀNH VỚI BRIEF: Không 'sáng tạo thêm cho hay'. Nhiệm vụ là chuyển brief thành kế hoạch có thể viết được, không phải mở rộng phạm vi truyện." : "",
    matureChapterPlanBlock(o),
    castPoolBlock(o.castPool),
    "KHÔNG viết văn xuôi. Chỉ bullet points."
  ].filter(Boolean).join("\n");
}

// V12.23: KẾ HOẠCH ĐỘ DÀI — chia ngân sách từ cho từng nhịp của gợi ý để AI không nén mỗi nhịp thành vài đoạn rồi kết sớm.
function buildLengthPlan(brief, target) {
  const raw = String(brief || "").trim();
  if (!raw || !target) return "";
  let beats = raw.split(/\n+/).map(x => x.trim()).filter(x => x.length >= 20);
  if (beats.length < 3) beats = raw.split(/(?<=[.!?…])\s+/).map(x => x.trim()).filter(x => x.length >= 20);
  if (beats.length < 2) return "";
  const isEnd = (x) => /^(chương\s+)?kết thúc|kết chương|cuối chương/i.test(x);
  const weights = beats.map(x => isEnd(x) ? 0.5 : 1);
  const sum = weights.reduce((a, b) => a + b, 0);
  const goal = Math.round(target * 1.05);
  const lines = beats.map((x, i) => {
    const w = Math.max(100, Math.round((goal * weights[i] / sum) / 50) * 50);
    const label = x.length > 70 ? x.slice(0, 70).replace(/\s+\S*$/, "") + "…" : x;
    return (i + 1) + ") " + label + " ≈ " + w + " từ";
  });
  return [
    "===== KẾ HOẠCH ĐỘ DÀI (BẮT BUỘC — lý do chương hay bị ngắn là nén mỗi nhịp thành vài đoạn) =====",
    "Chia chương thành " + beats.length + " phần theo ĐÚNG thứ tự gợi ý, mỗi phần viết ĐỦ ngân sách từ (tổng ≈ " + goal + " từ):",
    lines.join("\n"),
    "Mỗi phần phải có: bối cảnh/không khí, hành động từng bước, hội thoại, nội tâm + cảm giác, phản ứng và hệ quả. CẤM tóm tắt một phần thành 1–2 đoạn hay nhảy cóc thời gian. Chỉ viết phần cuối cùng khi cộng dồn đã gần đủ " + goal + " từ; nếu thấy mới được khoảng " + Math.round(target * 0.9) + " từ thì mở rộng các phần giữa chứ KHÔNG kết chương.",
    "===== HẾT KẾ HOẠCH ĐỘ DÀI ====="
  ].join("\n");
}

// V12.23: MỞ RỘNG CUỐI — khi đã hết lượt viết thêm mà chương vẫn thiếu từ, nhờ AI viết lại TOÀN BỘ chương dài hơn (giữ nguyên sự kiện + điểm kết).
function buildExpandPrompt(o) {
  const wc = o.wc, goal = o.goal, pct = Math.max(5, Math.round((goal * 1.04 / Math.max(1, wc) - 1) * 100));
  const brief = [o.directive ? ("MỆNH LỆNH: " + String(o.directive).trim()) : "", o.hint ? ("GỢI Ý: " + String(o.hint).trim()) : ""].filter(Boolean).join("\n");
  return [
    "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU.",
    "MỞ RỘNG CHƯƠNG: bản hiện tại chỉ " + wc + " từ, CHƯA ĐỦ độ dài. Cần tối thiểu " + goal + " từ (mục tiêu " + o.target + ", tuyệt đối không vượt " + o.maxWords + ").",
    "Hãy VIẾT LẠI TOÀN BỘ chương thành bản DÀI HƠN khoảng +" + pct + "% (≥ " + goal + " từ).",
    "CÁCH MỞ RỘNG: giữ NGUYÊN thứ tự, mọi sự kiện, mọi lời thoại quan trọng, giọng văn, POV, xưng hô và ĐIỂM KẾT CHƯƠNG. Với MỖI cảnh: thêm không khí/bối cảnh, hành động từng bước, hội thoại, nội tâm, giác quan, phản ứng và hệ quả. Đoạn nào đang kể tóm tắt/lướt nhanh thì viết thành cảnh đầy đủ. Cảnh nào ngắn nhất thì mở rộng nhiều nhất.",
    "CẤM: bỏ hoặc rút gọn bất kỳ đoạn nào; thêm biến cố lớn, nhân vật quan trọng mới, arc mới; lặp ý hoặc độn chữ; đổi điểm kết chương; chèn ghi chú/giải thích.",
    o.style || "",
    brief ? ("===== KẾ HOẠCH NGƯỜI DÙNG (không đổi) =====\n" + brief + (o.closing ? ("\nENDING ANCHOR: " + o.closing) : "") + "\n===== HẾT =====") : "",
    "===== BẢN HIỆN TẠI (" + wc + " từ) =====",
    String(o.text || ""),
    "===== HẾT BẢN HIỆN TẠI =====",
    "CHỈ TRẢ VỀ toàn bộ chương đã mở rộng (không tiêu đề, không 'NỘI DUNG:', không giải thích)."
  ].filter(Boolean).join("\n");
}

function acceptExpandedChapter(oldText, newText, maxWords) {
  let t = String(newText || "").trim();
  t = t.replace(/^\s*(?:TIÊU ĐỀ|TITLE)\s*:\s*[^\n]+\n+/i, "").replace(/^\s*NỘI DUNG\s*:\s*/i, "").trim();
  const ow = countWords(oldText), nw = countWords(t);
  if (!t || nw < 100) return { ok: false, reason: "AI trả rỗng/quá ngắn" };
  if (nw < ow * 0.9) return { ok: false, reason: "bản mở rộng ngắn hơn bản gốc (" + nw + " < " + ow + " từ)" };
  if (nw < ow + 120) return { ok: false, reason: "bản mở rộng không dài hơn đáng kể (" + nw + " so với " + ow + " từ)" };
  const cap = trimToWordLimit(t, maxWords);
  return { ok: true, text: cap.text, words: countWords(cap.text), trimmed: cap.trimmed };
}

function trimToWordLimit(text, maxWords) {
  // V12.14: cắt theo vị trí ký tự để GIỮ NGUYÊN xuống dòng/đoạn (bản cũ split+join làm mất toàn bộ đoạn văn/thoại).
  const s = String(text || "").trim();
  if (!s || countWords(s) <= maxWords) return { text: s, trimmed: false };
  const re = /\S+/g; let mt, n = 0, end = 0;
  while ((mt = re.exec(s))) { n++; end = mt.index + mt[0].length; if (n >= maxWords) break; }
  let out = s.slice(0, end);
  const m = out.match(/^([\s\S]*[.!?…][”"’']?)(?:\s|$)/);
  // V12.20: ngưỡng 70% giới hạn (bản cũ chỉ 180 từ cuối -> hay cắt cụt giữa câu khi đoạn dài)
  if (m && countWords(m[1]) >= Math.max(1, Math.floor(maxWords * 0.7))) out = m[1];
  return { text: out.trim(), trimmed: true };
}

// V12.21.2: xóa phần lập kế hoạch tiếng Anh mà model thinking nhúng vào đầu output.
// FIX: dùng mật độ diacritics (>12%) thay vì chỉ kiểm tra có/không,
// tránh bị lừa bởi tên nhân vật Việt lẫn trong đoạn tiếng Anh.
function stripThinkingOutput(text) {
  if (!text) return text;
  let t = String(text);
  // 1. Xóa <think>/<thinking> tags
  t = t.replace(/<think(?:ing)?[\s>][\s\S]*?<\/think(?:ing)?>/gi, '');
  // 2. Xóa khối tiếng Anh trước câu chuyện tiếng Việt.
  //    Văn xuôi tiếng Việt thật: mật độ diacritics > 12%.
  //    Tiếng Anh dù có tên Việt (Bùi Lạc, Mỹ Duyên) chỉ đạt ~3-8%.
  const viDRe = /[\u00C0-\u024F\u1EA0-\u1EF9]/g;
  const paras = t.split(/\n{2,}/); let start = 0;
  for (let i = 0; i < paras.length; i++) {
    const p = paras[i].trim(); if (!p) continue;
    const tot = p.replace(/\s/g, '').length || 1;
    const viC = (p.match(viDRe) || []).length;
    if (viC / tot > 0.12) { start = i; break; }        // văn xuôi Việt thật -> dừng
    const asc = (p.match(/[a-zA-Z0-9 .,!?:;()\-*_#*]/g)||[]).length;
    if (asc / tot > 0.75) start = i + 1;               // đoạn tiếng Anh -> bỏ
  }
  if (start > 0) t = paras.slice(start).join('\n\n');
  // 3. Xóa label còn sót
  t = t.replace(/^\s*\*{0,2}Block\s+[A-Z][:\s].{0,120}\n/gim, '')
       .replace(/^\s*(?:Let me|Let's|I'll|I will|I need|Note:|Draft:|Writing:)[^\n]*/gim, '')
       .replace(/^\s*[-*]{3,}\s*$/gm, '');
  return t.replace(/^\s+/, '').trim();
}

// V12.23: xóa câu/đoạn TIẾNG ANH do model "nghĩ to" lẫn vào giữa truyện (vd: "The user wants me to write the bridge section in Vietnamese...").
// stripThinkingOutput chỉ xử lý khối tiếng Anh Ở ĐẦU output; đoạn chèn/viết tiếp bị ghép giữa chương nên lọt qua.
const _EN_LEAK_STOP = new Set(["the","and","of","is","are","was","were","that","this","with","for","user","wants","want","write","writing","section","bridge","leaked","should","must","need","needs","will","would","vietnamese","chapter","text","output","response","let","not","but","from","then","now","here","there","scene","story","ending","anchor","insert","continue","paragraph","previous","existing","content","already"]);
function _isEnglishLeak(seg) {
  const plain = String(seg).replace(/\s/g, "");
  if (plain.length < 25) return false;
  const vi = (String(seg).match(/[\u00C0-\u024F\u1EA0-\u1EF9]/g) || []).length;
  if (vi / plain.length > 0.04) return false;                      // văn Việt thật có nhiều dấu
  const toks = String(seg).toLowerCase().match(/[a-z']+/g) || [];
  if (toks.length < 6) return false;
  let hits = 0; for (const t of toks) if (_EN_LEAK_STOP.has(t)) hits++;
  return hits >= 3;
}
function removeEnglishLeaksDetailed(text) {
  const removed = [];
  if (!text) return { text: text, removed };
  const lines = String(text).split("\n").map(line => {
    if (!line.trim()) return line;
    if (_isEnglishLeak(line)) { removed.push(line.trim().slice(0, 80)); return null; }
    const sents = line.split(/(?<=[.!?…])\s+/);
    if (sents.length < 2) return line;
    const keep = sents.filter(x => { if (_isEnglishLeak(x)) { removed.push(x.trim().slice(0, 80)); return false; } return true; });
    return keep.length === sents.length ? line : keep.join(" ");
  }).filter(x => x !== null);
  return { text: lines.join("\n").replace(/\n{3,}/g, "\n\n"), removed };
}
function removeEnglishLeaks(text) { return removeEnglishLeaksDetailed(text).text; }

function stripForeign(text) {
  text = stripThinkingOutput(text); // V12.21
  if (!text) return text;
  return sanitizeChapterText(text);
}
// V12.32.6c: bước làm sạch thuần (không có stripThinkingOutput) — dùng cho nút Chuẩn hóa trên chương đã lưu.
/* V14.3.5: model (đặc biệt model gốc Trung) rò chữ pinyin "de" (的/得/地) vào văn xuôi: "Sự kiêu hãnh cuối cùng de một tiểu thư". Trước đây không bị bắt vì mọi từ < 4 chữ cái bị bỏ qua.
   Tự sửa CHỈ ca chắc chắn (de + từ xác định/đại từ/tên riêng = sở hữu -> "của"); ca còn lại (de + động/tính từ) để findStrayWords báo cho bước sửa bằng AI. */
function fixPinyinDe(text) {
  const t = String(text || ""); if (!t || t.indexOf("de") < 0) return t;
  const DET = "(?:một|những|các|mọi|mình|nàng|hắn|cô|anh|chị|tên|kẻ|người|chính|nó|họ|tầng|căn|tòa|chiếc|cái|bản|toàn|từng|trứng|vòng|chủ)";
  const re = new RegExp("(?<![\\p{L}\\p{N}])de(?=[ \\t]+(?:" + DET + "(?![\\p{L}\\p{N}])|\\p{Lu}))", "gu");
  return t.replace(re, (m, off) => {
    const after = t.slice(off + 2).replace(/^[ \t]+/, ""), before = t.slice(0, off);
    if (/^\p{Lu}/u.test(after) && /(?:^|[ \t])\p{Lu}[\p{L}]*[ \t]+$/u.test(before) && /^[A-Za-z]/.test(after) && /[A-Za-z]$/.test(before.trim())) return m; // "Charles de Gaulle": tên nước ngoài, giữ nguyên
    return "của";
  });
}
function sanitizeChapterText(text) {
  // V12.10: dọn chữ Hán/Nhật/Hàn/Cyrillic/Thái/Ả Rập/Hindi còn sót (kể cả khi dưới ngưỡng viết lại).
  if (!text) return text;
  text = removeEnglishLeaks(text);   // V12.23
  let t = String(text)
    .replace(/，/g, ", ").replace(/。/g, ". ").replace(/！/g, "! ").replace(/？/g, "? ").replace(/：/g, ": ").replace(/、/g, ", ")
    .replace(/[\u3400-\u4DBF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\u0400-\u04FF\u0E00-\u0E7F\u0600-\u06FF\u0900-\u097F]+/g, "");
  t = stripJunkSymbols(t);
  t = fixPinyinDe(t);
  t = cleanProseArtifacts(t);
  return t.replace(/[ \t]{2,}/g, " ").replace(/ +([,.!?;:])/g, "$1").replace(/\( *\)|“ *”|" *"/g, "");
}
// Xóa hẳn các từ lạ (khớp nguyên từ, phân biệt hoa/thường) khỏi văn bản rồi dọn khoảng trắng/dấu câu.
function removeStrayWords(text, words) {
  let t = String(text || "");
  (words || []).forEach(w => {
    const esc = String(w).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (!esc) return;
    t = t.replace(new RegExp("(?<![\\p{L}\\p{N}])" + esc + "(?![\\p{L}\\p{N}])", "gu"), "");
  });
  return t.replace(/[ \t]{2,}/g, " ").replace(/ +([,.!?;:…])/g, "$1").replace(/([,;:]) *([.!?…])/g, "$2").replace(/\( *\)|“ *”|" *"/g, "").replace(/[ \t]+\n/g, "\n");
}
/* V12.32.6b: làm sạch "tạp chất" thường gặp trong output model để chương là văn xuôi thuần tiếng Việt:
   Unicode NFC, Ð→Đ, markdown/HTML, emoji, ghi chú meta của AI, nhãn "(tiếng Anh)", lặp từ/ký tự/dấu câu bất thường. */
function cleanProseArtifacts(text) {
  let t = String(text || "");
  if (!t) return t;
  t = t.normalize("NFC").replace(/Ð/g, "Đ").replace(/ð/g, "đ");
  // HTML / markdown (giữ chữ, bỏ ký hiệu). Không đụng dấu gạch đầu dòng thoại (— – -).
  t = t.replace(/<br\s*\/?>/gi, "\n").replace(/<\/?(?:p|div|span|b|i|u|em|strong|center|h[1-6])\b[^>]*>/gi, "");
  t = t.replace(/`{1,3}/g, "").replace(/^[ \t]*#{1,6}[ \t]+/gm, "").replace(/^[ \t]*>[ \t]?/gm, "");
  t = t.replace(/\*\*([^*\n]+)\*\*/g, "$1").replace(/(?<![\p{L}\p{N}*])\*([^*\n]+)\*(?![\p{L}\p{N}*])/gu, "$1").replace(/(?<![\p{L}\p{N}_])_([^_\n]+)_(?![\p{L}\p{N}_])/gu, "$1");
  t = t.replace(/\*{2,}/g, "");
  // Biến mẫu/ngoặc nhọn model để rò ("{phương án tài chính}") -> giữ chữ bên trong, bỏ ngoặc.
  t = t.replace(/\{\{?\s*([^{}\n]{1,120}?)\s*\}?\}/g, "$1");
  // Emoji / ký hiệu hình ảnh (văn xuôi thuần).
  t = t.replace(/[\p{Extended_Pictographic}\uFE0F\u20E3]/gu, "");
  // Nhãn ngôn ngữ do model rò rỉ: đoạn có >=2 nhãn bị bỏ cả đoạn; 1 nhãn thì bỏ nhãn.
  t = t.split("\n").filter(l => (l.match(/\((?:bằng\s+)?tiếng\s+(?:Việt|Anh|Trung|Nhật|Hàn|Pháp|Nga)\)/gi) || []).length < 2).join("\n")
       .replace(/\s*\((?:bằng\s+)?tiếng\s+(?:Việt|Anh|Trung|Nhật|Hàn|Pháp|Nga)\)/gi, "");
  // Dòng meta của AI (không phải lời thoại: không bắt đầu bằng nháy/gạch thoại).
  t = t.split("\n").filter(l => !/^\s*[\[(]?\s*(?:ghi chú|lưu ý|chú thích|note|word count|số từ|tổng số từ|hết chương|còn tiếp|to be continued|end of chapter)(?![\p{L}])[^\n]{0,160}$/iu.test(l)).join("\n");
  // Dấu câu bất thường.
  t = t.replace(/\.{4,}/g, "…").replace(/…{2,}/g, "…").replace(/([!?]){4,}/g, "$1$1$1").replace(/([,;:]){2,}/g, "$1").replace(/(?<=[\p{L}\p{N}”"’)]) ?\.{2}(?!\.)/gu, ".");
  // Lặp ký tự/từ bất thường (thoái hóa của model).
  t = t.replace(/(\p{L})\1{6,}/gu, "$1$1$1$1$1$1");
  t = t.replace(/\b([\p{L}]+)(?:[ \t]+\1\b){5,}/giu, "$1 $1 $1");
  // Dòng/đoạn lặp liền kề.
  const lines = t.split("\n"), out = [];
  for (const l of lines) { if (l.trim() && out.length && out[out.length - 1].trim() === l.trim() && l.trim().length > 12) continue; out.push(l); }
  return out.join("\n");
}

/* V12.32.6: model nhỏ đôi khi xả ký tự rác (chữ thuộc bảng chữ cái lạ như ᒞ, tổ hợp "/…/", ",/", dòng chỉ có ký hiệu).
   stripForeign trước đây chỉ bỏ Hán/Nhật/Hàn/Cyrillic/Thái/Ả Rập/Hindi nên các ký tự này lọt vào truyện và còn bị tách thành đoạn riêng. */
function stripJunkSymbols(text) {
  let t = String(text || "");
  // 1) Chữ cái không phải Latin (Canadian syllabics, Hy Lạp, Do Thái, Armenia, Georgia, Ethiopia, Cherokee...).
  t = t.replace(/(?![\p{Script=Latin}])\p{L}+/gu, "");
  // 2) Các ký tự điều khiển/ẩn lạ (giữ \n và \t).
  t = t.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u200B-\u200F\u2028\u2029\u202A-\u202E\u2060-\u2064\uFEFF\uFFFC\uFFFD]/g, "");
  // 3) Mảnh rác: token (tách bằng khoảng trắng) không có chữ/số nhưng chứa / \ | ^ ~ < > = _ (vd: "/…/", ",/", "\\|").
  t = t.replace(/(^|[ \t])[^\s\p{L}\p{N}]*[\/\\|^~<>=_][^\s\p{L}\p{N}]*(?=[ \t]|$)/gmu, "$1");
  // 4) Dòng không có chữ/số (trừ dòng ngăn cảnh như ---, ***, * * *, —, …).
  t = t.split("\n").filter(l => !l.trim() || (/[\p{L}\p{N}]/u.test(l) && !/^\s*\p{L}\s*$/u.test(l)) || /^[\s\-–—*_=~•·#…]+$/.test(l)).join("\n"); // bỏ cả dòng chỉ còn đúng 1 chữ cái lẻ (tàn dư sau khi lọc rác)
  return t;
}

function detectNonVietnamese(text) {
  if (!text) return false;
  const foreign = (String(text).match(/[\u3400-\u4DBF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\u0400-\u04FF\u0E00-\u0E7F\u0600-\u06FF\u0900-\u097F]/g) || []).length;
  const total = String(text).replace(/\s/g, "").length || 1;
  return (foreign / total) > 0.005;
}

function normalizeChapterMatureFocus(v) {
  const x = String(v || "none").toLowerCase();
  return x === "primary" || x === "secondary" ? x : "none";
}

const NSFW_KEYWORDS = [
  "cảnh nóng", "cảnh sex", "cảnh 18", "cảnh 18+", "làm tình", "ân ái", "giao hợp", "sex", "sexx", "sexy", "nsfw", "erotic", "erotica", "porn", "âu yếm", "vuốt ve", "mơn trớn", "ve vuốt", "hôn sâu", "hôn môi", "hôn cổ", "cởi đồ", "cởi áo", "cởi quần", "không mặc", "khỏa thân", "trần truồng", "nude", "sờ soạng", "sờ ngực", "sờ mông", "nắn bóp", "liếm", "thổi kèn", "dương vật", "âm đạo", "âm hộ", "núm vú", "háng", "cặc", "lồn", "thúc mạnh", "xuất tinh", "orgasm", "cao trào", "khoái cảm", "doggy", "missionary", "cowgirl", "oral", "blowjob", "handjob", "viết nóng", "viết 18", "tăng nhiệt", "nóng hơn", "cảnh ân ái", "đêm tân hôn", "mất trinh", "đoạt mất", "chiếm đoạt cơ thể", "ham muốn", "dục vọng", "nứng", "rên rỉ", "rên la", "rên ưỡn", "quan hệ tình dục", "quan hệ xác thịt", "bóp mông"
];

const _NSFW_RE = new RegExp("(?<![\\p{L}\\p{N}])(?:" + NSFW_KEYWORDS.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")(?![\\p{L}\\p{N}])", "iu");

function textHasNsfwKeyword(text) {
  if (!text) return false;
  return _NSFW_RE.test(String(text).normalize("NFC"));
}

// V14.1: ưu tiên số đứng ngay trước "tuổi" ("17 tuổi, đã tu luyện 300 năm" -> 17), nếu không có thì lấy số đầu tiên như cũ.
function parseAgeNum(a) {
  const s = String(a == null ? "" : a);
  const m = s.match(/(\d{1,4})\s*tuổi/i) || s.match(/\d{1,4}/);
  return m ? parseInt(m[1] !== undefined ? m[1] : m[0], 10) : null;
}
// V14.1: tuổi dùng cho rào chắn 18+ = số NHỎ NHẤT trong (tuổi, tuổi ngoại hình). Nhân vật tu tiên "300 tuổi nhưng ngoại hình 16" vẫn bị chặn.
function profileAgeNum(c, u) {
  const a = parseAgeNum((c && c.age) || (u && u.age)), b = parseAgeNum((c && c.apparentAge) || (u && u.apparentAge));
  if (a === null) return b; if (b === null) return a; return Math.min(a, b);
}

function underageNames(s) {
  const out = []; const chk = (n, c) => { const v = profileAgeNum(c); if (n && v !== null && v < 18) out.push(String(n)); };
  chk(s.mainCharProfile && s.mainCharProfile.name, s.mainCharProfile);
  (s.characters || []).forEach(c => chk(c && c.name, c));
  return out;
}

function ageGuardPrompt(s) {
  const u = underageNames(s);
  return "RÀO CHẮN TUỔI (bắt buộc): chỉ nhân vật đã trưởng thành (từ 18 tuổi trở lên) mới được tham gia cảnh tình dục/khiêu dâm. Tuyệt đối không viết nội dung tình dục với nhân vật dưới 18 tuổi hoặc được mô tả như trẻ em."
    + (u.length ? (" Nhân vật KHÔNG được xuất hiện trong cảnh 18+: " + u.join(", ") + ".") : "");
}

// V14.7.6 Cast Planner: AI đề xuất dàn nhân vật phụ bám truyện (chỉ người trưởng thành), tự nạp thành bản nháp để tác giả sửa sau.
// V14.7.9: dàn nhân vật mỏng (chỉ NVC + 1 người) thì tự nạp Cast Planner; kế hoạch chương phải LUÂN PHIÊN đưa nhân vật đã khai báo vào truyện.
function castIsThin(st) {
  st = st || {};
  const main = normalizeName(st.mainCharProfile && st.mainCharProfile.name || "");
  const others = (st.characters || []).filter(c => c && c.name && !c.dead && !c.isDead && normalizeName(c.name) !== main);
  return others.length < 3;
}
function castPoolForPlan(st, chapterNumber) {
  st = st || {};
  const main = normalizeName(st.mainCharProfile && st.mainCharProfile.name || "");
  const done = Math.max(0, (Number(chapterNumber) || 1) - 1);
  return (st.characters || []).filter(c => c && c.name && !c.dead && !c.isDead && normalizeName(c.name) !== main)
    .filter(c => c.lastAppearance == null || done - Number(c.lastAppearance) >= 2)
    .slice(0, 4).map(c => ({ name: String(c.name), role: String(c.role || c.relevanceToMC || "").slice(0, 80) }));
}
function castPoolBlock(pool) {
  if (!Array.isArray(pool) || !pool.length) return "";
  return "NHÂN VẬT PHỤ ĐÃ KHAI BÁO NHƯNG CHƯA/LÂU CHƯA XUẤT HIỆN: " + pool.map(c => c.name + (c.role ? " (" + c.role + ")" : "")).join("; ") +
    ".\n- Nếu hợp mạch, cho ÍT NHẤT MỘT người trong số này xuất hiện, được nhắc tới hoặc tác động vào tình huống của chương (ghi đúng tên hồ sơ trong beat [S]); đừng phá các mốc bắt buộc của brief. Không tạo thêm nhân vật có tên ngoài hồ sơ.";
}
const CAST_PLANNER_FIELDS = ["name","age","gender","role","relationship","desire","secret","appearance","height","bodyType","measurements","hair","eyes","skin","voice","scent","speech","addressTerms","personality","occupation"];
function buildCastPlannerPrompt(st, opts) {
  st = st || {}; opts = opts || {};
  const n = Math.max(3, Math.min(10, Number(opts.count) || 6));
  const mc = st.mainCharProfile || {};
  const known = [mc.name].concat((st.characters || []).map(c => c && c.name)).filter(Boolean);
  const mcLine = [mc.name, mc.age ? "tuổi " + mc.age : "", mc.gender, mc.occupation, mc.goals ? "mục tiêu: " + mc.goals : "", mc.personality].filter(Boolean).join(" | ");
  const outline = (st.outlinePlans || []).slice(0, 12).map(o => typeof o === "string" ? o : (o && (o.beat || o.title || o.summary || o.text)) || "").filter(Boolean).join("\n").slice(0, 1500);
  return [
    "Bạn là biên kịch dựng dàn nhân vật cho tiểu thuyết tiếng Việt. Hãy ĐỀ XUẤT " + n + " nhân vật mới, bám sát truyện, để câu chuyện có thêm xung đột, quan hệ và biến cố.",
    st.genre ? "THỂ LOẠI: " + st.genre : "",
    st.mainPlot ? "CỐT TRUYỆN: " + String(st.mainPlot).slice(0, 1500) : "",
    st.worldSetting ? "THẾ GIỚI: " + String(st.worldSetting).slice(0, 800) : "",
    mcLine ? "NHÂN VẬT CHÍNH: " + mcLine : "",
    outline ? "OUTLINE/CHẶNG TRUYỆN:\n" + outline : "",
    known.length ? "NHÂN VẬT ĐÃ CÓ (KHÔNG trùng tên, KHÔNG viết lại): " + known.join(", ") : "",
    st.mature ? "Truyện người lớn 18+: các nhân vật nên có sức hút, ham muốn, quan hệ quyền lực/cảm xúc đủ để triển khai cảnh nóng sau này." : "",
    "QUY TẮC BẮT BUỘC:",
    "- TẤT CẢ nhân vật phải là người trưởng thành, tuổi ghi rõ bằng SỐ từ 18 trở lên. Không đề xuất ai dưới 18, không dùng ngoại hình/vai trò học sinh/trẻ con.",
    "- Mỗi người phải có quan hệ cụ thể với nhân vật chính hoặc với nhau, một mong muốn rõ và một bí mật có thể bị lộ về sau.",
    "- Đa dạng vai trò (đồng minh, đối thủ, người cám dỗ, người cản đường, người giữ bí mật...), không trùng tính cách.",
    "- Ngoại hình cụ thể: chiều cao, vóc dáng, số đo (nếu hợp thể loại), tóc, mắt, da, giọng, mùi hương, dấu hiệu nhận dạng. Không dùng từ chung chung.",
    "- Cách nói và xưng hô riêng (gọi nhân vật chính là gì, tự xưng gì, giọng điệu).",
    "CHỈ TRẢ VỀ JSON thuần, một mảng, mỗi phần tử có các khóa: " + CAST_PLANNER_FIELDS.join(", ") + ". Không thêm giải thích."
  ].filter(Boolean).join("\n");
}
function normalizeCastPlannerCards(cards, st) {
  st = st || {};
  const accepted = [], rejected = [];
  const seen = new Set([(st.mainCharProfile && st.mainCharProfile.name)].concat((st.characters || []).map(c => c && c.name)).map(normalizeName).filter(Boolean));
  const str = v => (v == null ? "" : String(v)).trim();
  (Array.isArray(cards) ? cards : []).forEach(raw => {
    if (!raw || typeof raw !== "object") return;
    const name = str(raw.name);
    if (!name) return;
    const key = normalizeName(name);
    if (seen.has(key)) { rejected.push({ name, reason: "trùng tên nhân vật đã có" }); return; }
    const age = parseAgeNum(raw.age);
    if (age === null) { rejected.push({ name, reason: "thiếu tuổi (phải ghi số ≥ 18)" }); return; }
    if (age < 18) { rejected.push({ name, reason: "dưới 18 tuổi" }); return; }
    seen.add(key);
    const speech = [str(raw.speech), str(raw.addressTerms) ? "Xưng hô: " + str(raw.addressTerms) : ""].filter(Boolean).join(" | ");
    accepted.push({
      name, tier: "supporting", age: String(age), gender: str(raw.gender), role: str(raw.role), relevanceToMC: str(raw.relationship),
      goals: str(raw.desire), secret: str(raw.secret), appearance: str(raw.appearance), height: str(raw.height), bodyType: str(raw.bodyType),
      measurements: str(raw.measurements), hair: str(raw.hair), eyes: str(raw.eyes), skin: str(raw.skin), voice: str(raw.voice), scent: str(raw.scent),
      speech, personality: str(raw.personality), occupation: str(raw.occupation), locked: false
    });
  });
  return { accepted, rejected };
}

// V14.0.20 post-audit: nút "AI đề xuất" của Outline phải theo cài đặt 18+ của truyện (trước đây prompt không đọc
// mature/chapterMatureFocus nên luôn ra outline thường). Chỉ ở mức KẾ HOẠCH: chương nào có cảnh nóng, ai–ai (đều >=18),
// cảnh làm đổi điều gì — không tả chi tiết tình dục. Cụm "cảnh nóng" trong beat cũng là từ khoá để bộ định tuyến NSFW chọn model 18+.
function outlineMaturePrompt(st, total) {
  st = st || {};
  if (!st.mature) return "";
  const mf = normalizeChapterMatureFocus(st.chapterMatureFocus);
  if (mf === "none") return "";
  const n = Number(total) > 0 ? Number(total) : 10, primary = mf === "primary";
  const lo = primary ? Math.round(n * 0.4) : Math.max(1, Math.round(n * 0.2));
  const hi = primary ? Math.round(n * 0.6) : Math.max(lo, Math.round(n * 0.3));
  return [
    "NỘI DUNG 18+ (truyện người lớn, đã BẬT; trọng tâm trưởng thành: " + mf.toUpperCase() + "):",
    (primary
      ? "- Outline này PHẢI có khoảng " + lo + "–" + hi + " trong " + n + " chương là chương có cảnh nóng (cảnh nóng là trọng tâm của chương đó, vẫn có diễn biến cốt truyện trước/sau). Không được viết thành outline thuần tình tiết thường."
      : "- Outline nên có khoảng " + lo + "–" + hi + " trong " + n + " chương có cảnh nóng, đặt ở chỗ quan hệ/quyền lực/tình huống đã tích tụ tới mức hợp lý; các chương còn lại là cốt truyện."),
    "- Chương có cảnh nóng: beat PHẢI chứa đúng cụm \"cảnh nóng\", nêu rõ 2 nhân vật tham gia (theo tên trong Story Bible), tình huống đưa tới cảnh, và điều cảnh đó làm THAY ĐỔI (quan hệ, quyền lực, bí mật, hậu quả hoặc quyết định). Tối đa 3 câu. Outline chỉ là kế hoạch: KHÔNG tả chi tiết tình dục trong beat.",
    "- Các cảnh nóng không được lặp nhau: mỗi cảnh một tình huống và một mức thay đổi quan hệ khác nhau, tăng dần theo mạch truyện.",
    ageGuardPrompt(st),
    "- Nhân vật không ghi tuổi trong hồ sơ được coi là người lớn. Nhân vật có tuổi dưới 18 hoặc được mô tả như học sinh/trẻ em KHÔNG được tham gia cảnh nóng."
  ].join("\n");
}

// Rà kết quả AI: trả danh sách số chương có cảnh 18+ mà dính nhân vật dưới 18 tuổi (theo hồ sơ) hoặc từ ngữ chỉ trẻ em/học sinh.
function outlineAdultViolations(rows, st) {
  const kid = /(?<![\p{L}\p{N}])(?:học sinh|nữ sinh|nam sinh|trẻ em|bé gái|bé trai|dưới 18|chưa đủ 18|chưa thành niên)(?![\p{L}\p{N}])/iu;
  const nameRes = underageNames(st || {}).map(nm => new RegExp("(?<![\\p{L}\\p{N}])" + String(nm).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?![\\p{L}\\p{N}])", "iu"));
  const bad = [];
  (rows || []).forEach(r => {
    const b = String((r && r.b) || "");
    if (!textHasNsfwKeyword(b)) return;
    if (kid.test(b) || nameRes.some(re => re.test(b))) bad.push(Number(r.n));
  });
  return bad;
}

function _sumNorm(s){ return String(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\s+/g," ").trim(); }

function summaryNameList(text, characters){
  const nt=_sumNorm(text);
  return (characters||[]).map(c=>c&&c.name).filter(Boolean).filter(n=>nt.includes(_sumNorm(n))).slice(0,40);
}

function _sumNameGrounded(name, text){
  const toks=String(name).split(/\s+/).filter(Boolean);
  let hit=0;
  toks.forEach(t=>{ try{ if(new RegExp("(^|[^\\p{L}])"+t+"(?![\\p{L}])","u").test(text)) hit++; }catch(_){} });
  return hit >= Math.ceil(toks.length/2);
}

function summaryGrounded(summary, text){
  const names=[]; const bad=[]; let good=0;
  (String(summary).match(/(?:\p{Lu}\p{Ll}+)(?:\s+\p{Lu}\p{Ll}+)+/gu)||[]).forEach(nm=>{
    if(names.includes(nm)) return; names.push(nm);
    if(_sumNameGrounded(nm, text)) good++; else bad.push(nm);
  });
  const nameOk = names.length<2 || bad.length/names.length <= 0.34;
  const tw=new Set((_sumNorm(text).match(/[a-z0-9]{2,}/g)||[]));
  const sw=(_sumNorm(summary).match(/[a-z]{4,}/g)||[]);
  const ov = sw.length ? sw.filter(w=>tw.has(w)).length/sw.length : 1;
  return { ok: nameOk && ov>=0.4, bad, ov };
}

function extractiveSummary(text){
  const paras=String(text||"").split(/\n+/).map(p=>p.trim()).filter(p=>p.length>60);
  if(!paras.length) return "";
  const pick=Math.min(9, paras.length); const out=[];
  for(let i=0;i<pick;i++){
    const p=paras[Math.floor(i*paras.length/pick)];
    const w=p.split(/\s+/); let seg=w.slice(0,45).join(" ");
    if(w.length>45){ const k=Math.max(seg.lastIndexOf(". "),seg.lastIndexOf("! "),seg.lastIndexOf("? ")); if(k>seg.length*0.4) seg=seg.slice(0,k+1); }
    out.push(seg);
  }
  return "**Tóm tắt chương:** (trích tự động từ văn bản)\n\n"+out.join("\n\n");
}

function buildSummaryPrompt(text, n, names, adult){
  return [
    "Bạn là bộ máy tóm tắt. Chỉ được dựa vào văn bản trong thẻ <chuong>; không có kiến thức nào khác về truyện này.",
    "<chuong>", text, "</chuong>",
    "NHIỆM VỤ: tóm tắt CHƯƠNG "+n+" trên đây theo đúng trình tự diễn ra.",
    "1) Chỉ dùng nhân vật, địa điểm, đồ vật, giờ giấc, lời thoại CÓ trong <chuong>. Không thêm, không suy diễn. Nếu chương không nêu giờ giấc hay chức danh thì KHÔNG ghi.",
    names && names.length ? "2) Tên nhân vật xuất hiện trong chương (chỉ dùng đúng các tên này): "+names.join(", ")+"." : "2) Dùng đúng tên nhân vật như viết trong chương.",
    "3) Định dạng: mở đầu bằng dòng \"**Tóm tắt chương:**\", rồi 1 câu nêu mạch chính, sau đó 4-5 đoạn ngắn theo diễn biến (mỗi đoạn một cảnh/mốc). Không dùng nhãn Đầu/Giữa/Cuối, không gạch đầu dòng, không mô tả tiêu chí tóm tắt.",
    adult
      ? "4) Chương này có cảnh người lớn (18+/khống chế): thuật lại CỤ THỂ, không nói giảm nói tránh — nêu đúng ai làm gì với ai, hành động, đạo cụ, tư thế/vị trí, câu nói/mệnh lệnh chính và hệ quả, dùng đúng từ ngữ mà chương đã dùng; không rút gọn thành 'cảnh nóng/thân mật', không bỏ cảnh, không thêm chi tiết ngoài văn bản, không bình luận đạo đức."
      : "4) Với cảnh nhạy cảm (18+/bạo lực/cưỡng ép): thuật lại ngắn gọn, trung lập ai làm gì với ai, câu nói/mệnh lệnh chính và hệ quả — không bỏ cảnh, không thêm chi tiết ngoài văn bản.",
    "5) Câu cuối: trạng thái cuối chương theo đúng văn bản.",
    "6) Độ dài 300-400 từ tiếng Việt, tối đa 400. Chỉ trả về bản tóm tắt."
  ].join("\n");
}

function summaryRetryNote(g){
  return "\n\nLỖI LẦN TRƯỚC: bản tóm tắt chứa nội dung KHÔNG có trong <chuong>"+(g.bad&&g.bad.length?" (tên không có trong chương, cấm dùng: "+g.bad.join(", ")+")":"")+". Viết lại: bắt đầu bằng \"**Tóm tắt chương:**\" rồi chỉ kể lại các sự kiện có thật trong <chuong>.";
}

function formatParagraphs(text) {
  // V12.15: tự ngắt đoạn khi AI trả về khối văn đặc; mỗi lượt thoại một đoạn riêng; các đoạn cách nhau 1 dòng trống.
  let src = String(text || "").replace(/\r\n?/g, "\n").trim();
  if (!src) return src;
  // V12.32.6b: model đôi khi xuống dòng cứng giữa câu -> nối lại khi dòng trước chưa kết thúc và dòng sau bắt đầu bằng chữ thường.
  src = src.replace(/([\p{L}\p{N},;])[ \t]*\n(?!\n)[ \t]*(?=\p{Ll})/gu, "$1 ");
  // Viết tắt/tên viết tắt không phải điểm ngắt câu (TP. Hồ Chí Minh, TS. Nam, N. V. A...).
  const isAbbrevEnd = s0 => /(?:^|[\s“"(])(?:TP|TS|GS|PGS|BS|ThS|KS|Mr|Mrs|Ms|Dr|St|Q|P|TT|VN|Cty|CT|PTGĐ|GĐ)\.$/.test(s0.trim()) || /(?:^|[\s“"(])\p{Lu}\.$/u.test(s0.trim());
  const OPEN = /^[“"«‘'—–-]\s*/;
  const isTerm = c => ".!?…".indexOf(c) >= 0;
  const splitSentences = block => {
    const out = []; let cur = "", q = false;
    for (let i = 0; i < block.length; i++) {
      const ch = block[i]; cur += ch;
      if (ch === "“") q = true; else if (ch === "”") q = false; else if (ch === '"') q = !q;
      if (q) continue;
      let j = i; while (j + 1 < block.length && /["”’'»)]/.test(block[j + 1])) { j++; cur += block[j]; }
      const last = cur.replace(/["”’'»)\s]+$/, "").slice(-1);
      if (isTerm(last) && (j === i ? isTerm(ch) : true) && /\s/.test(block[j + 1] || " ")) {
        let k = j + 1; while (k < block.length && /\s/.test(block[k])) k++;
        const nx = block.slice(k, k + 1);
        if ((!nx || /[\p{Lu}“"«‘—–-]/u.test(nx)) && !(last === "." && isAbbrevEnd(cur.replace(/["”’»)\s]+$/, "")))) { out.push(cur.trim()); cur = ""; }
        i = j;
      } else i = j;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  };
  const paras = [];
  for (const raw of src.split(/\n+/)) {
    const block = raw.trim(); if (!block) continue;
    const sents = splitSentences(block);
    if (block.length <= 500 && !sents.some((x, i) => i > 0 && OPEN.test(x))) { paras.push(block); continue; }
    let cur = [], len = 0, curDialog = false;
    const flush = () => { if (cur.length) paras.push(cur.join(" ")); cur = []; len = 0; curDialog = false; };
    for (const s of sents) {
      const dlg = OPEN.test(s);
      if (dlg && cur.length) flush();
      if (!dlg && curDialog) flush();
      cur.push(s); len += s.length; curDialog = dlg || curDialog;
      if (curDialog) { if (/["”’»][^“"]{0,80}$/.test(s) || /[.!?…]$/.test(s)) flush(); }
      else if (cur.length >= 3 || len >= 320) flush();
    }
    flush();
  }
  // V12.32.6b: bỏ đoạn rỗng chữ/số (trừ dòng ngăn cảnh), nối mảnh vụn chưa kết thúc vào đoạn trước, bỏ đoạn trùng liền kề.
  const fin = [];
  for (const p0 of paras) {
    const p1 = p0.trim(); if (!p1) continue;
    const hasText = /[\p{L}\p{N}]/u.test(p1), isSep = /^[\s\-–—*_=~•·#…]+$/.test(p1);
    if (!hasText && !isSep) continue;
    if (fin.length && fin[fin.length - 1] === p1 && p1.length > 12) continue;
    const words = p1.split(/\s+/).length;
    if (fin.length && hasText && words <= 3 && !/[.!?…”"’»)]$/.test(p1) && /^\p{Ll}/u.test(p1) && !OPEN.test(p1) && !/^[\s\-–—*_=~•·#…]+$/.test(fin[fin.length - 1])) { fin[fin.length - 1] += " " + p1; continue; }
    fin.push(p1);
  }
  return fin.join("\n\n");
}

// ===== V12.15: chống lặp cảnh + phát hiện từ lạ =====
function _normWords(s) {
  return String(s || "").toLowerCase().normalize("NFC").replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(Boolean);
}
function _grams(words, n) {
  const set = new Set();
  for (let i = 0; i + n <= words.length; i++) set.add(words.slice(i, i + n).join(" "));
  return set;
}
function _sim(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0; for (const g of a) if (b.has(g)) inter++;
  return inter / Math.min(a.size, b.size);
}
// ===== V12.22b: chống "viết lại cả chương từ đầu rồi dán nối" (kể cả khi bản 2 chỉ diễn đạt lại, không trùng nguyên văn) =====
// Nhãn "TIÊU ĐỀ: ... / NỘI DUNG:" nằm GIỮA văn bản (kể cả dính liền câu trước, không xuống dòng) = model xuất lại cả chương.
const _LABEL_RE = /\*{0,2}\b(?:TIÊU ĐỀ|TITLE)\s*:\s*\*{0,2}[^\n]{0,160}\n+\s*\*{0,2}NỘI DUNG\s*:\*{0,2}[ \t]*|(?:^|\n)[ \t]*\*{0,2}NỘI DUNG\s*:\*{0,2}[ \t]*/gi;
function splitByInnerLabels(text) {
  const src = String(text || ""); const parts = []; let last = 0, m;
  _LABEL_RE.lastIndex = 0;
  while ((m = _LABEL_RE.exec(src))) { parts.push(src.slice(last, m.index)); last = m.index + m[0].length; }
  parts.push(src.slice(last));
  return parts.map(x => x.trim()).filter(x => x.length > 0);
}
// Hồ sơ từ NỘI DUNG của từng đoạn: bỏ từ quá phổ biến trong chương (cô, hắn, của, váy...) để so khớp theo từ đặc trưng.
function _paraProfiles(paras) {
  const words = paras.map(p => _normWords(p)), df = new Map();
  words.forEach(ws => new Set(ws).forEach(w => df.set(w, (df.get(w) || 0) + 1)));
  const lim = Math.max(3, Math.ceil(paras.length * 0.2));
  return words.map(ws => new Set(ws.filter(w => w.length >= 2 && (df.get(w) || 0) <= lim)));
}
function _setSim(a, b) {
  if (a.size < 5 || b.size < 5) return 0;
  let n = 0; for (const w of a) if (b.has(w)) n++;
  return n / Math.min(a.size, b.size);
}
// Tìm đoạn bắt đầu của "bản viết lại": từ đó trở đi các đoạn lần lượt khớp (diễn đạt lại hoặc y nguyên) với các đoạn phía trước
// THEO ĐÚNG THỨ TỰ (đường chéo: đoạn i+k khớp đoạn j+k, lệch tối đa ±2 do tách/gộp đoạn). Trả -1 nếu không có.
// minStart: chỉ xét từ đoạn này trở đi (phía trước đó là bản gốc/đã có).
function _findRestartIndex(paras, minStart, thr, win) {
  thr = thr || 0.5; win = win || 6;
  const n = paras.length; if (n < minStart + 3) return -1;
  const prof = _paraProfiles(paras);
  const START = Math.min(0.35, thr), HIT = Math.min(0.28, thr);
  const walk = (i, j0, limit) => {          // đi dọc đường chéo từ (i, j0), trả {q, hit}
    let q = 0, hit = 0, j = j0;
    for (let k = i; k < Math.min(n, limit); k++, j++) {
      if (prof[k].size < 5) continue; q++;
      let bs = 0, bj = j;
      for (let jj = Math.max(0, j - 2); jj <= j + 2 && jj < k - 2; jj++) { const v = _setSim(prof[k], prof[jj]); if (v > bs) { bs = v; bj = jj; } }
      if (bs >= HIT) { hit++; j = bj; }
    }
    return { q, hit };
  };
  for (let i = Math.max(3, minStart); i < n - 2; i++) {
    if (prof[i].size < 5) continue;
    const cands = [];
    for (let j = 0; j < i - 3; j++) { const v = _setSim(prof[i], prof[j]); if (v >= START) cands.push([v, j]); }
    cands.sort((x, y) => y[0] - x[0]);
    for (const [, j0] of cands.slice(0, 3)) {
      const w = walk(i, j0, i + Math.max(win, 8));
      if (w.hit < 3 || w.hit / Math.max(1, w.q) < 0.6) continue;
      const all = walk(i, j0, n);
      if (all.hit / Math.max(1, all.q) < 0.5) continue;
      // lùi ngược: đoạn mở đầu của bản viết lại thường diễn đạt lại nhiều hơn nên điểm khớp thấp hơn (>=0.2), vẫn phải đúng thứ tự
      let cut = i, ref = j0;
      for (let step = 0; step < 6 && cut - 1 >= Math.max(3, minStart) && ref > 0; step++) {
        const a = prof[cut - 1]; if (a.size < 5) { cut--; continue; }
        let bs = 0, bj = -1; for (let jj = Math.max(0, ref - 3); jj < ref; jj++) { const v = _setSim(a, prof[jj]); if (v > bs) { bs = v; bj = jj; } }
        if (bs >= 0.2 && bj >= 0) { cut--; ref = bj; } else break;
      }
      return cut;
    }
  }
  return -1;
}
// Nếu văn bản có một "bản viết lại" của phần đầu (model chép lại từ đầu), cắt bỏ từ chỗ lặp trở đi.
// Trả về text gốc nếu không phát hiện gì. Chấp nhận cả trường hợp 2 bản dính liền không có dòng trống.
function _dedupeByGrams(src) {
  const sep = src.replace(/(\p{Ll}[.!?…”"])(\p{Lu}\p{Ll})/gu, "$1\n\n$2");
  const paras = sep.split(/\n\s*\n+|\n/).map(p => p.trim()).filter(Boolean);
  const info = paras.map(p => { const w = _normWords(p); return { p, n: w.length, g: _grams(w, 3) }; });
  const isDup = (i, from) => {
    if (info[i].n < 8) return -1;
    for (let j = from; j < i; j++) if (info[j].n >= 8 && _sim(info[i].g, info[j].g) >= 0.5) return j;
    return -1;
  };
  for (let i = 3; i < info.length - 1; i++) {
    const j = isDup(i, 0);
    if (j < 0 || j > 2) continue; // chỉ coi là 'viết lại từ đầu' khi trùng với các đoạn mở đầu chương
    // xác nhận: đoạn kế tiếp cũng trùng với một đoạn nằm sau j (tránh nhầm câu lặp có chủ đích)
    let ok = false;
    for (let k = i + 1; k <= Math.min(i + 2, info.length - 1) && !ok; k++) {
      if (info[k].n < 8) continue;
      for (let m = j + 1; m < i; m++) if (_sim(info[k].g, info[m].g) >= 0.5) { ok = true; break; }
    }
    if (ok) return paras.slice(0, i).join("\n\n");
  }
  return src;
}
function _splitParas(t) { return String(t || "").replace(/(\p{Ll}[.!?…”"])(\p{Lu}\p{Ll})/gu, "$1\n\n$2").split(/\n\s*\n+|\n/).map(p => p.trim()).filter(Boolean); }
function dedupeRepeatedScene(text) {
  const raw = String(text || "");
  if (raw.length < 1500) return raw;
  // (1) Có nhãn TIÊU ĐỀ/NỘI DUNG giữa văn bản -> model xuất lại cả chương: tách các bản, giữ bản tốt nhất, bỏ bản lặp.
  const segs = splitByInnerLabels(raw);
  let src = raw;
  if (segs.length > 1) {
    let keep = segs[0];
    for (let k = 1; k < segs.length; k++) {
      const sg = segs[k], pk = _splitParas(keep), ps = _splitParas(sg);
      const idx = _findRestartIndex(pk.concat(ps), pk.length, 0.4, 5);
      const prof = _paraProfiles(pk.concat(ps));
      let q = 0, hit = 0;
      for (let i = pk.length; i < pk.length + ps.length; i++) { if (prof[i].size < 5) continue; q++; let ok = false; for (let j = 0; j < pk.length && !ok; j++) if (_setSim(prof[i], prof[j]) >= 0.4) ok = true; if (ok) hit++; }
      const isDup = idx >= 0 || (q >= 3 && hit / q >= 0.4) || countWords(sg) < 40;
      if (isDup) {
        // chọn bản đầy đủ hơn: bản sau chỉ thắng khi bản đầu bị cụt còn bản sau kết gọn và không ngắn hơn đáng kể
        if (!endsCleanly(keep) && endsCleanly(sg) && countWords(sg) >= countWords(keep) * 0.8) keep = sg;
      } else keep = keep.replace(/\s+$/, "") + "\n\n" + sg;   // không phải bản lặp (nhãn thừa): chỉ bỏ nhãn, giữ cả hai phần
    }
    src = keep;
  }
  // (2) Trùng gần nguyên văn với đoạn mở đầu
  const g = _dedupeByGrams(src);
  if (g.length < src.length) return g;
  // (3) Bản viết lại chỉ DIỄN ĐẠT LẠI (khác câu chữ nhưng cùng diễn biến), dính liền hoặc cách dòng
  const paras = _splitParas(src);
  const cut = _findRestartIndex(paras, 3, 0.5, 6);
  if (cut > 0) {
    const head = paras.slice(0, cut).join("\n\n"), tail = paras.slice(cut).join("\n\n");
    return (!endsCleanly(head) && endsCleanly(tail) && countWords(tail) >= countWords(head) * 0.8) ? tail : head;
  }
  return src.length < raw.length ? src : raw;
}
// Với lượt viết tiếp: bỏ các đoạn mở đầu lặp lại nội dung đã có. Trả "" nếu toàn bộ là lặp.
// V14.0.8: bỏ RIÊNG các đoạn của phần mới mà gần như trùng nguyên văn với văn bản đã có (model mở đầu lại cùng một cảnh),
// GIỮ các đoạn mới còn lại — khác dropRestartedContinuation (cắt toàn bộ từ chỗ lặp đầu tiên trở đi).
function dropRepeatedParagraphs(baseText, newText) {
  const baseG = _grams(_normWords(String(baseText || "")), 3);
  const paras = String(newText || "").split(/\n\s*\n+|\n/).map(p => p.trim()).filter(Boolean);
  const kept = paras.filter(p => { const w = _normWords(p); return w.length < 8 || _sim(_grams(w, 3), baseG) < 0.7; });
  return kept.join("\n\n");
}

// V14.0.9: dedupeRepeatedScene được viết cho trường hợp model xuất LẠI cả chương (cắt từ chỗ lặp trở đi, mất tới ~50%).
// Với chương Adaptive do code tự ghép scene, chỉ vài đoạn lặp lẻ cũng có thể khiến nó cắt cụt 3.000+ từ ("tụt" xuống ~4.100/3.400 từ).
// Bản an toàn: nếu cắt mất > 20% số từ thì GIỮ NGUYÊN (đoạn lặp lẻ đã được dropRepeatedParagraphs xử lý ở từng scene).
function safeDedupeRepeatedScene(text, minKeep) {
  const src = String(text || ""), d = dedupeRepeatedScene(src);
  if (d.length >= src.length) return src;
  return countWords(d) >= countWords(src) * (minKeep || 0.8) ? d : src;
}

function dropRestartedContinuation(baseText, contText) {
  const base = String(baseText || ""); let cont = String(contText || "").trim();
  if (!cont) return cont;
  // V12.22b: bản viết tiếp mở đầu bằng nhãn TIÊU ĐỀ/NỘI DUNG = model viết lại cả chương -> bỏ nhãn rồi để các bước dưới lọc phần lặp.
  const sg = splitByInnerLabels(cont); if (sg.length) cont = sg.join("\n\n");
  const baseG = _grams(_normWords(base), 3);
  const paras = cont.split(/\n\s*\n+|\n/).map(p => p.trim()).filter(Boolean);
  let cut = paras.length;
  for (let i = 0; i < paras.length; i++) {
    const w = _normWords(paras[i]); if (w.length < 15) continue;
    if (_sim(_grams(w, 3), baseG) >= 0.7) { cut = i; break; }
  }
  let out = paras.slice(0, cut);
  // V12.22b: phần viết tiếp diễn đạt lại nội dung đã có (không trùng nguyên văn) -> cắt từ chỗ lặp
  if (out.length >= 3) {
    const bp = _splitParas(base);
    if (bp.length >= 3) {
      const all = bp.concat(out), r = _findRestartIndex(all, bp.length, 0.5, 4);
      if (r >= bp.length) out = out.slice(0, r - bp.length);
    }
  }
  return out.join("\n\n");
}
const _VN_OK = new Set(["sedan","neon","email","wifi","online","offline","game","app","video","office","laptop","zalo","facebook","youtube","internet","tiktok","inbox","mail","file","link","logo","menu","poster","taxi","radio","karaoke","video","casino","hotel","studio","check","deadline","ceo","kpi","vip","boss","sexy","show","team","sale","sales","manager","ipad","iphone","macbook","google","zoom","slack","excel","word","pdf","silicon","latex","titan","inox","laser","camera","remote","vibrator","plug","cuff","temp","lock","sexy","porn","sms","wifi","bluetooth","smartphone","selfie","livestream","hashtag","comment","story","stress","stalker","vest","blazer","jacket","cardigan","sandal","jeans","shorts","bikini","lingerie","corset","sofa","mascara","vecni","lipstick","gloss","lotion","serum","shampoo","parfum","spa","massage","gym","yoga","pilates","sandwich","burger","pizza","coffee","latte","cappuccino","cocktail","whisky","vodka","chanel","dior","gucci","prada","hermes","versace","nike","adidas","lelo","durex","kindle","netflix","spotify","messenger","instagram","iphone","android","samsung","alô","alo","hello","okay","bye","café","cafe","bar","pub","resort","menu","blouse","boxer","ballet","salon","shop","box","stylist","designer","leader","model","manager","outfit","style","cocktail"]);
const _VN_SYL = /^(ngh|ng|nh|kh|gh|gi|ph|qu|th|tr|ch|[bcdghklmnpqrstvx])?[aeiouy]{1,3}(ng|nh|ch|[cmnpt])?$/;
// V12.19: tiếng cười/hét/thở/tượng thanh viết bằng chữ không dấu (Aaaa, hahaha, hihi, hmmm, shhh...) KHÔNG phải từ lạ.
const _VN_SFX_RUN = /(.)\1{2,}/i;                                   // aaaa, ahhh, hmmm, shhh, ooooh
const _VN_SFX_LAUGH = /^[aeiou]?([hk][aeiou])\1+h?$/i;               // hahaha, hihi, hehe, huhuhu, kekeke, ahaha
const _VN_SFX_WORD = /^(?:h+m+|sh+|ps+t+|ts+k+|gr+|zz+z*|uh+m*|ah+|oh+|eh+)$/i;
function _isSoundEffect(low) { return _VN_SFX_RUN.test(low) || _VN_SFX_LAUGH.test(low) || _VN_SFX_WORD.test(low); }
// V12.19: bằng chứng đổi hồ sơ (thăng chức...) phải TRÍCH từ chính chương: >=70% từ của bằng chứng có trong văn bản nguồn.
function evidenceInText(evidence, text) {
  const ev = _normWords(String(evidence || "")).filter(w => w.length >= 2);
  if (ev.length < 3) return false;
  const have = new Set(_normWords(String(text || "")));
  let hit = 0; ev.forEach(w => { if (have.has(w)) hit++; });
  return hit / ev.length >= 0.7;
}
// V12.30: bằng chứng phải hỗ trợ chính giá trị được đề xuất, không chỉ là một câu bất kỳ trong chương.
function evidenceSupportsValue(value, evidence, threshold = 0.55) {
  const stop = new Set(["va","la","cua","cho","voi","mot","nhung","cac","da","dang","se","thi","ma","nay","do","kia","duoc","bi","boi","tai","trong","ngoai","tren","duoi","den","tu","rat","hon","nhu","khi","neu","vi","sau","truoc","roi","con","cung","khong","co","ban"]);
  const words = _normWords(String(value || "")).filter(w => w.length >= 2 && !stop.has(w));
  const ev = new Set(_normWords(String(evidence || "")).filter(w => w.length >= 2));
  if (!words.length || !ev.size) return false;
  const uniq = [...new Set(words)];
  let hit = 0; uniq.forEach(w => { if (ev.has(w)) hit++; });
  return hit / uniq.length >= Math.max(0, Math.min(1, Number(threshold) || 0.55));
}
function fieldEvidenceSupports(value, evidence, source, threshold = 0.55) {
  return !!String(value || "").trim() && !!String(evidence || "").trim()
    && evidenceInText(evidence, source)
    && evidenceSupportsValue(value, evidence, threshold);
}
// V12.20: kiểm tra một âm tiết tiếng Việt hợp lệ (bỏ dấu thanh, giữ ă â ê ô ơ ư đ). Bắt lỗi kiểu "mươititude", "bănnton", "bọcampo".
const _VN_SYL_FULL = /^(?:ngh|ng|nh|kh|gh|gi|ph|qu|th|tr|ch|[bcdđghklmnpqrstvx])?[aăâeêioôơuưy]{1,3}(?:ng|nh|ch|[cmnpt])?$/;
function _stripToneMarks(s) { return String(s).normalize("NFD").replace(/[\u0300\u0301\u0303\u0309\u0323]/g, "").normalize("NFC"); }
function _isValidVnSyllable(low) { return _VN_SYL_FULL.test(_stripToneMarks(low)); }
function _hasVnDiacritic(t) { return /[ăâêôơưđàáảãạằắẳẵặầấẩẫậèéẻẽẹềếểễệìíỉĩịòóỏõọồốổỗộờớởỡợùúủũụừứửữựỳýỷỹỵ]/i.test(t); }
// V12.46: Semantic Prose Check — kiểm tra cụm tiếng Việt hợp lệ về mặt ký tự
// nhưng vô nghĩa/sai chính tả theo ngữ cảnh (ví dụ "tớn tiền"). Không tự đoán
// bằng từ điển: AI phải trả cụm nguyên văn + câu nguyên văn để có thể vá hẹp.
function splitSemanticSentences(text, maxChars) {
  const src = String(text || ""), cap = Number(maxChars) || 900;
  const out = []; let re = /[^\n.!?…]+(?:[.!?…]+|$)/gu, m;
  while ((m = re.exec(src))) {
    const raw = m[0], left = raw.search(/\S/); if (left < 0) continue;
    const right = raw.trimEnd().length, sentence = raw.slice(left, right);
    if (!sentence || sentence.length < 8) continue;
    out.push({ id: out.length + 1, sentence: sentence.slice(0, cap), start: m.index + left, end: m.index + left + Math.min(sentence.length, cap) });
  }
  return out;
}
function buildSemanticProseCheckPrompt(sentences) {
  const rows = (sentences || []).map(x => String(x.sentence || "").replace(/\r?\n/g, " ") ? (x.id + "|" + String(x.sentence || "").replace(/\r?\n/g, " ")) : "").filter(Boolean);
  return [
    "===== SEMANTIC PROSE CHECK — KHÔNG VIẾT LẠI CẢ CHƯƠNG =====",
    "Bạn là biên tập viên kiểm tra NGỮ NGHĨA văn xuôi tiếng Việt.",
    "Rà từng câu dưới đây để tìm CỤM TỪ rõ ràng vô nghĩa, sai chính tả theo ngữ cảnh hoặc bị ghép nhầm âm tiết, kể cả khi từng từ riêng lẻ đều là tiếng Việt.",
    "Ví dụ lỗi: ‘tớn tiền’ trong ngữ cảnh chi phí có thể phải là ‘tốn tiền’. Không được bắt lỗi chỉ vì văn phong lạ, từ địa phương, tên riêng, thuật ngữ, khẩu ngữ hoặc nội dung 18+ hợp ngữ cảnh.",
    "Mỗi câu chỉ được tối đa một mục. Nếu không chắc ít nhất 85%, dùng status=uncertain; không đề xuất sửa chắc chắn.",
    "CHỈ trả JSON hợp lệ dạng: {\"items\":[{\"id\":1,\"status\":\"fix|uncertain|ok\",\"phrase\":\"cụm nguyên văn\",\"replacement\":\"cụm thay thế\",\"confidence\":0.0,\"reason\":\"ngắn\"}]}",
    "Với status=ok, phrase/replacement để chuỗi rỗng. Với uncertain, replacement có thể để rỗng hoặc chỉ là gợi ý; ứng dụng sẽ KHÔNG tự thay.",
    "Không viết lại cả câu, không giải thích ngoài JSON.", "", rows.join("\n")
  ].join("\n");
}
function parseSemanticProseCheckResponse(raw) {
  let s = String(raw || "").replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim(), obj = null;
  try { obj = JSON.parse(s); } catch (_) {
    const a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a >= 0 && b > a) { try { obj = JSON.parse(s.slice(a, b + 1)); } catch (_) {} }
  }
  const items = obj && Array.isArray(obj.items) ? obj.items : [];
  return items.map(x => ({
    id: Number(x && x.id), status: /^(fix|uncertain|ok)$/i.test(String(x && x.status)) ? String(x.status).toLowerCase() : "uncertain",
    phrase: String(x && x.phrase || "").trim(), replacement: String(x && x.replacement || "").trim(),
    confidence: Math.max(0, Math.min(1, Number(x && x.confidence) || 0)), reason: String(x && x.reason || "").trim()
  })).filter(x => Number.isInteger(x.id) && x.id > 0);
}
function applySemanticProseFixes(text, sentences, items, minConfidence) {
  let out = String(text || ""); const warnings = [], applied = [];
  const byId = new Map((sentences || []).map(x => [Number(x.id), x]));
  const ops = [];
  const normPhrase = s => String(s || "").replace(/\s+/g, " ").trim().toLocaleLowerCase("vi");
  const isFragment = s => {
    const v = String(s || "").trim(), words = v.split(/\s+/).filter(Boolean);
    return v.length < 4 || (words.length === 2 && words.every(w => w.replace(/[^\p{L}]/gu, "").length <= 3));
  };
  (items || []).forEach(x => {
    const row = byId.get(Number(x.id));
    if (!row || x.status === "ok") return;
    // Không hiển thị/ghi nhận các phản hồi vô tác dụng hoặc mảnh từ do AI cắt sai.
    if (isFragment(x.phrase)) return;
    if (normPhrase(x.phrase) === normPhrase(x.replacement)) return;
    if (x.status !== "fix" || Number(x.confidence) < (Number(minConfidence) || 0.85) || !x.phrase || !x.replacement) {
      warnings.push({ id: x.id, phrase: x.phrase, reason: x.reason || "AI không đủ chắc chắn; cần người dùng chọn" }); return;
    }
    const at = row.sentence.indexOf(x.phrase);
    if (at < 0 || /[\r\n]/.test(x.replacement) || x.replacement.length > Math.max(80, x.phrase.length * 4)) {
      warnings.push({ id: x.id, phrase: x.phrase, reason: "Không khớp nguyên văn nên không tự sửa" }); return;
    }
    ops.push({ start: row.start + at, end: row.start + at + x.phrase.length, replacement: x.replacement, id: x.id, phrase: x.phrase });
  });
  ops.sort((a, b) => b.start - a.start).forEach(op => { out = out.slice(0, op.start) + op.replacement + out.slice(op.end); applied.push({ id: op.id, phrase: op.phrase, replacement: op.replacement }); });
  return { text: out, applied: applied.reverse(), warnings };
}
// Liệt kê từ lạ (không phải âm tiết tiếng Việt) chen trong văn bản. Chỉ để cảnh báo / làm đầu vào cho bước tự sửa.
// V12.20: bắt cả từ CÓ DẤU bị ghép lỗi (mươititude, bănnton, bọcampo); trước đây chỉ bắt từ không dấu.
const _LOANWORD_OK = new Set(['mini','micro','notebook','laptop','router','switch','robot','analog','digital','decibel','drap','vest','wifi','internet','online','offline','email','camera','video','radio','taxi','menu','game','show','shop','test','app','sim','usb','pin','tivi','karaoke','cà']);
function findStrayWords(text, allowNames, limit) {
  const out = []; const seen = new Set(); const max = Number(limit) || 12;
  const allow = new Set(_normWords((allowNames || []).join(" ")).map(w => w.normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
  const allowExact = new Set(_normWords((allowNames || []).join(" ")));
  const toks = String(text || "").match(/\p{L}+/gu) || [];
  /* V14.3.5: "de" (pinyin 的/得/地) và "then" (tiếng Anh "rồi/sau đó") rò vào truyện. "de" < 4 chữ cái nên bị bỏ qua; "then" là âm tiết Việt hợp lệ ("then cài") nên bị coi là đúng. */
  { const src = String(text || "");
    if (!allow.has("de") && /(?<![\p{L}\p{N}])de(?![\p{L}\p{N}])/u.test(src)) { out.push("de"); seen.add("de"); }
    if (!allow.has("then") && out.length < max) {
      for (const m of src.matchAll(/(?<![\p{L}\p{N}])then(?![\p{L}\p{N}])/gu)) {
        const after = src.slice(m.index + 4, m.index + 24), before = src.slice(Math.max(0, m.index - 14), m.index);
        if (/^[ \t]+(?:cài|cửa|chốt|ngang|gài|sắt|máy|khóa|gỗ|tre)(?![\p{L}])/u.test(after) || /(?:cái|chiếc|đóng|cài|gài|chốt|cửa|vặn)[ \t]+$/u.test(before)) continue;
        out.push("then"); seen.add("then"); break;
      }
    }
  }
  for (const t of toks) {
    const low = t.toLowerCase();
    if (seen.has(low)) continue;
    if (_LOANWORD_OK.has(low)) continue; // V14.3.8: từ vay mượn thông dụng trong tiếng Việt hiện đại (robot, router, notebook, mini...)
    if (/^[A-Za-z]+$/.test(t)) {
      if (t.length < 4) continue;
      if (_VN_OK.has(low) || _VN_SYL.test(low) || _isSoundEffect(low) || allow.has(low)) continue;
    } else {
      // Có dấu tiếng Việt: hợp lệ nếu là một âm tiết đúng cấu trúc. Chữ cái ngoài bảng chữ cái Việt (ü, ñ...) bỏ qua.
      if (t.length < 3 || !/^[\p{Script=Latin}]+$/u.test(t) || !_hasVnDiacritic(t)) continue;
      if (/[^a-zA-ZăâêôơưđĂÂÊÔƠƯĐàáảãạằắẳẵặầấẩẫậèéẻẽẹềếểễệìíỉĩịòóỏõọồốổỗộờớởỡợùúủũụừứửữựỳýỷỹỵÀÁẢÃẠẰẮẲẴẶẦẤẨẪẬÈÉẺẼẸỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌỒỐỔỖỘỜỚỞỠỢÙÚỦŨỤỪỨỬỮỰỲÝỶỸỴ]/.test(t)) continue;
      if (_isValidVnSyllable(low) || _VN_OK.has(low) || allowExact.has(low) || allow.has(low.normalize("NFD").replace(/[\u0300-\u036f]/g, ""))) continue;
    }
    seen.add(low); out.push(t);
    if (out.length >= max) break;
  }
  return out;
}

// V12.20: tìm câu chứa từng từ lỗi để gửi AI sửa. Trả mảng { word, start, end, sentence, before } (không chồng lấn, theo thứ tự xuất hiện).
function locateWordSentences(text, words) {
  const src = String(text || ""); const found = [];
  const isL = (ch) => !!ch && /\p{L}/u.test(ch);
  for (const w of words || []) {
    let from = 0;
    while (from < src.length) {
      const i = src.indexOf(w, from); if (i < 0) break;
      from = i + w.length;
      if (isL(src[i - 1]) || isL(src[i + w.length])) continue;
      let a = i; while (a > 0 && !/[.!?…\n]/.test(src[a - 1])) a--;
      let b = i + w.length; while (b < src.length && !/[.!?…\n]/.test(src[b])) b++;
      while (b < src.length && /[.!?…”"’')]/.test(src[b]) && src[b] !== "\n") b++;
      const sentence = src.slice(a, b).replace(/^\s+/, ""); const start = b - sentence.length;
      found.push({ word: w, start, end: b, sentence, before: src.slice(Math.max(0, start - 160), start).replace(/\s+/g, " ").trim() });
      break; // mỗi từ lỗi xử lý lần xuất hiện đầu tiên; các lần sau sẽ được quét lại ở vòng kế
    }
  }
  found.sort((x, y) => x.start - y.start);
  const out = []; let lastEnd = -1;
  for (const f of found) { if (f.start < lastEnd) { out[out.length - 1].extra = (out[out.length - 1].extra || []).concat(f.word); continue; } out.push(f); lastEnd = f.end; }
  return out;
}

// V12.20: câu sửa của AI chỉ được nhận nếu bỏ từ lỗi, độ dài gần câu gốc, và giữ phần lớn các từ còn lại.
function acceptWordFix(orig, fixed, badWords) {
  const f = String(fixed || "").trim(), o = String(orig || "").trim();
  if (!f || f.length < 8) return false;
  for (const w of badWords || []) if (f.includes(w)) return false;
  if (/[\u3400-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\u0400-\u04FF]/.test(f)) return false;
  const ow = _normWords(o), fw = _normWords(f);
  if (Math.abs(ow.length - fw.length) > 6 || f.length > o.length * 1.5 + 20) return false;
  const bad = new Set((badWords || []).map(w => _normWords(w)[0]));
  const keep = ow.filter(w => !bad.has(w)); if (!keep.length) return true;
  const have = new Set(fw); let hit = 0; keep.forEach(w => { if (have.has(w)) hit++; });
  return hit / keep.length >= 0.7;
}

// V12.20: câu cuối đã kết thúc đúng cách chưa (. ! ? … có thể kèm ngoặc/nháy đóng).
function endsCleanly(text) {
  const t = String(text || "").replace(/[\s*_]+$/, "");
  if (!t) return true;
  return /[.!?…][”"’')\]）»]*$/.test(t) || /[—–]$/.test(t);
}
// V12.20: lùi về câu hoàn chỉnh gần nhất. Giữ lại ít nhất minRatio độ dài; nếu không có chỗ cắt hợp lý thì trả nguyên.
function trimToLastSentence(text, minRatio) {
  const t = String(text || "").replace(/\s+$/, "");
  if (endsCleanly(t)) return { text: t, cut: false };
  const re = /[.!?…][”"’')\]）»]*(?=\s|$)/g; let m, last = -1;
  while ((m = re.exec(t))) last = m.index + m[0].length;
  if (last < 0 || last < t.length * (minRatio || 0.6)) return { text: t, cut: false };
  return { text: t.slice(0, last).replace(/\s+$/, ""), cut: true };
}
// V12.20: lấy "cú chốt / kết chương" mà người dùng ghi trong gợi ý/mệnh lệnh (để nhắc AI dừng đúng chỗ và để khép chương khi bị cụt).
function extractClosingBeat(text) {
  const src = String(text || ""); if (!src.trim()) return "";
  const re = /(ending\s*anchor|điểm\s*neo\s*kết|anchor\s*kết|cú chốt|câu chốt|chốt chương|chốt cuối|kết thúc chương|kết chương|kết bằng|khép chương|cliffhanger)/i;
  const lines = src.split(/\n+/).map(x => x.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) if (re.test(lines[i])) return lines[i].slice(0, 500);
  const sents = src.split(/(?<=[.!?…])\s+/);
  for (let i = sents.length - 1; i >= 0; i--) if (re.test(sents[i])) return sents.slice(i).join(" ").slice(0, 500);
  return "";
}

// V12.24: ENDING-ANCHOR GATE — không coi "đủ số từ" là đã hoàn thành nếu brief còn mốc kết chưa tới.
function extractEndingAnchor(text) {
  const src = String(text || "").trim();
  if (!src) return "";
  const explicit = extractClosingBeat(src);
  if (explicit) return explicit.replace(/^\s*(?:ending\s*anchor|điểm\s*neo\s*kết|anchor\s*kết|cú chốt|câu chốt|chốt chương|chốt cuối|kết thúc chương|kết chương|kết bằng|khép chương|cliffhanger)\s*[:：-]?\s*/i, "").trim();
  const lines = src.split(/\n+/).map(x => x.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, "").trim()).filter(Boolean);
  const candidates = lines.filter(x => x.length >= 30 && !/^(?:gợi ý|mệnh lệnh|outline|chapter outline|arc manager)\s*[:：]?$/i.test(x));
  return candidates.length ? candidates[candidates.length - 1].slice(0, 500) : "";
}

// V12.28.3: giữ helper Ending Target ở SHARED-CORE để client và worker luôn đồng bộ.
// Ưu tiên Ending Anchor trong GỢI Ý; nếu không có thì dùng MỆNH LỆNH.
function getEndingTarget(hint, directive) {
  const h = extractEndingAnchor(hint);
  if (h) return h;
  return extractEndingAnchor(directive);
}
function _anchorTokens(s) {
  const stop = new Set(["chương","kết","cuối","sau","trước","đến","rồi","và","là","của","cho","một","những","được","trong","với","này","đó","khi","thì","cũng","đã","sẽ","có","về","theo","nhưng","nếu","vào","ra","từ","tại","mà","lại","để","anh","cô","hắn","nàng","hắn","người"]);
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9\s]/g," ").split(/\s+/).filter(w => w.length >= 3 && !stop.has(w));
}
function endingAnchorReached(text, anchor) {
  const cleanAnchor = String(anchor || "").replace(/^\s*(?:ending\s*anchor|điểm\s*neo\s*kết|anchor\s*kết|cú chốt|câu chốt|chốt chương|chốt cuối|kết thúc chương|kết chương|kết bằng|khép chương|cliffhanger)\s*[:：-]?\s*/i, "");
  const a = _anchorTokens(cleanAnchor);
  if (a.length < 3) return false;
  const full = new Set(_anchorTokens(text));
  const tail = new Set(_anchorTokens(String(text || "").slice(-3500)));
  const hitFull = a.filter(w => full.has(w)).length / a.length;
  const hitTail = a.filter(w => tail.has(w)).length / a.length;
  // Ưu tiên đoạn cuối: một anchor được "đạt" khi các từ khóa cốt lõi đã xuất hiện và đang nằm trong đoạn kết.
  return hitTail >= 0.72 || (hitTail >= 0.58 && hitFull >= 0.82);
}
function endingGateInstruction(anchor) {
  return anchor ? [
    "===== ENDING ANCHOR / ĐIỂM KẾT BẮT BUỘC =====",
    anchor,
    "Đây là MỐC KẾT của chương, không phải gợi ý tùy chọn.",
    "Không được dừng chỉ vì đã đạt số từ. Nếu đoạn hiện tại CHƯA thực hiện mốc này, phải viết tiếp liền mạch cho tới khi hoàn thành mốc.",
    "Được kéo dài các diễn biến đang có bằng cảnh, thoại, nội tâm, phản ứng, chuyển tiếp và hệ quả; CẤM mở arc mới hoặc thêm biến cố lớn chỉ để đủ từ.",
    "Ngay sau khi thực hiện xong mốc kết này thì DỪNG HẲN, không viết thêm hậu cảnh."
  ].join("\n") : "";
}

// ===== V12.17: Quality Gate — phần THUẦN (không gọi AI, không đụng DOM/state toàn cục) =====
// Client và worker cùng dùng các hàm này; phần gọi AI / dựng prompt vẫn nằm riêng ở từng nơi.
const GATE_MAX_ATTEMPTS = 5;          // tối đa số lần chấm (và sửa) cho một chương (V12.32.12: 3 → 5)
const GATE_DEFAULT_ATTEMPTS = 5;     // mặc định; giá trị lưu cũ = 3 (mặc định cũ, không có ô chỉnh trên giao diện) cũng được nâng lên 5
const GATE_MAX_VERSIONS = 3;          // số bản gốc giữ lại trong chapter.versions
const GATE_MIN_REWRITE_RATIO = 0.6;   // bản sửa ngắn hơn 60% bản gốc bị từ chối

function gateItemText(x) { return typeof x === "string" ? x : ((x && (x.description || x.problem)) || JSON.stringify(x)); }

function gateMaxAttempts(v) { const n = Number(v); const eff = (!n || n === 3) ? GATE_DEFAULT_ATTEMPTS : n; return Math.max(1, Math.min(GATE_MAX_ATTEMPTS, eff)); }

// V14.1.5: lỗi cảnh chỉ là THIẾU CÂU CHUYỂN CẢNH (nhảy địa điểm/thời gian) hay là NGƯỜI VẮNG MẶT nói/làm? Chỉ loại thứ hai mới là lỗi nặng.
function sceneTransitionOnly(text) {
  const t = String(text || "").toLowerCase();
  if (!t.trim()) return false;
  const transition = /chuyển cảnh|đột ngột|không có (câu|mô tả)|không có dòng|thiếu (câu|mô tả)|nhảy (từ|sang|địa điểm|thời gian)|không (rõ|thấy) (cách|việc) (di chuyển|đến)|xuất hiện (ở|tại|trong)/.test(t);
  const absent = /không có mặt|đã rời (đi|khỏi cảnh)|đã đi khỏi|đã cúp máy|đã bị đưa đi|lời thoại[^|]{0,40}(cảnh cũ|lẫn)|(nói|trả lời|phản ứng|lên tiếng|chen vào)[^|]{0,60}(khi|dù|lúc)[^|]{0,40}(không có mặt|đã rời|chưa (đến|tới)|vắng)/.test(t);
  return transition && !absent;
}
// Chuẩn hoá kết quả Auditor → review có verdict cuối cùng. Trả null nếu obj không phải object JSON.
// opts: { maxMainEvents, maxNamedCharacters, passScore, softFailScore, extraHard: string[], now }
/* V14.5.14: Auditor hay nhét NHẬN XÉT "KHÔNG CÓ LỖI" vào danh sách lỗi ("… nên không phải lỗi continuity", "hợp lý", "đúng trình tự", "đã đúng"). Các dòng đó vào luồng AI tự sửa
   làm model sửa nhầm chỗ đang đúng. Chỉ bỏ dòng có kết luận "không lỗi" VÀ không chứa từ chỉ lỗi thật (thiếu/sai/mâu thuẫn/lặp/…), nên dòng lỗi thật không bị nuốt. */
function isNoopAuditNote(text) {
  const t = String(text || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (!t) return false;
  const ok = /(không phải (?:là )?(?:một )?lỗi|không (?:có )?lỗi|không có vấn đề|không cần sửa|hợp lý|đúng trình tự|đã đúng|đúng như outline|đạt yêu cầu|nên không phải)/.test(t);
  if (!ok) return false;
  const bad = /(không hợp lý|bất hợp lý|chưa hợp lý|không đúng|chưa đúng|không đạt|sai lệch|trái |thiếu|sai |sai\.|mâu thuẫn|vi phạm|bỏ sót|bị lặp|lặp lại|nhầm|không khớp|chưa (?:thấy|có|viết|thực hiện|rõ)|thừa|lỗi nặng|nên (?:sửa|thêm|bổ sung|viết lại)|cần (?:sửa|thêm|bổ sung|viết lại))/.test(t);
  return !bad;
}
function evaluateReview(obj, opts) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  opts = opts || {};
  const maxEv = Number(opts.maxMainEvents) || 3, maxCh = Number(opts.maxNamedCharacters) || 6;
  const passScore = Number(opts.passScore) || 90, softScore = Number(opts.softFailScore) || 75;
  const arr = (v, n) => (Array.isArray(v) ? v.slice(0, n) : []);
  // Một số Auditor đặt câu kiểm tra đạt vào hardFailures dù đây không phải lỗi.
  // Không để dòng "Không có lỗi continuity mức cao..." làm nhiễu Gate/UI.
  const hard = arr(obj.hardFailures, 20).filter(x => !/^\s*Không có lỗi continuity mức cao/i.test(gateItemText(x)) && !isNoopAuditNote(gateItemText(x)));
  const noiseDropped = (Array.isArray(obj.warnings) ? obj.warnings.slice(0, 20) : []).filter(x => isNoopAuditNote(gateItemText(x))).length + (Array.isArray(obj.hardFailures) ? obj.hardFailures.slice(0, 20).length : 0) - hard.length;
  /* V14.5.9: AI Auditor hay báo "Thiếu sự kiện/beat bắt buộc" dù chương đã viết ý đó bằng câu chữ khác -> chỉ CẢNH BÁO, không HARD_FAIL
     (viết lại không hết lỗi). Bật lại chặn cứng bằng opts.strictBeats. */
  const beatWarn = [];
  if (!opts.strictBeats) {
    const isMissingBeat = x => /(thiếu|chưa (?:thấy|thực hiện|có|viết)|bỏ sót|không (?:có|thấy)).{0,60}(sự kiện|beat|\[R\d|mốc|ý của outline)|(sự kiện|beat|\[R\d).{0,60}(bắt buộc|còn thiếu|thiếu bằng chứng)|Outline chương \d+ chưa thực hiện đủ/i.test(gateItemText(x));
    for (let i = hard.length - 1; i >= 0; i--) if (isMissingBeat(hard[i])) beatWarn.unshift(gateItemText(hard.splice(i, 1)[0]));
  }
  (opts.extraHard || []).forEach(m => hard.push(m));
  if (Number(obj.mainEventCount) > maxEv) hard.push("Vượt ngân sách sự kiện: " + obj.mainEventCount + " > " + maxEv);
  if (Number(obj.namedCharacterCount) > maxCh) hard.push("Vượt số nhân vật có tên: " + obj.namedCharacterCount + " > " + maxCh);
  if (obj.unauthorizedImportantCharacter) hard.push("Có nhân vật mới quan trọng không được outline/brief cho phép.");
  if (obj.knowledgeViolation) hard.push("Vi phạm Knowledge Ledger / nhân vật biết thông tin chưa thể biết.");
  if (obj.retcon) hard.push("Có dấu hiệu retcon canon đã xác nhận.");
  if (obj.stagnation) {
    const sn = (Array.isArray(obj.stagnationNotes) ? obj.stagnationNotes : []).slice(0, 2).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    hard.push("Chương dậm chân tại chỗ: cảnh lặp/kéo dài, cuối chương không có thay đổi nào so với đầu chương" + (sn ? ": " + sn : "."));
  }
  if (obj.arcStall) {
    const an2 = (Array.isArray(obj.arcNotes) ? obj.arcNotes : []).slice(0, 2).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    hard.push("Chương không đưa Arc/Outline tiến thêm bước nào (không làm việc bắt buộc của giai đoạn)" + (an2 ? ": " + an2 : "."));
  }
  const sceneWarn = [];
  if (obj.sceneViolation) {
    const sn2 = (Array.isArray(obj.sceneNotes) ? obj.sceneNotes : []).slice(0, 3).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    // V14.1.5: Auditor hay ghi cùng một lỗi cảnh hai lần (một dòng "sceneViolation: ..." trong hardFailures + cờ sceneViolation) => chương bị đếm 2 lỗi nặng.
    const isSceneItem = x => /^\s*(sceneViolation\b|Lỗi cảnh\/người có mặt)/i.test(gateItemText(x));
    const sceneItems = hard.filter(isSceneItem).map(gateItemText);
    const sceneText = sceneItems.concat(sn2).join(" | ");
    for (let i = hard.length - 1; i >= 0; i--) if (isSceneItem(hard[i])) hard.splice(i, 1);
    // Chỉ thiếu câu chuyển cảnh/nhảy địa điểm (không có ai nói/làm khi vắng mặt) => cảnh báo, không phải lỗi nặng; viết lại bằng vá chèn câu chuyển cảnh.
    if (sceneTransitionOnly(sceneText)) sceneWarn.push("Thiếu câu chuyển cảnh (không có nhân vật nào nói/làm khi vắng mặt)" + (sceneText ? ": " + sceneText.replace(/^\s*sceneViolation:\s*/i, "").slice(0, 600) : "."));
    else hard.push("Lỗi cảnh/người có mặt: nhân vật tự xuất hiện hoặc nói khi không có mặt/đã rời đi, hoặc lẫn cảnh" + (sceneText ? ": " + sceneText.slice(0, 900) : "."));
  }
  if (obj.profileViolation) {
    const pv = (Array.isArray(obj.profileViolations) ? obj.profileViolations : []).slice(0, 3).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    hard.push("Nhân vật hành xử/nói vượt thiết lập hồ sơ (địa vị, nghề, quyền hạn, năng lực, kiến thức, cách nói)" + (pv ? ": " + pv : "."));
  }
  if (obj.genderAnatomyMismatch) {
    const ga = (Array.isArray(obj.genderAnatomyNotes) ? obj.genderAnatomyNotes : []).slice(0, 3).map(x => typeof x === "string" ? x : (x && (x.description || x.problem || x.character)) || "").filter(Boolean).join(" | ");
    hard.push("Nhầm giải phẫu/đặc điểm sinh học giữa các giới theo hồ sơ nhân vật" + (ga ? ": " + ga : "."));
  }
  const timeWarn = [];
  /* V14.2: văn "liệt kê hành động" và kết chương không có móc chỉ là CẢNH BÁO mềm (không chặn Sync); dùng để gợi ý sửa/viết lại tay. */
  if (obj.listLikeProse) {
    const ln = (Array.isArray(obj.listLikeNotes) ? obj.listLikeNotes : []).slice(0, 2).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    timeWarn.push("Văn như liệt kê hành động nối nhau, thiếu cảm xúc/quyền lực đan xen" + (ln ? ": " + ln : "."));
  }
  if (obj.weakHook) {
    const hn = (Array.isArray(obj.hookNotes) ? obj.hookNotes : []).slice(0, 2).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    timeWarn.push("Kết chương chưa có móc (lệnh mới/nguy cơ bị phát hiện/ham muốn chưa thỏa/phụ thuộc hơn)" + (hn ? ": " + hn : "."));
  }
  if (obj.timeStagnation) {
    const tn = (Array.isArray(obj.timeNotes) ? obj.timeNotes : []).slice(0, 2).map(x => typeof x === "string" ? x : (x && (x.description || x.problem)) || "").filter(Boolean).join(" | ");
    timeWarn.push("Thời gian truyện bất nhất hoặc đứng yên" + (tn ? ": " + tn : "."));
  }
  if (obj.appearanceVague) {
    const an = (Array.isArray(obj.appearanceNotes) ? obj.appearanceNotes : []).slice(0, 3).map(x => typeof x === "string" ? x : (x && (x.description || x.name)) || "").filter(Boolean).join(" | ");
    timeWarn.push("Miêu tả ngoại hình chung chung, thiếu kích thước/chi tiết cụ thể" + (an ? ": " + an : "."));
  }
  const score = Math.max(0, Math.min(100, Number(obj.score) || 0));
  const verdict = hard.length ? "HARD_FAIL" : (score >= passScore ? "PASS" : (score >= softScore ? "SOFT_FAIL" : "HARD_FAIL"));
  return Object.assign({}, obj, {
    score, verdict, hardFailures: hard,
    dimensions: obj.dimensions && typeof obj.dimensions === "object" ? obj.dimensions : {},
    warnings: arr(obj.warnings, 20).filter(x => !isNoopAuditNote(gateItemText(x))).concat(beatWarn, sceneWarn, timeWarn, opts.extraWarnings || []), noiseDropped: Math.max(0, noiseDropped), suggestions: arr(obj.suggestions, 20), rewriteInstructions: arr(obj.rewriteInstructions, 12),
    reviewedAt: opts.now || Date.now()
  });
}

// Hướng sửa gửi cho Writer: ưu tiên rewriteInstructions, nếu trống thì dùng hardFailures.
function rewriteInstructionsText(review) {
  review = review || {};
  const ins = (review.rewriteInstructions || []).join("\n");
  return ins || (review.hardFailures || []).map(gateItemText).join("\n");
}

// Bản sửa có được phép thay bản thảo không? (không rỗng, không ngắn bất thường)
function checkRewriteAcceptable(oldWc, newText, newWc) {
  if (!String(newText || "").trim() || newWc < Math.max(20, Math.floor(oldWc * GATE_MIN_REWRITE_RATIO)))
    return { ok: false, reason: "Bản sửa quá ngắn/rỗng (" + newWc + " từ so với " + oldWc + ")" };
  return { ok: true };
}

// ===== V12.32.10: SỬA CỤC BỘ (patch) — AI chỉ trả các đoạn cần xoá/thêm/thay, app tự ghép vào bản thảo =====
// Lý do: viết lại cả chương dài thường bị cắt/tóm tắt (vd 1159/5309 từ) → Gate từ chối bản sửa. Vá cục bộ không có rủi ro đó.
const PATCH_MAX_COUNT = 12;            // tối đa số thao tác vá một lượt
const PATCH_MIN_RATIO = 0.6;           // sau vá, chương ngắn hơn 60% bản gốc bị từ chối
const PATCH_MAX_RATIO = 1.35;          // sau vá, chương dài hơn 135% bản gốc bị từ chối
function buildPatchPrompt(p) {
  p = p || {};
  const rv = p.review || {};
  return [
    "VÁ CỤC BỘ BẢN THẢO CHƯƠNG " + p.chapterNumber + " THEO QUALITY REVIEW.",
    "KHÔNG viết lại cả chương. Chỉ trả về danh sách thao tác nhỏ để app tự ghép vào bản thảo. Phần không nhắc đến sẽ được giữ nguyên 100%.",
    "Chỉ sửa đúng các lỗi được nêu. Không thêm sự kiện chính mới, không tạo nhân vật quan trọng mới. Giữ POV, xưng hô, giọng văn.",
    "ƯU TIÊN TUYỆT ĐỐI: OUTLINE/CONTRACT luôn thắng HƯỚNG SỬA. Bỏ qua mọi gợi ý nào xoá/thay/làm nhẹ beat, sự kiện hoặc lời thoại bắt buộc của Outline, hoặc thêm cảnh/tuyến ngoài Outline; chỉ áp dụng phần sửa cách viết, lặp, chuyển cảnh, thiếu beat.",
    p.storyControl || "",
    p.characterLock || "",
    (p.contractLabel || "OUTLINE/CONTRACT") + ":\n" + (p.contract || ""),
    p.context ? "CANON CONTEXT:\n" + compactGateContext(p.context, 6000, false) : "",
    p.prevEnding ? "ĐOẠN KẾT CHƯƠNG TRƯỚC (cảnh mở đầu chương này PHẢI nối tiếp đúng địa điểm / thời điểm / người có mặt ở đây — đây là sự thật, không được tự bịa địa điểm khác):\n" + String(p.prevEnding).slice(-1500) : "",
    (rv.alreadyFixed && rv.alreadyFixed.length) ? "LỖI ĐÃ SỬA Ở VÒNG TRƯỚC — GIỮ NGUYÊN các chỗ đã sửa, tuyệt đối không làm hỏng hoặc hoàn tác:\n- " + rv.alreadyFixed.join("\n- ") : "",
    "LỖI CẦN SỬA:\n" + (rv.hardFailures || []).concat((rv.warnings || []).slice(0, 8)).map(gateItemText).join("\n"),
    "HƯỚNG SỬA ƯU TIÊN (chỉ áp dụng phần KHÔNG mâu thuẫn Outline/Contract; mâu thuẫn thì Outline thắng):\n" + rewriteInstructionsText(rv),
    "ĐỊNH DẠNG TRẢ VỀ — CHỈ MỘT JSON, không markdown, không giải thích:",
    '{"patches":[{"op":"replace|delete|insert_after|insert_before|insert_before_end|insert_start|insert_end","find":"...","from":"...","to":"...","which":1,"text":"..."}]}',
    "QUY TẮC:",
    "- find / from / to: chép NGUYÊN VĂN từ bản thảo, 6–25 từ liên tiếp, nằm trong một đoạn. Không sửa dấu, không đổi dấu câu.",
    "- Xoá/thay một đoạn dài: dùng from (6–12 từ đầu đoạn) + to (6–12 từ cuối đoạn), không chép cả đoạn. Xoá/thay một câu ngắn: dùng find.",
    '- Nếu find/from xuất hiện nhiều lần (đoạn bị lặp), thêm which = số thứ tự lần xuất hiện cần tác động (1, 2, 3...) hoặc "last" cho lần cuối. Muốn xoá bản lặp ở cuối chương thì which = "last".',
    "- replace: thay đoạn tìm được bằng text. delete: xoá, không có text. insert_after / insert_before: chèn text (câu chuyển cảnh tự nhiên, chi tiết bổ sung…) sau/trước find. insert_before_end: chèn một cảnh còn thiếu ngay trước đoạn kết cuối cùng, KHÔNG cần find — ưu tiên dùng cho beat/biến cố Outline bị bỏ sót. insert_start / insert_end: chèn ở đầu / cuối chương, không cần find.",
    "- Nếu QUALITY REVIEW nói thiếu một beat/sự kiện bắt buộc nhưng không có câu neo chắc chắn, dùng insert_before_end thay vì bịa find. Cảnh mới phải nối tự nhiên với đoạn trước và không viết lại đoạn kết.",
    p.retryNote ? ("RETRY VÁ — lượt trước không ghép được patch. Với mọi [R] thiếu, BẮT BUỘC dùng insert_before_end có text là cảnh ngắn hoàn chỉnh; không dùng find [R1]/[R2] hoặc tên beat vì các mã đó thường không nằm trong bản thảo. Chỉ dùng replace/insert_after khi find là câu nguyên văn chắc chắn trong BẢN THẢO. Lý do lượt trước: " + p.retryNote) : "",
    "- text: văn xuôi tiếng Việt thuần, không đánh dấu, không ghi chú. Câu chuyển cảnh chỉ 1–3 câu.",
    p.prevEnding ? "- Khi sửa lỗi nối cảnh/địa điểm: đọc ĐOẠN KẾT CHƯƠNG TRƯỚC, rồi viết câu chuyển cảnh nối đúng từ chỗ đó vào cảnh mở đầu của bản thảo (ví dụ chương trước kết ở hành lang thì phải có hành động đi tiếp/mở cửa/bước vào trước khi tả cảnh trong phòng). Không dời cảnh sang địa điểm mới nào khác." : "",
    "- Chi tiết thêm vào (ngoại hình, đồ vật, thời gian) phải khớp CANON CONTEXT và hồ sơ nhân vật, không mâu thuẫn với phần còn lại của chương.",
    "- KHÔNG thêm câu/dòng báo ngày giờ như một nhãn ở đầu hoặc cuối chương. Nếu cần sửa lỗi thời gian, lồng chi tiết thời gian vào mạch kể (ánh sáng, việc đang làm, một mệnh đề chuyển) như văn xuôi thuần túy.",
    "- Tối đa " + PATCH_MAX_COUNT + " thao tác. Mỗi lỗi một thao tác ngắn nhất có thể.",
    "BẢN THẢO HIỆN TẠI:\n" + (p.draft || "")
  ].filter(Boolean).join("\n\n");
}
// Đọc JSON do AI trả về (chịu được ```json … ``` và chữ thừa quanh JSON). Trả mảng patch hoặc null.
function parsePatchResponse(raw) {
  const s = String(raw || "").trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
  const tryParse = t => { try { return JSON.parse(t); } catch (_) { return undefined; } };
  let obj = tryParse(s);
  if (obj === undefined) { const a = s.indexOf("{"), b = s.lastIndexOf("}"); if (a >= 0 && b > a) obj = tryParse(s.slice(a, b + 1)); }
  if (obj === undefined) { const a = s.indexOf("["), b = s.lastIndexOf("]"); if (a >= 0 && b > a) obj = tryParse(s.slice(a, b + 1)); }
  const arr = Array.isArray(obj) ? obj : (obj && Array.isArray(obj.patches) ? obj.patches : null);
  return arr ? arr.filter(x => x && typeof x === "object").slice(0, PATCH_MAX_COUNT) : null;
}
// Tìm mọi vị trí của snippet: khớp nguyên văn trước, không được thì khớp linh hoạt khoảng trắng/xuống dòng.
function _patchLocate(text, snippet, fromPos) {
  const sn = String(snippet || "").trim(); if (!sn) return [];
  const out = []; let i = text.indexOf(sn, fromPos || 0);
  while (i >= 0) { out.push({ start: i, end: i + sn.length }); i = text.indexOf(sn, i + sn.length); }
  if (out.length) return out;
  const re = new RegExp(sn.split(/\s+/).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("\\s+"), "g");
  re.lastIndex = fromPos || 0; let m;
  while ((m = re.exec(text))) { out.push({ start: m.index, end: m.index + m[0].length }); if (m[0].length === 0) re.lastIndex++; }
  return out;
}
function _patchPick(hits, which) {
  if (!hits.length) return { err: "không tìm thấy đoạn trong bản thảo" };
  const w = String(which === undefined || which === null ? "" : which).toLowerCase();
  if (w === "last") return { hit: hits[hits.length - 1] };
  const n = Number(w);
  if (n >= 1) return n <= hits.length ? { hit: hits[n - 1] } : { err: "which=" + n + " nhưng chỉ có " + hits.length + " chỗ khớp" };
  if (hits.length > 1) return { err: "đoạn khớp " + hits.length + " chỗ (cần which)" };
  return { hit: hits[0] };
}
// Ghép các patch vào văn bản. Trả { text, applied, skipped:[{index,reason}] }. Patch lỗi bị bỏ qua, không làm hỏng cả lượt.
function applyChapterPatches(text, patches) {
  let cur = String(text || ""); const skipped = []; let applied = 0;
  (Array.isArray(patches) ? patches : []).slice(0, PATCH_MAX_COUNT).forEach((p, index) => {
    const op = String((p && p.op) || "").toLowerCase(), add = String((p && p.text) || "").trim();
    const skip = r => skipped.push({ index, reason: op + ": " + r });
    if (op === "insert_start") { if (!add) return skip("thiếu text"); cur = add + "\n\n" + cur.replace(/^\s+/, ""); applied++; return; }
    if (op === "insert_end") { if (!add) return skip("thiếu text"); cur = cur.replace(/\s+$/, "") + "\n\n" + add; applied++; return; }
    if (op === "insert_before_end") {
      if (!add) return skip("thiếu text");
      const trimmed = cur.replace(/\s+$/, "");
      const cut = trimmed.lastIndexOf("\n\n");
      if (cut <= 0) { cur = trimmed + "\n\n" + add; applied++; return; }
      cur = trimmed.slice(0, cut) + "\n\n" + add + "\n\n" + trimmed.slice(cut + 2);
      applied++; return;
    }
    if (!["replace", "delete", "insert_after", "insert_before"].includes(op)) return skip("thao tác không hợp lệ");
    if (op !== "delete" && !add) return skip("thiếu text");
    let start, end;
    if (p.from && p.to && (op === "replace" || op === "delete")) {
      const a = _patchPick(_patchLocate(cur, p.from), p.which); if (a.err) return skip("from: " + a.err);
      const bh = _patchLocate(cur, p.to, a.hit.end).filter(h => h.start >= a.hit.start);
      if (!bh.length) return skip("to: không tìm thấy phía sau from");
      start = a.hit.start; end = bh[0].end;
      if (end - start > cur.length * 0.4) return skip("đoạn from→to quá dài (>40% chương)");
    } else {
      const f = p.find || p.from; if (!f) return skip("thiếu find");
      const a = _patchPick(_patchLocate(cur, f), p.which); if (a.err) return skip(a.err);
      start = a.hit.start; end = a.hit.end;
    }
    if (op === "replace") cur = cur.slice(0, start) + add + cur.slice(end);
    else if (op === "delete") cur = cur.slice(0, start) + cur.slice(end);
    else if (op === "insert_after") {
      let e2 = end; while (e2 < cur.length && /[.!?…”"’')\]]/.test(cur[e2])) e2++;   // neo thiếu dấu chấm/ngoặc đóng cuối đoạn vẫn tính là cuối đoạn
      const para = e2 >= cur.length || cur[e2] === "\n", at = para ? e2 : end;
      cur = cur.slice(0, at) + (para ? "\n\n" : " ") + add + cur.slice(at);
    } else {
      let s2 = start; while (s2 > 0 && /["“‘'(\[—\- \t]/.test(cur[s2 - 1])) s2--;          // neo thiếu ngoặc mở/gạch thoại đầu đoạn vẫn tính là đầu đoạn
      const para = s2 === 0 || cur[s2 - 1] === "\n", at = para ? s2 : start;
      cur = cur.slice(0, at) + add + (para ? "\n\n" : " ") + cur.slice(at);
    }
    applied++;
  });
  cur = cur.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  return { text: cur, applied, skipped };
}
// Bản vá có được thay bản thảo không? (đã ghép ≥1 patch, độ dài không lệch quá nhiều)
function checkPatchAcceptable(oldText, res) {
  const oldWc = countWords(oldText), newWc = countWords(res && res.text);
  if (!res || !res.applied) return { ok: false, reason: "không có thao tác vá nào ghép được" + (res && res.skipped && res.skipped.length ? " (" + res.skipped.slice(0, 2).map(s => s.reason).join("; ") + ")" : "") };
  if (newWc < Math.max(20, Math.floor(oldWc * PATCH_MIN_RATIO))) return { ok: false, reason: "bản vá làm chương ngắn bất thường (" + newWc + " từ so với " + oldWc + ")" };
  if (newWc > Math.ceil(oldWc * PATCH_MAX_RATIO)) return { ok: false, reason: "bản vá làm chương dài bất thường (" + newWc + " từ so với " + oldWc + ")" };
  return { ok: true, wordCount: newWc };
}

// V12.45: sửa theo vùng — dùng khi câu neo của patch không ghép được và chương quá dài để viết lại toàn bộ.
// AI chỉ trả hai mốc nguyên văn + phần thay thế; app tự tìm vùng và giữ nguyên phần còn lại.
function buildSegmentRepairPrompt(p) {
  p = p || {}; const rv = p.review || {};
  return [
    "SỬA THEO VÙNG BẢN THẢO CHƯƠNG " + p.chapterNumber + " THEO QUALITY REVIEW.",
    "Không viết lại cả chương. Chọn đúng MỘT vùng nhỏ nhất chứa lỗi được nêu (thường 1 cảnh hoặc 2–8 đoạn), rồi viết lại chỉ vùng đó.",
    "Nếu lỗi là tuyến phụ/nhân vật mới làm lệch Arc, được phép thay toàn bộ vùng đó bằng một đoạn cầu nối hoặc cảnh đúng Outline; không cố giữ tuyến sai. Không thêm nhân vật/tuyến mới.",
    p.storyControl || "", p.characterLock || "",
    (p.contractLabel || "OUTLINE/CONTRACT") + ":\n" + (p.contract || ""),
    p.context ? "CANON CONTEXT:\n" + compactGateContext(p.context, 5000, false) : "",
    "LỖI CẦN SỬA:\n" + (rv.hardFailures || []).concat((rv.warnings || []).slice(0, 8)).map(gateItemText).join("\n"),
    "HƯỚNG SỬA (chỉ áp dụng phần KHÔNG mâu thuẫn Outline/Contract; mâu thuẫn thì Outline thắng):\n" + rewriteInstructionsText(rv),
    "Với lỗi style/pacing: ưu tiên rút gọn câu dài, bỏ lặp ý/triết lý, tăng nhịp; không xóa sự kiện cần thiết.",
    "ĐỊNH DẠNG — chỉ trả đúng một JSON, không markdown:",
    '{"start":"8–24 từ NGUYÊN VĂN ở đầu vùng cần sửa","end":"8–24 từ NGUYÊN VĂN ở cuối vùng cần sửa","replacement":"toàn bộ văn xuôi mới thay cho vùng đó"}',
    "QUY TẮC MỐC:",
    "- start và end phải chép đúng từng chữ từ BẢN THẢO, không dùng mã [R], mô tả vị trí hoặc câu tự chế.",
    "- start phải đứng trước end; vùng thay thế không quá khoảng 30% chương.",
    "- replacement phải là văn xuôi tiếng Việt thuần, nối mượt với phần trước/sau; không ghi chú, không tiêu đề; với tuyến drift phải chuyển về đúng Arc/Outline.",
    "- Với cảnh bị dài, replacement có thể ngắn hơn bản cũ nhưng vẫn phải giữ nguyên nguyên nhân–kết quả và điểm kết.",
    "BẢN THẢO HIỆN TẠI:\n" + (p.draft || "")
  ].filter(Boolean).join("\n\n");
}
function parseSegmentRepairResponse(raw) {
  const s = String(raw || "").trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
  let obj; try { obj = JSON.parse(s); } catch (_) {
    const a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a >= 0 && b > a) { try { obj = JSON.parse(s.slice(a, b + 1)); } catch (__) {} }
  }
  if (!obj || typeof obj !== "object") return null;
  const start = String(obj.start || obj.startMarker || "").trim();
  const end = String(obj.end || obj.endMarker || "").trim();
  const replacement = String(obj.replacement || obj.text || "").trim();
  return start && end && replacement ? { start, end, replacement } : null;
}
function applySegmentRepair(text, repair) {
  const src = String(text || ""), r = repair || {};
  const sh = _patchLocate(src, r.start), eh = _patchLocate(src, r.end);
  if (!sh.length) return { ok: false, reason: "start: không tìm thấy mốc đầu vùng" };
  if (!eh.length) return { ok: false, reason: "end: không tìm thấy mốc cuối vùng" };
  const start = sh[0].start;
  const after = eh.filter(x => x.start >= start);
  if (!after.length) return { ok: false, reason: "mốc cuối nằm trước mốc đầu" };
  const end = after[0].end;
  if (end <= start || end - start > src.length * 0.30) return { ok: false, reason: "vùng sửa quá rộng hoặc không hợp lệ" };
  const replacement = String(r.replacement || "").trim();
  if (countWords(replacement) < 20) return { ok: false, reason: "phần thay thế quá ngắn" };
  const out = (src.slice(0, start) + replacement + src.slice(end)).replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const oldWc = countWords(src), newWc = countWords(out);
  if (newWc < Math.floor(oldWc * 0.85) || newWc > Math.ceil(oldWc * 1.15)) return { ok: false, reason: "sửa theo vùng làm thay đổi tổng độ dài quá mạnh (" + newWc + "/" + oldWc + " từ)" };
  return { ok: true, text: out, wordCount: newWc, start: r.start, end: r.end };
}

// ===== V12.32.13: GIỚI HẠN OUTPUT & MỞ RỘNG CHƯƠNG BẰNG CHÈN ĐOẠN (không viết lại cả chương) =====
// Mọi lệnh gọi AI bị chặn ở AI_MAX_OUTPUT_TOKENS token output (provider ~8192). Chương dài (vd 5000+ từ ≈ 9–11k token)
// KHÔNG thể được "viết lại toàn bộ" trong một lệnh gọi → bị cắt/tóm tắt. Thay vào đó AI chỉ viết các đoạn mới cần chèn.
const AI_MAX_OUTPUT_TOKENS = 7800;
function estimateOutputTokens(text) { return Math.ceil(String(text || "").length / 3); }   // ước lượng thô cho tiếng Việt
function wholeRewriteFits(text) {
  const est = Math.ceil(estimateOutputTokens(text) * 1.12);
  return { fits: est <= Math.floor(AI_MAX_OUTPUT_TOKENS * 0.9), est, cap: AI_MAX_OUTPUT_TOKENS };
}
function expandMaxTokens(needWords) { return Math.max(1500, Math.min(AI_MAX_OUTPUT_TOKENS, Math.ceil(Math.max(0, Number(needWords) || 0) * 2.6) + 1200)); }
function buildExpandInsertPrompt(o) {
  const wc = o.wc, need = Math.max(150, Math.ceil(o.goal * 1.04 - wc)), room = Math.max(0, o.maxWords - wc);
  const brief = [o.directive ? ("MỆNH LỆNH: " + String(o.directive).trim()) : "", o.hint ? ("GỢI Ý: " + String(o.hint).trim()) : ""].filter(Boolean).join("\n");
  return [
    "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU.",
    "MỞ RỘNG CHƯƠNG BẰNG CÁCH CHÈN THÊM ĐOẠN. Bản hiện tại " + wc + " từ, CHƯA ĐỦ độ dài: cần tối thiểu " + o.goal + " từ (mục tiêu " + o.target + ", tuyệt đối không vượt " + o.maxWords + "). Cần THÊM khoảng " + need + " từ (tối đa " + room + " từ).",
    "KHÔNG viết lại chương. Giữ nguyên 100% văn bản hiện có. Chỉ viết các ĐOẠN MỚI để chèn vào những chỗ chương đang kể lướt/thiếu chi tiết, và nêu chỗ chèn.",
    "CÁCH LÀM: chọn 4–8 chỗ khác nhau; mỗi chỗ viết 1–3 đoạn mới (không khí/bối cảnh, hành động từng bước, hội thoại, nội tâm, giác quan, phản ứng và hệ quả), cùng giọng văn, POV, xưng hô, nối mượt với câu trước và sau chỗ chèn.",
    "CẤM: thêm biến cố lớn, nhân vật quan trọng mới, arc mới; lặp ý hoặc độn chữ; mâu thuẫn với phần có sẵn; chèn sau câu cuối chương hoặc đổi điểm kết chương; ghi chú/giải thích.",
    o.style || "",
    brief ? ("===== KẾ HOẠCH NGƯỜI DÙNG (không đổi) =====\n" + brief + (o.closing ? ("\nENDING ANCHOR: " + o.closing) : "") + "\n===== HẾT =====") : "",
    "ĐỊNH DẠNG TRẢ VỀ — chỉ dùng đúng định dạng này, lặp lại cho từng chỗ chèn, không lời dẫn:",
    ">>> SAU: <chép NGUYÊN VĂN 6–20 từ CUỐI của một đoạn có sẵn, đúng từng chữ, không sửa dấu>",
    "<các đoạn mới, cách nhau một dòng trống>",
    ">>> TRƯỚC: <chép NGUYÊN VĂN 6–20 từ ĐẦU của một đoạn có sẵn>",
    "<các đoạn mới>",
    "Mỗi chỗ chèn dùng cụm neo khác nhau và duy nhất trong chương. Không chèn sau đoạn cuối cùng của chương.",
    "===== BẢN HIỆN TẠI (" + wc + " từ) =====",
    String(o.text || ""),
    "===== HẾT BẢN HIỆN TẠI ====="
  ].filter(Boolean).join("\n");
}
// Đọc các khối ">>> SAU: <neo>" / ">>> TRƯỚC: <neo>" + đoạn mới. Không dùng JSON để khỏi vỡ vì dấu ngoặc kép trong lời thoại.
function parseInsertBlocks(raw) {
  const re = /^\s*>>>\s*(SAU|TRƯỚC|TRUOC)\s*:\s*(.+?)\s*$/i, out = []; let cur = null;
  String(raw || "").replace(/\r/g, "").split("\n").forEach(ln => {
    const m = ln.match(re);
    if (m) { if (cur) out.push(cur); cur = { op: /^SAU$/i.test(m[1]) ? "insert_after" : "insert_before", find: m[2].replace(/^["“‘'`]+|["”’'`…]+$/g, "").trim(), body: [] }; }
    else if (cur) cur.body.push(ln);
  });
  if (cur) out.push(cur);
  return out.map(p => ({ op: p.op, find: p.find, text: p.body.join("\n").replace(/\n{3,}/g, "\n\n").trim() })).filter(p => p.find && p.text).slice(0, PATCH_MAX_COUNT);
}
// Chèn từng khối; bỏ khối nào làm đổi đoạn kết, vượt maxWords hoặc không tìm thấy neo. Trả { text, applied, skipped, added }.
function applyExpandInserts(text, blocks, maxWords) {
  const base = String(text || "").trim(), tail = base.slice(-160), skipped = []; let cur = base, applied = 0;
  (Array.isArray(blocks) ? blocks : []).forEach((b, index) => {
    if (!b || (b.op !== "insert_after" && b.op !== "insert_before")) return skipped.push({ index, reason: "chỉ cho phép chèn" });
    const res = applyChapterPatches(cur, [b]);
    if (!res.applied) return skipped.push({ index, reason: res.skipped[0] ? res.skipped[0].reason : "không ghép được" });
    if (!res.text.endsWith(tail)) return skipped.push({ index, reason: "chèn vào đoạn kết chương" });
    if (maxWords && countWords(res.text) > maxWords) return skipped.push({ index, reason: "vượt giới hạn " + maxWords + " từ" });
    cur = res.text; applied++;
  });
  return { text: cur, applied, skipped, added: countWords(cur) - countWords(base) };
}
function acceptExpandInserts(oldText, res) {
  if (!res || !res.applied) return { ok: false, reason: "không chèn được đoạn nào" + (res && res.skipped && res.skipped.length ? " (" + res.skipped.slice(0, 2).map(s => s.reason).join("; ") + ")" : "") };
  if (res.added < 120) return { ok: false, reason: "đoạn chèn quá ít (+" + res.added + " từ)" };
  return { ok: true, text: res.text, words: countWords(res.text), added: res.added };
}

// Lưu bản gốc vào chapter.versions (mới nhất đứng đầu, giữ tối đa GATE_MAX_VERSIONS).
function backupBeforeRewrite(chapter, note) {
  if (!Array.isArray(chapter.versions)) chapter.versions = [];
  const oldText = String(chapter.text || "");
  chapter.versions.unshift({ timestamp: Date.now(), text: oldText, wordCount: countWords(oldText), modelUsed: chapter.modelUsed || null, isNsfw: !!chapter.isNsfw, polished: !!chapter.polished, note: note || "Trước khi Quality Gate sửa" });
  chapter.versions = chapter.versions.slice(0, GATE_MAX_VERSIONS);
}

// Mỗi lượt thay cảnh báo do AI cũ bằng cảnh báo mới (giữ cảnh báo khác nguồn), không cộng dồn.
function mergeAiContinuityWarnings(existing, incoming, cap) {
  const keep = (Array.isArray(existing) ? existing : []).filter(w => !(w && w.source === "ai"));
  const fresh = (Array.isArray(incoming) ? incoming : []).map(w => Object.assign({}, w, { source: "ai" }));
  return keep.concat(fresh).slice(-(cap || 20));
}

// ===== V12.17 (phần 2): Story Control, dựng prompt Gate, vòng lặp Gate, đánh dấu Sync =====

// --- Story Control: một nguồn duy nhất cho chuẩn hoá + prompt (trước đây client và worker viết khác nhau) ---
function normalizeStoryControl(st) {
  const sc = (st && st.storyControl && typeof st.storyControl === "object") ? st.storyControl : {};
  return {
    schemaVersion: Number(sc.schemaVersion) || 1,
    maxMainEvents: Math.max(1, Math.min(3, Number(sc.maxMainEvents) || 3)),
    /* V14.7.5: mặc định nới (6) và tác giả chỉnh được (tới 12). Giá trị 4 cũ do mặc định cũ lưu lại không được coi là lựa chọn của tác giả (castCapUserSet). */
    maxNamedCharacters: Math.max(1, Math.min(12, sc.castCapUserSet === true ? (Number(sc.maxNamedCharacters) || 6) : Math.max(6, Number(sc.maxNamedCharacters) || 0))),
    castCapUserSet: sc.castCapUserSet === true, castAutoPlanned: sc.castAutoPlanned === true,
    maxNewThreads: Math.max(0, Math.min(5, Number(sc.maxNewThreads) || 3)),
    noRetcon: sc.noRetcon !== false,
    timePace: ["scene","day","fewdays","week"].includes(sc.timePace) ? sc.timePace : "",
    lockedFields: Array.isArray(sc.lockedFields) ? sc.lockedFields : ["identity","age","background","canon","relationships","cultivation","abilities","importantItems","secrets","promises","worldRules"],
    agencyRequired: sc.agencyRequired !== false
  };
}
// --- V12.32.5: TIẾN TRIỂN BẮT BUỘC + TRÍ NHỚ TRUYỆN (chống dậm chân tại chỗ, tăng liền lạc giữa các chương) ---
function progressRulesPrompt(st) {
  const mf = normalizeChapterMatureFocus(st && st.chapterMatureFocus);
  return [
    "TIẾN TRIỂN BẮT BUỘC (chống dậm chân tại chỗ):",
    "- Cuối chương, ít nhất MỘT điều phải đã THAY ĐỔI so với đầu chương: quan hệ giữa các nhân vật, thông tin/bí mật được lộ, quyền lực/vị thế, mục tiêu, hoặc một hậu quả mới. Không kết chương ở đúng trạng thái đã có lúc mở chương.",
    "- Mỗi cảnh phải có hành động hoặc lựa chọn làm tình thế dịch chuyển; cấm lặp lại cùng một hành động, cùng một kiểu miêu tả hay cùng nhịp cảm xúc chỉ để kéo dài. Muốn dài hơn thì đẩy tình huống sang bước kế tiếp, không nhắc lại bước vừa qua.",
    "- Chương phải tiếp nối từ điểm kết chương trước và các việc ĐANG DANG DỞ (nếu có trong bối cảnh); không bỏ quên và không làm như chưa từng xảy ra.",
    mf === "primary" ? "- Cảnh trưởng thành là trọng tâm nhưng KHÔNG phải toàn bộ chương: chỉ chiếm khoảng một nửa đến hai phần ba nội dung; phần còn lại (trước, xen kẽ, sau) là diễn biến cốt truyện/quan hệ. Cảnh nóng phải tự làm đổi điều gì đó (quan hệ, quyền lực, bí mật, hậu quả, quyết định) và mở ra bước kế tiếp; đừng lặp lại cùng một động tác hay cùng một đoạn tả." : ""
  ].filter(Boolean).join("\n");
}
// --- V12.32.8: NEO NGOẠI HÌNH — người đọc phải hình dung được nhân vật (kích thước/số đo cụ thể, không tính từ trống). ---
function appearanceAnchorPrompt(st, adult) {
  const mature = !!(adult || (st && st.mature));
  return [
    "NEO NGOẠI HÌNH (để người đọc hình dung được nhân vật):",
    "- Khi nhân vật có tên xuất hiện LẦN ĐẦU (và khi quay lại sau nhiều chương vắng mặt): tả 2–4 câu gồm tuổi/vẻ ngoài, chiều cao, vóc dáng, mặt-tóc-mắt-da, trang phục và MỘT nét nhận dạng riêng. Dùng con số hoặc so sánh cụ thể (VD: cao khoảng 1m65, vai hẹp, tóc ngang vai, mắt một mí), không chỉ tính từ chung chung.",
    "- Cấm tính từ trống đứng một mình như \"đẹp\", \"quyến rũ\", \"to\", \"đầy đặn\", \"cao ráo\": phải kèm kích thước, hình dáng hoặc so sánh cụ thể để người đọc hình dung ra.",
    "- Hồ sơ có chiều cao/dáng/SỐ ĐO thì dùng ĐÚNG. Hồ sơ còn trống mục ngoại hình thì TỰ ĐẶT chi tiết hợp lý ngay lần tả đầu và giữ nhất quán ở các chương sau (chi tiết này sẽ được lưu vào hồ sơ).",
    mature ? "- Khi tả cơ thể của nhân vật ĐÃ ĐỦ 18 TUỔI trong cảnh người lớn: nêu kích thước cụ thể ít nhất ở lần tả đầu tiên (ngực: cỡ/cup hoặc so sánh vật thể kèm độ đầy, độ nảy; eo, mông, đùi; chiều cao, cân nặng; với nam: kích thước và hình dạng) theo mục SỐ ĐO trong hồ sơ; hồ sơ trống thì tự đặt số hợp lý và giữ nhất quán. Nhân vật dưới 18 tuổi hoặc không rõ tuổi: KHÔNG tả số đo hay đặc điểm tình dục của cơ thể." : ""
  ].filter(Boolean).join("\n");
}
// Tóm tắt truyện đến nay: mỗi chương cũ 1–2 câu (trừ chương gần nhất đã có khối riêng), tổng không quá maxChars.
function storySoFarPrompt(chapters, maxChars) {
  const active = acceptedStoryChapters(chapters);
  const cs = active.slice(0, -1);
  maxChars = Number(maxChars) || 2800;
  const clean = c => String((c && c.summary) || "").replace(/\*\*[^*]*\*\*:?/g, " ").replace(/\s+/g, " ").trim();
  const items = [];
  cs.forEach((c, i) => { const t = clean(c); if (t) items.push({ n: Number(c.chapterNumber) || i + 1, t }); });
  if (!items.length) return "";
  const N = Math.min(items.length, Math.max(1, Math.floor(maxChars / 90)));
  const use = items.slice(-N), per = Math.max(80, Math.min(260, Math.floor(maxChars / N) - 8));
  const cutSentence = (t, n) => { if (t.length <= n) return t; const h = t.slice(0, n); const k = Math.max(h.lastIndexOf(". "), h.lastIndexOf("! "), h.lastIndexOf("? ")); return (k > n * 0.5 ? h.slice(0, k + 1) : h.trimEnd() + "…"); };
  const lines = use.map(x => "Ch" + x.n + ": " + cutSentence(x.t, per));
  return "TRUYỆN ĐẾN NAY (tóm tắt các chương trước" + (use.length < items.length ? ", chỉ " + use.length + " chương gần nhất" : "") + " — giữ liền mạch, không mâu thuẫn):\n" + lines.join("\n");
}
// Các việc đang dang dở lấy từ Current Status có cấu trúc.
function openLoopsPrompt(st) {
  const ss = (st && st.statusState && typeof st.statusState === "object") ? st.statusState : {};
  const cur = ss.currentState || {}, lt = ss.longTerm || {};
  const pick = (k) => { const v = cur[k] != null && cur[k] !== "" ? cur[k] : lt[k]; return typeof v === "string" ? v.trim() : (v ? JSON.stringify(v) : ""); };
  const rows = [["Chưa giải quyết", "unresolved"], ["Mâu thuẫn", "conflict"], ["Mục tiêu kế tiếp", "nextGoal"], ["Móc nối chương sau", "nextHooks"]]
    .map(([l, k]) => { const v = pick(k); return v ? "- " + l + ": " + (v.length > 260 ? v.slice(0, 260) + "…" : v) : ""; }).filter(Boolean);
  return rows.length ? "ĐANG DANG DỞ (phải tiếp nối, không bỏ quên):\n" + rows.join("\n") : "";
}

// --- V12.32.4: HỒ SƠ KHÓA — buộc AI không để nhân vật vượt thiết lập (địa vị/nghề/quyền hạn/tài sản/năng lực/kiến thức/giọng nói). ---
// Nhân vật có tên xuất hiện trong text (kèm nhân vật chính) — dùng cho Review/Rewrite.
function lockCharsForText(st, text, limit) {
  const t = String(text || ""), out = [], seen = new Set();
  const push = c => { if (c && c.name && !seen.has(c.name) && out.length < (limit || 8)) { seen.add(c.name); out.push(c); } };
  ((st && st.characters) || []).forEach(c => { if (c && c.name && !c.dead && knownNameMentions(t, [c.name]).length) push(c); });
  return out;
}
// --- V14.1: HỆ THỐNG TU LUYỆN (tu tiên / huyền huyễn / võ hiệp) ---
// Thang đại cảnh giới (thấp -> cao), mỗi đại cảnh giới chia 9 tiểu tầng "đệ nhất ... đệ cửu trọng". Người dùng có thể đổi thang trong Story Bible (state.realmLadder).
const CULT_GENRE_RE = /tu (tiên|chân|luyện|đạo)|tiên hiệp|huyền huyễn|kiếm hiệp|võ hiệp|xianxia|cultivation|wuxia|tiên nghịch/i;
const DEFAULT_REALM_LADDER = ["Luyện Khí", "Trúc Cơ", "Kết Đan", "Nguyên Anh"];
const CULT_DEFAULT_SYSTEM_TEXT = [
  "Cảnh giới giữ tên gọi cũ; mỗi đại cảnh giới chia chín tiểu tầng (đệ nhất đến đệ cửu trọng).",
  "• Luyện Khí: khởi đầu. Chín tiểu tầng chủ yếu rèn thể chất, mở kinh mạch. Đệ cửu là ngưỡng cửa trước Trúc Cơ — nhiều người mắc kẹt hàng chục năm vì thiếu tài nguyên.",
  "• Trúc Cơ: nơi phần lớn dừng chân lâu dài. Thể chất mạnh lên, nhan sắc giữ gìn, tuổi thọ kéo dài. Trúc Cơ hậu kỳ đã là nhân vật có tiếng trong giới trung lưu.",
  "• Kết Đan: đẳng cấp khan hiếm. Kim đan ngưng kết, sức mạnh tăng vọt. Đệ cửu (viên mãn) được xem là đỉnh cao của thời đại đối với phần lớn người còn sống.",
  "• Nguyên Anh trở lên: gần như chỉ còn trong lời đồn và cổ tịch. Còn nhiều cảnh giới khác chưa có ai chạm tới và chưa có ghi chép."
].join("\n");
const REALM_TIER_WORDS = ["nhat", "nhi", "tam", "tu", "ngu", "luc", "that", "bat", "cuu"];
// Các trường tu luyện của hồ sơ nhân vật (dùng chung NPC + nhân vật chính). aliases/peakRealm xử lý riêng.
const CULT_FIELDS = ["realm", "peakRealm", "spiritRoot", "talent", "element", "technique", "arts", "combatPower", "treasure", "inventory", "spiritStones", "apparentAge", "lifespan", "masterLine", "fortune", "grudges", "originSecret", "innerDemon", "karma"];
const CULT_ACCUM = ["arts", "fortune", "grudges", "innerDemon", "karma"];                       // ghi thêm, không xóa cũ
const CULT_FILL = ["spiritRoot", "talent", "element", "masterLine", "originSecret", "apparentAge"]; // chỉ điền khi còn trống
const CULT_EXPLICIT = ["technique", "treasure", "lifespan"];                                       // điền khi trống; đổi cần sự kiện + bằng chứng
const CULT_FREE = ["combatPower", "inventory", "spiritStones"];                                    // trạng thái động, được cập nhật
function isCultivationGenre(genre) { return CULT_GENRE_RE.test(String(genre || "")); }
function _rn(s) { return normalizeName(String(s == null ? "" : s).replace(/đ/gi, "d")).replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim(); }
function realmLadderOf(st) {
  const raw = st && st.realmLadder;
  let arr = Array.isArray(raw) ? raw : String(raw || "").split(/[,;\n>→]+/);
  arr = arr.map(x => String(x).trim()).filter(Boolean).slice(0, 30);
  return arr.length ? arr : DEFAULT_REALM_LADDER.slice();
}
// "Trúc Cơ đệ tam trọng" -> {major:1, tier:3, name:"Trúc Cơ", rank:13, known:true}. Tên ngoài thang -> known:false. "Phàm nhân" -> major:-1.
function parseRealm(text, ladder) {
  const n = _rn(text); if (!n) return null;
  ladder = ladder && ladder.length ? ladder : DEFAULT_REALM_LADDER;
  if (/(^| )(pham nhan|nguoi pham|chua tu luyen|chua nhap mon)( |$)/.test(n)) return { major: -1, tier: 0, name: "Phàm nhân", rank: -10, known: true };
  let major = -1, best = "";
  ladder.forEach((r, i) => { const rn = _rn(r); if (rn && (" " + n + " ").includes(" " + rn + " ") && rn.length >= best.length) { major = i; best = rn; } });
  if (major < 0) return { major: -1, tier: 0, name: "", rank: null, known: false };
  let tier = 0, m;
  if ((m = n.match(/(?:^| )de (nhat|nhi|tam|tu|ngu|luc|that|bat|cuu) (?:trong|tang)/))) tier = REALM_TIER_WORDS.indexOf(m[1]) + 1;
  else if ((m = n.match(/(?:tang|trong|cap) (\d)(?: |$)/)) || (m = n.match(/(?:^| )(\d) (?:trong|tang)/))) tier = Math.max(0, Math.min(9, parseInt(m[1], 10)));
  else if (/vien man|dinh phong|dai vien man/.test(n)) tier = 9;
  else if (/(^| )hau ky/.test(n)) tier = 8; else if (/(^| )trung ky/.test(n)) tier = 5; else if (/(^| )so ky/.test(n)) tier = 2;
  return { major, tier, name: ladder[major], rank: major * 10 + tier, known: true };
}
// Quyết định có chấp nhận đổi cảnh giới old -> new không (chưa tính bằng chứng). ok=true: hợp lệ về mặt thang bậc.
function realmChangeVerdict(oldText, newText, ladder) {
  const nn = String(newText || "").trim(); if (!nn) return { ok: false, reason: "empty" };
  const o = String(oldText || "").trim();
  const b = parseRealm(nn, ladder);
  if (!b || !b.known) return { ok: false, reason: "unknown", warn: "Cảnh giới \"" + nn.slice(0, 40) + "\" không nằm trong thang cảnh giới của truyện — bỏ qua (không tự đặt cảnh giới mới)." };
  if (!o) return { ok: true, kind: "set" };
  if (_rn(o) === _rn(nn)) return { ok: false, reason: "same" };
  const a = parseRealm(o, ladder);
  if (!a || !a.known) return { ok: true, kind: "set" };
  if (b.major - a.major >= 2) return { ok: false, reason: "jump", warn: "Bỏ qua đổi cảnh giới \"" + o.slice(0, 30) + "\" → \"" + nn.slice(0, 30) + "\": nhảy từ 2 đại cảnh giới trở lên." };
  if (b.rank > a.rank) return { ok: true, kind: b.major > a.major ? "breakthrough" : "advance" };
  return { ok: true, kind: "drop" };
}
function _realmEvidenceOk(newRealm, evidence, ladder) {
  const b = parseRealm(newRealm, ladder); if (!b || !b.known) return false;
  const e = _rn(evidence); if (!e) return false;
  return (b.name && e.includes(_rn(b.name))) || /dot pha|tien vao|tien len|len toi|dat toi|dat den|ngung ket|vien man|tang|trong|hau ky|trung ky|so ky|dinh phong|phe|tut|roi xuong|ton hai|suy giam/.test(e);
}
// Áp các trường tu luyện từ bản cập nhật AI `u` lên hồ sơ `target` (NPC hoặc nhân vật chính). Trả về mảng ghi chú/cảnh báo.
// o: { explicit:boolean (có explicitCoreChange + bằng chứng hợp lệ), evidence:string, state }
function applyCultivationUpdate(target, u, o) {
  const notes = [];
  if (!target || !u) return notes;
  o = o || {};
  const ladder = realmLadderOf(o.state), explicit = !!o.explicit;
  const has = v => v != null && String(v).trim() !== "";
  const clip = (v, n) => String(v).replace(/\s+/g, " ").trim().slice(0, n);
  if (has(u.realm)) {
    const v = realmChangeVerdict(target.realm, u.realm, ladder);
    if (v.ok) {
      const wasEmpty = !has(target.realm);
      if (wasEmpty || (explicit && _realmEvidenceOk(u.realm, o.evidence, ladder))) {
        target.realm = clip(u.realm, 80);
        if (!wasEmpty) notes.push("Cảnh giới: " + (v.kind === "drop" ? "tụt" : "tăng") + " → " + target.realm);
      } else notes.push("Bỏ qua đổi cảnh giới → \"" + clip(u.realm, 40) + "\": thiếu sự kiện đột phá có bằng chứng trích từ chương.");
    } else if (v.warn) notes.push(v.warn);
  }
  { const pr = parseRealm(target.realm, ladder), pk = parseRealm(target.peakRealm, ladder);
    if (pr && pr.known && pr.rank != null && (!pk || !pk.known || pr.rank > pk.rank)) target.peakRealm = target.realm; }
  CULT_ACCUM.forEach(k => { if (has(u[k])) target[k] = mergeTextSegments(target[k], clip(u[k], 800), 1200); });
  CULT_FILL.forEach(k => { if (has(u[k]) && !has(target[k])) target[k] = clip(u[k], 200); });
  CULT_EXPLICIT.forEach(k => { if (has(u[k]) && (!has(target[k]) || explicit)) target[k] = clip(u[k], 240); });
  CULT_FREE.forEach(k => { if (has(u[k])) target[k] = clip(u[k], 300); });
  { // tên khác / đạo hiệu: chỉ thêm tên mới, không trùng nhân vật khác
    const raw = Array.isArray(u.aliases) ? u.aliases : (has(u.aliases) ? String(u.aliases).split(/[,;\n]+/) : []);
    if (raw.length) {
      const cur = Array.isArray(target.aliases) ? target.aliases.slice() : [];
      const taken = new Set([_rn(target.name)].concat(cur.map(_rn)));
      const others = new Set();
      const sts = o.state;
      if (sts) { ((sts.characters) || []).forEach(c => { if (c && c !== target) { others.add(_rn(c.name)); (c.aliases || []).forEach(a => others.add(_rn(a))); } });
        if (sts.mainCharProfile && sts.mainCharProfile !== target) others.add(_rn(sts.mainCharProfile.name)); }
      raw.forEach(a => { const s = clip(a, 40), k = _rn(s);
        if (!k || taken.has(k) || cur.length >= 8) return;
        if (others.has(k)) { notes.push("Bỏ qua tên khác \"" + s + "\": trùng nhân vật khác."); return; }
        cur.push(s); taken.add(k); });
      if (cur.length) target.aliases = cur;
    }
  }
  return notes;
}
// Khối canon về hệ thống tu luyện đưa vào prompt (rỗng nếu truyện không dùng).
function cultivationSystemBlock(st) {
  if (!st) return "";
  const txt = String(st.cultivationSystem || "").trim();
  const hasLadder = Array.isArray(st.realmLadder) ? st.realmLadder.length > 0 : !!String(st.realmLadder || "").trim();
  if (!txt && !hasLadder && !isCultivationGenre(st.genre)) return "";
  const ladder = realmLadderOf(st), top = ladder[ladder.length - 1];
  const out = ["HỆ THỐNG TU LUYỆN (CANON — không tự đổi):"];
  if (txt) out.push(txt.length > 1800 ? txt.slice(0, 1800) + "…" : txt);
  out.push("Thang đại cảnh giới (thấp → cao): " + ladder.join(" → ") + ". Mỗi đại cảnh giới chia 9 tiểu tầng: đệ nhất, nhị, tam, tứ, ngũ, lục, thất, bát, cửu trọng.");
  out.push("- Dùng ĐÚNG tên cảnh giới trong thang; không tự đặt tên cảnh giới/đại cảnh giới mới. Các cảnh giới cao hơn " + top + " chưa có ai chạm tới và chưa có ghi chép: chỉ được nhắc như lời đồn/cổ tịch mơ hồ, KHÔNG đặt tên, KHÔNG miêu tả chi tiết, KHÔNG cho nhân vật nào đạt tới.");
  out.push("- Nhân vật chỉ đột phá/tụt cảnh khi chương kể RÕ sự kiện (tài nguyên, cơ duyên, ngộ đạo, bị thương nặng...). Không nhảy cảnh giới giữa hai chương; không vượt quá một đại cảnh giới mỗi lần.");
  out.push("- Chênh lệch đại cảnh giới là vực sâu: thắng người cao hơn một đại cảnh giới phải có bù đắp cụ thể trong chương (pháp bảo, trận pháp, mưu kế, đối phương bị thương). Tiểu tầng cao hơn trong cùng đại cảnh giới chỉ là ưu thế vừa phải.");
  return out.join("\n");
}

function characterLockPrompt(mc, chars, short) {
  const cut = (v, n) => { v = String(v == null ? "" : v).replace(/\s+/g, " ").trim(); return v.length > n ? v.slice(0, n) + "…" : v; };
  const line = (c, isMain) => {
    const f = [];
    if (c.occupation) f.push("nghề: " + cut(c.occupation, 50));
    if (c.role) f.push("vai trò: " + cut(c.role, 50));
    if (c.position) f.push("chức vụ/địa vị: " + cut(c.position, 50));
    if (c.faction) f.push("phe/tổ chức: " + cut(c.faction, 40));
    if (c.gender) f.push("giới tính theo hồ sơ: " + cut(c.gender, 20));
    if (c.maritalStatus) f.push("tình trạng hôn nhân: " + cut(c.maritalStatus, 30));
    if (c.spouseName) f.push("người phối ngẫu/người yêu: " + cut(c.spouseName, 50));
    if (c.maritalNotes) f.push("ghi chú hôn nhân: " + cut(c.maritalNotes, 80));
    if (c.age) f.push("tuổi: " + cut(c.age, 10));
    if (c.skills || c.strength) f.push("năng lực: " + cut(c.skills || c.strength, 60));
    if (c.realm) f.push("cảnh giới: " + cut(c.realm, 40));
    if (c.peakRealm && c.peakRealm !== c.realm) f.push("từng đạt: " + cut(c.peakRealm, 40));
    if (c.spiritRoot || c.talent) f.push("linh căn/tư chất: " + cut([c.spiritRoot, c.talent].filter(Boolean).join("; "), 60));
    if (c.technique) f.push("công pháp: " + cut(c.technique, 50));
    if (c.arts) f.push("thần thông/chiêu thức: " + cut(c.arts, 70));
    if (c.combatPower) f.push("sức chiến đấu: " + cut(c.combatPower, 50));
    if (c.treasure) f.push("pháp bảo/binh khí: " + cut(c.treasure, 50));
    if (c.masterLine) f.push("sư môn/bối phận: " + cut(c.masterLine, 50));
    if (c.apparentAge) f.push("tuổi ngoại hình: " + cut(c.apparentAge, 20));
    if (c.lifespan) f.push("thọ nguyên: " + cut(c.lifespan, 30));
    if (Array.isArray(c.aliases) && c.aliases.length) f.push("tên khác: " + cut(c.aliases.join(", "), 50));
    if (c.speech || c.voice) f.push("cách nói: " + cut(c.speech || c.voice, 60));
    if (c.personality) f.push("tính: " + cut(c.personality, 60));
    if (c.knowledge) f.push("biết: " + cut(c.knowledge, 60));
    if (c.relevanceToMC) f.push("với NVC: " + cut(c.relevanceToMC, 50));
    return f.length ? "- " + (c.name || "?") + (isMain ? " (NVC)" : "") + " | " + f.join(" | ") : "";
  };
  const rows = [];
  if (mc && mc.name) rows.push(line(mc, true));
  (chars || []).forEach(c => { if (c && c.name && !(mc && mc.name === c.name)) rows.push(line(c, false)); });
  const lines = rows.filter(Boolean);
  if (!lines.length) return "";
  const hasCult = [mc].concat(chars || []).some(c => c && (c.realm || c.technique || c.arts));
  const cultRule = hasCult ? "- CẢNH GIỚI/CÔNG PHÁP: giữ đúng cảnh giới, công pháp, thần thông, pháp bảo ghi trong hồ sơ; không tự nâng/hạ cảnh giới, không tự thêm công pháp hoặc thần thông cao hơn hồ sơ. Đột phá chỉ khi chương kể rõ sự kiện; thắng người cao hơn một đại cảnh giới phải có bù đắp cụ thể." : "";
  const anatomyLock = [
    "GENDER ANATOMY LOCK — bắt buộc phân biệt nhân vật theo giới tính trong hồ sơ:",
    "- Trước mọi đoạn tả thân thể, đối chiếu đúng TÊN nhân vật với giới tính hồ sơ; không lấy mô tả của người này gán sang người khác.",
    "- Nhân vật nam không được nhận bộ phận, đặc điểm hoặc phản ứng sinh học đặc trưng của nhân vật nữ; nhân vật nữ không được nhận bộ phận, đặc điểm hoặc phản ứng sinh học đặc trưng của nhân vật nam.",
    "- Khi nhiều nhân vật cùng cảnh, mỗi câu tả thân thể phải có chủ thể rõ bằng tên hoặc đại từ đã khóa; không dùng đại từ mơ hồ.",
    "- Nếu giới tính hồ sơ trống hoặc mâu thuẫn, không suy đoán chi tiết nhạy cảm; dùng mô tả trung tính và giữ nguyên hồ sơ."
  ];
  if (short) return ["HỒ SƠ KHÓA — giữ đúng nghề/địa vị/quyền hạn/năng lực/cách nói của từng nhân vật, không tự nâng cấp hay vượt thiết lập:", ...(cultRule ? [cultRule] : []), ...anatomyLock, ...lines].join("\n");
  return [
    "HỒ SƠ KHÓA — NHÂN VẬT PHẢI ĐÚNG THIẾT LẬP (ưu tiên hơn sự hấp dẫn của cảnh):",
    "- Mỗi nhân vật chỉ được nói, nghĩ và hành xử trong phạm vi nghề, địa vị, quyền hạn, tài sản, năng lực, tuổi, hiểu biết và tính cách ghi dưới đây. Không tự nâng cấp (quyền lực, giàu có, võ công, quan hệ, chức danh) và không tự hạ cấp.",
    "- Lời thoại và cách xưng hô phải hợp địa vị: người cấp thấp không ra lệnh như cấp trên, không nhận tài sản/tổ chức/quyền không có trong hồ sơ là của mình; người chưa biết một bí mật thì không được nói hay hành động như đã biết.",
    "- Muốn nhân vật vượt hồ sơ (thăng chức, lộ thân phận, có năng lực mới) thì phải có sự kiện RÕ RÀNG trong chính chương làm nguyên nhân (và brief cho phép); nếu không, giữ đúng hồ sơ.",
    "- Hồ sơ trống ở một mục nghề/địa vị/quyền hạn/tài sản/năng lực = chưa xác định: đừng bịa chi tiết quan trọng cho mục đó, dùng chi tiết trung tính hoặc để mở. (NGOẠI LỆ: ngoại hình/vóc dáng/số đo trống thì được tự đặt chi tiết cụ thể, hợp lý.)",
    "- Trước khi viết mỗi cảnh, tự hỏi: nhân vật này có THẬT SỰ được phép nói/làm điều này theo hồ sơ không? Nếu không, đổi cách viết.",
    ...(cultRule ? [cultRule] : []),
    ...anatomyLock,
    "HỒ SƠ:", ...lines
  ].join("\n");
}

// --- V12.32.18: TIẾN ĐỘ ARC + OUTLINE THEO CHƯƠNG (chống truyện đi quá chậm) ---
function activeArcOf(st) { return ((st && st.arcs) || []).find(a => a && a.status === "active") || null; }
function outlineOf(st, n) { return ((st && st.outlinePlans) || []).find(o => o && n >= o.from && n <= o.to) || null; }
// Tách nội dung outline thành dòng theo chương: "Ch12: ...", "Chương 12: ...", "12. ...", "12) ...", "12 - ...".
// V14.5.7: outline dán từ Word/Google Docs hay chứa ngắt dòng mềm U+2028/U+2029/U+0085 (Shift+Enter) trước "Sự kiện:/Kháng cự:/Hậu quả:/Móc kết:".
// JS không coi chúng là xuống dòng thường và `.` không khớp chúng -> toàn bộ outline "không có chương nào". Đổi thành khoảng trắng (giữ nhãn cùng dòng như định dạng chuẩn).
function outlineNormalizeText(s) { return String(s || "").replace(/\r\n?/g, "\n").replace(/[\u2028\u2029\u0085\u000b\u000c]/g, " "); }
// V14.5.6: outline đánh số lại từ 1 trong từng gói (gói áp dụng cho chương 7–12 nhưng viết Ch1…Ch6) -> đổi về số chương tuyệt đối để chương 9 không rơi vào dòng của chương khác.
function _outlineRemapLocal(map, ol) {
  if (!ol) return map;
  const from = Number(ol.from) || 1, to = Number(ol.to) || from, keys = Object.keys(map).map(Number);
  if (from <= 1 || !keys.length) return map;
  const mn = Math.min.apply(null, keys), mx = Math.max.apply(null, keys);
  if (!(mn < from && mx <= to - from + 1)) return map; // có khóa tuyệt đối hợp lệ -> giữ nguyên
  const out = {}; keys.forEach(k => { out[k + from - 1] = map[k]; });
  return out;
}
function outlineChapterLines(content, ol) {
  const map = {}; let cur = 0;
  /* V14.7.8: tiêu đề CHẶNG "Chương 2–3" / "Ch 4-5: ..." (nhiều chương chung một khối) trước đây bị đọc nhầm thành chương 2 với nội dung "3…" hoặc bị bỏ,
     nên outline dạng chặng không tới được kế hoạch từng chương. Nay: mọi dòng dưới tiêu đề chặng là nội dung chặng; chia đều cho các chương trong chặng,
     mỗi chương nhận nguyên nội dung kèm nhãn "phần k/n" để chỉ làm bước k, không dồn cả chặng vào một chương. */
  let range = null; const ranges = [];
  const closeRange = () => { if (range && range.body.length) ranges.push(range); range = null; };
  outlineNormalizeText(content).split(/\n+/).forEach(l => {
    const line = l.trim();
    const rm = line.match(/^(?:[-*•]\s*)?(?:ch(?:ư[ơ]ng)?\.?\s*)(\d{1,4})\s*[–—-]\s*(\d{1,4})\s*(?:[:.)]\s*)?(.*)$/i);
    if (rm && Number(rm[2]) > Number(rm[1]) && Number(rm[2]) - Number(rm[1]) <= 30) {
      closeRange(); cur = 0;
      range = { a: Number(rm[1]), b: Number(rm[2]), body: [] };
      if (rm[3] && rm[3].trim()) range.body.push(rm[3].trim());
      return;
    }
    const m = line.match(/^(?:[-*•]\s*)?(?:ch(?:ư[ơ]ng)?\.?\s*)?(\d{1,4})\s*[:.)\-–—]\s*(.+)$/i);
    if (m && m[2] && m[2].trim().length >= 8) { closeRange(); cur = Number(m[1]); map[cur] = m[2].trim(); return; }
    if (range) { if (line) range.body.push(line.replace(/^[•\-*–·▪◦●]\s*/, "")); return; }
    /* V14.4.1: dòng gạch đầu dòng (•, -, *, –, ·) nằm dưới tiêu đề chương là PHẦN CỦA chương đó. */
    if (cur && /^[•\-*–·▪◦●]\s*\S/.test(line)) {
      const piece = line.replace(/^[•\-*–·▪◦●]\s*/, "").trim();
      map[cur] += (/[.!?…;:]$/.test(map[cur]) ? " " : "; ") + piece;
    }
  });
  closeRange();
  ranges.forEach(r => {
    const n = r.b - r.a + 1, text = r.body.join(" ").replace(/\s+/g, " ").trim();
    for (let k = r.a; k <= r.b; k++) {
      if (map[k]) continue; // dòng chương riêng lẻ luôn thắng khối chặng
      map[k] = "[Chặng " + r.a + "–" + r.b + ", chương này là phần " + (k - r.a + 1) + "/" + n + " — chỉ thực hiện bước thứ " + (k - r.a + 1) + " của chặng, các phần còn lại để dành cho chương sau; mỗi chương nên đổi địa điểm/tình huống/mức độ] " + text;
    }
  });
  return _outlineRemapLocal(map, ol);
}
function arcProgressPrompt(st, nOverride) {
  const chapters = (st && Array.isArray(st.chapters)) ? st.chapters : [];
  const n = Number(nOverride) > 0 ? Number(nOverride) : chapters.length + 1;
  const arc = activeArcOf(st), lines = [];
  const cut = (v, k) => { v = String(v || "").replace(/\s+/g, " ").trim(); return v.length > k ? v.slice(0, k) + "…" : v; };
  if (arc) {
    const start = Number(arc.startChapter) || n, end = Number(arc.endChapterPlanned) || 0;
    lines.push("TIẾN ĐỘ ARC — ARC \"" + arc.name + "\": " + cut(arc.goal, 500));
    if (end && end >= start) {
      const total = end - start + 1, idx = Math.max(1, n - start + 1), left = end - n;
      if (left < 0) lines.push("- Arc đã QUÁ chương kết dự kiến (" + end + "). Chương này PHẢI đưa Arc tới điểm kết/giải quyết hoặc chuyển hẳn sang bước thu Arc; không kéo thêm.");
      else {
        lines.push("- Đây là chương " + idx + "/" + total + " của Arc (đã đi khoảng " + Math.round(((idx - 1) / total) * 100) + "%, còn " + left + " chương sau chương này).");
        lines.push(left === 0 ? "- ĐÂY LÀ CHƯƠNG CUỐI DỰ KIẾN của Arc: phải đạt mục tiêu Arc hoặc có kết cục rõ ràng." : (idx / total >= 0.5 ? "- Arc đã qua nửa chặng: các việc chưa giải quyết phải được đẩy mạnh về phía mục tiêu, không lặp lại bước đã làm." : "- Mỗi chương phải đưa Arc tiến thêm một bước cụ thể về phía mục tiêu."));
      }
    } else lines.push("- Arc chưa có chương kết dự kiến: mỗi chương vẫn phải đưa Arc tiến thêm một bước cụ thể (không đứng yên ở bước vừa làm).");
  }
  const ol = outlineOf(st, n);
  if (ol) {
    const per = outlineChapterLines(ol.content, ol), total = ol.to - ol.from + 1, idx = n - ol.from + 1;
    lines.push("OUTLINE \"" + ol.name + "\" (chương " + ol.from + "–" + ol.to + "), chương này là " + idx + "/" + total + ":");
    if (per[n]) {
      lines.push("- VIỆC BẮT BUỘC CỦA CHƯƠNG " + n + " THEO OUTLINE: " + cut(per[n], 900));
      if (per[n + 1]) lines.push("- (Chương " + (n + 1) + " sẽ làm, CHƯA làm ở chương này; chỉ cài móc nối): " + cut(per[n + 1], 300));
    } else lines.push(cut(ol.content, 1500));
    if (ol.to - n <= 1) lines.push("- Giai đoạn Outline sắp kết: chương này phải tiến tới mốc kết giai đoạn.");
  }
  return lines.join("\n");
}

// --- V14.4.0: KIỂM TRA OUTLINE TRƯỚC KHI VIẾT ---
// Mỗi chi tiết ép buộc trong Outline thành một beat [R] cần "bằng chứng" trong văn bản; Outline quá dài còn bị cắt khi đưa vào hợp đồng chương.
// Hàm thuần cấu trúc (không đánh giá nội dung): đo độ dài, số mục nhỏ, câu thoại bắt buộc, ràng buộc số lần/thứ tự, chuỗi bước nối tiếp.
function lintChapterOutline(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  const out = { level: 'ok', chars: t.length, findings: [] };
  if (!t) return out;
  const add = (sev, code, short, msg) => out.findings.push({ sev, code, short, msg });
  if (t.length > 1100) add('high', 'LENGTH', 'dài ' + t.length + ' ký tự', 'Outline dài ' + t.length + ' ký tự: phần cuối có thể bị cắt khi đưa vào hợp đồng chương nên không được kiểm tra. Nên gọn còn khoảng 500–700 ký tự.');
  else if (t.length > 700) add('warn', 'LENGTH', 'dài ' + t.length + ' ký tự', 'Outline dài ' + t.length + ' ký tự (khuyến nghị 500–700). Càng dài càng nhiều chi tiết bị coi là bắt buộc.');
  const labels = (t.match(/(?:^|[\s.;])(?:Sự kiện|Cảnh nóng|Cảnh chính|Cảnh|Kháng cự|Hậu quả|Móc kết|Mục tiêu|Bối cảnh|Kết quả|Lưu ý|Yêu cầu|Phản ứng|Kết)\s*:/gu) || []).length;
  if (labels >= 6) add('high', 'SECTIONS', labels + ' mục nhỏ', 'Outline chia ' + labels + ' mục nhỏ (Sự kiện/Hậu quả/Móc kết…). Mỗi mục là một beat riêng cần bằng chứng; thiếu một mục là bị báo lỗi nặng. Gộp còn 3–5 ý chính.');
  else if (labels >= 4) add('warn', 'SECTIONS', labels + ' mục nhỏ', 'Outline có ' + labels + ' mục nhỏ; mỗi mục là một beat cần bằng chứng. Cân nhắc gộp bớt.');
  const quotes = (t.match(/[“"«][^”"»]{10,}[”"»]/gu) || []).length;
  if (quotes >= 3) add('high', 'QUOTES', quotes + ' câu thoại bắt buộc', quotes + ' câu thoại/chuỗi chữ cụ thể bị buộc phải xuất hiện đúng nguyên văn. Chỉ giữ câu thật sự then chốt, còn lại mô tả ý.');
  else if (quotes >= 2) add('warn', 'QUOTES', quotes + ' câu thoại bắt buộc', quotes + ' câu thoại cụ thể bị buộc phải xuất hiện; nên giữ 1 câu then chốt.');
  const forced = (t.match(/(?<![\p{L}])(?:liên tục|từng câu|từng chút một|lần\s*\d|lần thứ|\d+\s*lần|một lần|hai lần|ba lần|bốn lần|vài vòng|nhiều lần|đúng\s+\d+|lặp lại)(?![\p{L}])/giu) || []).length;
  if (forced >= 5) add('high', 'FORCED', forced + ' ràng buộc số lần/thứ tự', 'Có ' + forced + ' ràng buộc về số lần hoặc thứ tự (liên tục, lần 1/lần 2, từng câu…). Model hay làm thiếu một chỗ và AI duyệt báo lỗi nặng. Chỉ ghi kết quả cần đạt, để AI tự quyết số lần.');
  else if (forced >= 3) add('warn', 'FORCED', forced + ' ràng buộc số lần/thứ tự', 'Có ' + forced + ' ràng buộc về số lần hoặc thứ tự; hãy giữ những cái thật sự bắt buộc.');
  const seq = (t.match(/(?<![\p{L}])(?:sau đó|rồi|tiếp theo|tiếp đến|sau khi|xong|cuối cùng|kế đó|trong khi|đồng thời)(?![\p{L}])/giu) || []).length;
  if (seq >= 7) add('high', 'SEQ', seq + ' bước nối tiếp', 'Outline là chuỗi ' + seq + ' bước nối tiếp (sau đó, rồi, xong…). Nên viết thành 1–2 sự kiện chính kèm kết quả, không liệt kê từng thao tác.');
  else if (seq >= 4) add('warn', 'SEQ', seq + ' bước nối tiếp', 'Outline có ' + seq + ' bước nối tiếp; nên gom thành ít sự kiện hơn.');
  const steps = t.split(/(?<=[.!?;])\s+|\s+\+\s+|\s*→\s*/u).filter(x => x.trim().length >= 6).length;
  if (steps >= 14) add('high', 'STEPS', steps + ' ý', 'Outline có ' + steps + ' ý/câu; chương chỉ nên 1–2 sự kiện chính (3–6 beat).');
  else if (steps >= 9) add('warn', 'STEPS', steps + ' ý', 'Outline có ' + steps + ' ý/câu; khuyến nghị 3–6 beat.');
  const highs = out.findings.filter(f => f.sev === 'high').length, warns = out.findings.length - highs;
  out.level = (highs || warns >= 3) ? 'high' : (warns >= 1 ? 'warn' : 'ok');
  return out;
}
function outlineLintShort(rep) { return ((rep && rep.findings) || []).map(f => f.short).join(' · '); }
function formatOutlineLint(rep, chapterNumber) {
  if (!rep || !rep.findings || !rep.findings.length) return '';
  const head = 'Outline chương ' + (chapterNumber || '?') + ' ' + (rep.level === 'high' ? 'có vẻ QUÁ CHI TIẾT / quá dài' : 'hơi nhiều ràng buộc') + ' — dễ bị báo thiếu beat, lặp cảnh hoặc Hard failure khi duyệt:';
  return head + '\n' + rep.findings.map(f => '• ' + f.msg).join('\n') + '\n\nGợi ý: mỗi chương 1–2 sự kiện chính, 3–6 beat, mỗi beat một ý; chỉ ghi số lần/thứ tự/câu thoại khi thật sự bắt buộc; chi tiết phụ để AI tự bổ sung.';
}
// Trạng thái Outline cho giao diện: còn bao nhiêu chương có Outline phủ.
function outlineCoverageLeft(st) {
  const n = ((st && st.chapters) || []).length + 1;
  const tos = ((st && st.outlinePlans) || []).map(o => Number(o.to) || 0);
  if (!tos.length) return null;
  return Math.max(...tos) - n + 1;
}

// --- V12.32.9: CHUYỂN CẢNH + NGƯỜI CÓ MẶT (chống nhân vật "tự xuất hiện" hoặc biến mất vô cớ) ---
function scenePresencePrompt() {
  return [
    "CẢNH & NGƯỜI CÓ MẶT — BẮT BUỘC:",
    "- Mỗi cảnh có một địa điểm và một danh sách người có mặt rõ ràng. Nhân vật chỉ được nói/hành động khi đang ở trong cảnh.",
    "- Người MỚI vào cảnh phải có câu cho thấy họ đến (gõ cửa, bước vào, gọi điện/nhắn tin, xuất hiện ở cửa…) và vì sao họ biết/đến đúng lúc đó. Người RỜI cảnh phải có câu cho thấy họ đi (ra ngoài, cúp máy, bị đưa đi…). Không để ai tự xuất hiện hay biến mất giữa chừng.",
    "- Người đã rời đi thì KHÔNG còn nói, nghe hay phản ứng trong cảnh đó cho tới khi có câu cho họ quay lại.",
    "- Chuyển sang địa điểm/thời điểm khác: dùng một câu chuyển cảnh tự nhiên trong mạch kể (di chuyển, thời gian trôi) hoặc dòng ngăn cảnh, và cho thấy ai có mặt ở cảnh mới. Không lẫn lời thoại/hành động của cảnh cũ vào cảnh mới.",
    "- MỌI lần đổi địa điểm hoặc nhảy thời gian phải có 1–2 câu cầu nối nêu: rời nơi cũ bằng cách nào, đến nơi mới (đi/lái xe/đến nơi), và thời điểm mới. Không mở cảnh bằng việc nhân vật đã ở sẵn chỗ mới; không để nhân vật chính thấy người khác 'đã ngồi sẵn' mà không có câu hắn đến và nhìn thấy.",
    "- Cảnh có ≥3 người: mỗi lượt lời thoại phải rõ ai nói; không để người không có mặt (hoặc đã đi) nói chen vào."
  ].join("\n");
}
// --- V12.32.7: THỜI GIAN TRUYỆN (chống "10 chương vẫn là một ngày") ---
const TIME_PACE_TEXT = {
  scene: "mỗi chương nằm trong khoảng vài giờ đến hết một ngày",
  day: "mỗi chương cách chương trước khoảng MỘT NGÀY (có thể nhảy sang ngày kế tiếp)",
  fewdays: "mỗi chương cách chương trước khoảng VÀI NGÀY",
  week: "mỗi chương cách chương trước khoảng MỘT TUẦN trở lên"
};
// Mốc thời gian hiện tại: ô Story Clock (nhập tay) ưu tiên, nếu trống dùng mốc Status tự trích từ chương.
function currentTimeMark(st) {
  const manual = String((st && st.storyClock) || "").trim();
  if (manual) return manual;
  const ss = (st && st.statusState && typeof st.statusState === "object") ? st.statusState : {};
  return String((ss.currentState && ss.currentState.time) || "").trim();
}
// Phát hiện nhiều chương liền không đổi mốc thời gian (so mốc chuẩn hóa trong statusState.timeLog).
function timeStallInfo(st) {
  const ss = (st && st.statusState && typeof st.statusState === "object") ? st.statusState : {};
  const log = Array.isArray(ss.timeLog) ? ss.timeLog.filter(x => x && x.time) : [];
  if (log.length < 3) return null;
  const norm = t => String(t).toLowerCase().replace(/[^\p{L}\p{N} ]/gu, " ").replace(/\s+/g, " ").trim();
  const last = norm(log[log.length - 1].time);
  let run = 1;
  for (let i = log.length - 2; i >= 0 && norm(log[i].time) === last; i--) run++;
  const span = Math.max(1, (Number(log[log.length - 1].chapter) || 0) - (Number(log[log.length - run].chapter) || 0) + 1);
  return run >= 3 ? { run, span, time: log[log.length - 1].time } : null;
}
function timePrompt(st) {
  const sc = normalizeStoryControl(st);
  const mark = currentTimeMark(st), stall = timeStallInfo(st);
  return [
    "THỜI GIAN TRUYỆN — CHẢY THEO MẠCH KỂ, NHƯ VĂN XUÔI THUẦN TÚY:",
    mark ? "- Dòng thời gian hiện tại (chỉ để bạn giữ nhất quán; KHÔNG cần nhắc lại trong văn): " + mark + "." : "",
    "- Thời gian là một phần của câu chuyện, không phải nhãn. KHÔNG mở chương bằng dòng/câu báo ngày giờ kiểu tiêu đề (\"Chiều thứ Sáu, ...\", \"Ngày 3, 9 giờ sáng\"), KHÔNG kết chương bằng câu tổng kết thời điểm, không ghi \"Thời gian:\". Chỉ nêu giờ/ngày cụ thể khi nhân vật thực sự nhìn đồng hồ/lịch/điện thoại hoặc tình tiết cần (hạn chót, hẹn giờ, khẩn cấp).",
    "- Chương có thể mở thẳng bằng hành động, cảnh hoặc lời thoại (tiếp nối đoạn kết chương trước). Để người đọc tự nhận ra thời điểm qua chi tiết trong cảnh: ánh sáng, thời tiết, bữa ăn, tiếng phố, độ mệt, việc nhân vật đang làm. Chương không nêu giờ giấc rõ ràng vẫn hoàn toàn đúng.",
    "- Khi thời gian TRÔI hoặc NHẢY (qua đêm, vài ngày, vài tuần), thể hiện bằng một mệnh đề/câu nằm ngay trong mạch kể (\"Mãi tới sáng hôm sau, ...\", \"Ba hôm sau, khi vết bầm đã nhạt, ...\") hoặc qua hệ quả quan sát được; không dùng khối thông báo riêng. Nếu sự kiện chương trước ĐÃ KẾT THÚC TRỌN (không còn cảnh đang dở), chương mới ĐƯỢC PHÉP nhảy thời gian theo cách đó; việc dang dở thì phải tiếp nối đúng thời điểm đó.",
    "- Nội bộ phải nhất quán: thời gian chỉ trôi về phía trước; nhân vật ăn/ngủ/đi lại/hồi phục/thay đổi hợp với khoảng thời gian đã trôi; quan hệ, vết thương, kế hoạch, công việc tiến triển theo thời gian, không dồn nhiều chương liên tiếp vào cùng một buổi/một ngày nếu không có lý do cốt truyện.",
    sc.timePace ? "- NHỊP THỜI GIAN do tác giả chọn: " + TIME_PACE_TEXT[sc.timePace] + "." : "",
    stall ? "- CẢNH BÁO: " + stall.run + " chương liên tiếp (khoảng " + stall.span + " chương gần nhất) vẫn cùng một mốc \"" + String(stall.time).slice(0, 80) + "\". Chương này PHẢI cho thời gian trôi tiếp: khép việc đang dở rồi để thời gian chảy qua đêm/sang hôm sau/vài ngày bằng một câu chuyển tự nhiên trong mạch kể, không tiếp tục cùng một ngày." : ""
  ].filter(Boolean).join("\n");
}

function storyControlPrompt(st) {
  const sc = normalizeStoryControl(st);
  return [
    "STORY CONTROL LAYER — BẮT BUỘC:",
    `- Ngân sách sự kiện: tối đa ${sc.maxMainEvents} sự kiện trục chính. Được phép có biến cố lớn LỒNG BÊN TRONG một sự kiện khi nó là nguyên nhân, bước ngoặt, phản ứng hoặc hậu quả trực tiếp của sự kiện đó và thật sự cần cho mạch truyện; không tính thành sự kiện chính thứ ${sc.maxMainEvents + 1}. Không tự thêm biến cố lồng nếu chương đã đủ lực.`,
    `- Nhân vật có tên xuất hiện trực tiếp: tối đa ${sc.maxNamedCharacters}; ưu tiên nhân vật đã tồn tại.`,
    `- Thread mới: tối đa ${sc.maxNewThreads}; không mở tuyến mới chỉ để kéo dài chương.`,
    "- Continuity: nguyên nhân → hành động → phản ứng → hậu quả phải nhất quán với trạng thái hiện tại.",
    sc.noRetcon ? "- NO RETCON: không tự sửa lịch sử, canon hoặc ký ức đã xác nhận. Nếu phát hiện mâu thuẫn, giữ nguyên dữ liệu cũ và đánh dấu xung đột để xử lý sau." : "",
    `- STATE LOCK: không tự ý thay đổi các trường canon/quan trọng (${sc.lockedFields.join(", ")}). Muốn thay đổi phải có sự kiện trong truyện làm bằng chứng và cập nhật trạng thái sau chương.`,
    sc.agencyRequired ? "- CHARACTER AGENCY: nhân vật quan trọng phải có mục tiêu, động cơ, phản ứng và lựa chọn riêng; không biến nhân vật thành công cụ của plot." : "",
    "- NHÂN VẬT PHỤ CÓ ĐỜI RIÊNG: nhân vật phụ có tên không chỉ phản ứng với nhân vật chính; họ có việc riêng, mong muốn riêng, tự quyết định và hành động chủ động (kể cả khi nhân vật chính không có mặt). Ngôi 3 giới hạn nghĩa là mỗi cảnh/đoạn bám sát MỘT nhân vật (thường là nhân vật chính, nhưng cảnh khác có thể bám nhân vật phụ), không nhảy vào đầu nhiều người trong cùng một đoạn.",
    "- Không tự tạo nhân vật quan trọng mới nếu nhân vật hiện có có thể đảm nhiệm vai trò đó.",
    "- Không tạo năng lực, quy tắc thế giới hoặc vật phẩm quan trọng mới chỉ để giải quyết vấn đề tức thời.",
    "- Chapter Focus chỉ kiểm soát phạm vi chủ đề trưởng thành; không được dùng nó để mở rộng cốt truyện ngoài brief.",
    "- Nếu Directive/Story Bible/Current Status xung đột, không âm thầm sửa canon; ưu tiên dữ liệu canon và ghi nhận xung đột khi cần.",
    "- ĐƯỢC TỰ DO: thêm cảnh phụ, chuyển cảnh, hội thoại, nội tâm, giác quan, hành động nhỏ và cả biến cố lồng khi chúng phục vụ trực tiếp một trong các sự kiện trục. Biến cố lồng phải có quan hệ nhân-quả rõ, không mở arc độc lập, không thêm nhân vật quan trọng mới và không phải chương nào cũng cần. Quyền tự do này KHÔNG áp dụng cho địa vị, nghề, quyền hạn, tài sản, năng lực, tuổi, kiến thức và cách nói của nhân vật — các điều đó phải đúng HỒ SƠ.",
    "- TIẾN TRIỂN: chiều sâu KHÔNG có nghĩa là đứng yên — cuối chương phải có ít nhất một thay đổi thật (quan hệ, thông tin, quyền lực, mục tiêu hoặc hậu quả); không lặp cùng hành động/miêu tả để kéo dài.",
    "- Mục tiêu là chiều sâu và tính liên tục, không phải nhồi thêm biến cố lớn.",
    scenePresencePrompt(),
    timePrompt(st)
  ].filter(Boolean).join("\n");
}

// --- Kiểm tra cứng xác định (không gọi AI). Hai ngân sách sự kiện/nhân vật do Auditor đếm, evaluateReview áp ngưỡng. ---
function gateHardChecks(chapter) {
  const text = String((chapter && chapter.text) || "");
  const warns = (chapter && chapter.continuityWarnings) || [];
  // V14.5.9: Quality Gate KHÔNG chấm số từ — độ dài do bước viết/bù từ lo; Gate chỉ chặn bản rỗng.
  return [
    { id: "language", ok: !detectNonVietnamese(text), message: "Ngôn ngữ: tiếng Việt" },
    { id: "text_nonempty", ok: text.trim().length > 0, message: "Bản thảo có nội dung" },
    { id: "duplicate", ok: !warns.some(x => x && (x.severity === "high" || x.severity === "critical")), message: "Không có lỗi continuity mức cao đã phát hiện" }
  ];
}
// Tên nhân vật đã biết (hồ sơ NV chính + danh sách NV) — dùng để đếm tự động bằng chứng cho Auditor.
function gateKnownNames(st) {
  const out = [], seen = new Set();
  const add = n => { n = String(n || "").trim(); if (n.length >= 2 && !seen.has(n)) { seen.add(n); out.push(n); } };
  add(st && st.mainCharProfile && st.mainCharProfile.name);
  ((st && st.characters) || []).forEach(c => add(c && c.name));
  return out;
}
// Những tên đã biết thật sự xuất hiện trong văn bản (khớp nguyên từ, phân biệt hoa/thường để tránh nhầm từ thường như "lan", "hoa").
function knownNameMentions(text, names) {
  const t = String(text || ""), found = [];
  (names || []).forEach(n => {
    const esc = String(n).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (new RegExp("(^|[^\\p{L}\\p{N}])" + esc + "(?![\\p{L}\\p{N}])", "u").test(t)) found.push(n);
  });
  return found;
}

// --- Prompt Auditor: phần khung/quy tắc/schema dùng chung; ngữ cảnh do client/worker tự truyền vào ---
const GATE_REVIEW_SCHEMA = '{"score":0,"verdict":"PASS|SOFT_FAIL|HARD_FAIL","dimensions":{"continuity":0,"characterConsistency":0,"canonConsistency":0,"plotDiscipline":0,"worldRules":0,"outlineCompliance":0,"style":0,"pacing":0,"knowledgeConsistency":0},"mainEventCount":0,"namedCharacterCount":0,"unauthorizedImportantCharacter":false,"knowledgeViolation":false,"retcon":false,"profileViolation":false,"profileViolations":[],"genderAnatomyMismatch":false,"genderAnatomyNotes":[],"stagnation":false,"stagnationNotes":[],"timeStagnation":false,"timeNotes":[],"sceneViolation":false,"sceneNotes":[],"arcStall":false,"arcNotes":[],"appearanceVague":false,"appearanceNotes":[],"outlineDeviation":false,"listLikeProse":false,"listLikeNotes":[],"weakHook":false,"hookNotes":[],"hardFailures":[],"warnings":[],"suggestions":[],"rewriteInstructions":[]}';
// p: { storyControl, contract, contractLabel, context, warnings, draft, hardChecks, knownNames, maxMainEvents, maxNamedCharacters }
/* V12.32.3: tiết kiệm token cho Review/Rewrite. Trước đây cắt cứng đầu 18000/15000 ký tự -> vừa tốn vừa dễ mất
   Current Status (nằm cuối ngữ cảnh). Nay: bỏ các khối không liên quan tới việc chấm/sửa (văn phong, mức miêu tả,
   độ khó, từ cấm...), rồi nếu vẫn dài thì giữ đầu 40% + cuối 60% (có Current Status/Threads). */
const GATE_CTX_DROP_ALWAYS = /^(MỨC MIÊU TẢ|MỨC 18\+|VĂN PHONG|ĐỘ KHÓ|TỪ MUỐN DÙNG|TỪ CẦN TRÁNH|CỤM ĐÃ LẶP|CÁCH GỌI BỘ PHẬN)/;
const GATE_CTX_DROP_REVIEW = /^(STYLE:|CẤM TỪ)/;
function compactGateContext(ctx, maxChars, forReview) {
  const blocks = String(ctx || "").split(/\n\n+/).filter(b => b && !GATE_CTX_DROP_ALWAYS.test(b.trim()) && !(forReview && GATE_CTX_DROP_REVIEW.test(b.trim())));
  const s = blocks.join("\n\n");
  if (s.length <= maxChars) return s;
  return s.slice(0, Math.floor(maxChars * 0.4)) + "\n[...]\n" + s.slice(-Math.floor(maxChars * 0.6));
}
function buildQualityReviewPrompt(p) {
  const evN = Number(p.maxMainEvents) || 3, chN = Number(p.maxNamedCharacters) || 6;
  const known = (p.knownNames || []);
  return [
    "Bạn là QUALITY AUDITOR cho tiểu thuyết dài kỳ.",
    "Mục tiêu: kiểm tra bản thảo so với Chapter Contract, Story Bible và continuity. KHÔNG viết lại chương.",
    "Trả DUY NHẤT JSON object theo schema cuối.",
    "STORY CONTROL:", p.storyControl || "",
    p.characterLock || "",
    (p.contractLabel || "CHAPTER CONTRACT / OUTLINE") + ":", p.contract || "(không có)",
    p.arcProgress ? ("TIẾN ĐỘ ARC / OUTLINE (chương này phải thực hiện):\n" + p.arcProgress) : "",
    "BỐI CẢNH/CANON TÓM LƯỢC:", compactGateContext(p.context, 9000, true),
    "BEAT LEDGER AUDIT — ưu tiên mã [R1], [R2]... là BEAT BẮT BUỘC; chỉ đánh hard failure khi [R] thiếu bằng chứng cụ thể trong bản thảo (hành động/lời thoại/thông tin/hậu quả). Mã [S1], [S2]... là beat hỗ trợ do AI đề xuất, không được tự biến thành hard failure và có thể bỏ nếu gây gượng ép. Với kế hoạch cũ dùng [B1], chỉ coi là bắt buộc nếu chính dòng đó ghi rõ REQUIRED/BẮT BUỘC hoặc xuất phát trực tiếp từ brief/Outline; không coi mọi ý AI tự thêm là canon. Nếu [R] thiếu, ghi rõ mã, nguồn bắt buộc và vị trí hợp lý để chèn trước đoạn kết. Nếu đã có, trích dẫn bằng chứng ngắn để tránh sửa nhầm.",
    "CONTINUITY WARNINGS ĐÃ PHÁT HIỆN:", JSON.stringify(p.warnings || []).slice(0, 6000),
    p.prevEnding ? ("ĐOẠN KẾT CHƯƠNG TRƯỚC (để đối chiếu địa điểm/thời điểm/người có mặt ở cảnh mở đầu):\n" + String(p.prevEnding).slice(-1500)) : "",
    "BẢN THẢO CHƯƠNG:", String(p.draft || "").slice(0, 50000),
    "KIỂM TRA CỨNG ĐÃ CÓ:", JSON.stringify(p.hardChecks || []),
    known.length ? "TÊN NHÂN VẬT ĐÃ BIẾT XUẤT HIỆN TRONG VĂN BẢN (đếm tự động, chỉ để tham khảo khi đếm namedCharacterCount): " + known.join(", ") : "",
    "QUY TẮC:",
    "- mainEventCount phải là số sự kiện chính thực sự (tối đa " + evN + "), không đếm scene beat/hành động nhỏ.",
    "- namedCharacterCount chỉ đếm nhân vật có tên riêng xuất hiện trực tiếp; tối đa " + chN + ".",
    "- unauthorizedImportantCharacter=true nếu xuất hiện nhân vật mới quan trọng mà outline/brief không cho phép.",
    "- knowledgeViolation=true nếu nhân vật biết điều họ chưa thể biết.",
    "- retcon=true nếu mâu thuẫn canon đã xác nhận.",
    "- stagnation=true CHỈ KHI cuối chương hầu như không có thay đổi nào so với đầu chương (quan hệ/thông tin/quyền lực/mục tiêu/hậu quả) HOẶC một cảnh lặp lại cùng hành động/miêu tả nhiều lần chỉ để kéo dài. Ghi 1–2 ví dụ ngắn vào stagnationNotes. Cảnh trưởng thành đủ dài nhưng có đổi quan hệ/quyền lực/hậu quả thì KHÔNG phải stagnation.",
    p.arcProgress ? "- arcStall=true CHỈ KHI chương hoàn toàn không thực hiện việc bắt buộc/bước tiến nêu trong TIẾN ĐỘ ARC/OUTLINE (không có sự kiện nào đưa Arc hay giai đoạn Outline tới gần mục tiêu hơn so với đầu chương; chỉ tả thêm/lặp lại không tính). Ghi 1 dẫn chứng ngắn vào arcNotes. Nếu chương đã làm được việc bắt buộc của Outline hoặc có một bước tiến thật của Arc thì KHÔNG báo." : "",
    "- sceneViolation=true CHỈ KHI có CÂU CỤ THỂ trong bản thảo cho nhân vật nói/hành động/phản ứng khi họ KHÔNG có mặt trong cảnh (chưa được nói là đến, hoặc đã rời đi mà không quay lại), hoặc lời thoại/hành động của cảnh cũ lẫn sang cảnh mới không có chuyển cảnh. Ghi trích dẫn ngắn + tên nhân vật vào sceneNotes. Không báo nếu chỉ là nhân vật ở gần/đang nghe được hợp lý. THIẾU câu chuyển cảnh/nhảy địa điểm hay thời gian mà KHÔNG có nhân vật nào nói/làm khi vắng mặt thì KHÔNG phải sceneViolation: ghi vào warnings, không ghi vào hardFailures; và không ghi cùng một lỗi vừa vào hardFailures vừa bật sceneViolation.",
    "- timeStagnation=true CHỈ KHI có BẰNG CHỨNG CỤ THỂ thời gian trong truyện sai hoặc đứng yên: (a) thời gian đi lùi/mâu thuẫn (vừa tối đã lại là buổi sáng cùng ngày không lý do; vết thương, hạn chót, tuổi, ngày tháng không khớp), hoặc (b) chương mở lại đúng thời điểm chương trước dù sự kiện trước đã kết thúc trọn và không có lý do cốt truyện. Ghi 1 dẫn chứng ngắn vào timeNotes. TUYỆT ĐỐI KHÔNG báo chỉ vì chương không ghi ngày/giờ/mốc rõ ràng ở đầu hay cuối chương: văn xuôi tự nhiên để thời gian ngầm hiểu qua chi tiết, thiếu nhãn thời gian KHÔNG phải lỗi. Đây chỉ là CẢNH BÁO mềm, không chặn.",
    "- appearanceVague=true CHỈ KHI có nhân vật có tên xuất hiện lần đầu hoặc cảnh tả cơ thể mà chỉ dùng tính từ trống (đẹp, to, đầy đặn…) không kèm kích thước/hình dáng/so sánh cụ thể nào để hình dung. Ghi tên nhân vật vào appearanceNotes. Chỉ là CẢNH BÁO mềm.",
    p.characterLock ? "- profileViolation=true CHỈ KHI có câu/đoạn CỤ THỂ trong bản thảo trái rõ ràng với HỒ SƠ KHÓA (nhân vật nói hoặc hành xử như có địa vị/quyền/tài sản/năng lực/kiến thức cao hơn hồ sơ; xưng hô hoặc giọng nói sai thiết lập; đổi nghề). Ghi trích dẫn ngắn + mục hồ sơ bị vi phạm vào profileViolations; không báo nếu chỉ suy đoán hoặc thiếu thông tin." : "",
    p.characterLock ? "- genderAnatomyMismatch=true nếu bản thảo gán cho một nhân vật bộ phận, đặc điểm hoặc phản ứng sinh học không phù hợp giới tính ghi trong HỒ SƠ KHÓA. Ghi đúng tên nhân vật, trích dẫn ngắn và giới tính hồ sơ vào genderAnatomyNotes. Đây là HARD FAILURE, không được chấm PASS." : "",
    p.prevEnding ? "- ĐỊA ĐIỂM MỞ CHƯƠNG: nếu cảnh mở đầu của bản thảo KHÁC địa điểm/thời điểm/người có mặt so với ĐOẠN KẾT CHƯƠNG TRƯỚC mà không có đoạn chuyển cảnh hợp lý (ví dụ chương trước kết ở biệt thự của A nhưng chương này mở ở phòng trọ của B), phải ghi vào hardFailures (nêu rõ kết ở đâu, mở ở đâu) và đặt continuity thấp." : "",
    "- outlineDeviation=true nếu bỏ mốc bắt buộc hoặc mở tuyến lớn ngoài contract.",
    "- HƯỚNG SỬA (rewriteInstructions, suggestions) PHẢI bám Chapter Contract/Outline: KHÔNG đề xuất xoá, thay hoặc làm nhẹ beat/sự kiện/lời thoại bắt buộc [R] của Outline; KHÔNG đề xuất thêm cảnh phụ, tuyến mới hoặc nội dung ngoài Outline (vd 'thay bằng cảnh phụ đời thường'). Nếu có đoạn lặp: giữ MỘT bản đầy đủ nhất và bổ sung phần Outline còn thiếu bằng nội dung đúng beat đó. Mỗi hướng sửa ghi rõ phục vụ [R#] nào hoặc 'văn phong/chuyển cảnh'. Không chắc thì đề xuất sửa cách viết, không đổi nội dung.",
    /* V14.2: chấm theo phong cách "chậm – sâu – ít sự kiện" (1–2 việc chính/chương, một cảnh trọng tâm). */
    "- CÁCH ĐẾM SỰ KIỆN: phần dẫn dắt + cảnh nóng/cảnh cao trào chính + hậu quả trực tiếp của nó là MỘT sự kiện chính, không tách thành nhiều. Chương chỉ có 1–2 sự kiện nhưng viết chậm, dày, có một bước tiến rõ về quyền lực hoặc tu luyện (cảnh giới, công pháp, thực lực) hay tâm lý là ĐÚNG phong cách mong muốn — KHÔNG trừ điểm pacing, KHÔNG báo arcStall/stagnation chỉ vì ít sự kiện hay một cảnh dài. Chương nhồi nhiều sự kiện/địa điểm/nhiều cảnh nóng mới là lỗi nhịp.",
    "- listLikeProse=true CHỈ KHI một đoạn dài (từ ~6 câu) chủ yếu là chuỗi hành động nối nhau kiểu 'rồi… rồi… tiếp theo…' mà thiếu phản ứng cảm xúc, cảm giác cơ thể, nội tâm hoặc thế quyền lực đổi qua từng bước; hoặc cảnh nóng chỉ liệt kê tư thế/hành động. Ghi 1–2 trích dẫn ngắn vào listLikeNotes. Chỉ là CẢNH BÁO mềm, không đưa vào hardFailures.",
    "- weakHook=true nếu câu/đoạn cuối chương KHÔNG để lại móc nào: lệnh mới chưa thực hiện, nghi ngờ/nguy cơ bị phát hiện, ham muốn chưa được thỏa, hoặc nhân vật bắt đầu có ý nghĩ nguy hiểm/phụ thuộc hơn. Ghi 1 dẫn chứng ngắn vào hookNotes. Chỉ là CẢNH BÁO mềm.",
    "- LẶP: nếu cách hành hạ/tư thế/lời thoại/phản ứng giống hệt chương trước (theo bối cảnh/đoạn kết chương trước), ghi vào warnings và hạ điểm style; không đưa vào hardFailures trừ khi lặp nguyên cảnh.",
    "- hardFailures phải chứa mọi lỗi chặn Sync. Nếu có hard failure thì verdict phải HARD_FAIL dù score cao.",
    "SCHEMA: " + GATE_REVIEW_SCHEMA
  ].filter(x => x !== "").join("\n\n");
}
// p: { chapterNumber, storyControl, contract, contractLabel, context, review, draft }
function buildRewritePrompt(p) {
  const review = p.review || {};
  const stagnationFix = review.stagnation ? [
    "SỬA STAGNATION BẮT BUỘC:",
    "- Không lặp lại ý niệm/ẩn dụ 'vách ngăn vô hình', cô độc hoặc khinh miệt xã hội nếu không có thông tin mới.",
    "- Giữ nguyên phần đúng nhưng phải tạo ít nhất MỘT thay đổi cụ thể và không thể coi như chưa xảy ra: mục tiêu đổi, thông tin mới được xác nhận, quan hệ/quyền lực thay đổi, quyết định có hậu quả, hoặc hành động mở ra bước tiếp theo.",
    "- Thay đổi phải xuất hiện trong hành động/thoại/hậu quả ở cuối chương, không chỉ được tuyên bố trong nội tâm."
  ].join("\n") : "";
  return [
    "SỬA LẠI BẢN THẢO CHƯƠNG " + p.chapterNumber + " THEO QUALITY REVIEW.",
    "Chỉ sửa đúng các lỗi được nêu; giữ nguyên các sự kiện hợp lệ, nhân vật hợp lệ, POV, xưng hô và giọng văn.",
    "TUYỆT ĐỐI không thêm sự kiện chính mới, không tạo nhân vật quan trọng mới, không mở thread mới chỉ để làm bản sửa dài hơn.",
    "ƯU TIÊN TUYỆT ĐỐI: OUTLINE/CONTRACT luôn thắng HƯỚNG SỬA. Bỏ qua mọi gợi ý nào xoá/thay/làm nhẹ beat, sự kiện hoặc lời thoại bắt buộc của Outline, hoặc thêm cảnh/tuyến ngoài Outline; chỉ áp dụng phần sửa cách viết, lặp, chuyển cảnh, thiếu beat.",
    p.storyControl || "",
    p.characterLock || "",
    (p.contractLabel || "OUTLINE/CONTRACT") + ":\n" + (p.contract || ""),
    p.context ? "CANON CONTEXT:\n" + compactGateContext(p.context, 8000, false) : "",
    p.prevEnding ? "ĐOẠN KẾT CHƯƠNG TRƯỚC (cảnh mở đầu phải nối tiếp đúng địa điểm/thời điểm/người có mặt ở đây):\n" + String(p.prevEnding).slice(-1500) : "",
    (p.review && p.review.alreadyFixed && p.review.alreadyFixed.length) ? "LỖI ĐÃ SỬA Ở VÒNG TRƯỚC — giữ nguyên các chỗ đã sửa, không làm hỏng lại:\n- " + p.review.alreadyFixed.join("\n- ") : "",
    "QUALITY REVIEW:\n" + JSON.stringify(review),
    stagnationFix,
    "HƯỚNG SỬA ƯU TIÊN (chỉ áp dụng phần KHÔNG mâu thuẫn Outline/Contract; mâu thuẫn thì Outline thắng):\n" + rewriteInstructionsText(review),
    "BẢN THẢO HIỆN TẠI:\n" + (p.draft || ""),
    "CHỈ TRẢ VỀ VĂN XUÔI CHƯƠNG ĐÃ SỬA, KHÔNG tiêu đề, không giải thích, không markdown."
  ].filter(Boolean).join("\n\n");
}

// --- Vòng lặp Gate dùng chung. Không gọi AI trực tiếp: client/worker truyền các hàm vào qua `deps`. ---
// deps: { review(attempt)→{ok,review|reason}, rewrite(review,attempt)→{ok,stopped,reason}, selfCheck?(attempt), onStatus?(msg), onChange?(), shouldStop?() }
// opts: { enabled, allowRewrite, maxAttempts, forceWarnings }
function bypassReview() {
  return { status: "bypassed", score: null, verdict: "BYPASS", dimensions: {}, hardFailures: [], warnings: ["Quality Gate đang tắt"], suggestions: [], rewriteInstructions: [], attempt: 0, reviewedAt: Date.now() };
}
// Khi người dùng bấm AI tự sửa, cảnh báo Canon/continuity có hướng xử lý
// không được bị coi là "PASS nên bỏ qua". Cảnh báo style thuần túy vẫn không ép sửa.
function hasActionableCanonWarning(review) {
  const r = review || {};
  const text = [].concat(r.warnings || [], r.rewriteInstructions || []).map(gateItemText).join(" ");
  return /(canon|continuity|liên tục|beat|outline|required|\[r\d+\]|hồ sơ|giới tính|hôn nhân|thế giới|knowledge|retcon|địa điểm|thời gian|cảnh\/người|nhân vật có mặt|mâu thuẫn)/i.test(text);
}
// V12.36 → V14.0.16 (hoist để dùng chung với tự sửa sau chấm nhanh): verdict tốt hơn thắng (PASS > SOFT_FAIL > HARD_FAIL), rồi tới điểm, rồi ít lỗi nặng hơn.
function reviewVerdictRank(v) { return v === "PASS" ? 3 : (v === "SOFT_FAIL" ? 2 : 1); }
function reviewIsBetter(a, b) {
  if (!b) return true;
  const vr = reviewVerdictRank(a && a.verdict) - reviewVerdictRank(b && b.verdict);
  if (vr !== 0) return vr > 0;
  const sd = Number(a && a.score || 0) - Number(b && b.score || 0);
  if (sd !== 0) return sd > 0;
  const ha = (a && a.hardFailures || []).length, hb = (b && b.hardFailures || []).length;
  if (ha !== hb) return ha < hb;
  // V14.1.6: điểm bằng nhau nhưng ít chỗ thiếu chuyển cảnh hơn => bản vá chèn câu chuyển cảnh được giữ.
  return transitionWarnings(a).length < transitionWarnings(b).length;
}
async function runGateLoop(chapter, deps, opts) {
  opts = opts || {}; deps = deps || {};
  const notify = () => { if (deps.onChange) deps.onChange(); };
  const stopped = () => !!(deps.shouldStop && deps.shouldStop());
  if (opts.enabled === false) { chapter.status = "APPROVED"; chapter.review = bypassReview(); notify(); return { approved: true }; }
  const maxAttempts = opts.allowRewrite === false ? 1 : gateMaxAttempts(opts.maxAttempts);
  const seenHard = []; // lỗi nặng của từng vòng đã chấm, để vòng sau không làm hỏng lại chỗ đã sửa
  // V12.36: không được để một lần tự sửa làm tụt chất lượng rồi ghi đè bản tốt hơn.
  // Ưu tiên verdict tốt hơn (PASS > SOFT_FAIL > HARD_FAIL), sau đó mới so điểm.
  const isBetterReview = reviewIsBetter;
  let bestReview = null, bestText = String(chapter.text || ""), bestWordCount = chapter.wordCount;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (stopped()) return { approved: false, stopped: true };
    if (deps.selfCheck) { chapter.status = "SELF_CHECKING"; notify(); await deps.selfCheck(attempt); }
    chapter.status = "REVIEWING"; chapter.review = Object.assign({}, chapter.review || {}, { attempt }); notify();
    const rr = await deps.review(attempt);
    if (!rr || !rr.ok) {
      const reason = (rr && rr.reason) || "review_error";
      chapter.review = Object.assign({}, chapter.review, { status: "error", verdict: "REVIEW_ERROR", warnings: ["Không đọc được kết quả Quality Review: " + reason] });
      chapter.status = "REVISION_REQUIRED"; notify();
      return { approved: false, error: reason };
    }
    chapter.review = Object.assign({}, chapter.review, rr.review, { status: "completed", attempt, reviewedAt: Date.now() });
    if (isBetterReview(rr.review, bestReview)) {
      bestReview = Object.assign({}, rr.review);
      bestText = String(chapter.text || "");
      bestWordCount = chapter.wordCount;
    }
    const forceActionableWarning = opts.forceWarnings === true && hasActionableCanonWarning(rr.review);
    if (rr.review.verdict === "PASS" && !forceActionableWarning) { chapter.status = "APPROVED"; notify(); return { approved: true, review: rr.review }; }
    if (forceActionableWarning && deps.onStatus) deps.onStatus("Quality Gate: phát hiện cảnh báo Canon cần xử lý — đang gửi cho AI tự sửa...");
    // V12.32.12: chỉ còn cảnh báo nhẹ (điểm ≥ ngưỡng mềm, KHÔNG có hard failure) → duyệt kèm cảnh báo, không chạy thêm vòng.
    if (opts.acceptSoft !== false && rr.review.verdict === "SOFT_FAIL" && !(rr.review.hardFailures || []).length) {
      chapter.review.softAccepted = true;
      chapter.review.warnings = (chapter.review.warnings || []).concat(["Duyệt kèm cảnh báo: điểm " + rr.review.score + " chưa tới ngưỡng PASS nhưng không có lỗi nặng."]);
      chapter.status = "APPROVED"; notify(); return { approved: true, softAccepted: true, review: chapter.review };
    }
    seenHard.push((rr.review.hardFailures || []).map(gateItemText));
    chapter.status = "REVISION_REQUIRED"; notify();
    if (attempt >= maxAttempts) break;
    if (deps.onStatus) deps.onStatus("Quality Gate: " + rr.review.verdict + " — đang sửa lần " + (attempt + 1) + "/" + maxAttempts + "...");
    const normKey = s => String(s || "").toLowerCase().replace(/\s+/g, " ").trim().slice(0, 80);
    const nowKeys = new Set((rr.review.hardFailures || []).map(gateItemText).map(normKey));
    const alreadyFixed = [].concat(...seenHard.slice(0, -1)).filter((s, i, a) => !nowKeys.has(normKey(s)) && a.findIndex(x => normKey(x) === normKey(s)) === i).slice(-6);
    const rw = await deps.rewrite(alreadyFixed.length ? Object.assign({}, rr.review, { alreadyFixed }) : rr.review, attempt);
    if (rw && rw.stopped) return { approved: false, stopped: true };
    if (!rw || !rw.ok) {
      chapter.review.warnings = (chapter.review.warnings || []).concat(["Bản sửa bị từ chối: " + ((rw && rw.reason) || "không rõ") + " — giữ nguyên bản thảo."]);
      notify(); break;
    }
    chapter.review.revisionTrace = (chapter.review.revisionTrace || []).concat([{
      attempt,
      patched: Number(rw.patched || 0),
      trace: rw.trace || [],
      skippedReasons: rw.skippedReasons || []
    }]);
    chapter.review.warnings = (chapter.review.warnings || []).concat(["AI tự sửa: đã áp dụng " + Number(rw.patched || 0) + " thao tác vá; bản sửa sẽ được chấm lại. Không có thao tác nào bị coi là đã sửa nếu chưa ghép được vào văn bản."]);
    notify();
  }
  // Nếu các vòng sửa sau làm điểm tụt, khôi phục bản tốt nhất đã được chấm.
  if (bestReview && String(chapter.text || "") !== bestText) {
    chapter.text = bestText;
    chapter.wordCount = bestWordCount;
    chapter.review = Object.assign({}, bestReview, {
      status: "completed",
      attempt: Math.max(Number(bestReview.attempt) || 0, Number(chapter.review && chapter.review.attempt) || 0),
      regressionGuard: true,
      warnings: (bestReview.warnings || []).concat(["Best Draft Guard: bản sửa sau có điểm thấp hơn nên đã khôi phục bản tốt hơn (" + bestReview.score + "/100)."])
    });
    if (deps.onChange) deps.onChange();
  }
  chapter.status = "REVISION_REQUIRED";
  return { approved: false, review: chapter.review };
}


/* ===== V14.0.16 — TỰ SỬA SAU CHẤM NHANH (dùng chung client + worker) =====
   Sau khi chấm nhanh một bản nháp: nếu có lỗi nặng (hoặc cảnh báo Canon/continuity/Beat hành động được) thì sửa tối đa `maxRounds` vòng
   (deps.rewrite = vá cục bộ → sửa theo vùng → viết lại cả chương, tùy chương dài), chấm lại, và KHÔNG BAO GIỜ giữ bản kém hơn
   (Best Draft Guard) hay bản làm chương tụt dưới số từ tối thiểu. Cảnh báo văn phong nhẹ không bị ép sửa.
   deps: { rewrite(review, round) -> {ok, patched?, reason?, stopped?}, review() -> {ok, review}, timeLeft()?, onStatus(msg)? }
   opts: { maxRounds (1..3, mặc định 1), minRoundMs (mặc định 120000), minWords? }
   Trả: { attempted, rounds, improved, restored, reason, before, after, review } — `review` là review tốt nhất; chapter.text đã là bản tốt nhất. */
function quickFixNeeded(review) {
  const r = review || {};
  if (!r.verdict || r.verdict === "PASS") return false;
  if (r.verdict === "HARD_FAIL" || (r.hardFailures || []).length) return true;
  return hasActionableCanonWarning(r) || transitionWarnings(r).length > 0;
}
// V14.1.6: cảnh báo THIẾU CÂU CHUYỂN CẢNH (nhảy địa điểm/thời gian) — sửa được bằng vài câu chèn, không cần viết lại.
function transitionWarnings(review) {
  return ((review && review.warnings) || []).map(gateItemText).filter(t => /thiếu câu chuyển cảnh|câu chuyển cảnh|chuyển cảnh|không có mô tả (di chuyển|thời gian)|nhảy (từ|sang)|đột ngột/i.test(t));
}
// Review "giả" chỉ chứa các chỗ thiếu chuyển cảnh + hướng sửa chỉ-chèn-câu, để vá cục bộ (không replace/delete, không viết lại chương). null nếu còn lỗi nặng hoặc không có cảnh báo chuyển cảnh.
function transitionFixReview(review) {
  const r = review || {};
  if ((r.hardFailures || []).length) return null;
  const tw = transitionWarnings(r);
  if (!tw.length) return null;
  return {
    verdict: r.verdict, score: r.score, dimensions: r.dimensions || {}, hardFailures: [], warnings: tw.slice(0, 6),
    rewriteInstructions: [
      "CHỈ CHÈN câu chuyển cảnh: dùng insert_after / insert_before để thêm 1–2 câu cầu nối ngay tại các chỗ nhảy địa điểm/thời gian đã nêu (rời nơi cũ bằng cách nào, đến nơi mới, thời điểm mới, ai có mặt).",
      "KHÔNG dùng replace/delete, KHÔNG đổi nội dung khác, KHÔNG thêm sự kiện hay nhân vật mới, KHÔNG viết nhãn ngày giờ; câu chèn là văn xuôi thuần nối mượt với đoạn trước và sau."
    ]
  };
}
// Gợi ý hành động cho người dùng từ một review: { level: ok|read|fix|split|rewrite, action, issues:[{kind,text}] }. null nếu chưa có review.
function reviewActionAdvice(review) {
  const r = review || {};
  if (!r.verdict) return null;
  const clip = (t, n) => { t = String(t || "").replace(/\s+/g, " ").trim(); return t.length > n ? t.slice(0, n) + "…" : t; };
  const kindOf = t => /vượt ngân sách sự kiện/i.test(t) ? "events" : /vượt số nhân vật có tên|nhân vật mới quan trọng/i.test(t) ? "cast" : /lỗi cảnh|người có mặt|sceneviolation/i.test(t) ? "scene"
    : /vượt thiết lập|hồ sơ|địa vị|quyền hạn/i.test(t) ? "profile" : /knowledge|biết thông tin|chưa thể biết/i.test(t) ? "knowledge" : /retcon/i.test(t) ? "retcon"
    : /dậm chân|stagnation/i.test(t) ? "stall" : /arc\/outline|không đưa arc/i.test(t) ? "arc" : /giải phẫu|đặc điểm sinh học/i.test(t) ? "anatomy" : "other";
  const issues = (r.hardFailures || []).map(gateItemText).map(t => ({ kind: kindOf(t), text: clip(t.replace(/^\s*sceneViolation:\s*/i, ""), 140) }));
  if (r.verdict === "PASS" && !issues.length) return { level: "ok", action: "Có thể bấm ☁ Chạy hậu kỳ luôn.", issues };
  if (!issues.length) {
    const tw = transitionWarnings(r).length;
    return { level: "read", action: "Chỉ có cảnh báo" + (tw ? " (" + tw + " chỗ thiếu câu chuyển cảnh)" : "") + ": đọc lướt rồi bấm ☁ Chạy hậu kỳ, không cần viết lại.", issues };
  }
  const kinds = new Set(issues.map(i => i.kind));
  if (["knowledge", "retcon", "stall", "arc"].some(k => kinds.has(k))) return { level: "rewrite", action: "Lỗi nội dung (nhân vật biết điều chưa thể biết / retcon / dậm chân / lệch Arc) — nên ↻ Viết lại, vá vài câu không đủ.", issues };
  if (kinds.has("events") || kinds.has("cast")) return { level: "split", action: "Chương nhồi quá nhiều sự kiện/nhân vật — rút bớt trong Outline (chia sang chương sau) rồi ↻ Viết lại, hoặc nâng giới hạn nếu cố ý.", issues };
  if (kinds.has("scene") || kinds.has("profile") || kinds.has("anatomy")) return { level: "fix", action: "Lỗi vá được: bấm 🔍 Duyệt lại (tự sửa cục bộ). Nếu đọc thấy mạch ổn có thể duyệt tay rồi chạy hậu kỳ" + (kinds.has("profile") ? "; kiểm tra hồ sơ nhân vật nếu hồ sơ mới là chỗ sai" : "") + ".", issues };
  return { level: "fix", action: "Đọc kỹ lỗi bên dưới: sửa tay hoặc 🔍 Duyệt lại; nếu nặng thì ↻ Viết lại.", issues };
}
function _reviewBrief(r) { return r ? { verdict: r.verdict, score: r.score == null ? null : r.score, hard: (r.hardFailures || []).length, warn: (r.warnings || []).length } : null; }
async function runQuickAutoFix(chapter, startReview, deps, opts) {
  opts = opts || {}; deps = deps || {};
  const timeLeft = typeof deps.timeLeft === "function" ? deps.timeLeft : () => Infinity;
  const maxRounds = Math.max(1, Math.min(3, Number(opts.maxRounds) || 1)), minRoundMs = opts.minRoundMs || 120000, minWords = Number(opts.minWords) || 0;
  const out = { attempted: false, rounds: 0, improved: false, restored: false, reason: "", before: _reviewBrief(startReview), after: _reviewBrief(startReview), review: startReview, patched: 0 };
  if (!quickFixNeeded(startReview)) { out.reason = "không cần sửa"; return out; }
  let best = { review: startReview, text: String(chapter.text || ""), wc: chapter.wordCount }, cur = startReview;
  const restoreBest = () => { chapter.text = best.text; chapter.wordCount = best.wc; };
  while (out.rounds < maxRounds && quickFixNeeded(cur)) {
    if (timeLeft() < minRoundMs) { out.reason = "hết thời gian job"; break; }
    out.attempted = true; out.rounds++;
    if (deps.onStatus) deps.onStatus("Tự sửa sau chấm nhanh: vòng " + out.rounds + "/" + maxRounds + "...");
    let rw;
    try { rw = await deps.rewrite(cur, out.rounds); } catch (e) { rw = { ok: false, reason: (e && e.message) || "lỗi khi sửa" }; }
    if (rw && rw.stopped) { restoreBest(); out.reason = "đã dừng"; break; }
    if (!rw || !rw.ok) { restoreBest(); out.reason = "bản sửa bị từ chối: " + String((rw && rw.reason) || "không rõ").slice(0, 160); break; }
    out.patched += Number(rw.patched || 0);
    if (minWords && countWords(chapter.text) < minWords && countWords(best.text) >= minWords) { restoreBest(); out.restored = true; out.reason = "bản sửa làm chương dưới " + minWords + " từ — giữ bản cũ"; break; }
    let rr;
    try { rr = await deps.review(); } catch (e) { rr = { ok: false, reason: (e && e.message) || "review_error" }; }
    if (!rr || !rr.ok) { restoreBest(); out.restored = true; out.reason = "không chấm lại được bản sửa — giữ bản cũ"; break; }
    if (reviewIsBetter(rr.review, best.review)) { best = { review: rr.review, text: String(chapter.text || ""), wc: chapter.wordCount }; cur = rr.review; out.improved = true; }
    else { restoreBest(); out.restored = true; out.reason = "bản sửa không tốt hơn (" + (rr.review.score == null ? "—" : rr.review.score) + " ≤ " + (best.review.score == null ? "—" : best.review.score) + ") — đã khôi phục"; break; }
  }
  out.review = best.review; out.after = _reviewBrief(best.review);
  if (!out.reason) out.reason = quickFixNeeded(best.review) ? "đã sửa nhưng vẫn còn lỗi" : "đã sửa xong";
  return out;
}

// --- Canon version / đánh dấu Sync / kết quả job nền ---
function nextCanonVersion(st) {
  const ex = Math.max(0, ...(((st && st.chapters) || []).map(c => Number(c && c.sync && c.sync.canonVersion) || 0)));
  return Math.max(ex, Number(st && st.canonVersion) || 0) + 1;
}
function applyCanonSync(st, chapter, now) {
  const cv = nextCanonVersion(st);
  st.canonVersion = cv; chapter.canonVersion = cv;
  const warn = !!(chapter.autoUpdateIssues && chapter.autoUpdateIssues.length);
  chapter.sync = Object.assign({ changes: [] }, chapter.sync || {}, { status: warn ? "SYNCED_WITH_WARNINGS" : "SYNCED", canonVersion: cv, syncedAt: now || Date.now() });
  chapter.status = chapter.sync.status;
  return cv;
}
function mergeCanonVersion(local, incoming) { return Math.max(Number(local) || 0, Number(incoming) || 0); }
// Kết quả job nền có phải "trượt Quality Gate" (chương nháp, chưa Sync) không?
function isGateFailedResult(d) {
  if (!d) return false;
  if (d.qualityGateFailed) return true;
  if (d.resultChapter && d.resultChapter.status === "REVISION_REQUIRED") return true;
  const chs = d.storyState && d.storyState.chapters;
  const last = Array.isArray(chs) && chs.length ? chs[chs.length - 1] : null;
  return !!(last && last.status === "REVISION_REQUIRED");
}

/* ===== V12.18 — NHÂN VẬT TRÙNG: nhận diện nhãn chung / tên ngắn, gộp an toàn (dùng chung client + worker) ===== */

const _GENERIC_MC_LABELS = ["nhan vat chinh", "nvc", "main character", "the main character", "protagonist", "the protagonist", "mc", "nhan vat chinh cua truyen"];
const _TIER_ORDER = ["background", "minor", "supporting", "important", "major"];
const _DUP_STOP = new Set(["ba", "ong", "co", "chu", "anh", "chi", "em", "me", "cha", "bo", "thay", "nguoi", "ke", "gia", "cau", "mo", "di", "duong"]);

/* "nhân vật chính", "main character", "protagonist", "nhân vật chính (tên chưa rõ)"... — nhãn chung, KHÔNG phải tên riêng. */
function isGenericMainLabel(name, mcName) {
  const n = normalizeName(name).replace(/[()\[\]{}"'“”‘’.,:;]/g, " ").replace(/\s+/g, " ").trim();
  if (!n) return false;
  if (_GENERIC_MC_LABELS.includes(n)) return true;
  const m = n.match(/^(nhan vat chinh|main character|protagonist)\s+(.+)$/);
  if (!m) return false;
  if (/^(ten chua ro|chua ro ten|chua dat ten|vo danh)$/.test(m[2])) return true;
  const mc = normalizeName(mcName || "");
  return !!mc && (m[2].includes(mc) || mc.includes(m[2]));
}

/* Tên (do AI trích xuất) trỏ tới đâu: hồ sơ Nhân Vật Chính / một nhân vật có sẵn (kể cả theo bí danh) / chưa có. */
function resolveCharacterTarget(state, name) {
  const n = normalizeName(name);
  if (!n) return { kind: "none" };
  const mc = state && state.mainCharProfile, mcName = (mc && mc.name) || "";
  if (mcName && normalizeName(mcName) === n) return { kind: "main" };
  if (mc && Array.isArray(mc.aliases) && mc.aliases.some(a => normalizeName(a) === n)) return { kind: "main", via: "alias" };
  if (mcName && isGenericMainLabel(name, mcName)) return { kind: "main", via: "generic" };
  const list = (state && state.characters) || [];
  let c = list.find(x => normalizeName(x.name) === n);
  if (c) return { kind: "character", character: c };
  c = list.find(x => Array.isArray(x.aliases) && x.aliases.some(a => normalizeName(a) === n));
  if (c) return { kind: "character", character: c, via: "alias" };
  return { kind: "new" };
}

/* AI báo thêm về nhân vật chính: chỉ cập nhật các trường trạng thái (không đụng hồ sơ do người dùng nhập). */
function applyMainCharUpdate(profile, u, sourceText, st) {
  if (!profile || !u) return false;
  let changed = false;
  ["currentLocation", "physicalState", "mentalState", "secret"].forEach(k => { if (u[k] && String(u[k]).trim()) { profile[k] = u[k]; changed = true; } });
  // V14.1: trường tu luyện (cảnh giới đổi cần explicitCoreChange + bằng chứng trích từ chương, như nghề/chức vụ).
  const explicit = u.explicitCoreChange === true && String(u.changeEvidence || "").trim().length >= 12 && (sourceText == null || evidenceInText(u.changeEvidence, sourceText));
  const before = JSON.stringify(profile);
  applyCultivationUpdate(profile, u, { explicit, evidence: u.changeEvidence, state: st || (typeof state !== "undefined" ? state : null) });
  if (JSON.stringify(profile) !== before) changed = true;
  return changed;
}

function mergeTextSegments(a, b, max) {
  max = max || 2500;
  const x = String(a || "").trim(), y = String(b || "").trim();
  if (!y) return x;
  if (!x) return y.slice(0, max);
  const nx = normalizeName(x), ny = normalizeName(y);
  if (nx === ny || nx.includes(ny)) return x;
  if (ny.includes(nx)) return y.slice(0, max);
  const fresh = y.split(/;\s*/).filter(seg => seg.trim() && !nx.includes(normalizeName(seg)));
  if (!fresh.length) return x;
  const parts = x.split(/;\s*/).concat(fresh);
  while (parts.length > 1 && parts.join("; ").length > max) parts.shift();
  return parts.join("; ").slice(-max);
}

/* Gộp hồ sơ `source` vào `target` (target là bản giữ lại). Không mất thông tin: trường trống thì điền, trường chữ thì nối ý mới. */
function mergeCharacterRecords(target, source) {
  const SKIP = ["id", "name", "relationships", "history", "aliases", "coreIdentity", "tier", "firstAppearance", "lastAppearance", "dead", "deathChapter", "locked", "coreLocked"];
  const TEXT = ["appearance", "personality", "goals", "secret", "weakness", "fear", "knowledge", "independentPlot", "speech", "strength", "role", "relevanceToMC", "arts", "fortune", "grudges", "innerDemon", "karma"];
  Object.keys(source).forEach(k => {
    if (SKIP.includes(k)) return;
    const v = source[k];
    if (v == null || v === "") return;
    if (TEXT.includes(k)) target[k] = mergeTextSegments(target[k], v, (k === "role" || k === "relevanceToMC") ? 400 : 2500);
    else if (target[k] == null || target[k] === "") target[k] = v;
  });
  if (_TIER_ORDER.indexOf(source.tier) > _TIER_ORDER.indexOf(target.tier)) target.tier = source.tier;
  const nums = (p, q, pick) => { const a = target[p], b = source[q]; return a == null ? b : (b == null ? a : pick(a, b)); };
  target.firstAppearance = nums("firstAppearance", "firstAppearance", Math.min);
  target.lastAppearance = nums("lastAppearance", "lastAppearance", Math.max);
  if (source.dead && !target.dead) { target.dead = true; target.deathChapter = source.deathChapter != null ? source.deathChapter : target.deathChapter; }
  const seenRel = new Set(), rels = [];
  (target.relationships || []).concat(source.relationships || []).forEach(r => {
    const k = normalizeName(r && r.withName);
    if (!k || seenRel.has(k) || k === normalizeName(target.name)) return;
    seenRel.add(k); rels.push(r);
  });
  target.relationships = rels;
  target.history = (Array.isArray(target.history) ? target.history : []).concat(Array.isArray(source.history) ? source.history : []).slice(-100);
  const aliases = [];
  (target.aliases || []).concat(source.aliases || [], [source.name]).forEach(a => {
    const k = normalizeName(a);
    if (k && k !== normalizeName(target.name) && !aliases.some(x => normalizeName(x) === k)) aliases.push(String(a).trim());
  });
  target.aliases = aliases;
  return target;
}

/* Gợi ý các mục có thể trùng (CHỈ gợi ý — người dùng quyết định). state.ignoredDupPairs: các cặp "Giữ riêng". */
function findDuplicateCharacterGroups(state) {
  const out = [], seen = new Set();
  const chars = (state && state.characters) || [], mc = state && state.mainCharProfile, mcName = (mc && mc.name) || "";
  const mcN = normalizeName(mcName), ignored = new Set((state && state.ignoredDupPairs) || []);
  const push = (src, targetId, targetName, type, reason, confidence) => {
    const key = src.id + "|" + (targetId || "");
    if (seen.has(key) || ignored.has(key)) return;
    seen.add(key);
    out.push({ key, sourceId: src.id, sourceName: src.name, targetId: targetId || null, targetName: targetName || "", type, reason, confidence });
  };
  const cands = chars.filter(c => /protagonist|nhan vat chinh|nam chinh|nu chinh/.test(normalizeName(c.role)) && !isGenericMainLabel(c.name, mcName));
  const flagged = new Set();
  chars.forEach(c => {
    const n = normalizeName(c.name);
    if (!n) return;
    if (mcN && n === mcN) { push(c, "MAIN", mcName, "main_name", "Trùng tên với hồ sơ Nhân Vật Chính", "high"); flagged.add(c.id); return; }
    if (!isGenericMainLabel(c.name, mcName)) return;
    flagged.add(c.id);
    if (mcN) push(c, "MAIN", mcName, "main_generic", "Nhãn chung “nhân vật chính” — chính là " + mcName, "high");
    else if (cands.length === 1) push(c, cands[0].id, cands[0].name, "main_generic", "Nhãn chung “nhân vật chính” — có vẻ là " + cands[0].name, "medium");
    else push(c, null, "", "generic_unresolved", "Nhãn chung “nhân vật chính” nhưng chưa khai báo Nhân Vật Chính", "medium");
  });
  const toks = c => normalizeName(c.name).split(" ").filter(Boolean);
  chars.forEach(a => {
    if (flagged.has(a.id)) return;
    const ta = toks(a);
    if (!ta.length || (ta.length === 1 && (_DUP_STOP.has(ta[0]) || ta[0].length < 2))) return;
    if (mcN) {
      const tm = mcN.split(" ").filter(Boolean);
      if (ta.length < tm.length && ta.every(t => tm.includes(t))) { push(a, "MAIN", mcName, "alias", "Tên ngắn trùng một phần với nhân vật chính " + mcName, "medium"); return; }
    }
    const longer = chars.filter(b => b !== a && !flagged.has(b.id) && (() => { const tb = toks(b); return ta.length < tb.length && ta.every(t => tb.includes(t)); })());
    if (longer.length === 1) push(a, longer[0].id, longer[0].name, "alias", "“" + a.name + "” trùng một phần với “" + longer[0].name + "” — có thể cùng một người", "medium");
  });
  return out;
}

/* Gộp nhân vật `sourceId` vào `targetId` ("MAIN" = hồ sơ Nhân Vật Chính: chỉ điền ô còn trống, không ghi đè nội dung người dùng đã nhập). */
function mergeCharacterIntoState(state, sourceId, targetId) {
  const chars = state.characters || [], src = chars.find(c => c.id === sourceId);
  if (!src) return { ok: false, reason: "không thấy mục nguồn" };
  let targetName;
  if (targetId === "MAIN") {
    const p = state.mainCharProfile;
    if (!p || !String(p.name || "").trim()) return { ok: false, reason: "chưa khai báo Nhân Vật Chính" };
    Object.keys(src).forEach(k => {
      const pk = k === "strength" ? "skills" : k, v = src[k];
      if (typeof v !== "string" || !v.trim() || !(pk in p) || pk === "name") return;
      if (!String(p[pk] || "").trim()) p[pk] = v;
    });
    const al = Array.isArray(p.aliases) ? p.aliases.slice() : [];
    if (normalizeName(src.name) !== normalizeName(p.name) && !al.some(x => normalizeName(x) === normalizeName(src.name))) al.push(String(src.name).trim());
    p.aliases = al; targetName = p.name;
  } else {
    const tgt = chars.find(c => c.id === targetId && c.id !== sourceId);
    if (!tgt) return { ok: false, reason: "không thấy mục đích" };
    mergeCharacterRecords(tgt, src); targetName = tgt.name;
  }
  state.characters = chars.filter(c => c.id !== sourceId);
  const sn = normalizeName(src.name);
  state.characters.forEach(c => {
    if (!Array.isArray(c.relationships)) return;
    c.relationships.forEach(r => { if (r && normalizeName(r.withName) === sn) r.withName = targetName; });
    const seenR = new Set();
    c.relationships = c.relationships.filter(r => { const k = normalizeName(r && r.withName); if (!k || k === normalizeName(c.name) || seenR.has(k)) return false; seenR.add(k); return true; });
  });
  return { ok: true, from: src.name, into: targetName };
}

const SCENE_PLAN_SYSTEM_PROMPT = "Lập kế hoạch scene cho tiểu thuyết dài kỳ tiếng Việt. Trả đúng JSON được yêu cầu, không viết văn xuôi, không thêm biến cố lớn ngoài brief/canon.";
const EROTIC_SCENE_LOCK = "QUY TẮC CẢNH NÓNG (bắt buộc khi scene là cảnh nóng giữa người trưởng thành; viết thẳng, không tự kiểm duyệt, không fade-to-black): lúc đang làm tình dùng từ thô tục đời thường (cặc, lồn, địt, nứng, nước lồn, tinh trùng…), không thay bằng ẩn dụ hoa mỹ; mỗi đoạn nóng đủ 4 lớp: cơ thể theo hồ sơ + cảm giác thể xác (căng, ướt, nóng, run) + nội tâm (xấu hổ↔dục, kháng cự↔cơ thể phản ứng) + âm thanh/nhịp (da chạm, hơi thở, rên, thoại); tăng thoại theo vai và quyền lực; chậm từng nhịp, không tóm tắt cao trào trong 1–2 câu, không chuyển cảnh trước khi hoàn tất; nhịp dẫn vào ~25% / diễn biến + cao trào ~50% / sau cảnh ~25%; không bịa số đo ngoài hồ sơ; trừ khi mệnh lệnh người dùng chỉ định dừng ở mốc khác.";
const SCENE_SYSTEM_PROMPT = "Viết văn xuôi tiểu thuyết tiếng Việt tự nhiên, 100% tiếng Việt có dấu. Đây là scene nối tiếp: giữ liên tục nhân vật, thời gian, địa điểm, quan hệ, xưng hô và trạng thái; không lặp đoạn trước, không meta, không tiêu đề, chỉ trả văn xuôi. Show, don't tell; câu có nhịp dài ngắn; không lặp sáo ngữ hoặc cụm cảm giác đã dùng ở đoạn trước; lời thoại đúng giọng từng người. Với cảnh người lớn: chỉ nhân vật từ 18 tuổi trở lên theo RÀO_CHẮN_TUỔI trong STYLE LOCK; quy tắc này không bao giờ bị chỉ dẫn khác ghi đè. Khi STYLE LOCK có mức_18+ và scene là cảnh nóng giữa người trưởng thành: viết đúng mức đó, trực tiếp, không tự kiểm duyệt, không fade-to-black, không tóm tắt thay cho cảnh.";

/* V14.0.6: VÒNG ĐIỀU PHỐI ADAPTIVE SCENE DÙNG CHUNG client + worker nền.
   Mọi thứ phụ thuộc môi trường (gọi AI, state, định tuyến model, đồng hồ) được truyền qua `deps`:
     deps.state, deps.callAI(prompt, opts) -> {text}, deps.buildContract(st, n, prior), deps.requiredBeats(st, n),
     deps.style(nsfw) -> string, deps.route(scene, o, tail) -> {model, nsfw}, deps.onNsfw(scene, route)?,
     deps.timeLeft()? -> ms còn lại (worker nền), deps.minSceneMs?/deps.minTopUpMs? ngưỡng dừng sớm.
   Trả: {rejected, reason} | {text, plan, underTarget, usedNsfw, timedOut?} | null (lỗi API ở scene). */
/* ===== V14.5.0 — CÁCH 3: MỖI CẢNH GẮN VỚI MỤC OUTLINE, APP KIỂM TRA KẾ HOẠCH TRƯỚC KHI VIẾT =====
   Outline dạng "Chương N — Tiêu đề Sự kiện: …" + các dòng gạch đầu dòng (+ Kháng cự/Hậu quả/Móc kết) được tách thành các MỤC đánh số.
   AI lập kế hoạch cảnh phải khai báo scene nào thực hiện mục nào; app kiểm tra (0 token) mọi mục đều có cảnh, đúng thứ tự, không dồn/trùng.
   Sai -> lập lại; vẫn sai -> dựng cảnh theo từng mục Outline (1 mục = 1 cảnh) từ chính kế hoạch AI (nhân vật/nơi/giờ). Chỉ áp dụng khi chương có 3–10 mục. */
function outlineChapterItems(content, ol) {
  const out = {}; let cur = 0;
  const META_RE = /(?=(?:Kháng cự|Hậu quả|Móc kết)\s*:)/u;
  const parseMeta = (txt, meta) => {
    const m = String(txt).match(/^(Kháng cự|Hậu quả|Móc kết)\s*:\s*([\s\S]*)$/u);
    if (!m) return;
    meta[m[1] === 'Kháng cự' ? 'resistance' : (m[1] === 'Hậu quả' ? 'consequence' : 'hook')] = m[2].trim().replace(/[.;\s]+$/u, '');
  };
  outlineNormalizeText(content).split(/\n+/).forEach(l => {
    const line = l.trim(); if (!line) return;
    const m = line.match(/^(?:[-*•]\s*)?(?:ch(?:ư[ơ]ng)?\.?\s*)?(\d{1,4})\s*[:.)\-–—]\s*(.+)$/i);
    if (m && m[2] && m[2].trim().length >= 8) {
      cur = Number(m[1]);
      const body = m[2].trim(), k = body.search(/Sự kiện\s*:/u);
      const title = k > 0 ? body.slice(0, k).trim() : '';
      const pieces = (k >= 0 ? body.slice(k).replace(/^Sự kiện\s*:\s*/u, '') : body).split(META_RE);
      const event = (pieces[0] || '').replace(/[.;\s]+$/u, '').trim();
      out[cur] = { title, items: event ? [event] : [], meta: {} };
      pieces.slice(1).forEach(x => parseMeta(x, out[cur].meta));
      return;
    }
    if (cur && out[cur] && /^[•\-*–·▪◦●]\s*\S/.test(line)) {
      const pieces = line.replace(/^[•\-*–·▪◦●]\s*/, '').trim().split(META_RE);
      const item = (pieces[0] || '').replace(/[.;\s]+$/u, '').trim();
      if (item.length >= 4) out[cur].items.push(item);
      pieces.slice(1).forEach(x => parseMeta(x, out[cur].meta));
    }
  });
  Object.keys(out).forEach(k => { if (out[k] && out[k].meta) out[k].meta = dedupeOutlineMeta(out[k].meta, out[k].items); }); // V14.5.14: Hậu quả trùng mục -> bỏ
  return _outlineRemapLocal(out, ol);
}
function validateOutlineMapping(plan, items) {
  const errs = [], N = Array.isArray(items) ? items.length : 0, scenes = (plan && plan.scenes) || [];
  if (!N) return errs;
  const owner = {}; let bridges = 0, lastMax = 0;
  scenes.forEach(s => {
    const idx = Array.from(new Set((Array.isArray(s.outlineItems) ? s.outlineItems : []).map(Number).filter(n => Number.isInteger(n) && n >= 1 && n <= N))).sort((a, b) => a - b);
    if (!idx.length) { bridges++; return; }
    if (idx.length > 3 || idx[idx.length - 1] - idx[0] + 1 !== idx.length) errs.push((s.id || 'scene') + ' gom mục ' + idx.join(',') + ': mỗi scene chỉ thực hiện 1–3 mục LIỀN KỀ.');
    if (idx[0] <= lastMax) errs.push((s.id || 'scene') + ' đảo/lặp thứ tự mục Outline (mục ' + idx[0] + ' đã nằm ở scene trước).');
    lastMax = Math.max(lastMax, idx[idx.length - 1]);
    idx.forEach(n => { owner[n] = (owner[n] || 0) + 1; });
  });
  for (let n = 1; n <= N; n++) { if (!owner[n]) errs.push('Mục Outline ' + n + ' chưa có scene thực hiện: «' + String(items[n - 1]).slice(0, 90) + '»'); else if (owner[n] > 1) errs.push('Mục Outline ' + n + ' bị ' + owner[n] + ' scene cùng thực hiện.'); }
  if (bridges > 1) errs.push('Có ' + bridges + ' scene không gắn mục Outline nào (chỉ được tối đa 1 scene nối/chuyển).');
  return errs.slice(0, 8);
}
function buildOutlineGraph(candidate, items, meta, limits, contract) {
  const n = items.length, groups = [];
  const size = n <= 6 ? 1 : Math.ceil(n / 6);
  for (let i = 0; i < n; i += size) groups.push(items.slice(i, i + size).map((t, k) => ({ idx: i + k + 1, text: t })));
  const cs = (candidate && candidate.scenes) || [];
  const fallbackCast = ((contract && contract.allowedCharacters) || []).slice(0, 3);
  const weights = groups.map(g => Math.max(200, g.reduce((a, x) => a + x.text.length, 0)));
  const wSum = weights.reduce((a, b) => a + b, 0);
  const scenes = groups.map((g, i) => {
    const ref = cs.length ? cs[Math.min(cs.length - 1, Math.floor(i * cs.length / groups.length))] : {};
    const nextText = groups[i + 1] ? groups[i + 1][0].text : ((meta && meta.hook) || '');
    return {
      id: 'S' + (i + 1),
      purpose: 'Thực hiện mục Outline ' + g.map(x => x.idx).join(', '),
      beats: g.map(x => String(x.text).slice(0, 500)),
      characters: (ref.characters && ref.characters.length) ? ref.characters.slice() : fallbackCast.slice(),
      location: ref.location || '', time: ref.time || '',
      targetWords: Math.max(350, Math.round((weights[i] / wSum) * ((limits && limits.target) || 5000) / 50) * 50),
      mustChange: g.map(x => x.text).join('; ').slice(0, 400),
      handoff: (nextText ? 'Dẫn sang: ' + String(nextText).slice(0, 220) : 'Kết chương theo Outline').slice(0, 400),
      outlineItems: g.map(x => x.idx)
    };
  });
  return { chapterGoal: (candidate && candidate.chapterGoal) || String(items[0] || '').slice(0, 300), endingAnchor: (meta && meta.hook) || (candidate && candidate.endingAnchor) || '', scenes };
}
async function runAdaptiveChapterPipeline(o, deps) {
  const st = deps.state, callAI = deps.callAI, t0 = Date.now();
  const priorChapters = acceptedStoryChapters(o.priorChapters || []);
  const limits = adaptiveChapterWordLimits(st);
  const timeLeft = typeof deps.timeLeft === 'function' ? deps.timeLeft : () => Infinity;
  const minSceneMs = deps.minSceneMs || 70000, minTopUpMs = deps.minTopUpMs || 70000;
  const recent = buildRecentBlocks(priorChapters).recentFullText;
  const chapterNumber = priorChapters.length + 1;
  let chapterContract = deps.buildContract(st, chapterNumber, priorChapters);
  const requiredBeats = deps.requiredBeats(st, chapterNumber);
  const outlineItems = (deps.outlineMap !== false && Array.isArray(chapterContract.outlineItems) && chapterContract.outlineItems.length >= 3 && chapterContract.outlineItems.length <= 10) ? chapterContract.outlineItems : null;
  let outlineMap = '';
  const planPrompt = buildAdaptiveScenePlanPrompt({
    outlineItems, outlineMeta: chapterContract.outlineMeta || null,
    state: st, context: o.context, recent,
    directive: st.directive, hint: (chapterHintVerification(st, chapterNumber).text || ""), requiredBeats,
    arcProgress: arcProgressPrompt(st, chapterNumber),
    allowedCast: chapterContract.allowedCharacters.join(', '),
    forbiddenDrift: chapterContract.forbiddenDrift.join(' '), chapterContract
  });
  let graph = null, planError = '', lastCandidate = null, lastChecked = null, strippedCast = [];
  for (let planAttempt = 1; planAttempt <= 2 && !graph; planAttempt++) {
    try {
      const correction = planAttempt > 1 ? "\nPLAN BỊ TỪ CHỐI. Sửa đúng lỗi Contract sau, không mở tuyến mới:\n" + planError : "";
      const planRes = await callAI(planPrompt + correction, { maxTokens: planAttempt > 1 ? 7800 : 5000, temperature: planAttempt > 1 ? 0.15 : 0.25, modelOverride: o.model, systemPrompt: SCENE_PLAN_SYSTEM_PROMPT });
      const rawPlan = String(planRes && planRes.text || '');
      const candidate = normalizeAdaptiveScenePlan(rawPlan, st);
      if (!candidate) {
        const snippet = rawPlan.replace(/\s+/g, ' ').trim().slice(0, 140);
        planError = 'Không parse được JSON Scene Graph; trả duy nhất JSON object, không markdown/lời dẫn.'
          + (rawPlan.trim() ? ' [model trả ' + rawPlan.length + ' ký tự' + (planRes && planRes.finishReason ? ', finish=' + planRes.finishReason : '') + ': "' + snippet + '"]' : ' [model trả RỖNG' + (planRes && planRes.finishReason ? ', finish=' + planRes.finishReason : '') + ']');
      } else {
        const checked = validateAdaptiveScenePlan(candidate, chapterContract);
        lastCandidate = candidate; lastChecked = checked;
        if (checked.ok && outlineItems) { const om = validateOutlineMapping(candidate, outlineItems); if (om.length) { checked.ok = false; checked.mappingOnly = true; checked.errors = om.map(x => 'OUTLINE: ' + x); } }
        lastChecked = checked;
        if (checked.ok) { graph = candidate; if (outlineItems) outlineMap = 'ai'; } else planError = checked.errors.join(' | ');
      }
    } catch (e) { planError = e && e.message || 'plan failed'; }
  }
  // V14.0.11: sau 2 lượt vẫn CHỈ sai ở chỗ có tên người ngoài Canon Cast (vai phụ thoáng qua: phục vụ, bảo vệ, bác sĩ…) -> gỡ tên đó khỏi
  // danh sách nhân vật của scene thay vì làm hỏng cả job. Mọi lỗi khác (drift tuyến, thiếu mustChange…) vẫn bị từ chối như cũ.
  if (!graph && lastCandidate && lastChecked && lastChecked.outsiders && lastChecked.outsiders.length && lastChecked.errors.length === 1) {
    const out = new Set(lastChecked.outsiders.map(normalizeName));
    // Chỉ gỡ nếu tên CHỈ nằm ở danh sách characters (vai thoáng qua). Tên xuất hiện trong beats/purpose/mustChange/handoff/goal = tình tiết mang tên đó -> từ chối.
    const plotText = normalizeName(JSON.stringify({ g: lastCandidate.chapterGoal, e: lastCandidate.endingAnchor, s: (lastCandidate.scenes || []).map(sc => Object.assign({}, sc, { characters: undefined })) }));
    const plotBearing = [...out].some(n => plotText.includes(n));
    if (!plotBearing) {
    (lastCandidate.scenes || []).forEach(sc => { sc.characters = (sc.characters || []).filter(n => !out.has(normalizeName(n))); });
    const rechecked = validateAdaptiveScenePlan(lastCandidate, chapterContract);
    if (rechecked.ok) { graph = lastCandidate; strippedCast = lastChecked.outsiders.slice(0, 8); }
    }
  }
  if (!graph && outlineItems && lastCandidate && lastChecked && lastChecked.mappingOnly) { graph = buildOutlineGraph(lastCandidate, outlineItems, chapterContract.outlineMeta, limits, chapterContract); outlineMap = 'fallback'; }
  if (!graph) return { rejected: true, reason: 'PLAN_REJECTED: ' + (planError || 'Scene Graph không hợp lệ') };

  // V14.0.12: nhân vật có tên trong Outline/chương trước (chưa vào Character Database) được thêm vào cast cho từng scene,
  // để prompt scene không cấm đúng người mà Outline yêu cầu.
  let addedCast = [];
  { const nameSet = _contractNameSet(chapterContract);
    graph.scenes.forEach(sc => (sc.characters || []).forEach(n => { if (_looksLikeNamedCharacter(n) && !_nameInCast(n, nameSet) && !addedCast.includes(String(n).trim())) addedCast.push(String(n).trim()); }));
    if (addedCast.length) chapterContract = Object.assign({}, chapterContract, { allowedCharacters: (chapterContract.allowedCharacters || []).concat(addedCast), canonicalCharacters: (chapterContract.canonicalCharacters || []).concat(addedCast) });
  }

  // Rebalance ngân sách mềm về khoảng 5.000 từ, không áp vai trò cố định cho scene.
  const rawSum = graph.scenes.reduce((n, x) => n + Math.max(1, Number(x.targetWords) || 1), 0);
  let remaining = limits.target;
  graph.scenes.forEach((scene, i) => {
    if (i === graph.scenes.length - 1) scene.targetWords = Math.max(350, remaining);
    else {
      scene.targetWords = Math.max(350, Math.round((scene.targetWords / rawSum) * limits.target / 50) * 50);
      remaining -= scene.targetWords;
    }
  });

  const pieces = [], sceneStates = [], sceneTelemetry = [];
  let dupDropped = 0, sceneRetries = 0, sceneAiReviews = 0, ratioSum = 0, ratioN = 0;
  const danglingTrimmed = [];
  const sceneRewritten = [], sceneWarnings = [], sceneKept = [], scenePatched = [];
  const pushSceneWarn = (w, force) => { if (force || sceneWarnings.length < 40) sceneWarnings.push(w); };
  /* V14.5.9: sổ bằng chứng sự kiện Outline. itemsAll = mục đánh số của Outline (hoặc các ý tách từ dòng Outline nếu không đánh số). */
  const itemsAll = (outlineItems && outlineItems.length ? outlineItems : outlineBeatSegments(chapterContract.chapterOutline || '').slice(0, 10)).map(x => String(x));
  const beatLedger = {}, pieceScene = [], beatRepaired = [];
  let beatChecks = 0;
  const beatCheckOn = deps.sceneBeatCheck !== false && deps.outlineComplete === true && !!outlineMap && itemsAll.length > 0;
  const sceneOwnItems = sc => beatCheckOn ? (Array.isArray(sc && sc.outlineItems) ? sc.outlineItems : []).filter(n => n >= 1 && n <= itemsAll.length).map(n => ({ n, text: itemsAll[n - 1] })) : [];
  const checkBeats = async (items, txt, model, scope) => {
    try {
      const r = await callAI(buildBeatEvidencePrompt({ items, text: txt, scope }), { maxTokens: Math.min(1400, 160 + 130 * items.length), temperature: 0.1, modelOverride: deps.sceneReviewModel || model, streaming: false });
      const pr = parseBeatEvidence(r && r.text, items.map(x => x.n), txt); beatChecks++;
      return pr;
    } catch (e) { if (deps.warn) deps.warn('[AdaptiveScene] beat evidence failed', e && e.message); return null; }
  };
  const recordLedger = (pr, sceneId) => { (pr && pr.results || []).forEach(x => { beatLedger[x.n] = { done: x.done, evidence: x.evidence, sceneId }; }); };
  const maxSceneRetries = deps.sceneRetries == null ? 1 : Math.max(0, Math.min(2, Number(deps.sceneRetries) || 0));
  let usedNsfw = !!o.usingNsfw, lastRoute = { model: o.model, nsfw: !!o.usingNsfw }, timedOut = false;
  let previousTail = priorChapters.length
    ? String(priorChapters[priorChapters.length - 1].text || '').slice(-900)
    : '';
  for (let i = 0; i < graph.scenes.length; i++) {
    const scene = graph.scenes[i];
    if (countWords(pieces.join('\n\n')) >= limits.maxAccept) break;
    if (pieces.length && timeLeft() < minSceneMs) { timedOut = true; break; }
    const route = deps.route(scene, o, previousTail);
    const _own = sceneOwnItems(scene);
    lastRoute = route;
    if (route.nsfw && !usedNsfw) { usedNsfw = true; if (deps.onNsfw) { try { deps.onNsfw(scene, route); } catch (_) {} } }
    // V14.0.16: KIỂM TRA TỪNG SCENE ngay sau khi viết. Lỗi nặng -> viết lại ĐÚNG scene này (tối đa sceneRetries lần), không ghép scene sai vào chương.
    /* V14.3.8: model viết scene ngắn hơn ngân sách (thường chỉ 75–90%) nên chương luôn phải bù từ SAU câu kết. Nâng mục tiêu trong PROMPT theo tỉ lệ đạt được của các scene trước (tối đa x1,35); kiểm tra vẫn dùng mục tiêu gốc. */
    const _boost = (deps.sceneTargetBoost !== false && ratioN) ? Math.min(1.35, Math.max(1, 1 / Math.max(0.6, ratioSum / ratioN))) : 1;
    const pScene = _boost > 1.05 ? Object.assign({}, scene, { targetWords: Math.round(scene.targetWords * _boost) }) : scene;
    const sceneT0 = Date.now(), sceneMetric = { sceneId: scene.id, outlineItems: Array.isArray(scene.outlineItems) ? scene.outlineItems.slice() : [], targetWords: Number(scene.targetWords) || 0, attempts: 0, retries: 0, inputChars: 0, outputWords: 0, status: 'running', errors: [], patched: false, aiReviews: 0 };
    let correction = '', accepted = null, skipScene = false, lastErrors = [], sceneTries = 0, lastText = '', lastAiOnly = false, bestAiOnly = null, beatChecked = false;
    for (let sa = 0; sa <= maxSceneRetries; sa++) {
      if (sa > 0 && timeLeft() < minSceneMs) break;
      sceneTries++;
      sceneMetric.attempts = sceneTries; sceneMetric.retries = Math.max(0, sceneTries - 1);
      const prompt = buildAdaptiveSceneWritePrompt({
        state: st, scene: pScene, chapterGoal: graph.chapterGoal,
        endingAnchor: graph.endingAnchor, previousTail,
        isOpeningScene: i === 0 && !!priorChapters.length,
        stateDelta: sceneStates.length ? sceneStates[sceneStates.length - 1] : null,
        requiredBeats,
        sceneScope: deps.sceneScope === false ? null : sceneScopeOf(graph.scenes, i, chapterContract.outlineMeta, itemsAll),
        prevScene: i > 0 && deps.sceneBridge !== false ? graph.scenes[i - 1] : null,
        allowedCast: chapterContract.allowedCharacters.join(', '),
        forbiddenDrift: chapterContract.forbiddenDrift.join(' '), chapterContract,
        isFinalScene: i === graph.scenes.length - 1,
        style: deps.style(route.nsfw),
        correction
      });
      sceneMetric.inputChars += prompt.length;
      let text;
      try {
        const r = await callAI(prompt, {
          maxTokens: Math.min(3600, Math.max(1100, Math.ceil(pScene.targetWords * 1.9))),
          temperature: Math.max(0.5, (route.nsfw ? 0.78 : 0.72) - (sa ? 0.1 : 0)),
          modelOverride: route.model,
          systemPrompt: SCENE_SYSTEM_PROMPT,
          frequency_penalty: 0.22,
          presence_penalty: 0.18,
          streaming: false
        });
        text = formatParagraphs(stripForeign(stripSceneLeaks(stripThinkingOutput(String(r && r.text || ''))))).trim();
        sceneMetric.outputWords = Math.max(sceneMetric.outputWords, countWords(text));
        if (detectNonVietnamese(text)) text = stripForeign(text);
        // V14.0.8: scene viết LẠI đoạn đã có (model mở đầu lại cùng một cảnh) -> cắt phần lặp, giống đường viết tiếp của writer cũ.
        if (pieces.length) { const d = dropRepeatedParagraphs(pieces.join('\n\n'), text); if (d.length < text.length) { dupDropped++; text = d.trim(); if (countWords(text) < 80) { skipScene = true; break; } } }
        { const tr = trimDanglingSceneEnd(text); if (tr !== text && countWords(tr) >= 80) { if (!danglingTrimmed.includes(scene.id)) danglingTrimmed.push(scene.id); text = tr; } }
      } catch (e) {
        sceneMetric.errors.push(String(e && e.message || 'scene API error').slice(0, 240));
        if (deps.warn) deps.warn('[AdaptiveScene] scene failed', scene.id, e && e.message);
        // V14.5.5: giữ thông báo lỗi API thật; lỗi tạm thời (timeout/5xx/429...) -> thử lại CHÍNH scene này thay vì hủy cả job.
        if (deps.onSceneError) { try { deps.onSceneError(scene.id, e && e.message); } catch (_) {} }
        if (sa < maxSceneRetries && timeLeft() > minSceneMs) continue;
        return null;
      }
      const chk = checkSceneQuality(text, scene, { contract: chapterContract, isFinal: i === graph.scenes.length - 1, endingAnchor: graph.endingAnchor });
      let errors = chk.errors.slice(), warns = chk.warnings.slice();
      lastText = text; lastAiOnly = !errors.length;
      /* V14.3.2: scene kể LẠI sự kiện của scene trước (khác câu chữ) -> viết lại. Không phải lỗi cứng: hết lượt thì giữ bản cuối + cảnh báo (như lỗi chỉ do AI rà), không hủy job. */
      let overlapErr = '';
      if (!errors.length && pieces.length && deps.sceneOverlapCheck !== false) {
        const ov = sceneParaphraseOverlap(pieces.join('\n\n'), text);
        if (ov.hit >= 3 && ov.hit / Math.max(1, ov.total) >= 0.3) overlapErr = 'LẶP SCENE TRƯỚC: ' + ov.hit + '/' + ov.total + ' đoạn kể lại sự kiện đã có ở scene trước (chỉ khác cách diễn đạt). Viết lại: chỉ làm checklist riêng của scene này và tiến sang diễn biến MỚI, không nhắc lại chi tiết cũ.';
      }
      /* V14.3.3: scene < 60% ngân sách -> viết lại (mềm, không hủy job; lượt cuối nhận bản đó và để bước bù từ lo). Trước đây phần thiếu bị bù bằng top-up NỐI SAU CÂU KẾT chương. */
      let shortErr = '';
      { const sT = Number(scene.targetWords) || 0, sW = countWords(text);
        if (!errors.length && !overlapErr && deps.sceneShortRetry !== false && sT >= 600 && sW >= 80 && sW < sT * 0.6 && sa < maxSceneRetries && timeLeft() > minSceneMs)
          shortErr = 'scene quá ngắn (' + sW + '/' + sT + ' từ). Viết lại dài ít nhất ' + Math.round(sT * 0.85) + ' từ: mỗi mục trong checklist là một cảnh đầy đủ (hành động, lời thoại, phản ứng, chi tiết giác quan), không tóm tắt, không dồn vào vài câu.'; }
      if (overlapErr || shortErr) errors = [overlapErr || shortErr];
      /* V14.5.9: BƯỚC 2 — AI trích câu bằng chứng cho từng mục Outline được giao cho scene này; mục thiếu -> lỗi vá-được (chèn cục bộ). */
      if (!errors.length && _own.length && timeLeft() > minSceneMs / 2) {
        const bc = await checkBeats(_own, text, route.model, 'scene');
        if (bc) {
          beatChecked = true; recordLedger(bc, scene.id);
          if (bc.missing.length) errors = [beatMissingError(bc.missing.map(n => itemsAll[n - 1]))];
        } else warns.push('kiểm tra bằng chứng sự kiện Outline không đọc được — để bước chốt cuối chương xử lý');
      }
      if (!errors.length && deps.sceneAiReview && timeLeft() > minSceneMs / 2) {
        try {
          const rv = await callAI(buildSceneReviewPrompt({ scene, text, chapterContract, nextScene: graph.scenes[i + 1] }), {
            maxTokens: 500, temperature: 0.1, modelOverride: deps.sceneReviewModel || route.model, streaming: false
          });
          const parsed = parseSceneReviewResponse(rv && rv.text);
          sceneAiReviews++;
          sceneMetric.aiReviews++;
          if (parsed) {
            errors = parsed.errors.slice(); warns = warns.concat(parsed.warnings);
            if (parsed.ok === false && !parsed.errors.length && !parsed.warnings.length) warns.push('rà AI báo ok=false nhưng không nêu lý do — scene được coi là đạt, nên đọc lại');
          } else warns.push('rà AI trả phản hồi không đọc được (JSON hỏng/rỗng) — scene này CHƯA được rà');
        } catch (e) { if (deps.warn) deps.warn('[AdaptiveScene] scene review failed', scene.id, e && e.message); }
      }
      if (!errors.length) { accepted = text; warns.forEach(w => pushSceneWarn(scene.id + ': ' + w)); break; }
      lastErrors = errors;
      if (lastAiOnly && errors.length) bestAiOnly = { text, errors: errors.slice() }; // bản vượt kiểm tra cứng, chỉ bị AI rà chê: dự phòng nếu lượt viết lại sau đó hỏng kiểm tra cứng
      /* V14.3.7: lỗi chỉ do AI rà và vá-được (MUST_CHANGE/LOCATION_TIME) -> VÁ CỤC BỘ NGAY (1 lời gọi, chèn ≤320 từ) thay vì viết lại cả scene (viết lại tốn 3–5 lời gọi và hay sinh lỗi mới). */
      if (deps.scenePatchFirst !== false && lastAiOnly && deps.sceneAiPatch !== false && sceneErrorsPatchable(errors) && sa < maxSceneRetries && countWords(text) >= 80) break;
      if (sa < maxSceneRetries) { sceneRetries++; if (!sceneRewritten.includes(scene.id)) sceneRewritten.push(scene.id); }
      correction = errors.join(' | ');
    }
    if (skipScene) continue;
    /* V14.3: scene hết lượt viết lại mà CHỈ bị AI rà báo lỗi vá-được (MUST_CHANGE / LOCATION_TIME) -> thử VÁ CỤC BỘ (chèn vài câu), rà lại một lần.
       Vá xong qua rà -> nhận; vá được nhưng AI vẫn chê -> giữ bản đã vá + cảnh báo; không vá được -> giữ bản viết cuối như V14.2.4. */
    let patchNote = '', rollbackNote = '';
    // V14.3: lượt viết lại làm scene HỎNG kiểm tra cứng (vd lẫn nhân vật ngoài cast) trong khi bản trước chỉ bị AI rà chê -> quay về bản trước (kèm cảnh báo) thay vì hủy cả job.
    if (accepted === null && !skipScene && !lastAiOnly && bestAiOnly && deps.keepAiOnlyRejected !== false) {
      rollbackNote = 'lượt viết lại sau hỏng: ' + String(lastErrors[0] || '').slice(0, 80) + ' → dùng lại bản trước';
      lastText = bestAiOnly.text; lastErrors = bestAiOnly.errors; lastAiOnly = true;
    }
    if (accepted === null && lastText && lastAiOnly && deps.sceneAiPatch !== false && (deps.sceneAiReview || beatChecked) && countWords(lastText) >= 80 && sceneErrorsPatchable(lastErrors) && timeLeft() > minSceneMs / 2) {
      try {
        const _beatFix = lastErrors.some(e => /SỰ KIỆN BẮT BUỘC/.test(String(e)));
        const pr = await callAI(buildSceneFixPrompt({ scene, text: lastText, errors: lastErrors, maxAdd: _beatFix ? 520 : undefined, profile: sceneProfileBlock(st, scene, chapterContract.allowedCharacters) }), {
          maxTokens: _beatFix ? 1500 : 900, temperature: 0.3, modelOverride: route.model, streaming: false
        });
        const fx = applySceneFixInserts(lastText, stripThinkingOutput(String(pr && pr.text || '')), _beatFix ? 520 : undefined);
        if (!fx.ok) patchNote = 'vá cục bộ không thành: ' + fx.reason;
        else {
          const chk2 = checkSceneQuality(fx.text, scene, { contract: chapterContract, isFinal: i === graph.scenes.length - 1, endingAnchor: graph.endingAnchor });
          if (chk2.errors.length) patchNote = 'bản vá bị loại: ' + chk2.errors[0];
          else {
            let errs2 = [];
            if (beatChecked && _own.length && timeLeft() > minSceneMs / 2) {
              const bc2 = await checkBeats(_own, fx.text, route.model, 'scene');
              if (bc2) { recordLedger(bc2, scene.id); if (bc2.missing.length) errs2 = [beatMissingError(bc2.missing.map(n => itemsAll[n - 1]))]; }
            } else if (timeLeft() > minSceneMs / 2) {
              try {
                const rv2 = await callAI(buildSceneReviewPrompt({ scene, text: fx.text, chapterContract, nextScene: graph.scenes[i + 1] }), { maxTokens: 500, temperature: 0.1, modelOverride: deps.sceneReviewModel || route.model, streaming: false });
                const p2 = parseSceneReviewResponse(rv2 && rv2.text); sceneAiReviews++;
                if (p2) errs2 = p2.errors.slice();
              } catch (e) { if (deps.warn) deps.warn('[AdaptiveScene] scene re-review failed', scene.id, e && e.message); }
            }
            scenePatched.push(scene.id);
            if (!errs2.length) { accepted = fx.text; pushSceneWarn(scene.id + ': ĐÃ VÁ CỤC BỘ (+' + fx.added + ' từ) sau ' + sceneTries + ' lượt viết' + (rollbackNote ? ' (' + rollbackNote + ')' : '') + ' — lỗi AI rà: ' + lastErrors.join(' | ').slice(0, 220), true); }
            else { accepted = fx.text; lastErrors = errs2; patchNote = 'đã vá (+' + fx.added + ' từ) nhưng AI vẫn báo: ' + errs2.join(' | ').slice(0, 420); }
          }
        }
      } catch (e) { patchNote = 'vá cục bộ lỗi: ' + (e && e.message || 'không rõ'); if (deps.warn) deps.warn('[AdaptiveScene] scene patch failed', scene.id, e && e.message); }
    }
    /* V14.2.4: scene hết lượt viết lại mà CHỈ bị AI rà báo (kiểm tra cứng cục bộ đã qua: đủ độ dài, không lặp, không lẫn ngoại ngữ) -> GIỮ bản viết cuối kèm cảnh báo,
       thay vì hủy cả job nháp (mất mọi scene đã viết). AI rà hay bắt lỗi quá chi tiết (vd thiếu một chi tiết cụ thể trong Contract); người dùng sửa tay hoặc 🔍 Duyệt lại sau. */
    if (accepted !== null && patchNote) {
      sceneKept.push(scene.id);
      pushSceneWarn(scene.id + ': GIỮ BẢN CUỐI dù AI rà báo (' + sceneTries + ' lượt, ' + patchNote + (rollbackNote ? '; ' + rollbackNote : '') + ')', true);
    } else if (accepted === null && lastText && lastAiOnly && deps.keepAiOnlyRejected !== false && countWords(lastText) >= 80) {
      accepted = lastText; sceneKept.push(scene.id);
      pushSceneWarn(scene.id + ': GIỮ BẢN CUỐI dù AI rà báo (' + sceneTries + ' lượt' + ([patchNote, rollbackNote].filter(Boolean).length ? ', ' + [patchNote, rollbackNote].filter(Boolean).join('; ') : '') + '): ' + (lastErrors.join(' | ') || 'scene không đạt rà AI').slice(0, 480), true);
    }
    if (accepted === null) { sceneMetric.status = 'rejected'; sceneMetric.errors = sceneMetric.errors.concat(lastErrors.map(x => String(x).slice(0, 240))).slice(0, 6); sceneMetric.durationMs = Date.now() - sceneT0; sceneTelemetry.push(sceneMetric); return { rejected: true, reason: 'SCENE_REJECTED ' + scene.id + (sceneTries > 1 ? ' (sau ' + sceneTries + ' lượt viết)' : '') + ': ' + (lastErrors.join(' | ') || 'scene không đạt kiểm tra') }; }
    pieces.push(accepted); pieceScene.push(i);
    sceneMetric.status = sceneKept.includes(scene.id) ? 'kept_with_warning' : (scenePatched.includes(scene.id) ? 'patched' : 'accepted');
    sceneMetric.patched = scenePatched.includes(scene.id); sceneMetric.outputWords = countWords(accepted); sceneMetric.errors = lastErrors.slice(0, 6).map(x => String(x).slice(0, 240)); sceneMetric.durationMs = Date.now() - sceneT0; sceneTelemetry.push(sceneMetric);
    if (Number(scene.targetWords) > 0) { ratioSum += countWords(accepted) / Number(scene.targetWords); ratioN++; }
    previousTail = accepted.slice(-1200);
    sceneStates.push({
      sceneId: scene.id, location: scene.location, time: scene.time,
      characters: scene.characters, mustChange: scene.mustChange,
      handoff: scene.handoff
    });
  }
  const clean = typeof deps.clean === 'function' ? deps.clean : (t => t);
  let text = clean(pieces.join('\n\n').trim()).trim();
  let wc = countWords(text), topUpAttempts = 0, topUpFails = 0;
  const wordsAfterScenes = wc, wordsBeforeClean = countWords(pieces.join(' '));
  /* V14.5.9: BƯỚC 3 — chốt cuối chương bằng SỔ BẰNG CHỨNG (không dùng đối chiếu từ khóa). Mục chưa có bằng chứng -> hỏi AI một lần trên cả chương;
     mục vẫn thiếu -> chèn đúng vào scene được giao (trước đoạn kết) thay vì nối thêm sau câu kết. null = không dùng sổ (tắt/không có Outline/AI lỗi). */
  let ledgerMiss = null;
  if (deps.beatLedger !== false && deps.outlineComplete === true && itemsAll.length) {
    const unresolved = itemsAll.map((_, k) => k + 1).filter(n => !(beatLedger[n] && beatLedger[n].done));
    ledgerMiss = [];
    if (unresolved.length && timeLeft() > minTopUpMs / 2) {
      const cr = await checkBeats(unresolved.map(n => ({ n, text: itemsAll[n - 1] })), text, lastRoute.model, 'chapter');
      if (cr) { recordLedger(cr, 'chapter'); ledgerMiss = cr.missing.slice(); }
      else pushSceneWarn('chương: không đọc được kết quả kiểm tra bằng chứng sự kiện Outline — bỏ qua bước bù sự kiện');
    }
    if (ledgerMiss.length && deps.beatRepair !== false) {
      const groups = {};
      ledgerMiss.forEach(n => {
        let si = graph.scenes.findIndex(sc => Array.isArray(sc.outlineItems) && sc.outlineItems.includes(n));
        let pi = si >= 0 ? pieceScene.indexOf(si) : -1;
        if (pi < 0) { pi = pieces.length - 1; si = pi >= 0 ? pieceScene[pi] : -1; }
        if (pi >= 0) (groups[pi] = groups[pi] || { si, ns: [] }).ns.push(n);
      });
      for (const key of Object.keys(groups)) {
        const gr = groups[key], pi = Number(key), room = Math.min(520, limits.hardMax - 60 - countWords(pieces.join(' ')));
        if (room < 120 || timeLeft() < minTopUpMs / 2) break;
        try {
          const sceneObj = graph.scenes[gr.si] || {};
          const pr = await callAI(buildSceneFixPrompt({ scene: sceneObj, text: pieces[pi], errors: [beatMissingError(gr.ns.map(n => itemsAll[n - 1]))], maxAdd: room, profile: sceneProfileBlock(st, sceneObj, chapterContract.allowedCharacters) }), { maxTokens: 1500, temperature: 0.3, modelOverride: lastRoute.model, streaming: false });
          const fx = applySceneFixInserts(pieces[pi], stripThinkingOutput(String(pr && pr.text || '')), room);
          if (!fx.ok) { pushSceneWarn((sceneObj.id || 'scene') + ': chèn sự kiện thiếu không thành: ' + fx.reason); continue; }
          const chk3 = checkSceneQuality(fx.text, sceneObj, { contract: chapterContract });
          if (chk3.errors.length) { pushSceneWarn((sceneObj.id || 'scene') + ': bản chèn sự kiện bị loại: ' + chk3.errors[0]); continue; }
          const rc = await checkBeats(gr.ns.map(n => ({ n, text: itemsAll[n - 1] })), fx.text, lastRoute.model, 'scene');
          if (rc) recordLedger(rc, sceneObj.id || 'repair');
          pieces[pi] = fx.text; beatRepaired.push((sceneObj.id || 'scene') + ':' + gr.ns.join(','));
          pushSceneWarn((sceneObj.id || 'scene') + ': ĐÃ CHÈN sự kiện Outline còn thiếu (mục ' + gr.ns.join(', ') + ', +' + fx.added + ' từ)', true);
        } catch (e) { if (deps.warn) deps.warn('[AdaptiveScene] beat repair failed', e && e.message); }
      }
      if (beatRepaired.length) { text = clean(pieces.join('\n\n').trim()).trim(); wc = countWords(text); }
      ledgerMiss = itemsAll.map((_, k) => k + 1).filter(n => !(beatLedger[n] && beatLedger[n].done) && ledgerMiss.includes(n));
    }
  }
  // V13.2: Adaptive Scene không được kết thúc dưới minAccept. Top-up chỉ gửi đuôi + state delta,
  // không gửi lại toàn bộ chương; chỉ kích hoạt khi các scene ban đầu bị model trả thiếu.
  // V14.0.9: (1) đếm từ SAU khi dọn (cắt lặp/rò tiếng Anh) để không "đủ 4.500" rồi tụt xuống 4.100 ở bước dọn cuối;
  // (2) nhắm minAccept + đệm (bước khép câu cuối/khóa độ dài có thể bớt vài chục từ); (3) lượt bù hỏng (quá ngắn/lặp/không tăng)
  // không làm dừng ngay — chỉ dừng sau 2 lượt hỏng LIÊN TIẾP; tối đa 8 lượt.
  const buffer = Math.min(200, Math.max(0, limits.maxAccept - limits.minAccept - 100));
  const goal = limits.minAccept + buffer;
  /* V14.4.4: sự kiện chính của Outline phải có ĐỦ trong chương. Nếu đối chiếu từ khóa thấy beat còn thiếu thì chạy tối đa 2 lượt bù RIÊNG cho beat đó, kể cả khi chương đã đủ từ. Bật bằng deps.outlineComplete === true. */
  const _castNames = [].concat(chapterContract.allowedCharacters || [], chapterContract.canonicalCharacters || []);
  let completionAttempts = 0;
  while (topUpAttempts < 8 && topUpFails < 2) {
    const miss = ledgerMiss ? ledgerMiss.map(n => itemsAll[n - 1]) : (deps.outlineComplete === true ? outlineMissingBeats(chapterContract.chapterOutline, text, _castNames) : []);
    const needLen = wc < goal, needBeats = miss.length > 0 && completionAttempts < 2 && wc + 300 <= limits.maxAccept;
    if (!needLen && !needBeats) break;
    if (timeLeft() < minTopUpMs) { timedOut = true; break; }
    if (needBeats) completionAttempts++;
    const needWords = needLen ? Math.min(1800, goal - wc) : Math.min(700, Math.max(350, limits.maxAccept - wc - 150));
    const topUpPrompt = buildAdaptiveSceneTopUpPrompt({
      state: st, currentWords: wc, needWords, missingBeats: needBeats ? miss : null, completeOnly: !needLen, chapterGoal: graph.chapterGoal,
      endingAnchor: graph.endingAnchor, previousTail: text.slice(-2400),
      stateDelta: sceneStates.length ? sceneStates[sceneStates.length - 1] : null,
      requiredBeats, doneList: deps.sceneScope === false ? null : sceneScopeOf(graph.scenes, graph.scenes.length).done, allowedCast: chapterContract.allowedCharacters.join(', '),
      forbiddenDrift: chapterContract.forbiddenDrift.join(' '), chapterContract, style: deps.style(lastRoute.nsfw)
    });
    topUpAttempts++;
    try {
      const r = await callAI(topUpPrompt, {
        maxTokens: Math.min(4200, Math.max(1800, Math.ceil(needWords * 2.1) + 450)),
        temperature: lastRoute.nsfw ? 0.76 : 0.70, modelOverride: lastRoute.model,
        frequency_penalty: 0.22, presence_penalty: 0.18, streaming: false
      });
      let extra = formatParagraphs(stripForeign(stripSceneLeaks(stripThinkingOutput(String(r && r.text || ''))))).trim();
      if (detectNonVietnamese(extra)) extra = stripForeign(extra);
      { const d = dropRepeatedParagraphs(text, extra); if (d.length < extra.length) { dupDropped++; extra = d.trim(); } }
      if (countWords(extra) < 80) { topUpFails++; continue; }
      if (needBeats) { const ov = sceneParaphraseOverlap(text, extra); if (ov.hit >= 3 && ov.hit / Math.max(1, ov.total) >= 0.3) { topUpFails++; continue; } }
      const extraCheck = validateSceneTextAgainstContract(extra, chapterContract);
      if (!extraCheck.ok) return { rejected: true, reason: 'TOPUP_REJECTED: ' + extraCheck.errors.join(' | ') };
      const before = wc;
      const merged = clean((text ? text + '\n\n' + extra : extra).trim()).trim();
      const mergedWc = countWords(merged);
      if (mergedWc <= before) { topUpFails++; continue; }
      text = merged; wc = mergedWc; topUpFails = 0;
      if (needBeats && ledgerMiss && ledgerMiss.length) { // kiểm tra lại đúng phần vừa viết; không đọc được -> coi như đã bù để khỏi lặp sự kiện
        const rc2 = await checkBeats(ledgerMiss.map(n => ({ n, text: itemsAll[n - 1] })), extra, lastRoute.model, 'scene');
        if (rc2) { recordLedger(rc2, 'topup'); ledgerMiss = ledgerMiss.filter(n => !(beatLedger[n] && beatLedger[n].done)); } else ledgerMiss = [];
      }
      previousTail = text.slice(-1200);
      sceneStates.push({ sceneId: 'TOPUP' + topUpAttempts, handoff: 'Đã bổ sung ' + (wc - before) + ' từ; tiếp tục nếu còn thiếu.' });
    } catch (e) {
      if (deps.warn) deps.warn('[AdaptiveScene] top-up failed', e && e.message);
      topUpFails++;
    }
  }
  const underTarget = wc < limits.minAccept;
  const outlineMissing = ledgerMiss ? ledgerMiss.map(n => itemsAll[n - 1].slice(0, 90)) : deps.outlineCheck === false ? [] : outlineMissingBeats(chapterContract.chapterOutline, text, [].concat(chapterContract.allowedCharacters || [], chapterContract.canonicalCharacters || []));
  const beatLedgerOut = {}; Object.keys(beatLedger).forEach(k => { beatLedgerOut[k] = { done: !!beatLedger[k].done, sceneId: beatLedger[k].sceneId, evidence: String(beatLedger[k].evidence || '').slice(0, 120) }; });
  const stats = { beatLedger: beatLedgerOut, beatChecks, beatRepaired, outlineMissing, outlineMap, scenes: pieces.length, plannedScenes: graph.scenes.length, topUpAttempts, dupDropped, sceneRetries, sceneRewritten, sceneWarnings, sceneKept, scenePatched, danglingTrimmed, sceneAiReviews, sceneTelemetry, strippedCast, addedCast, wordsAfterScenes, wordsBeforeClean, words: wc, seconds: Math.round((Date.now() - t0) / 1000) };
  return { text, plan: 'V14 CHAPTER CONTRACT\n' + JSON.stringify(promptChapterContract(chapterContract)) + '\nADAPTIVE SCENE GRAPH\n' + JSON.stringify(Object.assign({}, graph, { requiredBeats, topUpAttempts })), underTarget, usedNsfw, timedOut, stats };
}

/* ========== V14.0.15 — Canon Diff / Gợi ý nhân vật / Sức khỏe truyện / Rà mâu thuẫn / Telemetry ========== */
const CANON_DIFF_CHAR_FIELDS = ["tier","age","gender","maritalStatus","spouseName","role","position","occupation","faction","appearance","personality","goals","secret","weakness","fear","knowledge","speech","strength","independentPlot","currentLocation","physicalState","mentalState","height","bodyType","hair","eyes","skin","scars","tattoos","dead","lastAppearance"];
function _cdVal(v) { if (v === undefined || v === null) return ""; if (typeof v === "boolean") return v ? "true" : ""; return String(v); }
function _cdClip(v, n) { v = _cdVal(v); return v.length > n ? v.slice(0, n) + "…" : v; }
/* So sánh Character/World trước & sau hậu kỳ. `from` giữ NGUYÊN GIÁ TRỊ CŨ (tối đa 3000 ký tự) để có thể hoàn tác từng trường. */
function computeCanonDiff(before, after) {
  const out = { characters: [], locations: [], items: [], threads: [], at: Date.now() };
  const key = (x, k) => (x && (x.id || normalizeName(x[k || "name"]))) || "";
  const byKey = (arr, k) => { const m = new Map(); (Array.isArray(arr) ? arr : []).forEach(x => { const kk = key(x, k); if (kk) m.set(kk, x); }); return m; };
  const bC = byKey(before && before.characters), aC = Array.isArray(after && after.characters) ? after.characters : [];
  aC.forEach(c => {
    if (!c || !c.name) return;
    const old = bC.get(key(c));
    if (!old) { out.characters.push({ kind: "added", id: c.id, name: c.name, tier: c.tier || "", changes: [] }); return; }
    const changes = [];
    CANON_DIFF_CHAR_FIELDS.forEach(f => {
      const a = _cdVal(c[f]), b = _cdVal(old[f]);
      if (a !== b && !(f === "lastAppearance" && !a)) changes.push({ field: f, from: b.length > 3000 ? b.slice(0, 3000) : b, to: _cdClip(a, 400), fromClipped: b.length > 3000 });
    });
    const relB = (old.relationships || []).length, relA = (c.relationships || []).length;
    if (relA !== relB) changes.push({ field: "relationships", from: String(relB), to: String(relA), info: true });
    const hB = (old.history || []).length, hA = (c.history || []).length;
    if (hA > hB) changes.push({ field: "history", from: String(hB), to: String(hA), info: true });
    const meaningful = changes.filter(x => x.field !== "lastAppearance" && !x.info);
    if (changes.length) out.characters.push({ kind: "updated", id: c.id, name: c.name, changes, meaningful: meaningful.length });
  });
  const listDiff = (bArr, aArr, k, target) => {
    const bm = byKey(bArr, k);
    (Array.isArray(aArr) ? aArr : []).forEach(x => {
      if (!x) return; const kk = key(x, k), old = bm.get(kk), nm = x[k || "name"];
      if (!old) target.push({ kind: "added", name: _cdClip(nm, 120) });
      else if (_cdVal(old.status) !== _cdVal(x.status) || _cdVal(old.description) !== _cdVal(x.description) || _cdVal(old.owner) !== _cdVal(x.owner)) target.push({ kind: "updated", name: _cdClip(nm, 120), from: _cdClip(old.status, 40), to: _cdClip(x.status, 40) });
    });
  };
  listDiff(before && before.locations, after && after.locations, "name", out.locations);
  listDiff(before && before.items, after && after.items, "name", out.items);
  listDiff(before && before.threads, after && after.threads, "desc", out.threads);
  out.counts = { charsAdded: out.characters.filter(x => x.kind === "added").length, charsUpdated: out.characters.filter(x => x.kind === "updated").length, locations: out.locations.length, items: out.items.length, threads: out.threads.length };
  return out;
}
/* Hoàn tác một mục trong canonDiff trên `st` (state). Trả {ok, msg}. */
function undoCanonDiffItem(st, item, field) {
  if (!st || !item) return { ok: false, msg: "thiếu dữ liệu" };
  const list = st.characters || [];
  const idx = list.findIndex(c => c && ((item.id && c.id === item.id) || normalizeName(c.name) === normalizeName(item.name)));
  if (item.kind === "added") {
    if (idx < 0) return { ok: false, msg: "nhân vật không còn trong Database" };
    list.splice(idx, 1); return { ok: true, msg: "Đã gỡ nhân vật “" + item.name + "”" };
  }
  if (idx < 0) return { ok: false, msg: "nhân vật không còn trong Database" };
  const ch = (item.changes || []).find(x => x.field === field);
  if (!ch || ch.info) return { ok: false, msg: "trường này không hoàn tác được" };
  if (ch.fromClipped) return { ok: false, msg: "giá trị cũ quá dài, không hoàn tác tự động" };
  const c = list[idx];
  if (field === "dead") c.dead = ch.from === "true";
  else if (field === "lastAppearance") c.lastAppearance = ch.from === "" ? null : Number(ch.from);
  else c[field] = ch.from;
  return { ok: true, msg: "Đã trả “" + field + "” của " + item.name + " về giá trị cũ" };
}

/* ----- Hộp thư nhân vật gợi ý: tên riêng lặp lại nhưng chưa có trong Database ----- */
const NAME_SUGGEST_STOP = new Set(["viet nam","ha noi","sai gon","ho chi minh","da nang","hai phong","can tho","hue","trung quoc","nhat ban","han quoc","my","thu hai","thu ba","thu tu","thu nam","thu sau","thu bay","chu nhat","tet nguyen dan","nguyen dan","giang sinh","ban than","bo gia","ngay hom"]);
const NAME_SUGGEST_HONORIFIC = /^(ong|ba|co|anh|chi|em|chu|di|bac|thay|cau|mo|cu|thim|duong|gi)$/;
// V14.0.20 post-audit: tên công pháp / cảnh giới / thuật ngữ tu luyện (tu tiên, huyền huyễn, võ hiệp) không phải tên người.
// Chỉ lọc khi truyện thật sự thuộc thể loại này (xem nameSuggestCultivationMode) để không làm mất tên người ở truyện khác (vd. "Nguyên Anh" là tên con gái).
const NAME_SUGGEST_REALMS = ["luyen khi","truc co","ket dan","kim dan","ngung dan","nguyen anh","hoa than","luyen hu","hop the","dai thua","do kiep","phan than","xuat khieu","ngung mach","khai mach","tich coc","tien thien","hau thien","dia tien","thien tien","chan tien","huyen tien","kim tien","dau ky","dau su","dai dau su","dau vuong","dau hoang","dau ton","dau thanh","dau de","tong su","dai tong su"];
const NAME_SUGGEST_CONCEPT_HEAD = ["canh gioi","cong phap","tam phap","phap quyet","bi kip","bi tich","than thong","tu vi","linh can","linh khi","linh luc","chan khi","chan nguyen","kiem phap","than phap","quyen phap","dan duoc","phap bao","linh thach","linh dan","dai dao"];
const NAME_SUGGEST_TECH_SUFFIX = new Set(["quyết","công","pháp","kinh","thuật","chưởng","quyền","kiếm","trảo","trận","điển","đạo","phù","đan"]);
// Họ phổ biến (kể cả họ kiểu Trung): cụm 3 chữ bắt đầu bằng họ + kết thúc bằng từ như "Quyết/Công" vẫn có thể là TÊN NGƯỜI (vd. "Nguyễn Văn Công") nên không lọc.
const NAME_SUGGEST_SURNAMES = new Set(["nguyễn","trần","lê","phạm","hoàng","huỳnh","phan","vũ","võ","đặng","bùi","đỗ","hồ","ngô","dương","lý","lâm","trương","vương","tiêu","diệp","sở","mộ","âu","tư","thượng","lục","đường","triệu","tào","chu","tống","hạ","giang","cố","mạc","từ","thẩm","bạch","hứa","tạ","lưu","mã","hàn","đinh","khương","tôn","trịnh","đào","phùng","kiều"]);
const NAME_SUGGEST_CULT_CUES = ["tu luyện","linh khí","cảnh giới","tu vi","công pháp","đan điền","tu tiên","tu sĩ","pháp bảo","linh thạch","đột phá","kinh mạch","tông môn","chân khí","linh căn"];
function nameSuggestCultivationMode(chapters, opts) {
  if (opts && /tu (tiên|chân|luyện|đạo)|tiên hiệp|huyền huyễn|kiếm hiệp|võ hiệp|xianxia|cultivation|wuxia/i.test(String(opts.genre || ""))) return true;
  let n = 0;
  (chapters || []).some(ch => {
    const t = String((ch && ch.text) || "").normalize("NFC").toLowerCase();
    for (const c of NAME_SUGGEST_CULT_CUES) { let i = -1; while ((i = t.indexOf(c, i + 1)) >= 0) { if (++n >= 6) return true; } }
    return false;
  });
  return n >= 4;
}
function nameSuggestIsConcept(raw, nk) {
  if (NAME_SUGGEST_REALMS.some(r => nk === r || nk.startsWith(r + " "))) return true;
  if (NAME_SUGGEST_CONCEPT_HEAD.some(r => nk === r || nk.startsWith(r + " "))) return true;
  const rw = String(raw || "").toLowerCase().split(" ");
  return rw.length >= 3 && NAME_SUGGEST_TECH_SUFFIX.has(rw[rw.length - 1]) && !NAME_SUGGEST_SURNAMES.has(rw[0]);
}
function suggestCharacterCandidates(chapters, knownNames, opts) {
  opts = opts || {};
  const minCount = opts.minCount || 3, maxOut = opts.max || 12;
  const known = (knownNames || []).map(normalizeName).filter(Boolean);
  const re = /\p{Lu}\p{Ll}+(?:[ \t]+\p{Lu}\p{Ll}+){1,3}/gu;
  const found = new Map();
  const cultivation = nameSuggestCultivationMode(chapters, opts);
  (chapters || []).forEach((ch, ci) => {
    const text = String((ch && ch.text) || "").normalize("NFC");
    let m; re.lastIndex = 0;
    while ((m = re.exec(text))) {
      const raw = m[0].replace(/[ \t]+/g, " ").trim(), nk = normalizeName(raw);
      if (NAME_SUGGEST_STOP.has(nk)) continue;
      const words = nk.split(" ");
      if (words.length < 2) continue;
      let rec = found.get(nk);
      if (!rec) { rec = { name: raw, count: 0, chapters: new Set(), first: ci + 1, last: ci + 1, sample: "" }; found.set(nk, rec); }
      rec.count++; rec.chapters.add(ci + 1); rec.last = ci + 1;
      if (!rec.sample) { const s = Math.max(0, m.index - 50), e = Math.min(text.length, m.index + raw.length + 70); rec.sample = text.slice(s, e).replace(/\s+/g, " ").trim(); }
    }
  });
  const out = [];
  found.forEach((rec, nk) => {
    if (rec.count < minCount && rec.chapters.size < 2) return;
    if (rec.count < 2) return;
    if (cultivation && nameSuggestIsConcept(rec.name, nk)) return;
    const covered = known.some(k => k === nk || (" " + nk + " ").includes(" " + k + " ") || (" " + k + " ").includes(" " + nk + " "));
    if (covered) return;
    const w = nk.split(" ");
    // Cụm toàn từ thường gặp ở đầu câu/tiêu đề (không có tiền tố xưng hô, không lặp qua nhiều chương) cần xuất hiện nhiều hơn.
    if (!NAME_SUGGEST_HONORIFIC.test(w[0]) && rec.chapters.size < 2 && rec.count < minCount + 2) return;
    out.push({ name: rec.name, count: rec.count, chapters: rec.chapters.size, first: rec.first, last: rec.last, sample: rec.sample });
  });
  out.sort((a, b) => (b.chapters - a.chapters) || (b.count - a.count));
  return out.slice(0, maxOut);
}

/* ----- Bảng sức khỏe truyện ----- */
function storyHealthReport(st) {
  st = st || {};
  const chapters = Array.isArray(st.chapters) ? st.chapters : [], n = chapters.length;
  const rep = { chapters: n, avgWords: 0, scores: [], absent: [], openThreads: [], staleForeshadowing: [], arc: null, castLoad: 0, alerts: [], dead: 0 };
  if (!n) return rep;
  rep.avgWords = Math.round(chapters.reduce((s, c) => s + (Number(c && c.wordCount) || countWords(c && c.text)), 0) / n);
  rep.scores = chapters.slice(-10).map((c, i) => ({ chapter: n - Math.min(10, n) + i + 1, score: c && c.review && Number.isFinite(Number(c.review.score)) ? Number(c.review.score) : null }));
  const chars = Array.isArray(st.characters) ? st.characters : [];
  rep.dead = chars.filter(c => c && c.dead).length;
  chars.forEach(c => {
    if (!c || !c.name || c.dead) return;
    if (!["major", "important", "supporting"].includes(c.tier)) return;
    const gap = c.lastAppearance == null ? null : n - Number(c.lastAppearance);
    const limit = c.tier === "supporting" ? 12 : 6;
    if (gap !== null && gap > limit) rep.absent.push({ name: c.name, tier: c.tier, gap, last: c.lastAppearance });
  });
  rep.absent.sort((a, b) => b.gap - a.gap);
  (Array.isArray(st.threads) ? st.threads : []).forEach(t => {
    if (!t || !t.desc || ["paid_off", "abandoned", "resolved"].includes(String(t.status || "").toLowerCase())) return;
    const since = Number(t.chapterIntroduced || t.firstChapter) || null, age = since ? n - since : null;
    rep.openThreads.push({ desc: String(t.desc).slice(0, 140), type: t.type || "", status: t.status || "", age });
  });
  rep.openThreads.sort((a, b) => (b.age || 0) - (a.age || 0));
  (Array.isArray(st.foreshadowing) ? st.foreshadowing : []).forEach(f => {
    if (!f || !f.description || ["paid_off", "abandoned", "resolved"].includes(String(f.status || "").toLowerCase())) return;
    const age = n - (Number(f.plantedChapter) || n);
    if (age >= 10) rep.staleForeshadowing.push({ desc: String(f.description).slice(0, 140), planted: f.plantedChapter, age });
  });
  rep.staleForeshadowing.sort((a, b) => b.age - a.age);
  const arc = (Array.isArray(st.arcs) ? st.arcs : []).find(a => a && a.status === "active");
  if (arc) {
    const start = Number(arc.startChapter) || 1, end = Number(arc.endChapterPlanned) || null, done = Math.max(0, n - start + 1);
    rep.arc = { name: arc.name || "", goal: arc.goal || "", start, end, done, pct: end && end >= start ? Math.min(150, Math.round(done / (end - start + 1) * 100)) : null };
    if (rep.arc.pct !== null && rep.arc.pct > 100) rep.alerts.push({ level: "warn", text: "Arc “" + rep.arc.name + "” đã quá kế hoạch " + (rep.arc.pct - 100) + "% — cân nhắc đóng Arc hoặc dời mốc kết." });
  } else if ((st.arcs || []).length) rep.alerts.push({ level: "info", text: "Không có Arc nào ở trạng thái active." });
  const last = chapters[n - 1], lastText = String((last && last.text) || "");
  rep.castLoad = chars.filter(c => c && c.name && !c.dead && containsNameWord(c.name, lastText)).length;
  const sc = rep.scores.filter(x => x.score !== null).map(x => x.score);
  if (sc.length >= 4) {
    const half = Math.floor(sc.length / 2), a = sc.slice(0, half), b = sc.slice(half);
    const avg = arr => arr.reduce((s, x) => s + x, 0) / arr.length;
    if (avg(b) + 4 < avg(a)) rep.alerts.push({ level: "warn", text: "Điểm chất lượng đang giảm (" + Math.round(avg(a)) + " → " + Math.round(avg(b)) + ") trong các chương gần đây." });
  }
  if (rep.absent.length) rep.alerts.push({ level: "info", text: rep.absent.length + " nhân vật quan trọng vắng mặt lâu: " + rep.absent.slice(0, 3).map(x => x.name + " (" + x.gap + " chương)").join(", ") + "." });
  if (rep.staleForeshadowing.length) rep.alerts.push({ level: "warn", text: rep.staleForeshadowing.length + " foreshadowing gieo ≥10 chương chưa trả." });
  const oldThreads = rep.openThreads.filter(t => (t.age || 0) >= 15);
  if (oldThreads.length) rep.alerts.push({ level: "warn", text: oldThreads.length + " thread mở ≥15 chương chưa đóng." });
  if (rep.avgWords && rep.avgWords < 4000) rep.alerts.push({ level: "warn", text: "Độ dài trung bình chỉ " + rep.avgWords + " từ/chương." });
  return rep;
}
function containsNameWord(name, text) {
  const hay = " " + normalizeName(text).replace(/[^\p{L}\p{N}]+/gu, " ") + " ", nd = normalizeName(name).replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  return !!nd && hay.includes(" " + nd + " ");
}

/* ----- Rà mâu thuẫn: kiểm tra bằng code (không tốn token) ----- */
function deterministicConsistencyCheck(st) {
  st = st || {};
  const issues = [], chapters = Array.isArray(st.chapters) ? st.chapters : [], chars = Array.isArray(st.characters) ? st.characters : [];
  const seen = new Map();
  chars.forEach(c => {
    if (!c || !c.name) return; const k = normalizeName(c.name);
    if (seen.has(k)) issues.push({ severity: "medium", type: "duplicate", description: "Trùng tên nhân vật “" + c.name + "” (2 hồ sơ) — nên gộp bằng 🧹 Dọn nhân vật trùng.", chapters: [] });
    seen.set(k, c);
    const age = parseFloat(String(c.age || "").replace(/[^\d.]/g, ""));
    if (c.age && Number.isFinite(age) && (age < 0 || age > 150)) issues.push({ severity: "low", type: "age", description: "Tuổi bất thường của " + c.name + ": “" + c.age + "”.", chapters: [] });
    if (c.dead) {
      const dc = Number(c.deathChapter) || 0;
      if (dc > 0) {
        const later = [];
        chapters.forEach((ch, i) => { if (i + 1 > dc && containsNameWord(c.name, String((ch && ch.text) || "")) && /\b(nói|cười|bước|nhìn|đứng|ngồi|hỏi|đáp|gật|lắc|mỉm|thở)\b/i.test(String(ch.text).slice(0, 200000))) later.push(i + 1); });
        if (later.length) issues.push({ severity: "high", type: "dead_appears", description: c.name + " đã chết ở chương " + dc + " nhưng tên vẫn xuất hiện ở chương " + later.slice(0, 6).join(", ") + " — kiểm tra hồi tưởng/nhầm lẫn.", chapters: later.slice(0, 6) });
      }
    }
    if (c.lastAppearance != null && Number(c.lastAppearance) > chapters.length && chapters.length) issues.push({ severity: "low", type: "appearance", description: c.name + " có lastAppearance " + c.lastAppearance + " > số chương hiện có.", chapters: [] });
    if (c.spouseName) {
      const sp = seen.get(normalizeName(c.spouseName)) || chars.find(x => x && normalizeName(x.name) === normalizeName(c.spouseName));
      if (sp && sp.spouseName && normalizeName(sp.spouseName) !== normalizeName(c.name)) issues.push({ severity: "medium", type: "spouse", description: c.name + " ghi người phối ngẫu là " + c.spouseName + ", nhưng " + sp.name + " lại ghi " + sp.spouseName + ".", chapters: [] });
      if (sp && /doc than/.test(normalizeName(sp.maritalStatus || ""))) issues.push({ severity: "medium", type: "spouse", description: c.name + " có người phối ngẫu/người yêu là " + sp.name + " nhưng " + sp.name + " đang ghi “độc thân”.", chapters: [] });
    }
  });
  return issues;
}
function buildChapterPostWriteAudit(st, chapterNumber) {
  st = st || {};
  const n = Math.max(1, Math.floor(Number(chapterNumber) || 1)), chapters = Array.isArray(st.chapters) ? st.chapters : [];
  const chapter = chapters[n - 1] || {}, limits = chapterWordLimits(st), words = countWords(chapter.text || "");
  const withinWordBounds = words >= limits.minAccept && words <= limits.maxAccept;
  const lengthStatus = words < limits.minAccept ? "below_min" : words > limits.maxAccept ? (words <= limits.hardMax ? "within_hard_cap" : "above_max") : "within";
  const issues = (Array.isArray(chapter.continuityWarnings) ? chapter.continuityWarnings : []).map(x => String(x && (x.description || x.message) || x).trim()).filter(Boolean);
  const consistency = deterministicConsistencyCheck(st).filter(x => !Array.isArray(x.chapters) || !x.chapters.length || x.chapters.includes(n));
  consistency.forEach(x => { const text = String(x.description || "").trim(); if (text && !issues.includes(text)) issues.push(text); });
  const statusState = st.statusState && typeof st.statusState === "object" ? st.statusState : {};
  const log = (Array.isArray(statusState.timeLog) ? statusState.timeLog : Array.isArray(st.timeLog) ? st.timeLog : [])
    .filter(x => x && x.time && (!Number(x.chapter) || Number(x.chapter) <= n));
  const norm = x => String(x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\p{L}\p{N} ]/gu, " ").replace(/\s+/g, " ").trim();
  let run = 0, mark = "";
  if (log.length) { mark = String(log[log.length - 1].time); const last = norm(mark); for (let i = log.length - 1; i >= 0 && norm(log[i].time) === last; i--) run++; }
  const timeStall = run >= 3 ? { repeatedMarks: run, time: mark, startChapter: Number(log[log.length - run].chapter) || null, endChapter: Number(log[log.length - 1].chapter) || n } : null;
  if (timeStall) issues.push(run + " chương liên tiếp cùng mốc thời gian: " + mark);
  const terminal = ["paid_off", "abandoned", "resolved", "completed"];
  const unresolvedThreads = (Array.isArray(st.threads) ? st.threads : []).filter(x => x && !terminal.includes(String(x.status || "").toLowerCase())).length;
  const unresolvedForeshadowing = (Array.isArray(st.foreshadowing) ? st.foreshadowing : []).filter(x => x && !terminal.includes(String(x.status || "").toLowerCase())).length;
  return { chapterNumber: n, checkedAt: Date.now(), wordCount: words, minWords: limits.minAccept, maxWords: limits.maxAccept, hardMax: limits.hardMax, withinWordBounds, lengthStatus, continuityIssues: issues.slice(0, 30), timeStall, unresolvedThreads, unresolvedForeshadowing };
}
/* ----- Rà mâu thuẫn bằng AI trên dữ liệu rút gọn ----- */
function buildConsistencyPrompt(st) {
  const chars = (st.characters || []).slice(0, 60).map(c => ({ name: c.name, tier: c.tier, age: c.age, gender: c.gender, role: c.role || c.occupation, married: c.maritalStatus, spouse: c.spouseName, dead: !!c.dead, deathChapter: c.deathChapter, loc: c.currentLocation, secret: String(c.secret || "").slice(0, 80) }));
  const sums = (st.chapters || []).map((c, i) => "Ch" + (i + 1) + ": " + String((c && c.summary) || "").replace(/\s+/g, " ").slice(0, 420)).join("\n");
  const tl = (st.timeline || []).slice(-40).map(x => "Ch" + x.chapter + ": " + String(x.summary || "").slice(0, 140)).join("\n");
  return [
    "RÀ MÂU THUẪN TOÀN TRUYỆN. Chỉ tìm mâu thuẫn CỤ THỂ giữa các chương/hồ sơ (tuổi, giới tính, quan hệ, ai còn sống, địa điểm, ai biết điều gì, thời gian, vật phẩm). Không phê bình văn phong, không đề xuất cốt truyện mới.",
    "Mỗi mục phải nêu rõ chương liên quan và dữ kiện đối chiếu. Không chắc thì bỏ qua. Tối đa 10 mục, ưu tiên nghiêm trọng.",
    "CHỈ trả JSON: {\"issues\":[{\"severity\":\"high|medium|low\",\"type\":\"age|gender|relationship|death|location|knowledge|timeline|item|other\",\"description\":\"\",\"chapters\":[1,2],\"evidence\":\"dữ kiện/đoạn tóm tắt đối chiếu\"}]}",
    "NHÂN VẬT:\n" + JSON.stringify(chars), "TÓM TẮT CHƯƠNG:\n" + sums, tl ? "TIMELINE GẦN ĐÂY:\n" + tl : ""
  ].filter(Boolean).join("\n\n");
}
function parseConsistencyResponse(raw) {
  let s = String(raw || "").replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim(), obj = null;
  try { obj = JSON.parse(s); } catch (_) { const a = s.indexOf("{"), b = s.lastIndexOf("}"); if (a >= 0 && b > a) { try { obj = JSON.parse(s.slice(a, b + 1)); } catch (_) {} } }
  const items = obj && Array.isArray(obj.issues) ? obj.issues : [];
  return items.filter(x => x && String(x.description || "").trim()).slice(0, 10).map(x => ({
    severity: ["high", "medium", "low"].includes(x.severity) ? x.severity : "medium", type: String(x.type || "other").slice(0, 20),
    description: String(x.description).slice(0, 400), chapters: Array.isArray(x.chapters) ? x.chapters.map(Number).filter(Number.isFinite).slice(0, 8) : [], evidence: String(x.evidence || "").slice(0, 300)
  }));
}

/* ----- Telemetry theo bước ----- */
const STEP_LABELS = { write: "Viết chương", scene: "Viết scene", plan: "Kế hoạch/Scene graph", gate: "Quality Gate", repair: "Sửa/vá", post: "Hậu kỳ", hint: "Gợi ý chương sau", check: "Kiểm tra nhanh", other: "Khác" };
function classifyStep(prompt) {
  const p = String(prompt || "").slice(0, 1500);
  const map = [
    [/SEMANTIC PROSE CHECK|RÀ MÂU THUẪN/i, "check"], [/GỢI Ý CHI TIẾT cho CHƯƠNG|NEXT HINT/i, "hint"],
    [/HẬU KỲ|CẬP NHẬT NHÂN VẬT|CHAPTER SUMMARY\/CONTENT/i, "post"], [/Quality Review|QUALITY REVIEW|chấm điểm chương|CHẤM CHƯƠNG/i, "gate"],
    [/VÁ CỤC BỘ|PATCH|SỬA THEO VÙNG|VIẾT LẠI CHƯƠNG|CHÈN THÊM DIỄN BIẾN|MỞ RỘNG CHƯƠNG|ĐỂ CHẠM ĐIỂM KẾT/i, "repair"],
    [/SCENE GRAPH|KẾ HOẠCH CHƯƠNG|CHAPTER CONTRACT/i, "plan"], [/SCENE\s*\d|VIẾT SCENE|Scene Contract/i, "scene"], [/Bạn đang viết CHƯƠNG THỨ|VIẾT TIẾP chương/i, "write"]
  ];
  for (const [re, k] of map) if (re.test(p)) return k;
  return "other";
}
function recordStepUsage(st, step, model, inTok, outTok, cost) {
  if (!st) return;
  if (!st.costByStep || typeof st.costByStep !== "object") st.costByStep = {};
  const k = STEP_LABELS[step] ? step : "other", r = st.costByStep[k] || (st.costByStep[k] = { calls: 0, tokIn: 0, tokOut: 0, cost: 0 });
  r.calls++; r.tokIn += inTok; r.tokOut += outTok; r.cost += cost;
  return r;
}
/* Model theo bước: cấu hình st.stepModels = {post:"...",gate:"...",check:"...",hint:"..."}; rỗng = dùng model chính. */
function modelForStep(st, step, fallback) {
  const m = st && st.stepModels && typeof st.stepModels[step] === "string" ? st.stepModels[step].trim() : "";
  return m || fallback;
}
/* ----- Memory phân tầng: range chương, arc và volume ----- */
function buildLayeredMemoryRanges(chapterCount, config) {
  const positiveInt = (value, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) && n >= 1 ? Math.min(1000000, Math.floor(n)) : fallback;
  };
  const rawCount = Number(chapterCount);
  const count = Number.isFinite(rawCount) ? Math.max(0, Math.floor(rawCount)) : 0;
  const cfg = config && typeof config === "object" ? config : {};
  const chunkSize = positiveInt(cfg.chunkSize, 4), chunksPerArc = positiveInt(cfg.chunksPerArc, 5), arcsPerVolume = positiveInt(cfg.arcsPerVolume, 3);
  const chunks = [], arcs = [], volumes = [];
  const chunkCount = Math.ceil(count / chunkSize), arcSize = chunkSize * chunksPerArc, volumeSize = arcSize * arcsPerVolume;
  const idFor = (prefix, index) => prefix + "-" + String(index).padStart(4, "0");
  for (let i = 0; i < chunkCount; i++) {
    const startChapter = i * chunkSize + 1, expectedEndChapter = startChapter + chunkSize - 1;
    const endChapter = Math.min(count, expectedEndChapter), arcIndex = Math.floor(i / chunksPerArc), volumeIndex = Math.floor(arcIndex / arcsPerVolume);
    chunks.push({ id: idFor("L2", i + 1), index: i + 1, startChapter, endChapter, expectedEndChapter, complete: endChapter === expectedEndChapter, arcId: idFor("L3", arcIndex + 1), volumeId: idFor("L4", volumeIndex + 1) });
  }
  const arcCount = Math.ceil(count / arcSize);
  for (let i = 0; i < arcCount; i++) {
    const startChapter = i * arcSize + 1, expectedEndChapter = startChapter + arcSize - 1, endChapter = Math.min(count, expectedEndChapter);
    const chunkIds = chunks.filter(x => x.arcId === idFor("L3", i + 1)).map(x => x.id);
    arcs.push({ id: idFor("L3", i + 1), index: i + 1, startChapter, endChapter, expectedEndChapter, complete: endChapter === expectedEndChapter, volumeId: idFor("L4", Math.floor(i / arcsPerVolume) + 1), chunkIds });
  }
  const volumeCount = Math.ceil(count / volumeSize);
  for (let i = 0; i < volumeCount; i++) {
    const startChapter = i * volumeSize + 1, expectedEndChapter = startChapter + volumeSize - 1, endChapter = Math.min(count, expectedEndChapter);
    const arcIds = arcs.filter(x => x.volumeId === idFor("L4", i + 1)).map(x => x.id);
    volumes.push({ id: idFor("L4", i + 1), index: i + 1, startChapter, endChapter, expectedEndChapter, complete: endChapter === expectedEndChapter, arcIds });
  }
  return { chunks, arcs, volumes };
}
function upsertFrozenLayerSummary(existing, incoming) {
  const result = Array.isArray(existing) ? existing.slice() : [];
  if (!incoming || typeof incoming.id !== "string" || !incoming.id.trim()) return result;
  const index = result.findIndex(item => item && item.id === incoming.id);
  if (index >= 0 && result[index].frozen === true) return result;
  const summary = Object.assign({}, incoming, { frozen: true });
  if (index >= 0) result[index] = summary;
  else result.push(summary);
  return result;
}
function organizationProfilesPromptBlock(st, maxChars) {
  st = st || {};
  const orgs = Array.isArray(st.organizations) ? st.organizations.filter(x => x && String(x.name || "").trim()).slice(-10) : [];
  const rawBudget = Number(maxChars), budget = Number.isFinite(rawBudget) && rawBudget >= 0 ? Math.floor(rawBudget) : 2200;
  if (!orgs.length || !budget) return "";
  const cut = (v, n) => String(v == null ? "" : v).replace(/\s+/g, " ").trim().slice(0, n);
  let out = "HỒ SƠ THẾ LỰC (trạng thái/lịch sử đã xác nhận; không tự đổi):\n";
  orgs.forEach(org => {
    if (out.length >= budget) return;
    const row = "- " + cut(org.name, 80) + " [" + cut(org.status || "active", 24) + "]" +
      (org.type ? " | loại: " + cut(org.type, 60) : "") + (org.leader ? " | thủ lĩnh: " + cut(org.leader, 60) : "") +
      (org.territory ? " | lãnh địa: " + cut(org.territory, 80) : "") + (org.description ? " | hồ sơ: " + cut(org.description, 200) : "") +
      (org.historyText ? " | lịch sử: " + cut(org.historyText, 160) : "") + "\n";
    const room = budget - out.length;
    out += row.length <= room ? row : (room > 1 ? row.slice(0, room - 1) + "…" : "");
  });
  return out.slice(0, budget).trimEnd();
}
function buildLayeredMemoryContextBlock(st, targetChapter, maxChars) {
  st = st || {};
  const memory = st.layeredMemory && typeof st.layeredMemory === "object" ? st.layeredMemory : {};
  const summaries = memory.summaries && typeof memory.summaries === "object" ? memory.summaries : {};
  const target = Math.max(1, Math.floor(Number(targetChapter) || ((st.chapters || []).length + 1)));
  const rawBudget = Number(maxChars), budget = Number.isFinite(rawBudget) && rawBudget >= 0 ? Math.floor(rawBudget) : 5200;
  if (!budget) return "";
  const labels = { L1: "L1 · TÓM TẮT CHƯƠNG GẦN", L5: "L5 · TỔNG QUAN TOÀN TRUYỆN", L4: "L4 · VOLUME", L3: "L3 · ARC", L2: "L2 · NHÓM CHƯƠNG" };
  const blocks = [];
  ["L1", "L5", "L4", "L3", "L2"].forEach(level => {
    const list = Array.isArray(summaries[level]) ? summaries[level] : [];
    const eligible = list.filter(x => {
      const end = Number(x && (x.endChapter != null ? x.endChapter : x.toChapter));
      return x && x.frozen === true && !x.stale && Number.isFinite(end) && end < target && String(x.summary || x.text || "").trim();
    }).sort((a, b) => Number(b.endChapter != null ? b.endChapter : b.toChapter) - Number(a.endChapter != null ? a.endChapter : a.toChapter));
    if (!eligible.length) return;
    const selected = level === "L1" ? eligible.slice(0, 2).reverse() : [eligible[0]];
    selected.forEach(item => {
      const start = Number(item.startChapter != null ? item.startChapter : item.fromChapter) || 0;
      const end = Number(item.endChapter != null ? item.endChapter : item.toChapter) || 0;
      let text = String(item.summary || item.text || "").trim();
      if (level === "L1" && text.length > 900) text = text.slice(0, 899).trimEnd() + "…";
      blocks.push({ heading: labels[level] + (start && end ? " (ch" + start + "–" + end + ")" : "") + ":\n", text });
    });
  });
  let out = "";
  for (const block of blocks) {
    if (out.length >= budget) break;
    const separator = out ? "\n\n" : "";
    const available = budget - out.length - separator.length;
    if (available <= 0) break;
    const heading = block.heading.slice(0, available);
    const contentBudget = Math.max(0, available - heading.length);
    const content = block.text.length > contentBudget && contentBudget > 1 ? block.text.slice(0, contentBudget - 1).trimEnd() + "…" : block.text.slice(0, contentBudget);
    out += separator + heading + content;
  }
  return out.slice(0, budget);
}

/* V14.7 pure helpers for per-story accuracy mode. */
function extractRequiredBeatItems(contractText) {
  const text = String(contractText == null ? "" : contractText), matches = [], re = /\[R(\d+)\]/g;
  let m;
  while ((m = re.exec(text))) matches.push({ code: "[R" + m[1] + "]", index: m.index, end: re.lastIndex });
  const out = [], seen = new Set();
  matches.forEach((item, i) => {
    if (seen.has(item.code)) return;
    seen.add(item.code);
    const lineStart = text.lastIndexOf("\n", item.index - 1) + 1;
    const nl = text.indexOf("\n", item.end), lineEnd = nl < 0 ? text.length : nl;
    let descStart = lineStart;
    for (let j = i - 1; j >= 0; j--) { if (matches[j].index < lineStart) break; descStart = matches[j].end; break; }
    let descEnd = lineEnd;
    for (let j = i + 1; j < matches.length; j++) {
      if (matches[j].index >= lineEnd) break;
      descEnd = matches[j].index;
    }
    let desc = text.slice(item.end, descEnd).replace(/^\s*(?:[-*•:]|\d+[.)])\s*/u, "").replace(/[.;,|\s]+$/u, "").replace(/\s+/g, " ").trim();
    const prefix = descStart === lineStart && item.index > lineStart ? text.slice(lineStart, item.index).replace(/^\s*(?:[-*•:]|\d+[.)])\s*/u, "").replace(/[;|,\s]+$/u, "").trim() : "";
    if (prefix && !/\[R#\]/.test(prefix)) desc = (prefix + (desc ? " " + desc : "")).replace(/\s+/g, " ").trim();
    out.push({ code: item.code, text: desc });
  });
  return out;
}
function auditRequiredBeatEvidence(requiredItems, draft, result) {
  const items = Array.isArray(requiredItems) ? requiredItems : [];
  const requiredCodes = Array.from(new Set(items.map(x => x && typeof x.code === "string" ? x.code : "").filter(x => /^\[R\d+\]$/.test(x))));
  const verifiedCodes = [], missingCodes = [], issues = [];
  if (!requiredCodes.length) return { status: "verified", requiredCodes, verifiedCodes, missingCodes, issues };
  const validResult = !!result && typeof result === "object" && !Array.isArray(result) && Array.isArray(result.items);
  if (!validResult) issues.push("Audit result is missing or malformed.");
  // V14.7.1: so khớp trích dẫn sau khi chuẩn hóa Unicode NFC + gộp khoảng trắng (tiếng Việt có thể ở dạng NFC hoặc NFD) và đòi trích dẫn đủ dài để có nghĩa.
  const normEv = x => String(x == null ? "" : x).normalize("NFC").replace(/\s+/gu, " ").trim();
  const evidenceUsable = x => x.length >= 12 && (x.match(/[\p{L}\p{N}]+/gu) || []).length >= 3;
  const rows = validResult ? result.items : [], source = normEv(typeof draft === "string" ? draft : "");
  requiredCodes.forEach(code => {
    const matches = rows.filter(x => x && typeof x === "object" && x.code === code);
    let ok = false;
    if (matches.length === 1) {
      const row = matches[0], evidence = row.evidence;
      const ev = typeof evidence === "string" ? normEv(evidence) : "";
      ok = row.status === "present" && evidenceUsable(ev) && source.indexOf(ev) >= 0;
      if (!ok) issues.push(code + ": missing, uncertain, invalid status, or non-verbatim evidence.");
    } else issues.push(code + (matches.length ? ": duplicate audit entries." : ": no audit entry."));
    (ok ? verifiedCodes : missingCodes).push(code);
  });
  return { status: missingCodes.length ? "failed" : "verified", requiredCodes, verifiedCodes, missingCodes, issues };
}
function accuracyModeQualityGateOptions(state, options) {
  const st = state && typeof state === "object" ? state : {}, opts = options && typeof options === "object" ? options : {};
  const strict = st.accuracyMode === true;
  return {
    enabled: strict || st.qualityGateEnabled !== false,
    allowRewrite: opts.rewrite !== false,
    maxAttempts: strict ? 3 : st.qualityMaxAttempts,
    acceptSoft: strict ? false : st.qualityAcceptSoft !== false,
    requiredBeatBarrier: strict || st.requiredBeatBarrier !== false,
    forceWarnings: strict || opts.forceWarnings === true
  };
}
function findRepeatedParagraphs(text, options) {
  const opts = options && typeof options === "object" ? options : {};
  const minTokens = Math.max(1, Math.floor(Number(opts.minTokens) || 12));
  const thresholdValue = Number(opts.threshold), threshold = Number.isFinite(thresholdValue) ? Math.max(0, Math.min(1, thresholdValue)) : 0.88;
  const paragraphs = String(text == null ? "" : text).split(/\n\s*\n+/).map((raw, i) => ({ index: i + 1, raw: raw.trim(), normalized: raw.toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim() })).filter(x => x.raw);
  const tokens = x => String(x && x.normalized != null ? x.normalized : x).split(/\s+/u).filter(Boolean);
  const levRatio = (a, b) => {
    if (a === b) return 1;
    const aa = tokens(a), bb = tokens(b), prev = Array.from({ length: bb.length + 1 }, (_, i) => i);
    for (let i = 1; i <= aa.length; i++) {
      let diagonal = prev[0]; prev[0] = i;
      for (let j = 1; j <= bb.length; j++) { const old = prev[j]; prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diagonal + (aa[i - 1] === bb[j - 1] ? 0 : 1)); diagonal = old; }
    }
    return 1 - prev[bb.length] / Math.max(aa.length, bb.length, 1);
  };
  const out = [];
  for (let i = 0; i < paragraphs.length; i++) for (let j = i + 1; j < paragraphs.length; j++) {
    const a = paragraphs[i], b = paragraphs[j];
    const la = tokens(a).length, lb = tokens(b).length;
    if (la < minTokens || lb < minTokens) continue;
    if (a.normalized !== b.normalized && Math.min(la, lb) / Math.max(la, lb) < threshold) continue; // chênh độ dài quá lớn thì không thể đạt ngưỡng giống
    const exact = a.normalized === b.normalized, similarity = exact ? 1 : levRatio(a.normalized, b.normalized);
    if (exact || similarity >= threshold) out.push({ paragraphs: [a.index, b.index], exact, similarity: Number(similarity.toFixed(4)), excerpt: a.raw.slice(0, 180) });
  }
  return out;
}
// <<SHARED-CORE:END>>
function escapeHtml(s){ return String(s==null?"":s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function stripCodeFences(s){ return (s||"").replace(/```json/gi,"```").replace(/```/g,"").trim(); }
/* Cũ: lấy "từ dấu ngoặc đầu tiên tới hết chuỗi" rồi JSON.parse — nếu AI thòng
   thêm 1 câu ghi chú sau khối JSON (rất hay gặp) là parse hỏng toàn bộ, và
   các hàm gọi hàm này chỉ âm thầm return chứ không báo lỗi => "tự nhiên
   không cập nhật". Giờ tìm ĐÚNG cặp ngoặc khớp nhau (đếm độ sâu, bỏ qua
   ngoặc nằm trong chuỗi "...") rồi mới parse phần đó, nên chữ thừa phía sau
   không còn phá được nữa. */
function repairTruncatedArray(raw){
  const s = stripCodeFences(raw || "");
  const start = s.indexOf("[");
  if(start < 0) return [];
  const out = [];
  let i = start + 1;
  while(i < s.length){
    while(i < s.length && /[\s,]/.test(s[i])) i++;
    if(s[i] !== "{") break;
    const st = i; let depth = 0, inStr = false, esc = false;
    for(; i < s.length; i++){
      const c = s[i];
      if(inStr){ if(esc) esc=false; else if(c==='\\') esc=true; else if(c==='"') inStr=false; continue; }
      if(c==='"'){ inStr=true; continue; }
      if(c==='{') depth++;
      else if(c==='}'){ depth--; if(depth===0){ const t=jsonTryParse(s.slice(st,i+1)); if(t.ok && t.value && typeof t.value==="object") out.push(t.value); i++; break; } }
    }
    if(depth!==0) break;
  }
  return out;
}
/* v9.3: parser JSON chống lỗi (đồng bộ với worker).
   - Sửa xuống dòng thô/dấu phẩy thừa/dấu " lồng trong chuỗi.
   - Không đổi “ ” toàn cục; không "rơi" vào mảng/object con khi phần ngoài bị hỏng/cắt.
   - JSON bị cắt: đóng ngoặc tại dấu phẩy hợp lệ gần nhất. */
function jsonFixSyntax(s, heal){
  let out="", inStr=false, esc=false;
  const nextSig=(k)=>{ while(k<s.length && /\s/.test(s[k])) k++; return s[k]; };
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(inStr){
      if(esc){ out+=c; esc=false; continue; }
      if(c==="\\"){ out+=c; esc=true; continue; }
      if(c==='"'){
        if(heal){ const nx=nextSig(i+1); if(!(nx===undefined||nx===","||nx===":"||nx==="}"||nx==="]")){ out+='\\"'; continue; } }
        inStr=false; out+=c; continue;
      }
      if(c==="\n"){ out+="\\n"; continue; }
      if(c==="\r") continue;
      if(c==="\t"){ out+="\\t"; continue; }
      if(c.charCodeAt(0)<32) continue;
      out+=c; continue;
    }
    if(c==='"'){ inStr=true; out+=c; continue; }
    if(c==="}"||c==="]") out=out.replace(/,\s*$/,"");
    out+=c;
  }
  return out;
}
function jsonTryParse(s){
  try{ return {ok:true,value:JSON.parse(s)}; }catch(e){}
  try{ return {ok:true,value:JSON.parse(jsonFixSyntax(s,false))}; }catch(e){}
  try{ return {ok:true,value:JSON.parse(jsonFixSyntax(s,true))}; }catch(e){}
  try{ return {ok:true,value:JSON.parse(jsonFixSyntax(s.replace(/[“”]/g,'"'),true))}; }catch(e){}
  return {ok:false};
}
function jsonScanTop(s){
  const res=[]; let i=0;
  while(i<s.length){
    let st=-1;
    for(let k=i;k<s.length;k++){ if(s[k]==="["||s[k]==="{"){ st=k; break; } }
    if(st<0) break;
    const open=s[st], close=open==="["?"]":"}";
    let depth=0,inStr=false,esc=false,end=-1;
    for(let j=st;j<s.length;j++){
      const c=s[j];
      if(inStr){ if(esc) esc=false; else if(c==="\\") esc=true; else if(c==='"') inStr=false; continue; }
      if(c==='"'){ inStr=true; continue; }
      if(c===open) depth++;
      else if(c===close){ depth--; if(depth===0){ end=j; break; } }
    }
    if(end<0){ res.push({text:s.slice(st),complete:false}); break; }
    res.push({text:s.slice(st,end+1),complete:true}); i=end+1;
  }
  return res;
}
function jsonSalvageTruncated(text){
  const stack=[]; let inStr=false, esc=false; const pts=[];
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(inStr){ if(esc) esc=false; else if(c==="\\") esc=true; else if(c==='"') inStr=false; continue; }
    if(c==='"'){ inStr=true; continue; }
    if(c==="{") stack.push("}"); else if(c==="[") stack.push("]");
    else if(c==="}"||c==="]") stack.pop();
    else if(c===","&&stack.length) pts.push({pos:i,closers:stack.slice().reverse().join("")});
  }
  for(let k=pts.length-1;k>=Math.max(0,pts.length-300);k--){
    const t=jsonTryParse(text.slice(0,pts[k].pos)+pts[k].closers);
    if(t.ok) return t.value;
  }
  return null;
}
function safeJsonParse(raw){
  const cleaned = stripCodeFences(raw || "");
  if(!cleaned) return null;
  const whole = jsonTryParse(cleaned);
  if(whole.ok && whole.value!==null && typeof whole.value==="object") return whole.value;
  let truncated = "";
  for(const c of jsonScanTop(cleaned)){
    if(c.complete){ const t=jsonTryParse(c.text); if(t.ok && t.value!==null && typeof t.value==="object") return t.value; }
    else truncated = c.text;
  }
  if(truncated){ const sv=jsonSalvageTruncated(truncated); if(sv && typeof sv==="object") return sv; }
  const repaired = repairTruncatedArray(cleaned);
  if(repaired.length) return repaired;
  return null;
}

function estimateTokens(text){ return text ? Math.ceil(text.length / 3.2) : 0; }
function shortModelName(m){
  if(!m) return "?";
  const parts = m.split("/");
  const name = parts[parts.length - 1];
  return name.length > 24 ? name.slice(0,21) + "..." : name;
}
function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

/* ========== PRICING ========== */
const MODEL_PRICING = {
  "deepseek/deepseek-chat": { in: 0.14, out: 0.28 },
  "deepseek/deepseek-v4-flash-0731": { in: 0.10, out: 0.20 },
  "deepseek/deepseek-v3.2": { in: 0.14, out: 0.28 },
  "deepseek/deepseek-r1": { in: 0.55, out: 2.19 },
  "openai/gpt-4o-mini": { in: 0.15, out: 0.60 },
  "openai/gpt-4o": { in: 2.50, out: 10.00 },
  "anthropic/claude-3.5-sonnet": { in: 3.00, out: 15.00 },
  "google/gemini-flash-1.5": { in: 0.075, out: 0.30 },
  "qwen/qwen-2.5-72b-instruct": { in: 0.35, out: 0.40 },
  "x-ai/grok-4.3": { in: 3.00, out: 15.00 },
  "aion-labs/aion-2.0": { in: 0.80, out: 1.60 },
  "_default": { in: 0.50, out: 1.50 }
};
function priceForModel(m){
  try{
    if(!m) return MODEL_PRICING._default;
    const mLower = String(m).toLowerCase();
    const keys = Object.keys(MODEL_PRICING).filter(k=> k !== "_default" && k.indexOf("/") > 0);
    const key = keys.find(k=>{
      const parts = k.split("/");
      if(!parts || parts.length < 2) return false;
      return mLower.indexOf(parts[0]) !== -1 && mLower.indexOf(parts[1].split("-")[0]) !== -1;
    });
    return MODEL_PRICING[key] || MODEL_PRICING._default;
  }catch(e){ return MODEL_PRICING._default; }
}


/* ========== STORY STORAGE — IndexedDB v10.2 ========== */
let storiesIndex = [];
let currentStoryId = null;
const IDB_NAME = "XuongTruyenAI_v10";
const IDB_VERSION = 2;
const IDB_STORY_STORE = "stories";
const IDB_INDEX_STORE = "meta";
const IDB_DRAFT_STORE = "drafts";
let idb = null;
let idbReady = null;
const idbStoryCache = new Map();
let persistTimer = null;

function openStoryDB(){
  if(idbReady) return idbReady;
  idbReady = new Promise((resolve,reject)=>{
    if(!("indexedDB" in window)){ reject(new Error("Trình duyệt không hỗ trợ IndexedDB.")); return; }
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = e=>{
      const db=e.target.result;
      if(!db.objectStoreNames.contains(IDB_STORY_STORE)) db.createObjectStore(IDB_STORY_STORE);
      if(!db.objectStoreNames.contains(IDB_INDEX_STORE)) db.createObjectStore(IDB_INDEX_STORE);
      if(!db.objectStoreNames.contains(IDB_DRAFT_STORE)) db.createObjectStore(IDB_DRAFT_STORE);
    };
    req.onsuccess=e=>{ idb=e.target.result; resolve(idb); };
    req.onerror=()=>reject(req.error||new Error("Không mở được IndexedDB."));
  });
  return idbReady;
}
function idbPut(store,key,value){
  return openStoryDB().then(db=>new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readwrite"); tx.objectStore(store).put(value,key);
    tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error);
  }));
}
function idbGet(store,key){
  return openStoryDB().then(db=>new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readonly"); const req=tx.objectStore(store).get(key);
    req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error);
  }));
}
function idbDelete(store,key){
  return openStoryDB().then(db=>new Promise((resolve,reject)=>{
    const tx=db.transaction(store,"readwrite"); tx.objectStore(store).delete(key);
    tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error);
  }));
}

function saveStoriesIndex(){
  const copy = JSON.parse(JSON.stringify(storiesIndex||[]));
  try{ localStorage.setItem(STORIES_INDEX_KEY, JSON.stringify(copy)); }catch(e){}
  idbPut(IDB_INDEX_STORE,"storiesIndex",copy).catch(()=>{});
}
function loadStoriesIndex(){
  try{
    const raw=localStorage.getItem(STORIES_INDEX_KEY);
    if(raw){ storiesIndex=JSON.parse(raw)||[]; return; }
  }catch(e){}
  storiesIndex=[];
}
async function loadStoriesIndexAsync(){
  try{
    const v=await idbGet(IDB_INDEX_STORE,"storiesIndex");
    if(Array.isArray(v)&&v.length) storiesIndex=v;
  }catch(e){}
}
function buildStoryMetaData(source){
  const s=source||state;
  const meta={};
  Object.keys(s).forEach(k=>{
    if(k==="chapters" || k==="scenes" || k==="storyMetaData" || k==="apiSettings") return;
    meta[k]=s[k];
  });
  meta.apiSettings = {
    endpoint:s.apiEndpoint||s.apiSettings?.endpoint||"",
    key:s.apiKey||s.apiSettings?.key||"",
    primaryModel:s.model||s.apiSettings?.primaryModel||"",
    nsfwModel:s.modelNsfw||s.apiSettings?.nsfwModel||"",
    nsfwMode:s.nsfwMode||s.apiSettings?.nsfwMode||"auto",
    nsfwThreshold:Number(s.nsfwAutoThreshold||s.apiSettings?.nsfwThreshold||6)
  };
  meta.styleBible=s.styleBible||{};
  meta.storyBible={
    mainPlot:s.mainPlot||"", genre:s.genre||"", worldSetting:s.worldSetting||"",
    worldRules:s.worldRules||"", antagonist:s.antagonist||"", pronounRules:s.pronounRules||"",
    cultivationSystem:s.cultivationSystem||"", realmLadder:Array.isArray(s.realmLadder)?s.realmLadder.join(", "):(s.realmLadder||""),
    worldDescription:s.worldDescription||"", storyBibleLocked:!!s.storyBibleLocked,
    mainCharProfile:s.mainCharProfile||null
  };
  meta.lorebook=s.lorebook||[];
  meta.vocabulary=s.vocabulary||{};
  return meta;
}
function buildChapterData(source){
  const s=source||state;
  return {
    chapters:s.chapters||[],
    chapterDrafts:s.chapterDrafts||[],
    scenes:s.scenes||[],
    knowledgeLedger:s.knowledgeLedger||[],
    chapterSnapshots:(s.chapters||[]).map(c=>({id:c.id||null,chapter:c.chapter||null,stateSnapshot:c.stateSnapshot||null,stateSnapshots:c.stateSnapshots||[]})),
    characterStateTracker:s.characterStateTracker||{},
    plotArchive:s.plotArchive||[],
    canonVersion:Number(s.canonVersion||0),
    qualityGate:{enabled:s.qualityGateEnabled!==false,accuracyMode:s.accuracyMode===true,passScore:Number(s.qualityPassScore||90),softFailScore:Number(s.qualitySoftFailScore||75),maxAttempts:Number(s.qualityMaxAttempts||5),autoRepairOnCreate:s.autoRepairOnCreate!==false},
    version:3
  };
}
function serializeStoryRecord(source){
  return { schemaVersion:11, storyId:source.storyId, updatedAt:Date.now(),
    StoryMetaData:buildStoryMetaData(source),
    ChapterData:buildChapterData(source)
  };
}
function hydrateFromRecord(record){
  if(!record) return null;
  if(record.StoryMetaData && record.ChapterData){
    const meta=record.StoryMetaData, ch=record.ChapterData;
    const out=Object.assign({},meta);
    if(meta.apiSettings){
      out.apiSettings=meta.apiSettings;
      out.apiEndpoint=meta.apiSettings.endpoint||out.apiEndpoint;
      out.apiKey=meta.apiSettings.key||out.apiKey||"";
      out.model=meta.apiSettings.primaryModel||out.model;
      out.modelNsfw=meta.apiSettings.nsfwModel||out.modelNsfw;
      out.nsfwMode=meta.apiSettings.nsfwMode||out.nsfwMode;
      out.nsfwAutoThreshold=meta.apiSettings.nsfwThreshold||out.nsfwAutoThreshold;
    }
    if(meta.storyBible){
      Object.assign(out,meta.storyBible);
      if(meta.storyBible.mainCharProfile) out.mainCharProfile=meta.storyBible.mainCharProfile;
    }
    out.chapters=ch.chapters||[];
    out.chapterDrafts=ch.chapterDrafts||[];
    out.canonVersion=Number(ch.canonVersion||0);
    out.qualityGateEnabled=ch.qualityGate?.enabled!==false; out.accuracyMode=ch.qualityGate?.accuracyMode===true; out.qualityPassScore=Number(ch.qualityGate?.passScore||90); out.qualitySoftFailScore=Number(ch.qualityGate?.softFailScore||75); out.qualityMaxAttempts=Number(ch.qualityGate?.maxAttempts||5); out.autoRepairOnCreate=ch.qualityGate?.autoRepairOnCreate!==false;
    out.chapters.forEach(c=>{ if(c && c.sync && c.sync.status==="SYNCED" && !c.status) c.status="SYNCED"; });
    out.scenes=ch.scenes||out.scenes||[];
    out.knowledgeLedger=ch.knowledgeLedger||out.knowledgeLedger||[];
    out.characterStateTracker=ch.characterStateTracker||out.characterStateTracker||{};
    out.plotArchive=ch.plotArchive||out.plotArchive||[];
    out.storyMetaData=meta;
    return out;
  }
  /* legacy flat record */
  return record;
}
/* v11: bản lưu khẩn cấp. Ghi ĐỒNG BỘ vào localStorage khi (a) IndexedDB lỗi hoặc (b) trang sắp
   bị ẩn/đóng (iOS có thể đóng băng tab trước khi transaction IndexedDB kịp hoàn tất). Bản này
   chỉ bị xoá khi IndexedDB xác nhận đã ghi xong một bản MỚI HƠN hoặc bằng nó. */
const EMERGENCY_PREFIX = "aiStoryWorkshop_emergency_v11_";
function writeEmergencyCopy(id,record){
  try{
    localStorage.setItem(EMERGENCY_PREFIX+id, JSON.stringify({t:record.updatedAt||Date.now(), record:record}));
    return true;
  }catch(e){ return false; /* quota đầy / chế độ riêng tư */ }
}
function clearEmergencyCopy(id,upToT){
  try{
    const raw=localStorage.getItem(EMERGENCY_PREFIX+id); if(!raw) return;
    const o=JSON.parse(raw);
    if(!o || typeof o.t!=="number" || o.t<=upToT) localStorage.removeItem(EMERGENCY_PREFIX+id);
  }catch(e){ try{ localStorage.removeItem(EMERGENCY_PREFIX+id); }catch(_){} }
}
function readEmergencyRecord(id){
  try{
    const raw=localStorage.getItem(EMERGENCY_PREFIX+id); if(!raw) return null;
    const o=JSON.parse(raw); return (o && o.record) ? o : null;
  }catch(e){ return null; }
}
function saveStoryStateToDisk(id,s,opts){
  if(!id) return;
  try{ idbStoryCache.set(id,JSON.parse(JSON.stringify(s))); }catch(e){}
  const record=serializeStoryRecord(Object.assign({},s,{storyId:id}));
  if(opts && opts.sync) writeEmergencyCopy(id,record);
  idbPut(IDB_STORY_STORE,id,record).then(()=>{
    clearEmergencyCopy(id,record.updatedAt);
  }).catch(e=>{
    console.warn("[IndexedDB]",e);
    const ok=writeEmergencyCopy(id,record);
    showSaveInd(ok?"⚠ IndexedDB lỗi — đã lưu dự phòng":"❌ Không lưu được — hãy Xuất JSON ngay","warn");
  });
}
async function loadStoryStateFromDiskAsync(id){
  if(!id) return null;
  if(idbStoryCache.has(id)) return idbStoryCache.get(id);
  try{
    let record=await idbGet(IDB_STORY_STORE,id);
    const em=readEmergencyRecord(id);
    if(em && (!record || (record.updatedAt||0) < em.t)){ record=em.record; console.info("[v11] khôi phục từ bản lưu khẩn cấp"); }
    const s=hydrateFromRecord(record);
    if(s){ idbStoryCache.set(id,s); return JSON.parse(JSON.stringify(s)); }
  }catch(e){ console.warn("[IndexedDB read]",e); }
  try{ const em=readEmergencyRecord(id); if(em){ const s=hydrateFromRecord(em.record); if(s){ idbStoryCache.set(id,s); return JSON.parse(JSON.stringify(s)); } } }catch(e){}
  /* localStorage bản cũ (v9) dùng như migration fallback. */
  try{
    const raw=localStorage.getItem(STORY_KEY_PREFIX+id);
    if(raw){ const s=JSON.parse(raw); saveStoryStateToDisk(id,s); return s; }
  }catch(e){}
  return null;
}
function removeStoryFromDisk(id){
  idbStoryCache.delete(id); idbDelete(IDB_STORY_STORE,id).catch(()=>{});
  try{ localStorage.removeItem(STORY_KEY_PREFIX+id); localStorage.removeItem(EMERGENCY_PREFIX+id); }catch(e){}
}
async function initIndexedDBStorage(){
  try{
    await openStoryDB();
    await loadStoriesIndexAsync();
    for(const item of storiesIndex){
      try{
        let record=await idbGet(IDB_STORY_STORE,item.id);
        const em=readEmergencyRecord(item.id);
        if(em && (!record || (record.updatedAt||0) < em.t)){ record=em.record; console.info("[v11] khôi phục từ bản lưu khẩn cấp:",item.id); }
        const s=hydrateFromRecord(record);
        if(s) idbStoryCache.set(item.id,s);
      }catch(e){}
    }
  }catch(e){ console.warn("[IndexedDB init]",e); }
}
/* ========== STATE ========== */
const state = {
  schemaVersion: 13,
  apiEndpoint: "https://openrouter.ai/api/v1/chat/completions", apiKey: "",
  model: "deepseek/deepseek-v3.2", modelNsfw: "aion-labs/aion-2.0",
  nsfwMode: "auto", nsfwAutoThreshold: 6, chapterMatureFocus: "none",
  descriptionLevel: "balanced",
  explicitLevel: "strong",
  advancedRules: DEFAULT_ADVANCED_RULES, autoIntervalSec: 180,
  includeKeyOnExport: false, spellCheckEnabled: false,
  autoContinueEnabled: true, autoSummaryEnabled: true, autoSceneEnabled: true,
  dupCheckEnabled: true, streamingEnabled: true, queueEnabled: true,
  parallelEnabled: true, checkpointEnabled: true,
  autoContinueMax: 4, minChapterWords: 5000, chapterWordMin: null, chapterWordMax: null,
  totalCalls: 0, totalTokensIn: 0, totalTokensOut: 0, totalCostUSD: 0,
  storyId: null, storyName: "",
  styleBible: { pov:"third_limited", tense:"past", tone:"", sample:"", extra:"" },
  mainPlot: "", genre: "", worldSetting: "", worldRules: "", antagonist: "", cultivationSystem: "", realmLadder: "",
  pronounRules: "", worldDescription: "", storyBibleLocked: false,
  mainCharProfile: null,
  vocabulary: { preferred:"", banned:"", overused:"", anatomy:"" },
  arcs: [], outlinePlans: [], storyClock: "", directive: "", nextChapterHint: "", nextChapterHintMeta: { targetChapter: 0, version: 0, status: "unverified" }, autoNextChapterHint: "",
  difficulty: "vua", mature: false, chapterMatureFocus: "none",
  storyControl: { schemaVersion:1, maxMainEvents:2, maxNamedCharacters:6, maxNewThreads:3, noRetcon:true, agencyRequired:true, lockedFields:["identity","age","background","canon","relationships","cultivation","abilities","importantItems","secrets","promises","worldRules"] },
  currentStatus: "",
  characters: [], locations: [], items: [], organizations: [], threads: [],
  scenes: [], consentLog: [],
  chapters: [], currentChapterIndex: -1,
  chaptersSinceBackup: 0,
  statusState: {}, timeline: [], timeLog: [], foreshadowing: [], knowledgeLedger: [], memoryEvents: [], lastMemorySyncChapter: 0,
  layeredMemory: { schemaVersion: 1, config: { chunkSize: 4, chunksPerArc: 5, arcsPerVolume: 3 }, summaries: { L1: [], L2: [], L3: [], L4: [], L5: [] }, history: [] },
  triggeredCheckpoints: [],
  lastPacingWarnChapter: 0,
  includeScenesInPrompt: true,
  /* v10.2 normalized architecture */
  apiSettings: { endpoint:"https://openrouter.ai/api/v1/chat/completions", key:"", primaryModel:"deepseek/deepseek-v3.2", nsfwModel:"aion-labs/aion-2.0", nsfwMode:"auto", nsfwThreshold:6 },
  storyMetaData: { styleBible:{}, storyBible:{}, worldRules:"", lorebook:[], vocabulary:{}, apiSettings:{} },
  characterCards: [],
  banWords: [],
  glossaryLock: [],
  characterStateTracker: {},
  plotArchive: [],
  tokenCapPerPrompt: 5,
  snapshotLimit: 7,
  wakeLockEnabled: true,
  slidingWindowWords: 1500,
  qualityGateEnabled: false, qualityAcceptSoft: false, requiredBeatBarrier: true, accuracyMode: false, qualityPassScore: 90, qualitySoftFailScore: 75, qualityMaxAttempts: 2, autoRepairOnCreate: true, adaptiveScenePipeline: true, semanticProseAuto: false, sceneAiReview: false
};

function newMainCharProfile(){
  const p = {
    name:"", age:"", gender:"", maritalStatus:"", spouseName:"", maritalNotes:"", appearance:"", personality:"", occupation:"",
    goals:"", skills:"", physicalState:"", mentalState:"", currentLocation:"", secret:"",
    height:"", bodyType:"", measurements:"", hair:"", eyes:"", skin:"", voice:"", scent:"",
    style:"", scars:"", tattoos:"", speech:"",
    sexualExperience:"", boundaries:"", preferences:"",
    position:"", faction:"", weakness:"", fear:"", knowledge:""
  };
  CULT_FIELDS.forEach(k=>{ p[k] = ""; });   // V14.1: trường tu luyện dùng chung với nhân vật phụ
  return p;
}
function newStoryState(name){
  return {
    schemaVersion: 13, lorebook: [], loreBudgetTokens: 2000, storyId: newStoryId(), storyName: name || ("Truyện " + (storiesIndex.length + 1)),
    styleBible: { pov:"third_limited", tense:"past", tone:"", sample:"", extra:"" },
    mainPlot:"", genre:"", worldSetting:"", worldRules:"", antagonist:"", cultivationSystem:"", realmLadder:"",
    pronounRules:"", worldDescription:"", storyBibleLocked:false,
    mainCharProfile: newMainCharProfile(),
    mainCharCoreIdentity: {},
    femaleCharacterDefinition: "",
    vocabulary: { preferred:"", banned:"", overused:"", anatomy:"" },
    arcs:[], outlinePlans:[], storyClock:"", directive:"", nextChapterHint:"", nextChapterHintMeta:{targetChapter:0,version:0,status:"unverified"}, autoNextChapterHint:"",
    difficulty:"vua", mature:false, chapterMatureFocus:"none", storyControl:{schemaVersion:1,maxMainEvents:2,maxNamedCharacters:6,maxNewThreads:3,noRetcon:true,agencyRequired:true,lockedFields:["identity","age","background","canon","relationships","cultivation","abilities","importantItems","secrets","promises","worldRules"]}, currentStatus:"",
    characters:[], locations:[], items:[], organizations:[], threads:[], chapterWordMin:null, chapterWordMax:null,
    scenes:[], consentLog:[],
    chapters:[], chapterDrafts:[], currentChapterIndex:-1, chaptersSinceBackup:0,
    triggeredCheckpoints: [], lastPacingWarnChapter: 0,
    statusState: {}, timeline: [], timeLog: [], foreshadowing: [], knowledgeLedger: [], memoryEvents: [],
    layeredMemory:{schemaVersion:1,config:{chunkSize:4,chunksPerArc:5,arcsPerVolume:3},summaries:{L1:[],L2:[],L3:[],L4:[],L5:[]},history:[]},
    lastMemorySyncChapter: 0,
    apiSettings: { endpoint:"https://openrouter.ai/api/v1/chat/completions", key:"", primaryModel:"deepseek/deepseek-v3.2", nsfwModel:"aion-labs/aion-2.0", nsfwMode:"auto", nsfwThreshold:6 },
    storyMetaData: { styleBible:{}, storyBible:{}, worldRules:"", lorebook:[], vocabulary:{}, apiSettings:{} },
    characterCards: [], banWords: [], glossaryLock: [], characterStateTracker:{}, plotArchive:[],
    tokenCapPerPrompt:5, snapshotLimit:7, wakeLockEnabled:true, slidingWindowWords:1500,
    qualityGateEnabled:false, qualityAcceptSoft:false, requiredBeatBarrier:true, accuracyMode:false, qualityPassScore:90, qualitySoftFailScore:75, qualityMaxAttempts:2, autoRepairOnCreate:true,
    spellCheckEnabled:false, adaptiveScenePipeline:true, semanticProseAuto:false, sceneAiReview:false
  };
}

const TIERS = ["background","minor","supporting","important","major"];
const CHARACTER_CORE_LOCK_FIELDS = ["name","age","gender","maritalStatus","spouseName","appearance","personality","goals","role","position","occupation","faction"];
const openCharDetails = new Set();

function newCharacter(partial){
  const c = Object.assign({
    id: genId(), name:"", tier:"supporting", age:"", gender:"", maritalStatus:"", spouseName:"", maritalNotes:"",
    /* Phân loại vai trò & mức liên quan tới truyện/nhân vật chính */
    role:"", relevanceToMC:"",
    /* Miêu tả ngoại hình chi tiết */
    appearance:"", height:"", bodyType:"", measurements:"", hair:"", eyes:"", skin:"",
    voice:"", scent:"", style:"", scars:"", tattoos:"",
    personality:"", speech:"", occupation:"", position:"", faction:"", goals:"", secret:"",
    weakness:"", fear:"", strength:"", currentLocation:"", schedule:"",
    physicalState:"", mentalState:"", knowledge:"", independentPlot:"",
    sexualExperience:"", boundaries:"", taboos:"", preferences:"",
    attractionToMC:"", tensionWithMC:"", consentNotes:"",
    relationships:[], firstAppearance:null, lastAppearance:null,
    /* Hồ sơ gốc: AI không được tự ý thay đổi các trường nhận diện cốt lõi.
       Chỉ thao tác lưu thủ công trong UI mới cập nhật coreIdentity. */
    coreIdentity:{}, coreLocked:true,
    locked:false, dead:false, deathChapter:null, history:[]
  }, partial||{});
  CULT_FIELDS.forEach(k=>{ if(c[k]==null) c[k]=""; });   // V14.1: cảnh giới, công pháp, pháp bảo...
  if(!c.coreIdentity || typeof c.coreIdentity!=="object" || !Object.keys(c.coreIdentity).length){
    c.coreIdentity = {};
    CHARACTER_CORE_LOCK_FIELDS.forEach(k=>{ c.coreIdentity[k] = c[k] ?? ""; });
  }
  if(c.coreLocked==null) c.coreLocked=true;
  return c;
}
function newRelationship(partial){
  return Object.assign({
    withName:"", trust:"", respect:"", affection:"", attraction:"",
    suspicion:"", stage:"", tension:"", boundaries:"", notes:"", history:[]
  }, partial||{});
}
function newLocation(partial){
  return Object.assign({ id: genId(), name:"", description:"", status:"active",
    firstAppearance:null, lastAppearance:null }, partial||{});
}
function newItem(partial){
  /* V14.1: kind = loại (pháp bảo/binh khí/đan dược...), grade = phẩm cấp, effect = công dụng/hạn chế, bound = đã nhận chủ/bản mệnh */
  return Object.assign({ id: genId(), name:"", description:"", owner:"", status:"active",
    kind:"", grade:"", effect:"", bound:false,
    firstAppearance:null, lastAppearance:null }, partial||{});
}
function normalizeCharacterCoreLocks(){
  (state.characters||[]).forEach(c=>{
    if(!c.coreIdentity || typeof c.coreIdentity!=="object" || !Object.keys(c.coreIdentity).length){
      c.coreIdentity={};
      CHARACTER_CORE_LOCK_FIELDS.forEach(k=>{ c.coreIdentity[k]=c[k] ?? ""; });
    }
    if(c.coreLocked==null) c.coreLocked=true;
  });
}

function findCharacterByName(name){
  const n = normalizeName(name);
  if(!n) return null;
  if(state.mainCharProfile && normalizeName(state.mainCharProfile.name) === n) return { _isMC: true, ...state.mainCharProfile };
  return state.characters.find(c => normalizeName(c.name) === n);
}
function findLocationByName(name){ const n = normalizeName(name); return n ? state.locations.find(l => normalizeName(l.name) === n) : null; }
function findItemByName(name){ const n = normalizeName(name); return n ? state.items.find(it => normalizeName(it.name) === n) : null; }

/* ========== BOOT / MIGRATION ========== */
function bootstrapStorage(){
  loadStoriesIndex();
  /* Migrate v6 → v7 */
  if(!storiesIndex.length){
    const v6Index = localStorage.getItem(MIGRATION_KEYS_V6.index);
    if(v6Index){
      try{
        const arr = JSON.parse(v6Index) || [];
        arr.forEach(meta=>{
          const v6 = localStorage.getItem(MIGRATION_KEYS_V6.story + meta.id);
          if(v6){
            const old = JSON.parse(v6);
            const s = newStoryState(meta.name || "Truyện");
            s.storyId = meta.id;
            Object.keys(s).forEach(k=>{ if(old[k] !== undefined) s[k] = old[k]; });
            /* Migrate MC profile */
            if(old.mainCharProfile){
              const mc = newMainCharProfile();
              Object.keys(mc).forEach(k=>{ if(old.mainCharProfile[k] !== undefined) mc[k] = old.mainCharProfile[k]; });
              s.mainCharProfile = mc;
            }
            /* Migrate characters */
            if(Array.isArray(old.characters)){
              s.characters = old.characters.map(c=>{
                const nc = newCharacter();
                Object.keys(nc).forEach(k=>{ if(c[k] !== undefined) nc[k] = c[k]; });
                nc.id = c.id || genId();
                return nc;
              });
            }
            saveStoryStateToDisk(meta.id, s);
          }
        });
        storiesIndex = arr;
        saveStoriesIndex();
        localStorage.setItem(LAST_STORY_KEY, arr[0].id);
        const g6 = localStorage.getItem(MIGRATION_KEYS_V6.global);
        if(g6){ try{ localStorage.setItem(GLOBAL_KEY, g6); }catch(e){} }
        const last6 = localStorage.getItem(MIGRATION_KEYS_V6.last);
        if(last6) localStorage.setItem(LAST_STORY_KEY, last6);
      }catch(e){ console.warn("Migrate v6→v7:", e); }
    }
  }
  
  /* Migrate v7 → v8 */
  if(!storiesIndex.length){
    const v7Index = localStorage.getItem(MIGRATION_KEYS_V7.index);
    if(v7Index){
      try{
        const arr = JSON.parse(v7Index) || [];
        arr.forEach(meta=>{
          const v7 = localStorage.getItem(MIGRATION_KEYS_V7.story + meta.id);
          if(v7){
            const old = JSON.parse(v7);
            const s = newStoryState(meta.name || "Truyện");
            s.storyId = meta.id;
            Object.keys(s).forEach(k=>{ if(old[k] !== undefined) s[k] = old[k]; });
            if(old.mainCharProfile){
              const mc = newMainCharProfile();
              Object.keys(mc).forEach(k=>{ if(old.mainCharProfile[k] !== undefined) mc[k] = old.mainCharProfile[k]; });
              s.mainCharProfile = mc;
            }
            if(Array.isArray(old.characters)){
              s.characters = old.characters.map(c=>{
                const nc = newCharacter();
                Object.keys(nc).forEach(k=>{ if(c[k] !== undefined) nc[k] = c[k]; });
                nc.id = c.id || genId();
                return nc;
              });
            }
            saveStoryStateToDisk(meta.id, s);
          }
        });
        storiesIndex = arr;
        saveStoriesIndex();
        localStorage.setItem(LAST_STORY_KEY, arr[0] ? arr[0].id : "");
        const g7 = localStorage.getItem(MIGRATION_KEYS_V7.global);
        if(g7){ try{ localStorage.setItem(GLOBAL_KEY, g7); }catch(e){} }
        const last7 = localStorage.getItem(MIGRATION_KEYS_V7.last);
        if(last7) localStorage.setItem(LAST_STORY_KEY, last7);
      }catch(e){ console.warn("Migrate v7→v8:", e); }
    }
  }

  if(!storiesIndex.length){
    const s = newStoryState("Truyện 1");
    saveStoryStateToDisk(s.storyId, s);
    storiesIndex.push({ id: s.storyId, name: s.storyName, updatedAt: Date.now() });
    saveStoriesIndex();
    localStorage.setItem(LAST_STORY_KEY, s.storyId);
  }
  const lastId = localStorage.getItem(LAST_STORY_KEY);
  currentStoryId = (lastId && storiesIndex.some(x=>x.id===lastId)) ? lastId : storiesIndex[0].id;
}

const GLOBAL_KEYS = ["apiEndpoint","apiKey","model","modelNsfw","nsfwMode","nsfwAutoThreshold",
  "descriptionLevel","explicitLevel","advancedRules","autoIntervalSec","includeKeyOnExport",
  "spellCheckEnabled","autoContinueEnabled","autoSummaryEnabled","autoSceneEnabled",
  "dupCheckEnabled","streamingEnabled","queueEnabled","parallelEnabled","checkpointEnabled",
  "autoContinueMax","minChapterWords","totalCalls","totalTokensIn","totalTokensOut","totalCostUSD","costByStep","stepModels",
  "includeScenesInPrompt"];

function showSaveInd(text, kind){
  const el = $("saveIndicator");
  el.textContent = text;
  el.className = "item save-ind " + (kind || "");
  if(kind === "saved") setTimeout(()=>{ el.textContent = "✓ Đã lưu"; el.className = "item save-ind"; }, 2000);
}


function persistNow(opts){
  persistPending=false;
  showSaveInd("💾 đang lưu...", "saving");
  if(state.storyId){
    const blob={};
    Object.keys(state).forEach(k=>{ blob[k]=state[k]; });
    GLOBAL_KEYS.forEach(k=>{ blob[k]=state[k]; });
    blob.apiSettings=state.apiSettings;
    blob.storyMetaData=buildStoryMetaData(state);
    saveStoryStateToDisk(state.storyId,blob,opts);
    const idx=storiesIndex.findIndex(x=>x.id===state.storyId);
    if(idx>=0){
      storiesIndex[idx].name=state.storyName||storiesIndex[idx].name;
      storiesIndex[idx].updatedAt=Date.now();
      saveStoriesIndex();
    }
  }
  /* Cấu hình toàn cục vẫn đồng bộ trong runtime; không auto-write localStorage. */
  updateStorageBar();
  showSaveInd("✓ Đã lưu","saved");
}
let persistPending=false;
function persist(){
  persistPending=true;
  showSaveInd("⏳ chờ lưu...","saving");
  clearTimeout(persistTimer);
  persistTimer=setTimeout(()=>persistNow(),1750);
}
/* v11: không đợi debounce 1,75s khi người dùng rời trang / khoá màn hình / chuyển app. */
function flushPersist(){
  if(!persistPending) return;
  clearTimeout(persistTimer);
  persistNow({sync:true});
}
document.addEventListener("visibilitychange",()=>{ if(document.visibilityState==="hidden") flushPersist(); });
window.addEventListener("pagehide",flushPersist);
window.addEventListener("beforeunload",flushPersist);
function loadGlobalSettings(){
  try{
    const raw = localStorage.getItem(GLOBAL_KEY);
    if(!raw) return;
    const g = JSON.parse(raw);
    GLOBAL_KEYS.forEach(k=>{ if(g[k] !== undefined) state[k] = g[k]; });
  }catch(e){}
}

async function loadCurrentStoryIntoState(){
  loadGlobalSettings();
  const s = await loadStoryStateFromDiskAsync(currentStoryId);
  if(!s){
    const fresh = newStoryState();
    const keep = {}; GLOBAL_KEYS.forEach(k=> keep[k] = state[k]);
    Object.assign(state, keep, fresh);
    state.storyId = fresh.storyId;
    currentStoryId = fresh.storyId;
    saveStoryStateToDisk(fresh.storyId, fresh);
    storiesIndex.push({ id: fresh.storyId, name: fresh.storyName, updatedAt: Date.now() });
    saveStoriesIndex();
    localStorage.setItem(LAST_STORY_KEY, fresh.storyId);
    return;
  }
  const keep = {}; GLOBAL_KEYS.forEach(k=> keep[k] = state[k]);
  Object.assign(state, keep, s);
  state.storyId = s.storyId || currentStoryId;
  if(!state.storyName){
    const meta = storiesIndex.find(x=>x.id===state.storyId);
    state.storyName = meta ? meta.name : "Truyện không tên";
  }
  if(!state.mainCharProfile) state.mainCharProfile = newMainCharProfile();
  // V12.3: chuẩn hóa độ dài cũ về 500–6.000 từ; hard cap thực tế là +15%.
  state.minChapterWords = Math.min(6000, Math.max(500, Number(state.minChapterWords) || 5000));
  if(!state.styleBible) state.styleBible = { pov:"third_limited", tense:"past", tone:"", sample:"", extra:"" };
  if(!state.vocabulary) state.vocabulary = { preferred:"", banned:"", overused:"", anatomy:"" };
  if(!Array.isArray(state.locations)) state.locations = [];
  if(!Array.isArray(state.items)) state.items = [];
  if(!Array.isArray(state.outlinePlans)) state.outlinePlans = [];
  if(!Array.isArray(state.triggeredCheckpoints)) state.triggeredCheckpoints = [];
  if(!Array.isArray(state.scenes)) state.scenes = [];
  if(typeof state.autoNextChapterHint !== "string") state.autoNextChapterHint = "";
  if(!state.nextChapterHintMeta || typeof state.nextChapterHintMeta !== "object") state.nextChapterHintMeta = { targetChapter: 0, version: 0, status: "unverified" };
  if(!Number.isFinite(Number(state.nextChapterHintMeta.targetChapter))) state.nextChapterHintMeta.targetChapter = 0;
  if(!Number.isFinite(Number(state.nextChapterHintMeta.version))) state.nextChapterHintMeta.version = 0;
  if(!state.nextChapterHintMeta.status) state.nextChapterHintMeta.status = "unverified";
  if(!state._hintAutoV25){ state.hintStyle = "auto"; state._hintAutoV25 = true; }   /* V12.25: kiểu gợi ý mặc định = Tự động */
  if(!Array.isArray(state.consentLog)) state.consentLog = [];
  if(!state.statusState || typeof state.statusState !== "object") state.statusState = {};
  if(!Array.isArray(state.timeline)) state.timeline = [];
  if(!Array.isArray(state.timeLog)) state.timeLog = [];
  if(!Array.isArray(state.organizations)) state.organizations = [];
  if(!Array.isArray(state.foreshadowing)) state.foreshadowing = [];
  if(!Array.isArray(state.knowledgeLedger)) state.knowledgeLedger = [];
  if(!Array.isArray(state.memoryEvents)) state.memoryEvents = [];
  if(!state.layeredMemory || typeof state.layeredMemory !== "object") state.layeredMemory = {};
  state.layeredMemory.schemaVersion = 1;
  state.layeredMemory.config = Object.assign({ chunkSize: 4, chunksPerArc: 5, arcsPerVolume: 3 }, state.layeredMemory.config || {});
  state.layeredMemory.summaries = Object.assign({ L1: [], L2: [], L3: [], L4: [], L5: [] }, state.layeredMemory.summaries || {});
  ["L1", "L2", "L3", "L4", "L5"].forEach(k => { if(!Array.isArray(state.layeredMemory.summaries[k])) state.layeredMemory.summaries[k] = []; });
  if(!Array.isArray(state.layeredMemory.history)) state.layeredMemory.history = [];
  if(!Number.isFinite(Number(state.lastMemorySyncChapter))) state.lastMemorySyncChapter = 0;
  /* v10.2 normalize merged metadata objects */
  if(!state.apiSettings || typeof state.apiSettings!=="object") state.apiSettings={};
  state.apiSettings.endpoint=state.apiEndpoint||state.apiSettings.endpoint||"https://openrouter.ai/api/v1/chat/completions";
  state.apiSettings.key=state.apiKey||state.apiSettings.key||"";
  state.apiSettings.primaryModel=state.model||state.apiSettings.primaryModel||"deepseek/deepseek-v3.2";
  state.apiSettings.nsfwModel=state.modelNsfw||state.apiSettings.nsfwModel||"aion-labs/aion-2.0";
  state.apiSettings.nsfwMode=state.nsfwMode||state.apiSettings.nsfwMode||"auto";
  state.apiSettings.nsfwThreshold=Number(state.nsfwAutoThreshold||state.apiSettings.nsfwThreshold||6);
  state.storyMetaData=buildStoryMetaData(state);
  if(!Array.isArray(state.characterCards)) state.characterCards=[];
  if(!Array.isArray(state.banWords)) state.banWords=[];
  if(!Array.isArray(state.glossaryLock)) state.glossaryLock=[];
  if(!state.characterStateTracker||typeof state.characterStateTracker!=="object") state.characterStateTracker={};
  if(!Number.isFinite(Number(state.tokenCapPerPrompt))) state.tokenCapPerPrompt=5;
  if(!Number.isFinite(Number(state.snapshotLimit))) state.snapshotLimit=7;
  if(state.wakeLockEnabled==null) state.wakeLockEnabled=true;
  if(!Number.isFinite(Number(state.slidingWindowWords))) state.slidingWindowWords=1500;
  state.schemaVersion = 13;
}

/* ========== DOM REFS ========== */
const $ID = id => document.getElementById(id);

/* V12.33 P0/P1/P2 helpers — giữ nguyên schema dữ liệu cũ */
const AGE_GATE_KEY = "xta_age_verified_v1";
function setupAgeGate(){
  const gate=$ID("ageGate"), check=$ID("ageGateCheck"), cont=$ID("ageGateContinue");
  if(!gate||!check||!cont) return;
  if(window.__XTA_TEST__ || localStorage.getItem(AGE_GATE_KEY)==="1"){ gate.hidden=true; return; }
  gate.hidden=false;
  check.addEventListener("change",()=>{cont.disabled=!check.checked;});
  cont.addEventListener("click",()=>{if(!check.checked)return; try{localStorage.setItem(AGE_GATE_KEY,"1");}catch(e){} gate.hidden=true;});
}
function setupUIMode(){
  const sel=$ID("uiModeSelect"); if(!sel)return;
  let mode="simple"; try{mode=localStorage.getItem("xta_ui_mode")||"simple";}catch(e){}
  const sections=[...document.querySelectorAll(".sidebar .section")];
  const applyMode=()=>{
    mode=sel.value==="expert"?"expert":"simple";
    document.body.classList.toggle("ui-simple",mode==="simple");
    sections.forEach(sec=>{const head=sec.querySelector(".section-head span"); const text=(head&&head.textContent||"").trim();
      const essential=/^(0\.0|0\.1|0\.2|2\.\s|4\.)/.test(text);
      sec.dataset.simpleHidden=mode==="simple"&&!essential?"true":"false";
    });
    try{localStorage.setItem("xta_ui_mode",mode);}catch(e){}
  };
  sel.value=mode; applyMode();
  sel.addEventListener("change",()=>{applyMode();setStatus(mode==="simple"?"Đã bật Chế độ đơn giản — các mục nâng cao đã được ẩn.":"Đã bật Chế độ chuyên gia — toàn bộ công cụ đã hiện.",false);});
}
function setWriteProgress(step){
  const box=$ID("writeProgress"); if(!box)return;
  if(!step){box.classList.remove("on"); box.querySelectorAll(".progress-step").forEach(x=>x.classList.remove("active","done")); return;}
  box.classList.add("on"); const order=["plan","write","expand","gate","post","sync"], at=order.indexOf(step);
  box.querySelectorAll(".progress-step").forEach(x=>{const i=order.indexOf(x.dataset.progress);x.classList.toggle("active",i===at);x.classList.toggle("done",i<at);});
}
async function runSecurityAudit(){
  const box=$ID("securityAudit"), txt=$ID("securityAuditText"); if(!box||!txt)return;
  txt.textContent="Đang kiểm tra cấu hình server…"; box.className="security-audit";
  try{
    const r=await fetch("/.netlify/functions/security-status",{headers:{"Accept":"application/json"}});
    if(!r.ok) throw new Error("HTTP "+r.status);
    const d=await r.json(); const bad=(d.checks||[]).filter(x=>!x.ok);
    box.className="security-audit "+(bad.length?"bad":"ok");
    txt.textContent=bad.length?"⚠ "+bad.map(x=>x.label).join(" · ")+" — hãy sửa trước khi chạy viết nền.":"✓ Cấu hình server đạt mức khuyến nghị.";
  }catch(e){
    box.className="security-audit bad";
    txt.textContent="Không đọc được endpoint kiểm tra. Hãy đặt JOB_SECRET, APP_PASSCODE và ALLOWED_ORIGIN trên Netlify; nếu chỉ viết cục bộ, có thể bỏ qua.";
  }
}
function setupSecurityAudit(){const b=$ID("securityAuditBtn");if(b)b.addEventListener("click",runSecurityAudit);}
function showOnboardingWizard(){
  if(window.__XTA_TEST__ || state.chapters.length || state.mainPlot || state.mainCharProfile&&state.mainCharProfile.name) return;
  const ov=document.createElement("div"); ov.className="age-gate"; ov.id="onboardingWizard";
  ov.innerHTML='<div class="age-gate-card onboarding-card"><h2>✍ Bắt đầu một truyện mới</h2><p>Chỉ cần điền vài thông tin cốt lõi. Các thiết lập nâng cao có thể bổ sung sau.</p><label>Tên truyện<input id="wizStoryName" type="text" placeholder="Ví dụ: Mùa Hạ Không Tên"></label><label>Thể loại / không khí<input id="wizGenre" type="text" placeholder="Ví dụ: dark romance, đô thị"></label><label>Nhân vật chính<input id="wizChar" type="text" placeholder="Tên nhân vật"></label><label>Tuổi nhân vật chính<input id="wizAge" type="number" min="18" value="25"></label><label>Ý tưởng chương đầu<textarea id="wizIdea" rows="4" placeholder="Chương đầu bắt đầu như thế nào?"></textarea></label><button class="btn btn-gold" id="wizStart">Lưu thiết lập và bắt đầu</button><button class="btn btn-ghost" id="wizSkip">Bỏ qua, tự thiết lập sau</button></div>';
  document.body.appendChild(ov);
  $ID("wizSkip").addEventListener("click",()=>ov.remove());
  $ID("wizStart").addEventListener("click",()=>{
    const name=$ID("wizStoryName").value.trim(), genre=$ID("wizGenre").value.trim(), ch=$ID("wizChar").value.trim(), age=$ID("wizAge").value.trim(), idea=$ID("wizIdea").value.trim();
    if(name)state.storyName=name; if(genre){state.genre=genre;const g=$ID("genre");if(g)g.value=genre;} if(idea){state.mainPlot=idea;const p=$ID("mainPlot");if(p)p.value=idea;state.directive=idea; if(nextChapterHintEl)nextChapterHintEl.value=idea;}
    if(ch){state.mainCharProfile=Object.assign(newMainCharProfile(),state.mainCharProfile||{}, {name:ch,age:age||"25"}); hydrateFormFromState();}
    persistNow(); renderAll(); renderStoryTabs(); ov.remove(); setStatus("Đã tạo thiết lập cơ bản. Bạn có thể bấm ✨ Tạo Chương Mới.",false);
  });
}

const apiEndpointInput = $ID("apiEndpoint"), apiKeyInput = $ID("apiKey"), modelSelect = $ID("modelSelect");
const modelNsfwSelect = $ID("modelNsfwSelect"), nsfwModeSelect = $ID("nsfwModeSelect"), apiStatus = $ID("apiStatus");
const nsfwAutoThresholdInput = $ID("nsfwAutoThreshold");
const mainPlotEl = $ID("mainPlot"), genreEl = $ID("genre"), worldSettingEl = $ID("worldSetting");
const worldRulesEl = $ID("worldRules"), antagonistEl = $ID("antagonist"), pronounRulesEl = $ID("pronounRules");
const worldDescriptionEl = $ID("worldDescription");
const storyBibleLockEl = $ID("storyBibleLock"), storyClockEl = $ID("storyClock") || { value: "" }, directiveEl = $ID("directive");
const nextChapterHintEl = $ID("nextChapterHint") || { value: "" };
const chapterMatureFocusEl = $ID("chapterMatureFocus") || { value: "none" };
const advancedRulesEl = $ID("advancedRules"), difficultyEl = $ID("difficulty"), matureToggle = $ID("matureToggle");
const statusBox = $ID("statusBox"), statusEdit = $ID("statusEdit"), charList = $ID("charList");
const arcList = $ID("arcList"), outlineList = $ID("outlineList"), locationList = $ID("locationList");
const itemList = $ID("itemList"), threadList = $ID("threadList"), continuityList = $ID("continuityList"), memoryStats = $ID("memoryStats");
const sceneList = $ID("sceneList"), consentList = $ID("consentList");
const chapterStrip = $ID("chapterStrip"), chapterSearch = $ID("chapterSearch"), quickJumpSelect = $ID("quickJumpSelect");
const deleteChapterSelect = $ID("deleteChapterSelect"), deleteWipeMemoryToggle = $ID("deleteWipeMemoryToggle");
const chapterTitleEl = $ID("chapterTitle"), editorBadges = $ID("editorBadges");
const summaryBox = $ID("summaryBox"), planBox = $ID("planBox"), sceneBox = $ID("sceneBox"), chapterTextEl = $ID("chapterText");
const statusLine = $ID("statusLine"), autoToggle = $ID("autoToggle"), autoIntervalInput = $ID("autoIntervalInput");
const includeKeyToggle = $ID("includeKeyToggle"), spellCheckToggle = $ID("spellCheckToggle");
const autoContinueToggle = $ID("autoContinueToggle"), autoSummaryToggle = $ID("autoSummaryToggle");
const autoSceneToggle = $ID("autoSceneToggle");
const dupCheckToggle = $ID("dupCheckToggle"), streamingToggle = $ID("streamingToggle");
const queueToggle = $ID("queueToggle"), parallelToggle = $ID("parallelToggle");
const checkpointToggle = $ID("checkpointToggle"), autoRepairOnCreateToggle = $ID("autoRepairOnCreateToggle");
const minWordsInput = $ID("minWordsInput"), chapterWordMinInput = $ID("chapterWordMinInput"), chapterWordMaxInput = $ID("chapterWordMaxInput"), autoContinueMaxInput = $ID("autoContinueMaxInput");
const regenModeSelect = $ID("regenModeSelect");
const descriptionLevelSelect = $ID("descriptionLevelSelect");
const explicitLevelSelect = $ID("explicitLevelSelect");
const backupBanner = $ID("backupBanner"), backupBannerText = $ID("backupBannerText");
const checkpointBanner = $ID("checkpointBanner"), checkpointBannerText = $ID("checkpointBannerText"), checkpointActions = $ID("checkpointActions");
const pacingBanner = $ID("pacingBanner"), pacingBannerText = $ID("pacingBannerText"), pacingActions = $ID("pacingActions");
const storyTabList = $ID("storyTabList"), floatingRewrite = $ID("floatingRewrite");
const stopBtn = $ID("stopBtn");

let autoTimer = null;
/* V12.14: bộ hẹn giờ "Tự động tạo" (trước đây thiếu hàm -> ReferenceError). Chỉ bấm viết khi nút đang rảnh. */
function scheduleNextAuto(){
  clearTimeout(autoTimer); autoTimer = null;
  if(!autoToggle || !autoToggle.checked) return;
  const sec = Math.max(30, parseInt(autoIntervalInput.value,10) || 180);
  autoTimer = setTimeout(()=>{
    autoTimer = null;
    const btn = $ID("writeChapterBtn");
    if(autoToggle.checked && btn && !btn.disabled){ try{ btn.click(); }catch(e){ console.error(e); } }
    scheduleNextAuto();
  }, sec*1000);
}
let generating = false;
let globalAbort = null;
let lastPromptSent = "";
let lastResponseRaw = "";
/* Cờ "người dùng bấm Dừng" — trước đây callAI kiểm tra opts.userAbort để
   biết có nên coi 1 lần abort() là "người dùng chủ động dừng" (thì dừng
   hẳn) hay chỉ là hết-giờ-timeout (thì thử lại). Nhưng opts.userAbort chưa
   từng được set ở đâu cả trong toàn bộ code => bấm "⏹ Dừng" chỉ hủy được
   request hiện tại, rồi app lại ÂM THẦM TỰ THỬ LẠI (coi như timeout) thay
   vì dừng hẳn như người dùng mong đợi. Dùng cờ toàn cục này để sửa đúng. */
let userStopRequested = false;

document.querySelectorAll("[data-toggle]").forEach(head=>{
  head.addEventListener("click", ()=> head.closest("[data-section]").classList.toggle("open"));
});

function setStatus(msg, busy){
  statusLine.innerHTML = "";
  if(busy){
    const dots = document.createElement("span");
    dots.className = "dot-anim";
    dots.innerHTML = "<span></span><span></span><span></span>";
    statusLine.appendChild(dots);
  }
  const t = document.createElement("span");
  t.textContent = msg;
  statusLine.appendChild(t);
}

function refreshStatBar(){
  $ID("statChaptersBar").textContent = state.chapters.length;
  const totalW = state.chapters.reduce((s,c)=> s + (c.wordCount||countWords(c.text)), 0);
  $ID("statWordsBar").textContent = totalW.toLocaleString("vi-VN");
  $ID("statScenesBar").textContent = (state.scenes||[]).length;
  $ID("statCostBar").textContent = "$" + (state.totalCostUSD || 0).toFixed(3);
  $ID("statCallsBar").textContent = state.totalCalls || 0;
}

function refreshBackupBanner(){
  if(state.chaptersSinceBackup >= 5){
    backupBannerText.textContent = "Đã " + state.chaptersSinceBackup + " chương chưa sao lưu JSON.";
    backupBanner.classList.add("show");
  } else backupBanner.classList.remove("show");
}

function updateStorageBar(){
  const fill=$ID("storageFill"), txt=$ID("storageText");
  if(!(navigator.storage && navigator.storage.estimate)) return;
  navigator.storage.estimate().then(({usage=0,quota=0})=>{
    if(!quota) return;
    const pct=Math.min(100,usage/quota*100);
    if(fill) fill.style.width=Math.max(pct,0.5).toFixed(1)+"%";
    if(txt){ txt.textContent=(usage/1048576).toFixed(1)+" MB đã dùng / ~"+Math.round(quota/1048576)+" MB cho phép ("+pct.toFixed(1)+"%)"+(pct>75?" ⚠ sắp đầy — nên nén chương cũ":""); txt.style.color=pct>80?"var(--red)":(pct>60?"var(--amber)":"var(--ink-dim)"); }
  }).catch(()=>{});
}

/* ========== STORY TABS ========== */
function renderStoryTabs(){
  storyTabList.innerHTML = "";
  storiesIndex.forEach(meta=>{
    const tab = document.createElement("div");
    tab.className = "story-tab" + (meta.id === currentStoryId ? " active" : "");
    tab.innerHTML = '<span>'+escapeHtml(meta.name || "Truyện")+'</span>'
      + (storiesIndex.length > 1 ? '<span class="story-tab-close" title="Xoá">×</span>' : '');
    tab.addEventListener("click", (e)=>{
      if(e.target.classList.contains("story-tab-close")) return;
      if(meta.id === currentStoryId) return;
      switchStory(meta.id);
    });
    const closeEl = tab.querySelector(".story-tab-close");
    if(closeEl) closeEl.addEventListener("click", (e)=>{ e.stopPropagation(); deleteStory(meta.id); });
    tab.addEventListener("dblclick", (e)=>{
      if(e.target.classList.contains("story-tab-close")) return;
      renameStory(meta.id);
    });
    storyTabList.appendChild(tab);
  });
}
async function switchStory(storyId){
  if(storyId === currentStoryId) return;
  persistNow();
  currentStoryId = storyId;
  localStorage.setItem(LAST_STORY_KEY, storyId);
  openCharDetails.clear();
  await loadCurrentStoryIntoState();
  hydrateFormFromState();
  renderAll();
  renderStoryTabs();
  setStatus("Đã chuyển sang: " + (state.storyName||""), false);
}
async function renameStory(storyId){
  const meta = storiesIndex.find(x=>x.id===storyId);
  if(!meta) return;
  const name = await askText("Đổi tên truyện", meta.name || "");
  if(name == null) return;
  meta.name = name.trim() || meta.name;
  saveStoriesIndex();
  if(storyId === currentStoryId){ state.storyName = meta.name; persist(); }
  renderStoryTabs();
}
async function deleteStory(storyId){
  if(storiesIndex.length <= 1){ setStatus("Không thể xoá truyện duy nhất.", false); return; }
  const meta = storiesIndex.find(x=>x.id===storyId);
  const ok = await showConfirm("Xoá vĩnh viễn \""+(meta?meta.name:"?")+"\"?", {okText:"Xoá", danger:true});
  if(!ok) return;
  removeStoryFromDisk(storyId);
  /* v10.2.4: nếu truyện này đang có job nền chờ đồng bộ, huỷ theo dõi luôn — nếu không, job cũ
     hoàn tất sau này sẽ bị merge nhầm vào bất kỳ truyện nào đang mở lúc đó (xem mergeBackgroundChapter). */
  try{
    const pending = normalizeBgRecord(localStorage.getItem(BG_JOB_KEY));
    if(pending && pending.storyId === storyId){
      if(bgPollTimer){ clearInterval(bgPollTimer); bgPollTimer=null; }
      localStorage.removeItem(BG_JOB_KEY);
    }
  }catch(e){}
  storiesIndex = storiesIndex.filter(x=>x.id!==storyId);
  saveStoriesIndex();
  if(storyId === currentStoryId){
    currentStoryId = storiesIndex[0].id;
    localStorage.setItem(LAST_STORY_KEY, currentStoryId);
    openCharDetails.clear();
    await loadCurrentStoryIntoState(); hydrateFormFromState(); renderAll();
  }
  renderStoryTabs();
  setStatus("Đã xoá truyện.", false);
}
$ID("storyTabAdd").addEventListener("click", async ()=>{
  const name = await askText("Tên truyện mới", "Truyện " + (storiesIndex.length + 1));
  if(name == null) return;
  persistNow();
  const s = newStoryState((name||"").trim() || ("Truyện " + (storiesIndex.length + 1)));
  saveStoryStateToDisk(s.storyId, s);
  storiesIndex.push({ id: s.storyId, name: s.storyName, updatedAt: Date.now() });
  saveStoriesIndex();
  currentStoryId = s.storyId;
  localStorage.setItem(LAST_STORY_KEY, s.storyId);
  openCharDetails.clear();
  await loadCurrentStoryIntoState(); hydrateFormFromState(); renderAll(); renderStoryTabs();
  setStatus("Đã tạo: " + state.storyName, false);
});
$ID("newStoryBtn").addEventListener("click", ()=> $ID("storyTabAdd").click());

$ID("duplicateStoryBtn").addEventListener("click", async ()=>{
  const ok = await showConfirm("Nhân bản truyện \""+state.storyName+"\"?", {okText:"Nhân bản"});
  if(!ok) return;
  persist();
  const blob = JSON.parse(JSON.stringify(state));
  blob.storyId = newStoryId();
  blob.storyName = state.storyName + " (bản nháp)";
  GLOBAL_KEYS.forEach(k=> delete blob[k]);
  saveStoryStateToDisk(blob.storyId, blob);
  storiesIndex.push({ id: blob.storyId, name: blob.storyName, updatedAt: Date.now() });
  saveStoriesIndex();
  currentStoryId = blob.storyId;
  localStorage.setItem(LAST_STORY_KEY, blob.storyId);
  openCharDetails.clear();
  await loadCurrentStoryIntoState(); hydrateFormFromState(); renderAll(); renderStoryTabs();
  setStatus("Đã nhân bản.", false);
});

/* ========== CHAPTER MATURE FOCUS ========== */

function matureFocusAllowsRouting(){
  if(!state.mature) return false;
  return normalizeChapterMatureFocus(state.chapterMatureFocus) !== "none";
}
function matureFocusPrompt(){
  const f=normalizeChapterMatureFocus(state.chapterMatureFocus);
  if(f === "primary") return "TRỌNG TÂM TRƯỞNG THÀNH: PRIMARY. Chủ đề trưởng thành là một trọng tâm được người dùng chỉ định cho chương này. Chỉ triển khai trong phạm vi brief/mạch truyện đã có; không tự mở tuyến mới. Cốt truyện vẫn phải tiến triển song song: cảnh nóng phải làm đổi quan hệ/quyền lực/bí mật/hậu quả, không lặp một cảnh để kéo dài.";
  if(f === "secondary") return "TRỌNG TÂM TRƯỞNG THÀNH: SECONDARY. Chỉ sử dụng nội dung trưởng thành khi brief hoặc diễn biến hiện tại yêu cầu rõ. Không biến nó thành trọng tâm và không tự chèn cảnh chỉ để tăng nhiệt.";
  return "TRỌNG TÂM TRƯỞNG THÀNH: NONE. Tuyệt đối không tự chèn hoặc kéo dài nội dung trưởng thành trong chương này, kể cả khi mạch truyện trước đó có nội dung trưởng thành.";
}

/* ========== MODEL PICK ========== */
function pickWritingModel(forceNsfw){
  if(normalizeChapterMatureFocus(state.chapterMatureFocus) === "none") forceNsfw = false;
  const mainModel = (state.model || modelSelect.value.trim() || "").trim();
  const nsfwModel = (state.modelNsfw || modelNsfwSelect.value.trim() || "").trim();
  if(forceNsfw){
    if(nsfwModel) return { model: nsfwModel, isNsfw: true };
    return { model: mainModel, isNsfw: false, warn: "Chưa cấu hình NSFW." };
  }
  if(!nsfwModel) return { model: mainModel, isNsfw: false };
  const mode = state.nsfwMode || "auto";
  if(mode === "never") return { model: mainModel, isNsfw: false };
  if(mode === "always") return { model: nsfwModel, isNsfw: true };
  if(mode === "mature_only"){
    if(state.mature) return { model: nsfwModel, isNsfw: true };
    return { model: mainModel, isNsfw: false };
  }
  return { model: mainModel, isNsfw: false, isAuto: true };
}

/* ========== NSFW KEYWORD DETECT (ép chuyển model ngay) ========== */

// V12.14: khớp theo TỪ nguyên vẹn (Unicode), không khớp chuỗi con — tránh "cà phê", "cây bút", "phản kháng"... bị nhận nhầm là 18+.

/** Kiểm tra mệnh lệnh + kế hoạch + đoạn gần → có nên ép NSFW không */
function shouldForceNsfwByKeyword(plan, tail){
  if(!state.mature) return false;
  if(!matureFocusAllowsRouting()) return false;
  if((state.nsfwMode || "auto") === "never") return false;
  if(!state.modelNsfw) return false;
  const sources = [
    state.directive || "",
    state.nextChapterHint || "",
    plan || "",
    (tail || "").slice(-1500),
    (state.chapters[state.currentChapterIndex] && state.chapters[state.currentChapterIndex].title) || ""
  ].join("\n");
  return textHasNsfwKeyword(sources);
}

/* ========== HEAT DETECTION ========== */
async function detectHeatLevel(tail, plan){
  const prompt = [
    "Bạn là bộ phân loại nhiệt độ cảnh cho tiểu thuyết.",
    "Chấm mức 18+ của CẢNH SẮP VIẾT theo thang 0-10:",
    "0-2 bình thường | 3-4 cảm xúc nhẹ | 5-6 hôn/ôm | 7-8 cởi đồ/sờ | 9-10 quan hệ",
    "CHỈ TRẢ VỀ 1 SỐ DUY NHẤT. KHÔNG giải thích.",
    "",
    "MỆNH LỆNH: " + (state.directive || "(không)"),
    matureFocusPrompt(),
    "KẾ HOẠCH: " + (plan || "(không)"),
    "DIỄN BIẾN GẦN:",
    (tail || "(chưa có)").slice(-2000)
  ].join("\n");
  try{
    const { text } = await callAI(prompt, {
      maxTokens: 8, temperature: 0.1,
      modelOverride: state.model, skipTracking: true
    });
    const m = String(text).match(/\d+/);
    const n = m ? parseInt(m[0], 10) : 0;
    return Math.max(0, Math.min(10, isNaN(n) ? 0 : n));
  }catch(e){ console.warn("[HeatDetect]", e.message); return 0; }
}

/* ========== AI CALL ========== */
const AI_CALL_TIMEOUT_MS = 180000;
const AI_IDLE_TIMEOUT_MS = 90000;
const AI_MAX_RETRIES = 4;
/* V12.32.16: lỗi 5xx từ nhà cung cấp model (502 "The server had an error…") thường kéo dài vài giây–vài chục giây -> chờ lâu hơn giữa các lần thử. */
const AI_BACKOFF_5XX_MS = [2000, 5000, 10000, 20000];
const AI_RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504, 524]);

function trackCost(model, inTok, outTok, step){
  const p = priceForModel(model);
  const cost = (inTok/1e6)*p.in + (outTok/1e6)*p.out;
  try{ recordStepUsage(state, step || "other", model, inTok, outTok, cost); }catch(_){}
  state.totalCalls = (state.totalCalls||0) + 1;
  state.totalTokensIn = (state.totalTokensIn||0) + inTok;
  state.totalTokensOut = (state.totalTokensOut||0) + outTok;
  state.totalCostUSD = (state.totalCostUSD||0) + cost;
  refreshStatBar();
}

/* V12.25d: đo thời gian từng lượt gọi AI để biết bước nào chậm. Hiện tóm tắt cuối mỗi chương (viết thường). */
let _callLog = [], _chapterStartAt = 0;
function _callLabel(prompt){
  const p = String(prompt || "");
  const map = [
    [/Bạn đang viết CHƯƠNG THỨ/i, "Viết chính"], [/VIẾT TIẾP chương/i, "Viết tiếp"], [/CHÈN THÊM DIỄN BIẾN/i, "Chèn diễn biến"],
    [/ĐỂ CHẠM ĐIỂM KẾT/i, "Chốt kết"], [/kiểm tra tiến độ chương/i, "Kiểm tra điểm kết"], [/GỢI Ý CHI TIẾT cho CHƯƠNG/i, "Gợi ý chương sau"],
    [/MỞ RỘNG CHƯƠNG/i, "Mở rộng"], [/chấm.*nhiệt|nhiệt độ cảnh/i, "Chấm nhiệt 18+"]
  ];
  for(const [re, name] of map) if(re.test(p.slice(0, 1500))) return name;
  return p.replace(/\s+/g, " ").trim().slice(0, 32) || "AI";
}
async function callAI(prompt, opts){
  const _t0 = Date.now();
  opts = opts || {};
  const endpoint = state.apiEndpoint || apiEndpointInput.value.trim();
  let key = state.apiKey || apiKeyInput.value.trim();
  key = key.trim().replace(/^bearer\s+/i, "").replace(/^["']|["']$/g, "");
  let model = (opts.modelOverride || state.model || modelSelect.value.trim() || "").trim();
  /* V14.0.15: model riêng cho bước phụ (post/gate/check/hint) — chỉ khi không có override riêng hoặc override = model chính. */
  if(!opts.modelOverride || opts.modelOverride === state.model){ const _st = classifyStep(prompt); const _sm = modelForStep(state, _st, ""); if(_sm && ["post","gate","check","hint"].includes(_st)) model = _sm; }
  if(!endpoint) throw new Error("Chưa cấu hình endpoint.");
  if(!key) throw new Error("Chưa có API key.");
  if(!model) throw new Error("Chưa nhập model.");

  lastPromptSent = prompt;
  /* V14.7.1: không bao giờ để API key lọt vào thông báo lỗi (nhà cung cấp hay lặp lại key trong 401, trình duyệt có thể đưa URL/header vào lỗi mạng). */
  const redactKey = m => { let t = String(m == null ? "" : m); if(key.length >= 6) t = t.split(key).join("[đã che API key]"); return t.replace(/\b(?:sk|pk|key)-[A-Za-z0-9_-]{8,}/g, "[đã che API key]").replace(/(Bearer\s+)[A-Za-z0-9._~+\/=-]{12,}/gi, "$1[đã che]"); };
  let streaming = opts.streaming && state.streamingEnabled && typeof opts.onChunk === "function";

  const systemPrompt = String(opts.systemPrompt || SYSTEM_PROMPT);
  const body = {
    model, messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt }
    ],
    temperature: opts.temperature != null ? opts.temperature : 0.9,
    max_tokens: Math.max(1, Math.min(AI_MAX_OUTPUT_TOKENS, Number(opts.maxTokens) || 2048)), // V12.31.2: AnonRouter/model cap 8192; leave headroom to avoid provider rejection
    /* v9.3: gọi trích xuất JSON (temperature thấp) KHÔNG dùng penalty — penalty làm model né lặp key/dấu ngoặc nên JSON hỏng. */
    frequency_penalty: opts.frequency_penalty != null ? opts.frequency_penalty : ((opts.temperature != null && opts.temperature <= 0.3) ? 0 : 0.45),
    presence_penalty: opts.presence_penalty != null ? opts.presence_penalty : ((opts.temperature != null && opts.temperature <= 0.3) ? 0 : 0.35)
  };
  if(streaming) body.stream = true;

  const isOpenRouter = /openrouter\.ai/i.test(endpoint);
  if(opts.reasoningEffort && isOpenRouter) body.reasoning = { effort: opts.reasoningEffort };   /* V12.25: giảm thời gian "nghĩ" của model reasoning */
  const headers = { "Content-Type": "application/json", "Authorization": "Bearer " + key };
  if(isOpenRouter){
    headers["HTTP-Referer"] = location.protocol === "file:" ? "https://localhost" : location.origin;
    headers["X-Title"] = "Xuong Truyen AI Pro Max v14.7.9";
  }

  let lastErr = null;
  for(let attempt = 0; attempt <= AI_MAX_RETRIES; attempt++){
    const controller = new AbortController();
    globalAbort = controller;
    let timer = setTimeout(()=>controller.abort(), AI_CALL_TIMEOUT_MS);
    const armTimer = ms => { clearTimeout(timer); timer = setTimeout(()=>controller.abort(), ms); };
    let res;
    try{
      res = await fetch(endpoint, { method:"POST", headers, body: JSON.stringify(body), signal: controller.signal });
    }catch(networkErr){
      clearTimeout(timer); globalAbort = null;
      const isFile = location.protocol === "file:";
      const isLocalhost = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
      if(networkErr.name === "AbortError"){
        if(userStopRequested){ const e = new Error("Đã hủy."); e.userAbort = true; throw e; }
        lastErr = new Error("Hết thời gian chờ.");
      }
      else if(isFile) lastErr = new Error("file:// — CORS.");
      else if(!isLocalhost && location.protocol !== "https:") lastErr = new Error("http:// không phải localhost.");
      else lastErr = new Error("Không kết nối API (" + redactKey(networkErr.message||"network") + ").");
      if(attempt < AI_MAX_RETRIES){ await sleep(800 * Math.pow(2, attempt)); continue; }
      throw lastErr;
    }
    if(streaming && res.ok) armTimer(AI_IDLE_TIMEOUT_MS); else clearTimeout(timer);
    if(!res.ok){
      globalAbort = null;
      let detail = "";
      try{ const raw = await res.json(); detail = (raw.error && (raw.error.message || raw.error)) || JSON.stringify(raw); }
      catch(e){ detail = res.statusText; }
      const err = new Error(redactKey(detail) || ("HTTP " + res.status));
      err.status = res.status;
      if(res.status === 400 && body.reasoning){ delete body.reasoning; lastErr = err; continue; }   /* model/endpoint không nhận tham số reasoning -> thử lại không có */
      if(AI_RETRYABLE_STATUS.has(res.status) && attempt < AI_MAX_RETRIES){
        lastErr = err;
        const ra = parseFloat(res.headers.get("retry-after"));
        const is5xx = res.status >= 500;
        await sleep(!isNaN(ra) ? Math.min(ra*1000, 30000) : (is5xx ? AI_BACKOFF_5XX_MS[Math.min(attempt, AI_BACKOFF_5XX_MS.length-1)] : 1000 * Math.pow(2, attempt)));
        continue;
      }
      if(res.status >= 500){ err.message = String(err.message || "") + " [HTTP " + res.status + " — lỗi phía nhà cung cấp model/endpoint sau " + (attempt+1) + " lần thử; thử lại sau ít phút hoặc đổi model]"; }
      throw err;
    }

    let content = "";
    let finishReason = null;

    if(streaming && /text\/event-stream/i.test(res.headers.get("content-type") || "")){
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      const consumeSSELine = line => {
        const trimmed = String(line || "").trim();
        if(!trimmed || trimmed.startsWith(":")) return;
        // SSE chuẩn cho phép "data:" không có dấu cách sau dấu hai chấm.
        if(!trimmed.startsWith("data:")) return;
        const payload = trimmed.slice(5).trim();
        if(!payload || payload === "[DONE]") return;
        try{
          const json = JSON.parse(payload);
          const choice = json.choices && json.choices[0];
          let delta = choice && choice.delta && choice.delta.content;
          // Một số gateway trả content dạng mảng các phần text.
          if(Array.isArray(delta)) delta = delta.map(part => typeof part === "string" ? part : (part && (part.text || part.content)) || "").join("");
          if(typeof delta === "string" && delta.length){ content += delta; opts.onChunk(delta, content); }
          if(choice && choice.finish_reason) finishReason = choice.finish_reason;
        }catch(e){ /* Bỏ qua heartbeat/event không phải JSON; kiểm tra buffer cuối sau khi stream kết thúc. */ }
      };
      try{
        while(true){
          const { done, value } = await reader.read();
          if(done) break;
          armTimer(AI_IDLE_TIMEOUT_MS);
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split(/\r?\n/);
          buffer = lines.pop() || "";
          for(const line of lines) consumeSSELine(line);
        }
        buffer += decoder.decode();
        // Không được bỏ mất event cuối nếu nhà cung cấp không kết thúc bằng newline.
        if(buffer.trim()) consumeSSELine(buffer);
      }catch(streamErr){
        if(streamErr && streamErr.name === "AbortError"){
          globalAbort = null;
          if(userStopRequested){ const ue = new Error("Đã hủy."); ue.userAbort = true; throw ue; }
          if(content.length < 800) throw new Error("Hết thời gian chờ: model không gửi thêm dữ liệu.");
          finishReason = "length"; /* giữ phần đã nhận, vòng viết tiếp sẽ nối */
        } else throw streamErr;
      }finally{ clearTimeout(timer); try{ reader.releaseLock(); }catch(e){} }
      globalAbort = null;
      if(!content.trim()){
        // Gateway có thể nhận stream=true nhưng trả body JSON hoặc stream không có delta content.
        // Chuyển sang non-streaming cho lần thử tiếp theo; không ghi/hiển thị nội dung rỗng.
        if(attempt < AI_MAX_RETRIES){
          streaming = false;
          delete body.stream;
          lastErr = new Error("Streaming không có content; thử lại non-streaming.");
          await sleep(350);
          continue;
        }
        throw new Error("Phản hồi trống (streaming và non-streaming đều không có nội dung).");
      }
    } else {
      let data;
      try{ data = await res.json(); }
      catch(jsonErr){ globalAbort = null; throw new Error("Phản hồi API không phải JSON hợp lệ (có thể do proxy/gateway trả trang lỗi hoặc phản hồi bị cắt). Thử lại hoặc kiểm tra endpoint."); }
      globalAbort = null;
      const choice = data.choices && data.choices[0];
      if(!choice) throw new Error("Không có phản hồi.");
      // KHÔNG bao giờ dùng reasoning/reasoning_content làm nội dung hiển thị.
      // Một số model reasoning (đặc biệt Aion 3.5 Mini) có thể trả phần suy luận riêng;
      // nếu lấy fallback reasoning ở đây, giao diện sẽ hiện tiếng Anh kiểu "Let me start..."
      // thay vì câu trả lời cuối cùng. Chỉ nhận final content/text.
      content = choice.message ? choice.message.content : choice.text;
      finishReason = choice.finish_reason || null;
      if(!content || !content.trim()) throw new Error("Phản hồi cuối rỗng (finish: " + (finishReason||"?") + "). Không dùng reasoning làm nội dung.");
    }

    if(!opts.skipTracking){
      try{
        const inTok = estimateTokens(systemPrompt + prompt);
        const outTok = estimateTokens(content);
        trackCost(model, inTok, outTok, classifyStep(prompt));
      }catch(tcErr){ console.warn("[trackCost]", tcErr); }
    }
    lastResponseRaw = content;
    try{ _callLog.push({ label:_callLabel(prompt), ms: Date.now() - _t0, chars: content.length, model: String(model||"") }); if(_callLog.length > 80) _callLog.shift(); }catch(_){}
    return { text: content.trim(), finishReason, modelUsed: model };
  }
  throw lastErr || new Error("Không thể gọi API.");
}

function stopGeneration(){
  userStopRequested = true;
  if(globalAbort){
    try{ globalAbort.abort(); }catch(e){}
    setStatus("Đã dừng.", false);
  }
  }
stopBtn.addEventListener("click", stopGeneration);

/* ========== QUEUE (parallel + sequential) ========== */
const taskQueue = [];
let queueRunning = false;
/* v12.4: hậu xử lý theo pha. Pha 1: [tóm tắt → gợi ý chương sau] ∥ Nhân vật ∥ Thế giới ∥ rà chính tả.
   Pha 2: Status ∥ Memory (đọc state đã có NV/Thế giới mới). Các hàm merge vào state ĐỒNG BỘ sau mỗi await
   nên chạy song song không ghi đè nhau. Tắt "Song song" trong cài đặt để quay về chế độ tuần tự cũ. */

/* ========== CONFIRM DIALOG ========== */
function showConfirm(message, opts){
  opts = opts || {};
  return new Promise(resolve => {
    const overlay = document.createElement("div"); overlay.className = "modal-overlay";
    const box = document.createElement("div"); box.className = "modal-box"; box.style.maxWidth = "440px";
    const msg = document.createElement("div");
    msg.style.cssText = "font-size:14px;line-height:1.55;color:#e8e8ec;margin-bottom:18px;white-space:pre-wrap;";
    msg.textContent = message;
    const btns = document.createElement("div"); btns.style.cssText = "display:flex;gap:8px;justify-content:flex-end;";
    const btnCancel = document.createElement("button");
    btnCancel.textContent = opts.cancelText || "Hủy";
    btnCancel.style.cssText = "padding:9px 16px;border-radius:8px;border:1px solid #2a2e3a;background:transparent;color:#e8e8ec;font-weight:600;font-size:13px;cursor:pointer;font-family:inherit;";
    const btnOk = document.createElement("button");
    btnOk.textContent = opts.okText || "Đồng ý";
    btnOk.style.cssText = "padding:9px 16px;border-radius:8px;border:1px solid " + (opts.danger ? "#e2584d" : "#d9a441") + ";background:" + (opts.danger ? "rgba(226,88,77,.12)" : "rgba(217,164,65,.12)") + ";color:" + (opts.danger ? "#e2584d" : "#d9a441") + ";font-weight:600;font-size:13px;cursor:pointer;font-family:inherit;";
    if(!opts.hideCancel) btns.appendChild(btnCancel); btns.appendChild(btnOk);
    box.appendChild(msg); box.appendChild(btns);
    overlay.appendChild(box); document.body.appendChild(overlay);
    const onKey = e => { if(e.key==="Escape") cleanup(false); else if(e.key==="Enter") cleanup(true); };
    function cleanup(r){ overlay.remove(); document.removeEventListener("keydown", onKey); resolve(r); }
    btnCancel.onclick = ()=>cleanup(false);
    btnOk.onclick = ()=>cleanup(true);
    overlay.onclick = e => { if(e.target === overlay) cleanup(false); };
    document.addEventListener("keydown", onKey);
    setTimeout(()=>btnOk.focus(), 50);
  });
}

function showAlert(m){ return showConfirm(String(m), {okText:"Đóng", hideCancel:true}); }
function askText(title, def){
  return new Promise(res=>{
    const ov=document.createElement("div"); ov.className="modal-overlay";
    const bx=document.createElement("div"); bx.className="modal-box"; bx.style.maxWidth="440px";
    bx.innerHTML='<div style="font-size:14px;margin-bottom:10px;"></div><input type="text" style="margin-bottom:14px;"><div style="display:flex;gap:8px;justify-content:flex-end;"><button class="btn btn-ghost" style="width:auto;">Hủy</button><button class="btn btn-gold" style="width:auto;">OK</button></div>';
    bx.firstChild.textContent=title; const inp=bx.querySelector("input"); inp.value=def||"";
    const bs=bx.querySelectorAll("button"); const done=v=>{ov.remove();res(v);};
    bs[0].onclick=()=>done(null); bs[1].onclick=()=>done(inp.value);
    inp.onkeydown=e=>{ if(e.key==="Enter"){e.preventDefault();done(inp.value);} else if(e.key==="Escape") done(null); };
    ov.onclick=e=>{ if(e.target===ov) done(null); };
    ov.appendChild(bx); document.body.appendChild(ov); setTimeout(()=>{inp.focus();inp.select();},50);
  });
}
function askChoice(title, options, def){
  return new Promise(res=>{
    const ov=document.createElement("div"); ov.className="modal-overlay";
    const bx=document.createElement("div"); bx.className="modal-box"; bx.style.maxWidth="420px";
    const h=document.createElement("div"); h.style.cssText="font-size:14px;margin-bottom:12px;"; h.textContent=title; bx.appendChild(h);
    const done=v=>{ov.remove();res(v);};
    options.forEach(([k,label])=>{
      const b=document.createElement("button"); b.className="btn "+(k===def?"btn-gold":"btn-ghost"); b.style.marginBottom="8px"; b.textContent=label; b.onclick=()=>done(k); bx.appendChild(b);
    });
    const c=document.createElement("button"); c.className="btn btn-ghost"; c.textContent="Hủy"; c.onclick=()=>done(null); bx.appendChild(c);
    ov.onclick=e=>{ if(e.target===ov) done(null); };
    ov.appendChild(bx); document.body.appendChild(ov);
  });
}

/* ========== SCENE TRACKER ========== */
function newScene(partial){
  return Object.assign({
    id: genId(),
    chapter: null,
    title: "",
    participants: [],
    intensity: 0,       // 0-10
    structure: "",       // VD: "dạo đầu → oral → penetrative → afterglow"
    location: "",
    initiator: "",
    consentState: "",    // "both", "one_doubt", "hesitant", "unclear"
    emotion: "",         // cảm xúc chính
    aftermath: "",       // hậu quả cảm xúc
    boundariesPushed: "", // ranh giới bị đẩy
    firstTime: [],       // VD: ["first_kiss", "first_sex"]
    notes: "",
    createdAt: Date.now()
  }, partial||{});
}

const SCENE_JSON_HINT = 'Trả về DUY NHẤT một mảng JSON các CẢNH 18+ trong chương. Mỗi phần tử: {"title":"Tên ngắn","participants":["Tên1","Tên2"],"intensity":số 0-10,"structure":"mô tả cấu trúc ngắn (dạo đầu→...→kết)","location":"","initiator":"ai chủ động","consentState":"both|one_doubt|hesitant|unclear","emotion":"cảm xúc chính","aftermath":"hậu quả cảm xúc","boundariesPushed":"ranh giới nào bị đẩy","firstTime":["first_kiss","first_sex",...],"notes":""}. Nếu chương KHÔNG có cảnh 18+ → trả về []. TIẾNG VIỆT.';

async function detectScenesInChapter(text, chapterNumber){
  if(!text || !state.mature) return [];
  const prompt = [
    "Đọc chương dưới đây và trích xuất mọi CẢNH 18+ thực sự xảy ra (không tính mơ tưởng, không tính hồi tưởng mơ hồ).",
    "Chương " + chapterNumber + ":",
    text,
    "",
    SCENE_JSON_HINT
  ].join("\n");
  try{
    const { text: raw } = await callAI(prompt, {maxTokens:2000, temperature:0.2, skipTracking:true});
    const arr = safeJsonParse(raw);
    if(!Array.isArray(arr)) return [];
    return arr.map(s=> newScene({
      chapter: chapterNumber,
      title: s.title || "",
      participants: Array.isArray(s.participants) ? s.participants : [],
      intensity: Math.max(0, Math.min(10, parseInt(s.intensity,10) || 0)),
      structure: s.structure || "",
      location: s.location || "",
      initiator: s.initiator || "",
      consentState: s.consentState || "",
      emotion: s.emotion || "",
      aftermath: s.aftermath || "",
      boundariesPushed: s.boundariesPushed || "",
      firstTime: Array.isArray(s.firstTime) ? s.firstTime : [],
      notes: s.notes || ""
    }));
  }catch(e){ console.warn("[SceneDetect]", e.message); return []; }
}

async function scanScenesForChapter(chapterNumber){
  if(!state.mature) return;
  const ch = state.chapters[chapterNumber - 1];
  if(!ch) return;
  /* Xoá scene cũ của chương này rồi add lại */
  state.scenes = (state.scenes||[]).filter(s=> s.chapter !== chapterNumber);
  const scenes = await detectScenesInChapter(ch.text, chapterNumber);
  state.scenes.push(...scenes);
  state.scenes.sort((a,b)=> (a.chapter||0) - (b.chapter||0));
  persist(); renderScenes(); refreshStatBar();
}

$ID("rescanScenesBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  if(!state.mature){ setStatus("Bật 'Cho phép trưởng thành' trước.", false); return; }
  const ok = await showConfirm("Quét lại toàn bộ " + state.chapters.length + " chương để tìm cảnh 18+?\n\nSẽ tốn token.",{okText:"Bắt đầu"});
  if(!ok) return;
  setStatus("Đang quét scene...", true);
  state.scenes = [];
  for(let i=0;i<state.chapters.length;i++){
    setStatus("Quét cảnh chương " + (i+1) + "/" + state.chapters.length + "...", true);
    const ch = state.chapters[i];
    try{
      const scenes = await detectScenesInChapter(ch.text, i+1);
      state.scenes.push(...scenes);
    }catch(e){}
  }
  persist(); renderScenes(); refreshStatBar();
  setStatus("Đã quét " + state.scenes.length + " cảnh.", false);
});

$ID("showScenesInPromptBtn").addEventListener("click", ()=>{
  state.includeScenesInPrompt = !state.includeScenesInPrompt;
  persist();
  const btn = $ID("showScenesInPromptBtn");
  btn.style.background = state.includeScenesInPrompt ? "rgba(232,107,154,.25)" : "";
  btn.textContent = state.includeScenesInPrompt ? "👁 Đang gửi vào prompt" : "👁 Đang TẮT";
  setStatus("Scene gửi vào prompt: " + (state.includeScenesInPrompt ? "BẬT" : "TẮT"), false);
});

function renderScenes(){
  const scenes = state.scenes || [];
  $ID("statSceneTotal").textContent = scenes.length;
  const last10 = state.chapters.length - 10;
  $ID("statSceneRecent").textContent = scenes.filter(s=> (s.chapter||0) > last10).length;
  const lastCh = scenes.length ? scenes[scenes.length-1].chapter : "–";
  $ID("statSceneLastCh").textContent = lastCh;

  if(!scenes.length){
    sceneList.innerHTML = '<div class="empty-note">Chưa có cảnh 18+ nào.</div>';
  } else {
    sceneList.innerHTML = scenes.slice().reverse().map(s=>{
      const inten = s.intensity || 0;
      return '<div class="scene-item">'
        + '<div class="scene-item-head">'
          + '<b>Chương ' + (s.chapter||"?") + ': ' + escapeHtml(s.title||"Cảnh") + '</b>'
          + '<span class="scene-chip intensity-' + inten + '">' + inten + '/10</span>'
        + '</div>'
        + (s.participants && s.participants.length ? '<div class="scene-item-meta">👥 ' + escapeHtml(s.participants.join(" & ")) + (s.location ? ' · 📍 ' + escapeHtml(s.location) : '') + '</div>' : '')
        + (s.structure ? '<div class="scene-item-meta">🎬 ' + escapeHtml(s.structure) + '</div>' : '')
        + (s.initiator ? '<div class="scene-item-meta">🎯 Người khởi xướng: ' + escapeHtml(s.initiator) + '</div>' : '')
        + (s.consentState ? '<div class="scene-item-meta">✅ Consent: ' + escapeHtml(s.consentState) + '</div>' : '')
        + (s.firstTime && s.firstTime.length ? '<div class="scene-item-meta">⭐ ' + escapeHtml(s.firstTime.join(", ")) + '</div>' : '')
        + (s.aftermath ? '<div class="scene-item-meta">💭 ' + escapeHtml(s.aftermath) + '</div>' : '')
        + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-scene-del="' + s.id + '">Xóa</button></div>'
      + '</div>';
    }).join("");
    sceneList.querySelectorAll("[data-scene-del]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-scene-del");
        state.scenes = state.scenes.filter(s=> s.id !== id);
        persist(); renderScenes(); refreshStatBar();
      });
    });
  }
  updatePacingHint();
  checkPacingGuard(true);
}

function updatePacingHint(){
  const hintEl = $ID("pacingHint");
  if(!hintEl) return;
  const scenes = state.scenes || [];
  const totalCh = state.chapters.length;
  if(totalCh < 3){ hintEl.textContent = "Pacing: chưa đủ dữ liệu (cần ≥ 3 chương)."; return; }
  const last10 = totalCh - 10;
  const recent = scenes.filter(s=> (s.chapter||0) > last10).length;
  let msg = "10 chương gần: " + recent + " cảnh 18+.";
  if(recent === 0) msg += " Cân nhắc thêm 1 cảnh.";
  else if(recent >= 4) msg += " Hơi nhiều — cân nhắc pha loãng.";
  hintEl.textContent = msg;
}

/* ========== PACING GUARD ========== */
function checkPacingGuard(silent){
  if(!state.mature || state.chapters.length < 5) return;
  const scenes = state.scenes || [];
  const totalCh = state.chapters.length;
  const lastChWithScene = scenes.length ? scenes[scenes.length-1].chapter : 0;
  const gap = totalCh - lastChWithScene;
  const warns = [];
  if(gap >= 6 && lastChWithScene > 0){
    warns.push("Đã " + gap + " chương không có cảnh 18+ — có thể hơi nguội.");
  }
  if(scenes.length >= 3){
    const last3 = scenes.slice(-3);
    const last3Structures = last3.map(s=> (s.structure||"").slice(0,30)).filter(Boolean);
    if(last3Structures.length === 3 && new Set(last3Structures).size === 1){
      warns.push("3 cảnh gần nhất cùng cấu trúc (\"" + last3Structures[0] + "\") — dễ nhàm.");
    }
  }
  if(!silent && warns.length && state.lastPacingWarnChapter !== totalCh){
    showPacingBanner(warns);
    state.lastPacingWarnChapter = totalCh;
    persist();
  }
  if(silent && warns.length){
    /* Chỉ hiện nếu chưa warn chương này */
    if(state.lastPacingWarnChapter !== totalCh){
      showPacingBanner(warns);
      state.lastPacingWarnChapter = totalCh;
      persist();
    }
  }
}
function showPacingBanner(warns){
  pacingBannerText.innerHTML = "⚠ <b>Pacing check</b><br>" + warns.map(w=> "• " + escapeHtml(w)).join("<br>");
  pacingActions.innerHTML = "";
  const btn1 = document.createElement("button");
  btn1.className = "btn btn-pink btn-sm";
  btn1.style.width = "auto";
  btn1.textContent = "🎬 Xem scene";
  btn1.onclick = ()=>{ hidePacingBanner(); document.querySelector('[data-section].tone-pink')?.classList.add("open"); };
  const btn2 = document.createElement("button");
  btn2.className = "btn btn-ghost btn-sm";
  btn2.style.width = "auto";
  btn2.textContent = "Bỏ qua";
  btn2.onclick = hidePacingBanner;
  pacingActions.appendChild(btn1); pacingActions.appendChild(btn2);
  pacingBanner.classList.add("show");
}
function hidePacingBanner(){ pacingBanner.classList.remove("show"); }

/* ========== CONSENT LOG ========== */
function renderConsentLog(){
  const log = state.consentLog || [];
  if(!log.length){ consentList.innerHTML = '<div class="empty-note">Chưa có log.</div>'; return; }
  consentList.innerHTML = log.slice().reverse().map((c,i)=>{
    const idx = log.length - 1 - i;
    return '<div class="consent-item">'
      + '<div class="arc-card-top">'
        + '<b>' + escapeHtml(c.charA||"?") + ' & ' + escapeHtml(c.charB||"?") + '</b>'
        + '<span class="hint">Ch ' + (c.chapter||"?") + '</span>'
      + '</div>'
      + (c.action ? '<div style="margin-top:4px;">✅ ' + escapeHtml(c.action) + '</div>' : '')
      + (c.boundary ? '<div class="hint" style="margin-top:3px;">🚧 ' + escapeHtml(c.boundary) + '</div>' : '')
      + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-consent-del="' + idx + '">Xóa</button></div>'
    + '</div>';
  }).join("");
  consentList.querySelectorAll("[data-consent-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const i = parseInt(btn.getAttribute("data-consent-del"),10);
      state.consentLog.splice(i,1);
      persist(); renderConsentLog();
    });
  });
}
$ID("consentAddBtn").addEventListener("click", ()=>{
  const charA = $ID("consentCharAInput").value.trim();
  const charB = $ID("consentCharBInput").value.trim();
  const chapter = parseInt($ID("consentChInput").value,10) || state.chapters.length;
  const action = $ID("consentActionInput").value.trim();
  const boundary = $ID("consentBoundaryInput").value.trim();
  if(!charA || !charB || !action){ setStatus("Cần A, B và hành động.", false); return; }
  state.consentLog.push({ id: genId(), charA, charB, chapter, action, boundary, ts: Date.now() });
  persist(); renderConsentLog();
  $ID("consentCharAInput").value = ""; $ID("consentCharBInput").value = "";
  $ID("consentChInput").value = ""; $ID("consentActionInput").value = ""; $ID("consentBoundaryInput").value = "";
  setStatus("Đã thêm consent log.", false);
});

/* ========== VOCABULARY ========== */
$ID("saveVocabBtn").addEventListener("click", ()=>{
  state.vocabulary = {
    preferred: $ID("vocabPreferred").value.trim(),
    banned: $ID("vocabBanned").value.trim(),
    overused: $ID("vocabOverused").value.trim(),
    anatomy: $ID("vocabAnatomy").value.trim()
  };
  state.explicitLevel = $ID("explicitLevelSelect").value;
  persist();
  setStatus("Đã lưu Vocabulary.", false);
});

$ID("autoDetectOverusedBtn").addEventListener("click", ()=>{
  if(state.chapters.length < 3){ setStatus("Cần ≥ 3 chương.", false); return; }
  /* Tìm các cụm 3-gram lặp ≥ 4 lần trong 5 chương gần */
  const recent = state.chapters.slice(-5).map(c=> c.text || "").join(" ");
  const words = recent.toLowerCase().replace(/[.,!?;:"()«»\-–—]/g," ").split(/\s+/).filter(w=> w.length > 1);
  const counts = {};
  for(let i=0; i<words.length-2; i++){
    const gram = words[i] + " " + words[i+1] + " " + words[i+2];
    counts[gram] = (counts[gram] || 0) + 1;
  }
  const sorted = Object.entries(counts).filter(([g,c])=> c >= 4).sort((a,b)=> b[1] - a[1]).slice(0, 25);
  if(!sorted.length){ setStatus("Không phát hiện cụm lặp đáng kể.", false); return; }
  const text = sorted.map(([g,c])=> "• " + g + " (" + c + " lần)").join("\n");
  const existing = $ID("vocabOverused").value.trim();
  $ID("vocabOverused").value = existing ? existing + "\n" + text : text;
  state.vocabulary = {
    preferred: $ID("vocabPreferred").value.trim(),
    banned: $ID("vocabBanned").value.trim(),
    overused: $ID("vocabOverused").value.trim(),
    anatomy: $ID("vocabAnatomy").value.trim()
  };
  persist();
  setStatus("Đã tìm " + sorted.length + " cụm lặp.", false);
});

/* ========== SEARCH & REPLACE ========== */
$ID("srFindBtn").addEventListener("click", ()=>{
  const find = $ID("srFindInput").value;
  if(!find){ setStatus("Nhập từ cần tìm.", false); return; }
  const panel = $ID("srResultPanel");
  const resultEl = $ID("srResult");
  let hits = [];
  state.chapters.forEach((c,i)=>{
    const t = c.text || "";
    const title = c.title || "";
    const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    const inTitle = (title.match(re) || []).length;
    const inText = (t.match(re) || []).length;
    if(inTitle || inText) hits.push({ ch: i+1, title, inTitle, inText });
  });
  if(!hits.length){
    resultEl.textContent = "Không tìm thấy.";
  } else {
    resultEl.innerHTML = "Tìm thấy ở " + hits.length + " chương:<br>" +
      hits.map(h=> "• Chương " + h.ch + ": " + escapeHtml(h.title) + " — " + h.inText + " lần").join("<br>");
  }
  panel.classList.add("show");
  setStatus("Tìm xong.", false);
});

$ID("srReplaceAllBtn").addEventListener("click", async ()=>{
  const find = $ID("srFindInput").value;
  const replace = $ID("srReplaceInput").value;
  if(!find){ setStatus("Nhập từ cần tìm.", false); return; }
  const ok = await showConfirm("Thay TẤT CẢ \"" + find + "\" bằng \"" + replace + "\" trong toàn truyện?\n\nBản cũ sẽ mất (không undo được).", {okText:"Thay", danger:true});
  if(!ok) return;
  let count = 0;
  const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  state.chapters.forEach(c=>{
    const before = (c.text || "").match(re) || [];
    count += before.length;
    c.text = (c.text || "").replace(re, replace);
    c.wordCount = countWords(c.text);
    c.title = (c.title || "").replace(re, replace);
  });
  persist(); renderChapterNav(); renderCurrentChapter();
  setStatus("Đã thay " + count + " lần.", false);
});

/* ========== STORAGE COMPRESS ========== */
$ID("compressOldBtn").addEventListener("click", async ()=>{
  if(state.chapters.length < 20){ setStatus("Cần ≥ 20 chương để nén.", false); return; }
  const keep = 15;
  const compressCount = state.chapters.length - keep;
  const ok = await showConfirm(
    "Nén " + compressCount + " chương đầu tiên?\n\n" +
    "→ Giữ nguyên tiêu đề + tóm tắt\n" +
    "→ Xoá nội dung chữ (giảm dung lượng ~70%)\n" +
    "→ 15 chương gần giữ nguyên\n\n" +
    "Nên backup JSON trước khi nén!",
    {okText:"Nén", danger:true}
  );
  if(!ok) return;
  let freed = 0;
  for(let i=0; i<compressCount; i++){
    const c = state.chapters[i];
    freed += (c.text || "").length;
    if(!c.summary){
      /* Nếu chưa có summary, tạo trước khi xoá */
      setStatus("Tạo summary chương " + (i+1) + "...", true);
      try{
        const sum = await generateChapterSummary(c.text, i+1, true);
        if(sum) c.summary = sum;
      }catch(e){}
    }
    c.text = "[Chương đã nén — xem tóm tắt]\n\n" + (c.summary || "(chưa có tóm tắt)");
    c.compressed = true;
    c.wordCount = 0;
  }
  persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
  setStatus("Đã nén " + compressCount + " chương, tiết kiệm ~" + Math.round(freed/1024) + " KB.", false);
});

/* V12.31: prompt context audit — lọc quy tắc trùng và phát hiện xung đột rõ ràng, không gọi thêm model. */
function normalizePromptRuleText(text){
  return String(text || "").normalize("NFC").toLocaleLowerCase("vi-VN")
    .replace(/^[\s>*•\-\d.)]+/, "")
    .replace(/[“”"'‘’`]/g, "")
    .replace(/[.,;:!?()[\]{}]+/g, " ")
    .replace(/\s+/g, " ").trim();
}
function promptRuleIsDisabled(line){
  return /^\s*(?:\[\s*(?:tắt|off|disabled)\s*\](?:\s*[:：\-]|\s+|$)|(?:tắt|off|disabled)\s*[:：\-])/i.test(String(line || ""));
}
function buildEffectiveRuleBlock(){
  const sources = [
    { label: "Quy Tắc Nâng Cao", text: state.advancedRules || "" },
    { label: "Quy Tắc Khác", text: state.antagonist || "" }
  ];
  const seen = new Set(), kept = [];
  let removedDuplicates = 0, skippedDisabled = 0;
  for(const source of sources){
    const lines = String(source.text || "").split(/\r?\n/);
    for(const raw of lines){
      const line = String(raw || "").trim();
      if(!line) continue;
      if(promptRuleIsDisabled(line)){ skippedDisabled++; continue; }
      const key = normalizePromptRuleText(line);
      if(!key) continue;
      if(seen.has(key)){ removedDuplicates++; continue; }
      seen.add(key);
      kept.push("- [" + source.label + "] " + line);
    }
  }
  if(!kept.length) return "";
  const notes = [];
  if(removedDuplicates) notes.push("đã bỏ " + removedDuplicates + " dòng trùng sau chuẩn hóa");
  if(skippedDisabled) notes.push("đã bỏ " + skippedDisabled + " dòng được đánh dấu TẮT/OFF");
  return "QUY TẮC ĐANG ÁP DỤNG" + (notes.length ? " (" + notes.join("; ") + ")" : "") + ":\n" + kept.join("\n");
}
function _foldPromptAuditText(text){
  return String(text || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").toLocaleLowerCase("vi-VN").replace(/\s+/g, " ").trim();
}
function _promptConstraint(line){
  const raw = String(line || "").trim();
  if(!raw) return null;
  const f = _foldPromptAuditText(raw);
  // Điều kiện/ngoại lệ được giữ lại, không bị gắn nhãn xung đột máy móc.
  if(/ngoai brief|neu.{0,35}(brief|nguoi dung|menh lenh)|tru khi|unless|only if|tu tien|qua nhieu|thuc su can|co ly do|neu can|khi can|khong can thiet/.test(f)) return null;
  let topic = "";
  if(/nhan vat/.test(f) && /(moi|tao|them|gioi thieu|xuat hien)/.test(f)) topic = "nhân vật mới";
  else if(/(su kien|bien co|tuyen moi|arc moi|tuyen truyen moi)/.test(f) && /(moi|tao|them|mo|phat sinh|khong|cam|tranh|dung)/.test(f)) topic = "sự kiện/tuyến truyện mới";
  if(!topic) return null;
  const denied = /(?:^|[\s([{,:;])(?:không|cấm|đừng|tránh)(?=$|[\s,.;:!?)}\]])|\b(?:never|do not|must not)\b/i.test(raw);
  const mandatory = /\b(phai|bat buoc|hay|tuyet doi|must|add|create|introduce)\b/.test(f);
  if(denied) return {topic, polarity:"deny", text:raw};
  if(mandatory) return {topic, polarity:"allow", text:raw};
  return null;
}
function auditPromptInstructions(){
  const sources = [
    {label:"Quy Tắc Nâng Cao", text:state.advancedRules || ""},
    {label:"Quy Tắc Khác", text:state.antagonist || ""},
    {label:"Chỉ đạo chương", text:state.directive || ""},
    {label:"Gợi ý chương hiện tại", text:state.nextChapterHint || ""}
  ];
  const entries=[];
  for(const source of sources){
    const parts=String(source.text || "").split(/\r?\n|(?<=[.!?。！？])\s+/).map(x=>x.trim()).filter(Boolean);
    for(const part of parts){
      const c=_promptConstraint(part);
      if(c) entries.push({...c, source:source.label});
    }
  }
  const warnings=[], seen=new Set(), sourceTopicSeen=new Set();
  // Chỉ phát một cảnh báo cho mỗi cặp nguồn + chủ đề; không tạo tổ hợp mọi câu
  // với mọi câu vì một nhóm quy tắc dài có thể phình thành hàng chục cảnh báo giả.
  for(let i=0;i<entries.length;i++) for(let j=i+1;j<entries.length;j++){
    const a=entries[i], b=entries[j];
    if(a.source===b.source || a.topic!==b.topic || a.polarity===b.polarity) continue;
    const pair=[a.topic,a.source,b.source].sort().join("|");
    if(sourceTopicSeen.has(pair)) continue;
    const key=[a.topic,a.source,b.source,a.text,b.text].sort().join("|");
    if(seen.has(key)) continue;
    seen.add(key); sourceTopicSeen.add(pair);
    warnings.push("Có thể xung đột về " + a.topic + ": [" + a.source + "] “" + a.text.slice(0,180) + (a.text.length>180?"…":"") + "” ↔ [" + b.source + "] “" + b.text.slice(0,180) + (b.text.length>180?"…":"") + "”. Chỉ xử lý nếu hai yêu cầu thực sự áp dụng cùng chương/phạm vi; không sửa canon đã xác nhận.");
  }
  // Giữ prompt gọn: tối đa 3 cảnh báo đại diện. Không thêm phần còn lại vào prompt.
  const MAX_PROMPT_CONFLICT_WARNINGS = 3;
  if(warnings.length > MAX_PROMPT_CONFLICT_WARNINGS){
    const omitted = warnings.length - MAX_PROMPT_CONFLICT_WARNINGS;
    return warnings.slice(0, MAX_PROMPT_CONFLICT_WARNINGS).concat("Đã gộp/bỏ qua " + omitted + " cảnh báo trùng chủ đề hoặc ít ưu tiên; không coi đây là các mâu thuẫn đã được xác nhận.");
  }
  return warnings;
}

/* ========== CONTEXT BUILDING (với nén context) ========== */
function buildStoryBibleSummary(options){
  const lines = [];
  const p = state.mainCharProfile;
  if(p && p.name){
    const parts = [p.name];
    if(p.age) parts.push("tuổi:"+p.age);
    if(p.gender) parts.push(p.gender);
    if(p.maritalStatus) parts.push("hôn nhân:"+p.maritalStatus);
    if(p.spouseName) parts.push("người phối ngẫu/người yêu:"+p.spouseName);
    if(p.occupation) parts.push("nghề:"+p.occupation);
    if(p.height) parts.push("cao:"+p.height);
    if(p.bodyType) parts.push("dáng:"+p.bodyType);
    if(p.measurements) parts.push("SỐ ĐO:"+String(p.measurements).slice(0,80));
    if(p.appearance) parts.push("ngoại hình:"+String(p.appearance).slice(0,200));
    if(p.hair) parts.push("tóc:"+p.hair);
    if(p.eyes) parts.push("mắt:"+p.eyes);
    if(p.skin) parts.push("da:"+p.skin);
    if(p.sexualExperience) parts.push("18+:"+String(p.sexualExperience).slice(0,120));
    if(p.preferences) parts.push("kink:"+String(p.preferences).slice(0,80));
    if(p.skills) parts.push("kỹ năng:"+p.skills);
    if(p.realm) parts.push("CẢNH GIỚI:"+p.realm);
    if(p.technique) parts.push("công pháp:"+String(p.technique).slice(0,60));
    if(p.arts) parts.push("thần thông:"+String(p.arts).slice(0,80));
    if(p.treasure) parts.push("pháp bảo:"+String(p.treasure).slice(0,60));
    if(p.faction) parts.push("thế lực:"+String(p.faction).slice(0,40));
    if(p.position) parts.push("chức vị:"+String(p.position).slice(0,40));
    if(p.apparentAge) parts.push("tuổi ngoại hình:"+p.apparentAge);
    if(p.currentLocation) parts.push("ở:"+p.currentLocation);
    if(p.goals) parts.push("mục tiêu:"+p.goals);
    if(p.physicalState) parts.push("thể trạng:"+p.physicalState);
    if(p.mentalState) parts.push("tâm lý:"+p.mentalState);
    lines.push("NHÂN VẬT CHÍNH (BÁM HỒ SƠ — số đo/ngoại hình KHÔNG được bịa khác): " + parts.join(" | "));
  }
  if(state.mainPlot) lines.push("CỐT TRUYỆN: " + state.mainPlot);
  if(state.genre) lines.push("THỂ LOẠI: " + state.genre);
  if(state.worldSetting) lines.push("THẾ GIỚI: " + state.worldSetting);
  if(state.worldRules) lines.push("QUY TẮC THẾ GIỚI: " + state.worldRules);
  { const _cs = cultivationSystemBlock(state); if(_cs) lines.push(_cs); }
  if(!(options && options.includeOtherRules === false) && state.antagonist) lines.push("QUY TẮC KHÁC: " + state.antagonist);
  if(state.worldDescription) lines.push("MIÊU TẢ THẾ GIỚI: " + state.worldDescription);
  if(state.pronounRules) lines.push("QUY TẮC XƯNG HÔ:\n" + state.pronounRules);
  if(state.storyBibleLocked) lines.push("(Story Bible đã KHÓA.)");
  return lines.join("\n");
}

function buildStyleBlock(){
  const s = state.styleBible || {};
  const parts = [];
  const povMap = { third_limited: "Ngôi 3 giới hạn — mỗi cảnh/đoạn bám sát MỘT nhân vật (thường là nhân vật chính; được chuyển sang nhân vật phụ ở cảnh khác, có chuyển cảnh rõ), không nhảy vào đầu nhiều người trong cùng đoạn; nhân vật phụ vẫn có việc riêng, lời thoại và hành động chủ động", third_omniscient: "Ngôi 3 toàn tri", first: "Ngôi 1" };
  const tenseMap = { past: "Quá khứ", present: "Hiện tại" };
  if(s.pov) parts.push("NGÔI: " + (povMap[s.pov] || s.pov));
  if(s.tense) parts.push("THÌ: " + (tenseMap[s.tense] || s.tense));
  if(s.tone) parts.push("TÔNG: " + s.tone);
  if(s.extra) parts.push("VĂN PHONG: " + s.extra);
  if(s.sample) parts.push("ĐOẠN VĂN MẪU (bắt chước):\n\"\"\"\n" + s.sample + "\n\"\"\"");
  return parts.length ? parts.join("\n") : "";
}

function buildVocabularyBlock(){ return buildVocabularyBlockFrom(state); }

function buildSceneHistoryBlock(maxScenes){
  maxScenes = maxScenes || 5;
  if(!state.includeScenesInPrompt) return "";
  const scenes = (state.scenes || []).slice(-(Math.min(maxScenes || 6, 6)));
  if(!scenes.length) return "";
  const lines = scenes.map(s=>{
    const p = (s.participants||[]).join("&");
    return "Ch" + (s.chapter||"?") + " [" + p + "] " + (s.title||"") + " — intensity " + (s.intensity||0) + "/10" + (s.structure ? ", structure: " + s.structure : "") + (s.aftermath ? " → " + s.aftermath : "");
  });
  return "LỊCH SỬ CẢNH 18+ (KHÔNG lặp cấu trúc / lời thoại / chi tiết):\n" + lines.join("\n");
}

function buildConsentBlock(){
  const log = state.consentLog || [];
  if(!log.length) return "";
  const lines = log.slice(-8).map(c=> "Ch" + (c.chapter||"?") + ": " + (c.charA||"?") + " & " + (c.charB||"?") + " — " + (c.action||"") + (c.boundary ? " (ranh giới: " + c.boundary + ")" : ""));
  return "CONSENT LOG:\n" + lines.join("\n");
}

function chaptersSummaryText(n){
  const arr = state.chapters.slice(-n);
  if(!arr.length) return "";
  return arr.map((c,i)=>{
    const num = state.chapters.length - arr.length + i + 1;
    return "Chương " + num + " (" + c.title + "): " + (c.summary || "(chưa có tóm tắt)");
  }).join("\n");
}

function buildContextBlock(options){
  const contextOptions = options || {};
  const includeChapterInstructions = contextOptions.includeChapterInstructions !== false;
  /* Ngân sách ngữ cảnh — ưu tiên: status mới nhất + NV chính + đoạn nối; brief được chèn riêng đúng một lần khi viết chương. */
  const lines = [];
  if(state.accuracyMode===true) lines.push("🎯 ƯU TIÊN ĐỘ CHÍNH XÁC: bám sát mọi beat bắt buộc [R#] trong Outline/Contract; giữ nguyên canon, nhân vật, thời gian và địa điểm đã xác nhận; không tự bịa chi tiết để lấp chỗ trống; tránh lặp lại đoạn văn/hành động đã xuất hiện trong cùng chương.");
  const clip = (s, n) => {
    s = String(s || "");
    if(s.length <= n) return s;
    return s.slice(0, Math.floor(n*0.4)) + "\n[...]\n" + s.slice(-Math.floor(n*0.5));
  };

  /* Story bible — ngắn */
  const bible = buildStoryBibleSummary({ includeOtherRules:false });
  if(bible) lines.push(clip(bible, 1800));
  const rulesBlock = buildEffectiveRuleBlock();
  if(rulesBlock) lines.push(clip(rulesBlock, 2400));
  const contextConflicts = auditPromptInstructions();
  if(contextConflicts.length) lines.push("KIỂM TRA XUNG ĐỘT QUY TẮC TRƯỚC KHI GỌI AI:\n" + contextConflicts.map((x,i)=>(i+1)+". "+x).join("\n") + "\nGiữ nguyên canon/quan hệ/trạng thái đã xác nhận. Nếu không thể dung hòa mà không sửa canon, không tự bịa dữ kiện.");
  const loreTxt = loreForPrompt(); if(loreTxt) lines.push(loreTxt);

  const style = buildStyleBlock();
  if(style) lines.push("STYLE:\n" + clip(style, 900));

  const vocab = buildVocabularyBlock();
  if(vocab) lines.push(clip(vocab, 600));

  /* V12.32.18: tiến độ Arc + việc bắt buộc của chương theo Outline (thay cho dòng ARC/OUTLINE cắt 200/800 ký tự). */
  { const _n = (Array.isArray(contextOptions.priorChapters) ? contextOptions.priorChapters.length : state.chapters.length) + 1; const ap = arcProgressPrompt(state, _n); if(ap) lines.push(ap); }

  { const tm = currentTimeMark(state); if(tm) lines.push("THỜI ĐIỂM: " + tm); }

  // V12.32: không chèn tóm tắt chương cũ lần thứ hai vào khối ngữ cảnh.
  /* V12.32.5: nhưng cần TRÍ NHỚ TRUYỆN: mỗi chương cũ 1–2 câu (trừ chương gần nhất đã có khối riêng), tối đa ~2800 ký tự. */
  const soFar = storySoFarPrompt(Array.isArray(contextOptions.priorChapters) ? contextOptions.priorChapters : state.chapters, 2800); if(soFar) lines.push(soFar);
  const memoryTargetChapter = Number(contextOptions.chapterNumber) || ((Array.isArray(contextOptions.priorChapters) ? contextOptions.priorChapters.length : state.chapters.length) + 1);
  const layeredMemoryBlock = buildLayeredMemoryContextBlock(state, memoryTargetChapter, 3600); if(layeredMemoryBlock) lines.push("BỘ NHỚ PHÂN TẦNG (chỉ dữ kiện đã chốt trước chương này; ưu tiên canon mới hơn nếu xung đột):\n" + layeredMemoryBlock);
  const loops = openLoopsPrompt(state); if(loops) lines.push(loops);
  /* NV: bóc thẻ tự động, tối đa 5 thẻ cho mỗi prompt */
  const cardText = characterCardsForPromptV102((state.chapters.slice(-1)[0]?.text||"") + "\n" + (state.directive||""));
  if(cardText) lines.push("THẺ NHÂN VẬT KÍCH HOẠT (tối đa 5):\n" + clip(cardText, 2400));

  /* QUAN TRỌNG: danh sách nhân vật đã có trong truyện — nếu không liệt kê ở đây,
     model không biết họ tồn tại nên sẽ tự bịa nhân vật mới dù prompt cấm. */
  const rosterChars = relevantCharacters(8);
  if(rosterChars.length) lines.push("NHÂN VẬT CÒN SỐNG CÓ LIÊN QUAN (chỉ tham khảo khi phù hợp; không bắt buộc xuất hiện):\n" + characterSummaryForPrompt(rosterChars));

  if(state.mainCharProfile && state.mainCharProfile.name){
    const mc = state.mainCharProfile;
    const mcParts = ["NHÂN VẬT CHÍNH (trục của truyện, phải có mặt trong chương; không cần có mặt ở mọi cảnh): " + mc.name];
    if(mc.personality) mcParts.push("tính:"+clip(mc.personality, 120));
    if(mc.goals) mcParts.push("mục tiêu:"+clip(mc.goals, 120));
    if(mc.currentLocation) mcParts.push("ở:"+mc.currentLocation);
    if(mc.realm) mcParts.push("CẢNH GIỚI:"+clip(mc.realm, 40));
    if(mc.technique) mcParts.push("công pháp:"+clip(mc.technique, 50));
    if(mc.faction) mcParts.push("thế lực:"+clip(mc.faction, 40));
    if(mc.mentalState) mcParts.push("tâm lý:"+clip(mc.mentalState, 100));
    if(mc.physicalState) mcParts.push("thể trạng:"+clip(mc.physicalState, 100));
    lines.push(mcParts.join(" | "));
  } else if(state.mainPlot || state.worldSetting) {
    lines.push("⚠ CHƯA khai báo Nhân Vật Chính (tab Nhân Vật Chính) — nếu Cốt Truyện/Bối Cảnh có nhắc tên nhân vật chính, PHẢI dùng đúng tên đó xuyên suốt, không tự đặt tên khác.");
  }

  const organizationBlock = organizationProfilesPromptBlock(state, 2200); if(organizationBlock) lines.push(organizationBlock);
  const activeLocs = state.locations.filter(l=>l.status === 'active').slice(-4);
  if(activeLocs.length) lines.push("ĐỊA ĐIỂM:\n" + activeLocs.map(l=>"- "+l.name+": "+clip(l.description, 100)).join("\n"));

  const activeItems = state.items.filter(it=>it.status === 'active').slice(-5);
  if(activeItems.length) lines.push("VẬT PHẨM:\n" + activeItems.map(it=>"- "+it.name+((it.kind||it.grade)?" ["+[it.kind,it.grade].filter(Boolean).join(", ")+"]":"")+(it.owner?" (của "+it.owner+(it.bound?", đã nhận chủ":"")+")":"")+": "+clip(it.description, 80)+(it.effect?" | công dụng: "+clip(it.effect, 60):"")).join("\n"));

  /* V14.4.3: THREADS/FORESHADOWING/TIMELINE/KIẾN THỨC không có nhãn ưu tiên nên model coi là việc phải đẩy tiến ở MỖI chương (vd tuyến "ân nhân"), kéo truyện khỏi Outline. */
  if((state.threads||[]).length || (state.foreshadowing||[]).length) lines.push("LƯU Ý ƯU TIÊN: THREADS / FORESHADOWING / TIMELINE / KIẾN THỨC bên dưới chỉ là BỐI CẢNH để giữ nhất quán. Chương này không bắt buộc đẩy chúng tiến triển; có thể thêm yếu tố/tình tiết phụ nếu hợp lý, nhưng sự kiện chính của Outline chương PHẢI có và viết đầy đủ trước, không để các mục này chiếm chỗ hay làm thiếu Outline.");
  const openThreads = state.threads.filter(t=>!['paid_off','abandoned','resolved','completed'].includes(String(t.status||'').toLowerCase())).slice(0, 6);
  if(openThreads.length) lines.push("THREADS:\n" + openThreads.map(t=>"- ["+t.type+"] "+clip(t.desc, 120)).join("\n"));

  const openForeshadowing = (state.foreshadowing||[]).filter(f=>!['paid_off','abandoned','resolved'].includes(f.status)).slice(-8);
  if(openForeshadowing.length) lines.push("FORESHADOWING CHƯA GIẢI:\n" + openForeshadowing.map(f=>"- "+clip(f.description,160)+" ["+(f.status||"seeded")+"]").join("\n"));
  const timeline = (state.timeline||[]).slice(-8);
  if(timeline.length) lines.push("TIMELINE GẦN:\n" + timeline.map(e=>"- Ch"+e.chapter+": "+clip(e.summary,160)).join("\n"));
  const knownFacts = (state.knowledgeLedger||[]).slice(-12);
  if(knownFacts.length) lines.push("KIẾN THỨC NHÂN VẬT:\n" + knownFacts.map(k=>"- "+k.character+" biết: "+clip(k.fact,140)).join("\n"));

  const sceneBlock = buildSceneHistoryBlock(4);
  if(sceneBlock) lines.push(clip(sceneBlock, 700));

  const consentBlock = buildConsentBlock();
  if(consentBlock) lines.push(clip(consentBlock, 400));

  if(state.currentStatus){
    const knownStatusChapter = Math.max(0, Number(state.lastStatusChapter) || 0);
    const latestCompletedChapter = (state.chapters || []).length;
    const statusIsStale = latestCompletedChapter > 0 && knownStatusChapter < latestCompletedChapter;
    const statusLabel = "CURRENT STATUS — mốc đã xác nhận: Ch" + (knownStatusChapter || "không rõ") + "; chương đã lưu: " + latestCompletedChapter + (statusIsStale ? " (CHƯA CẬP NHẬT ĐẾN CHƯƠNG MỚI NHẤT)" : " (đã khớp chương đã lưu)");
    lines.push(statusLabel + ":\n" + clip(state.currentStatus, 4200) + (statusIsStale ? "\nCẢNH BÁO ĐỘ MỚI: Đây là trạng thái tại mốc cũ, không được coi là hiện trạng tuyệt đối. Nếu khác với tóm tắt/đoạn kết của các chương mới hơn, ưu tiên diễn biến có bằng chứng trong chương mới hơn; không tự đoán các thay đổi chưa được xác nhận." : ""));
  } else if((state.chapters || []).length){
    lines.push("CURRENT STATUS: Chưa có bản trạng thái được xác nhận. Dựa vào tóm tắt và đoạn kết các chương đã lưu; không bịa trạng thái không có bằng chứng.");
  }
  const trackers=Object.values(state.characterStateTracker||{}).filter(x=>x && !x.dead && !x.isDead).slice(-8);
  if(trackers.length) lines.push("CHARACTER STATE TRACKER:\n"+trackers.map(x=>"- "+x.name+" | Ch"+x.chapter+" | cấp:"+(x.powerLevel||"?")+" | vị trí:"+(x.location||"?")+" | sức khỏe:"+(x.health||"?")+" | vật phẩm:"+(x.itemsHeld||"?")+" | "+(x.dead?"đã chết":"còn sống")).join("\n"));
  if((state.glossaryLock||[]).length) lines.push("GLOSSARY LOCK:\n"+state.glossaryLock.map(x=>"- "+x).join("\n"));
  if((state.banWords||[]).length) lines.push("CẤM TỪ / ANTI-AI TROPES:\n"+state.banWords.slice(0,80).map(x=>"- "+x).join("\n"));
  if(includeChapterInstructions){
    if(state.directive) lines.push("CHỈ ĐẠO ĐANG ÁP DỤNG CHO CHƯƠNG NÀY (chèn nguyên văn một lần ở đây):\n" + String(state.directive).trim());
    const _hintTarget = (Array.isArray(contextOptions.priorChapters) ? contextOptions.priorChapters.length : state.chapters.length) + 1;
    const _verifiedHint = typeof chapterHintVerification === "function" ? chapterHintVerification(state, _hintTarget) : { text: "", verified: false };
    if(_verifiedHint.verified) lines.push("GỢI Ý ĐÃ XÁC MINH CHO CHƯƠNG " + _hintTarget + " (v" + (_verifiedHint.version || 1) + "):\n" + _verifiedHint.text);
    else if(state.nextChapterHint) lines.push("GỢI Ý CHƯƠNG HIỆN TẠI: KHÔNG ĐƯỢC DÙNG — thiếu provenance/không khớp chương mục tiêu (" + (_verifiedHint.reason || "unverified") + ").");
  }
  // Không tự động đưa autoNextChapterHint cũ vào prompt: trường này không có mã chương để xác nhận còn phù hợp hay không.

  const diffMap = { de:"Dễ thở.", vua:"Cân bằng.", kho:"Khó.", tan_khoc:"Tàn khốc." };
  lines.push("ĐỘ KHÓ: " + (diffMap[state.difficulty] || diffMap.vua));
  lines.push(matureFocusPrompt());
  if(state.mature && normalizeChapterMatureFocus(state.chapterMatureFocus) !== "none") lines.push("VĂN PHONG: nội dung trưởng thành chỉ xuất hiện trong phạm vi được chỉ định, không tự mở tuyến mới.");
  const descLevel = state.descriptionLevel || "balanced";
  lines.push("MỨC MIÊU TẢ: " + (DESCRIPTION_PROMPTS[descLevel] || DESCRIPTION_PROMPTS.balanced));
  if(state.mature) lines.push("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || EXPLICIT_PROMPTS.sensual));
  if(state.mature) lines.push(ageGuardPrompt(state));
  return lines.filter(Boolean).join("\n\n");
}


/* ========== v11 AGE GUARD ========== */

/* ========== CHAPTER VERSIONS ========== */
function pushChapterVersion(idx, note){
  const c = state.chapters[idx]; if(!c) return;
  if(!Array.isArray(c.versions)) c.versions = [];
  c.versions.unshift({
    timestamp: Date.now(), text: c.text, wordCount: c.wordCount || countWords(c.text),
    modelUsed: c.modelUsed || null, isNsfw: !!c.isNsfw, polished: !!c.polished, note: note || ""
  });
  if(c.versions.length > 3) c.versions = c.versions.slice(0,3);
}

function showVersionsModal(){
  const idx = state.currentChapterIndex;
  if(idx < 0 || !state.chapters[idx]){ setStatus("Chưa có chương.", false); return; }
  const c = state.chapters[idx];
  const versions = c.versions || [];
  const overlay = document.createElement("div"); overlay.className = "modal-overlay";
  const box = document.createElement("div"); box.className = "modal-box"; box.style.position = "relative";
  let html = '<div class="modal-close" id="verClose">×</div>';
  html += '<h3 class="modal-title">Lịch sử phiên bản — Chương ' + (idx+1) + '</h3>';
  if(!versions.length) html += '<div class="empty-note">Chưa có bản cũ.</div>';
  else html += versions.map((v,i)=>{
    const d = new Date(v.timestamp);
    return '<div class="version-item">'
      + '<div class="arc-card-top"><b>Bản ' + (i+1) + '</b>'
      + '<span class="hint">' + d.toLocaleString("vi-VN") + ' · ' + v.wordCount + ' từ'
      + (v.modelUsed ? ' · ' + escapeHtml(shortModelName(v.modelUsed)) : '') + '</span></div>'
      + (v.note ? '<div class="hint">' + escapeHtml(v.note) + '</div>' : '')
      + '<div class="char-actions">'
        + '<button class="btn btn-ghost btn-sm" data-ver-view="'+i+'">👁 Xem</button>'
        + '<button class="btn btn-blue btn-sm" data-ver-restore="'+i+'">↩ Khôi phục</button>'
      + '</div></div>';
  }).join("");
  box.innerHTML = html;
  overlay.appendChild(box); document.body.appendChild(overlay);
  $ID("verClose").onclick = ()=>overlay.remove();
  overlay.onclick = e => { if(e.target === overlay) overlay.remove(); };
  box.querySelectorAll("[data-ver-view]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const vi = parseInt(btn.getAttribute("data-ver-view"),10);
      const v = versions[vi]; if(!v) return;
      showAlert("=== Bản "+(vi+1)+" ===\n\n" + v.text.slice(0, 3000) + (v.text.length > 3000 ? "\n\n...(còn)" : ""));
    });
  });
  box.querySelectorAll("[data-ver-restore]").forEach(btn=>{
    btn.addEventListener("click", async ()=>{
      const vi = parseInt(btn.getAttribute("data-ver-restore"),10);
      const v = versions[vi]; if(!v) return;
      const ok = await showConfirm("Khôi phục bản "+(vi+1)+"?", {okText:"Khôi phục"});
      if(!ok) return;
      pushChapterVersion(idx, "Trước khi khôi phục");
      c.text = v.text; c.wordCount = countWords(v.text);
      c.modelUsed = v.modelUsed; c.isNsfw = v.isNsfw; c.polished = v.polished;
      persist(); renderChapterNav(); renderCurrentChapter();
      overlay.remove();
      setStatus("Đã khôi phục.", false);
    });
  });
}
$ID("versionsBtn").addEventListener("click", showVersionsModal);

/* ========== POLISH ========== */

function charNameList(){ return (state.characters || []).map(x => x && x.name).filter(Boolean); }
/* V12.15: sửa từ lạ (Latinh vô nghĩa/tiếng Anh chen giữa câu) chỉ trên các đoạn bị lỗi — rẻ hơn polish cả chương */
async function fixStrayWordsInText(text, opts){
  opts = opts || {};
  const stray = findStrayWords(text, charNameList());
  if(!stray.length) return { text: text, fixed: 0, remaining: [] };
  const paras = String(text).split(/\n\n/);
  const idxs = [];
  paras.forEach((p, i)=>{ const low = p.toLowerCase(); if(stray.some(w => low.includes(w.toLowerCase()))) idxs.push(i); });
  if(!idxs.length) return { text: text, fixed: 0, remaining: stray };
  const pronounBlock = state.pronounRules ? ("\nQUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "";
  let fixed = 0;
  for(let start = 0; start < idxs.length; start += 8){
    const batch = idxs.slice(start, start + 8);
    const body = batch.map((i, k) => "##" + (k+1) + "\n" + paras[i]).join("\n");
    const prompt = [
      "Các đoạn truyện tiếng Việt dưới đây bị lỗi: có từ lạ (tiếng Anh hoặc chữ vô nghĩa) chen giữa câu.",
      "Từ lạ cần xử lý: " + stray.join(", "),
      "NHIỆM VỤ: chỉ thay các từ lạ đó bằng từ/cụm tiếng Việt tự nhiên, hợp ngữ cảnh (hoặc bỏ nếu thừa). Giữ NGUYÊN mọi chữ khác, không thêm/bớt ý, không viết lại câu, không đổi tên riêng.",
      pronounBlock,
      "ĐỊNH DẠNG TRẢ VỀ: mỗi đoạn bắt đầu bằng đúng dòng ##1, ##2,... rồi nội dung đã sửa. Không giải thích.",
      "",
      body
    ].join("\n");
    try{
      const { text: out } = await callAI(prompt, {
        maxTokens: Math.min(12000, Math.max(1500, Math.ceil(body.length/2) + 600)),
        temperature: 0.2, modelOverride: opts.modelOverride, frequency_penalty: 0, presence_penalty: 0
      });
      const parts = String(out || "").split(/^##(\d+)[ \t]*$/m);
      for(let k = 1; k < parts.length; k += 2){
        const n = parseInt(parts[k], 10) - 1; const fixedPara = (parts[k+1] || "").trim();
        if(n < 0 || n >= batch.length || !fixedPara) continue;
        const orig = paras[batch[n]];
        if(fixedPara.length < orig.length * 0.7 || fixedPara.length > orig.length * 1.3) continue;
        if(detectNonVietnamese(fixedPara)) continue;
        if(fixedPara !== orig){ paras[batch[n]] = fixedPara; fixed++; }
      }
    }catch(e){ console.warn("[fixStray]", e.message); }
  }
  const outText = paras.join("\n\n");
  return { text: outText, fixed: fixed, remaining: findStrayWords(outText, charNameList()) };
}

// V12.46: rà ngữ nghĩa theo từng câu; chỉ vá cụm nguyên văn có confidence cao.
async function semanticProseCheckInText(text, opts){
  opts = opts || {};
  let cur = String(text || ""), fixed = [], warnings = [], calls = 0;
  for(let offset = 0; ; offset += 18){
    const all = splitSemanticSentences(cur, 1000), batch = all.slice(offset, offset + 18);
    if(!batch.length) break;
    if(calls >= 12){ warnings.push({reason:"Chưa rà hết chương vì giới hạn số lượt kiểm tra; cần rà lại thủ công."}); break; }
    calls++;
    try{
      const { text: raw } = await callAI(buildSemanticProseCheckPrompt(batch), {
        maxTokens: Math.min(5000, 500 + batch.length * 180), temperature: 0.05,
        modelOverride: opts.modelOverride, frequency_penalty: 0, presence_penalty: 0
      });
      const result = applySemanticProseFixes(cur, batch, parseSemanticProseCheckResponse(raw), 0.85);
      cur = result.text; fixed = fixed.concat(result.applied); warnings = warnings.concat(result.warnings);
    }catch(e){ warnings.push({reason:"Semantic Prose Check lỗi API: " + (e.message || e)}); }
  }
  return {text:cur, fixed, warnings, calls};
}

async function polishVietnamese(text, opts){
  opts = opts || {};
  if(!text || text.trim().length < 20) return text;
  const pronounBlock = state.pronounRules ? ("\n\nQUY TẮC XƯNG HÔ BẮT BUỘC:\n" + state.pronounRules) : "";
  const prompt = [
    "Bạn là biên tập viên tiếng Việt dày dặn. RÀ LẠI đoạn văn sau và trả về bản đã sửa.",
    "",
    "YÊU CẦU:",
    "1. Sửa lỗi chính tả, dấu câu, ngữ pháp tiếng Việt.",
    "2. Đảm bảo xưng hô NHẤT QUÁN.",
    "3. Sửa câu lẫn tiếng Anh/Trung/Nhật/Hàn thành tiếng Việt thuần.",
    "4. Sửa lỗi chính tả phổ biến (sử dụng/xử dụng, dành/giành...).",
    "5. GIẢM MÙI AI: thay câu máy móc ('cô ấy cảm thấy...', 'anh ta nhận ra rằng...', 'một cảm giác lạ lùng...') bằng diễn đạt tự nhiên hơn.",
    "6. Giữ nhịp câu đa dạng.",
    "7. KHÔNG thêm/bớt sự kiện, không tóm tắt, không viết lại hoàn toàn.",
    (function(){ const st = findStrayWords(text, charNameList()); return st.length ? ("8. BẮT BUỘC thay các từ lạ sau bằng tiếng Việt hợp ngữ cảnh: " + st.slice(0,10).join(", ")) : ""; })(),
    pronounBlock,
    "",
    "CHỈ TRẢ VỀ nội dung đã sửa, không giải thích, không markdown.",
    "",
    "===== ĐOẠN VĂN =====",
    text
  ].join("\n");
  try{
    const { text: fixed } = await callAI(prompt, {
      maxTokens: Math.min(16000, Math.max(2000, Math.ceil(text.length/2) + 800)),
      temperature: 0.2, modelOverride: opts.modelOverride,
      frequency_penalty: 0.3, presence_penalty: 0.2
    });
    let out = fixed.trim();
    out = out.replace(/^```[a-z]*\n?/i, "").replace(/\n?```$/,"").trim();
    out = out.replace(/^(Đây là|Dưới đây là|Bản đã sửa[^\n]*:?)\s*\n+/i, "").trim();
    if(out.length < text.length * 0.65){
      console.warn("[Polish] Output quá ngắn.");
      return text;
    }
    if(/(tóm tắt|những điểm chính|nội dung chính là)/i.test(out.slice(0,200))){
      console.warn("[Polish] Có vẻ là tóm tắt.");
      return text;
    }
    return out;
  }catch(err){
    console.warn("[Polish]", err.message);
    return text;
  }
}

/* ========== SIMPLE SAVE HANDLERS ========== */
$ID("saveStyleBibleBtn").addEventListener("click", ()=>{
  state.styleBible = {
    pov: $ID("povSelect").value, tense: $ID("tenseSelect").value,
    tone: $ID("toneInput").value.trim(), sample: $ID("sampleStyleInput").value.trim(),
    extra: $ID("styleExtraInput").value.trim()
  };
  persist(); setStatus("Đã lưu Style Bible.", false);
});
if($ID("cultSeedBtn")) $ID("cultSeedBtn").addEventListener("click", ()=>{
  const cs = $ID("cultivationSystem"), rl = $ID("realmLadder");
  if(cs) cs.value = CULT_DEFAULT_SYSTEM_TEXT;
  if(rl) rl.value = DEFAULT_REALM_LADDER.join(", ");
  setStatus("Đã nạp mẫu hệ thống tu luyện — bấm 'Lưu Story Bible' để áp dụng.", false);
});
$ID("saveSettingsBtn").addEventListener("click", ()=>{
  state.mainPlot = mainPlotEl.value; state.genre = genreEl.value;
  state.worldSetting = worldSettingEl.value; state.worldRules = worldRulesEl.value;
  state.antagonist = antagonistEl.value; state.pronounRules = pronounRulesEl.value;
  state.cultivationSystem = ($ID("cultivationSystem")||{value:state.cultivationSystem||""}).value;
  state.realmLadder = ($ID("realmLadder")||{value:state.realmLadder||""}).value.trim();
  state.worldDescription = worldDescriptionEl.value;
  state.storyBibleLocked = storyBibleLockEl.checked;
  persist(); setStatus("Đã lưu Story Bible.", false);
});
$ID("maxNamedChars") && $ID("maxNamedChars").addEventListener("change", ()=>{
  if(!state.storyControl || typeof state.storyControl!=="object") state.storyControl={};
  state.storyControl.maxNamedCharacters = Math.max(1, Math.min(12, Number($ID("maxNamedChars").value) || 6));
  state.storyControl.castCapUserSet = true; persist();
  setStatus("Đã lưu giới hạn nhân vật có tên mỗi chương: " + state.storyControl.maxNamedCharacters + ".", false);
});
$ID("timePace") && $ID("timePace").addEventListener("change", ()=>{
  if(!state.storyControl || typeof state.storyControl!=="object") state.storyControl={};
  state.storyControl.timePace = $ID("timePace").value; persist();
  setStatus("Đã lưu nhịp thời gian.", false);
});
$ID("saveClockBtn") && $ID("saveClockBtn").addEventListener("click", ()=>{
  state.storyClock = storyClockEl.value; persist(); renderCurrentChapter();
  setStatus("Đã lưu mốc thời gian.", false);
});
$ID("saveAdvancedRulesBtn").addEventListener("click", ()=>{
  state.advancedRules = advancedRulesEl.value; persist();
  setStatus("Đã lưu.", false);
});
[directiveEl, nextChapterHintEl, difficultyEl, matureToggle, chapterMatureFocusEl].forEach(el=>{
  el.addEventListener("change", ()=>{
    const oldHint = String(state.nextChapterHint || "");
    state.directive = directiveEl.value; state.nextChapterHint = nextChapterHintEl.value;
    if(String(state.nextChapterHint) !== oldHint){
      const targetChapter = (state.chapters || []).length + 1;
      state.nextChapterHintMeta = { targetChapter, version: Number(state.nextChapterHintMeta && state.nextChapterHintMeta.version || 0) + 1, status: state.nextChapterHint.trim() ? "active" : "inactive", updatedAt: Date.now(), source: "user" };
    }
    { const hs=$ID("hintStyle"); if(hs) state.hintStyle=hs.value; const hf=$ID("hintFormat"); if(hf) state.hintFormat=hf.value; }
    state.difficulty = difficultyEl.value;
    state.mature = matureToggle.checked;
    state.chapterMatureFocus = normalizeChapterMatureFocus(chapterMatureFocusEl.value);
    persist(); updateNsfwHint();
  });
});
autoIntervalInput.addEventListener("change", ()=>{
  state.autoIntervalSec = Math.max(30, parseInt(autoIntervalInput.value,10) || 180);
  autoIntervalInput.value = state.autoIntervalSec; persist();
  if(autoToggle.checked) scheduleNextAuto();
});
autoToggle.addEventListener("change", ()=>{ scheduleNextAuto(); if(autoToggle.checked) setStatus("Tự động tạo chương: bật, mỗi "+Math.max(30, parseInt(autoIntervalInput.value,10)||180)+"s khi rảnh.", false); else setStatus("Đã tắt tự động tạo chương.", false); });
includeKeyToggle.addEventListener("change", ()=>{ state.includeKeyOnExport = includeKeyToggle.checked; persist(); });
spellCheckToggle.addEventListener("change", ()=>{ state.spellCheckEnabled = spellCheckToggle.checked; persist(); });
$ID("qualityGateToggle").addEventListener("change", ()=>{ state.qualityGateEnabled = $ID("qualityGateToggle").checked; persist(); });
$ID("autoRepairOnCreateToggle").addEventListener("change", ()=>{ state.autoRepairOnCreate = $ID("autoRepairOnCreateToggle").checked; persist(); });
$ID("beatLedgerToggle").addEventListener("change", ()=>{ state.beatLedgerCheck = $ID("beatLedgerToggle").checked; persist(); });
$ID("sceneAiReviewToggle").addEventListener("change", ()=>{ state.sceneAiReview = $ID("sceneAiReviewToggle").checked; persist(); });
$ID("qualityAcceptSoftToggle").addEventListener("change", ()=>{ state.qualityAcceptSoft = !$ID("qualityAcceptSoftToggle").checked; persist(); });
$ID("requiredBeatBarrierToggle").addEventListener("change", ()=>{ state.requiredBeatBarrier = $ID("requiredBeatBarrierToggle").checked; persist(); });
function syncAccuracyModeControls(){
  const strict=state.accuracyMode===true, mode=$ID("accuracyModeToggle");
  if(mode) mode.checked=strict;
  [["qualityGateToggle",strict||state.qualityGateEnabled!==false],["autoRepairOnCreateToggle",strict||state.autoRepairOnCreate!==false],["qualityAcceptSoftToggle",strict||state.qualityAcceptSoft===false],["requiredBeatBarrierToggle",strict||state.requiredBeatBarrier!==false]].forEach(([id,checked])=>{
    const input=$ID(id); if(!input) return; input.checked=checked; input.disabled=strict;
  });
}
$ID("accuracyModeToggle").addEventListener("change", ()=>{ state.accuracyMode=$ID("accuracyModeToggle").checked; syncAccuracyModeControls(); persist(); });
$ID("outlineBeatGateToggle").addEventListener("change", ()=>{ state.outlineBeatGate = $ID("outlineBeatGateToggle").checked; persist(); });
autoContinueToggle.addEventListener("change", ()=>{ state.autoContinueEnabled = autoContinueToggle.checked; persist(); });
autoSummaryToggle.addEventListener("change", ()=>{ state.autoSummaryEnabled = autoSummaryToggle.checked; persist(); });
autoSceneToggle.addEventListener("change", ()=>{ state.autoSceneEnabled = autoSceneToggle.checked; persist(); });
dupCheckToggle.addEventListener("change", ()=>{ state.dupCheckEnabled = dupCheckToggle.checked; persist(); });
streamingToggle.addEventListener("change", ()=>{ state.streamingEnabled = streamingToggle.checked; persist(); });
queueToggle.addEventListener("change", ()=>{ state.queueEnabled = queueToggle.checked; persist(); });
parallelToggle.addEventListener("change", ()=>{ state.parallelEnabled = parallelToggle.checked; persist(); });
checkpointToggle.addEventListener("change", ()=>{ state.checkpointEnabled = checkpointToggle.checked; persist(); });
minWordsInput.addEventListener("change", ()=>{
  state.minChapterWords = Math.min(12000, Math.max(500, parseInt(minWordsInput.value,10) || 5000));
  if(state.chapterWordMin!=null && state.chapterWordMax!=null && Number.isFinite(Number(state.chapterWordMin)) && Number.isFinite(Number(state.chapterWordMax)) && Number(state.chapterWordMax) >= Number(state.chapterWordMin)){
    state.minChapterWords = Math.max(Number(state.chapterWordMin), Math.min(Number(state.chapterWordMax), state.minChapterWords));
  }
  minWordsInput.value = state.minChapterWords; persist();
});
function saveChapterWordBounds(){
  const minText = chapterWordMinInput.value.trim(), maxText = chapterWordMaxInput.value.trim();
  if(!minText && !maxText){ state.chapterWordMin = null; state.chapterWordMax = null; persist(); setStatus("Đã dùng lại giới hạn mục tiêu ±500 từ.", false); return; }
  const min = Number(minText), max = Number(maxText);
  if(!minText || !maxText || !Number.isFinite(min) || !Number.isFinite(max) || min < 300 || max > 12000 || min > max){
    setStatus("Khoảng min/max không hợp lệ: nhập đủ hai số, 300 ≤ min ≤ max ≤ 12.000.", false);
    chapterWordMinInput.value = state.chapterWordMin || ""; chapterWordMaxInput.value = state.chapterWordMax || ""; return;
  }
  state.chapterWordMin = Math.floor(min); state.chapterWordMax = Math.floor(max);
  state.minChapterWords = Math.max(state.chapterWordMin, Math.min(state.chapterWordMax, Number(state.minChapterWords) || 5000));
  minWordsInput.value = state.minChapterWords; persist(); setStatus("Đã lưu min/max riêng cho truyện này.", false);
}
chapterWordMinInput.addEventListener("change", saveChapterWordBounds);
chapterWordMaxInput.addEventListener("change", saveChapterWordBounds);
autoContinueMaxInput.addEventListener("change", ()=>{
  state.autoContinueMax = Math.max(0, Math.min(8, parseInt(autoContinueMaxInput.value,10) || 4));
  autoContinueMaxInput.value = state.autoContinueMax; persist();
});
modelNsfwSelect.addEventListener("change", ()=>{ state.modelNsfw = modelNsfwSelect.value.trim(); syncApiSettingsV102(); persist(); updateNsfwHint(); });
modelSelect.addEventListener("change", ()=>{ state.model = modelSelect.value.trim(); syncApiSettingsV102(); persist(); });
nsfwModeSelect.addEventListener("change", ()=>{ state.nsfwMode = nsfwModeSelect.value; syncApiSettingsV102(); persist(); updateNsfwHint(); toggleAutoOpts(); });
chapterMatureFocusEl.addEventListener("change", ()=>{ state.chapterMatureFocus=normalizeChapterMatureFocus(chapterMatureFocusEl.value); if(state.chapterMatureFocus === "none") state.mature=false; persist(); updateNsfwHint(); });
nsfwAutoThresholdInput.addEventListener("change", ()=>{
  state.nsfwAutoThreshold = Math.max(3, Math.min(9, parseInt(nsfwAutoThresholdInput.value,10) || 6));
  state.chapterMatureFocus = normalizeChapterMatureFocus(chapterMatureFocusEl.value);
  nsfwAutoThresholdInput.value = state.nsfwAutoThreshold; persist();
});
descriptionLevelSelect.addEventListener("change", ()=>{ state.descriptionLevel = descriptionLevelSelect.value; persist(); });
explicitLevelSelect.addEventListener("change", ()=>{ state.explicitLevel = explicitLevelSelect.value; persist(); });
regenModeSelect.addEventListener("change", ()=>{ /* noop */ });

/* ========== API KEY / ENDPOINT (fix missing handlers) ========== */
$ID("toggleKeyVis").addEventListener("click", ()=>{
  const inp = apiKeyInput;
  if(!inp) return;
  if(inp.type === "password"){ inp.type = "text"; $ID("toggleKeyVis").textContent = "🙈"; }
  else { inp.type = "password"; $ID("toggleKeyVis").textContent = "👁"; }
});

$ID("saveKeyBtn").addEventListener("click", async ()=>{
  state.apiEndpoint = (apiEndpointInput.value || "").trim();
  state.apiKey = (apiKeyInput.value || "").trim().replace(/^bearer\s+/i, "").replace(/^["']|["']$/g, "");
  state.model = (modelSelect.value || "").trim();
  state.modelNsfw = (modelNsfwSelect.value || "").trim();
  state.nsfwMode = nsfwModeSelect.value || "auto";
  state.nsfwAutoThreshold = Math.max(3, Math.min(9, parseInt(nsfwAutoThresholdInput.value,10) || 6));
  syncApiSettingsV102();
  persistNow();
  apiStatus.textContent = "Đang kiểm tra...";
  apiStatus.className = "api-status";
  if(!state.apiEndpoint || !state.apiKey){
    apiStatus.textContent = "Thiếu endpoint hoặc API key.";
    apiStatus.className = "api-status bad";
    setStatus("Thiếu endpoint / API key.", false);
    return;
  }
  try{
    const isOpenRouter = /openrouter\.ai/i.test(state.apiEndpoint);
    const headers = { "Content-Type": "application/json", "Authorization": "Bearer " + state.apiKey };
    if(isOpenRouter){
      headers["HTTP-Referer"] = location.protocol === "file:" ? "https://localhost" : location.origin;
      headers["X-Title"] = "Xuong Truyen AI Pro Max v14.7.9";
    }
    // Lightweight probe: request 1 token
    const body = {
      model: state.model || "deepseek/deepseek-v3.2",
      messages: [{ role: "user", content: "ping" }],
      max_tokens: 1,
      temperature: 0
    };
    const controller = new AbortController();
    const timer = setTimeout(()=>controller.abort(), 15000);
    const res = await fetch(state.apiEndpoint, {
      method: "POST", headers, body: JSON.stringify(body), signal: controller.signal
    });
    clearTimeout(timer);
    if(res.ok){
      apiStatus.textContent = "✓ Kết nối OK · " + shortModelName(state.model);
      apiStatus.className = "api-status ok";
      setStatus("API key hợp lệ.", false);
    } else {
      let detail = res.statusText;
      try{
        const j = await res.json();
        detail = (j.error && (j.error.message || j.error)) || JSON.stringify(j);
      }catch(e){}
      apiStatus.textContent = "Lỗi " + res.status + ": " + String(detail).slice(0, 120);
      apiStatus.className = "api-status bad";
      setStatus("API lỗi: " + res.status, false);
    }
  }catch(err){
    const msg = err.name === "AbortError" ? "Hết thời gian chờ." : (err.message || "Không kết nối được");
    apiStatus.textContent = "Lỗi: " + msg;
    apiStatus.className = "api-status bad";
    setStatus("Không kiểm tra được API.", false);
  }
  updateNsfwHint();
});

/* Also persist endpoint/key when leaving the fields */
apiEndpointInput.addEventListener("change", ()=>{ state.apiEndpoint = apiEndpointInput.value.trim(); persist(); });
apiKeyInput.addEventListener("change", ()=>{
  state.apiKey = apiKeyInput.value.trim().replace(/^bearer\s+/i, "").replace(/^["']|["']$/g, "");
  persist();
});

/* ========== BACKUP NOW ========== */
$ID("backupNowBtn").addEventListener("click", ()=>{
  downloadJson();
  setStatus("Đã xuất JSON sao lưu.", false);
});

/* ========== DELETE CHAPTER ========== */
$ID("deleteChapterBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  const idx = parseInt(deleteChapterSelect.value, 10);
  if(isNaN(idx) || idx < 0 || idx >= state.chapters.length){
    setStatus("Chọn chương hợp lệ.", false); return;
  }
  const ch = state.chapters[idx];
  const wipe = deleteWipeMemoryToggle ? deleteWipeMemoryToggle.checked : true;
  const ok = await showConfirm(
    "Xóa chương " + (idx+1) + ": \"" + (ch.title || "") + "\" ?\n\n" +
    (wipe ? "Sẽ xóa kèm scene / history / điều chỉnh số chương liên quan, và các nhân vật / địa điểm / vật phẩm chỉ xuất hiện ở chương này." : "Chỉ xóa văn bản chương, giữ bộ nhớ."),
    { okText: "Xóa", danger: true }
  );
  if(!ok) return;

  /* Snapshot của chương ngay trước chương bị xóa. Nếu đang xóa chương cuối,
     đây là mốc chính xác để rollback toàn bộ bộ nhớ về trạng thái trước chương đó. */
  const removedNum = idx + 1;
  const previousSnapshot = idx > 0 && state.chapters[idx - 1]
    ? JSON.parse(JSON.stringify(state.chapters[idx - 1].stateSnapshot || null))
    : null;
  const wasLastChapter = idx === state.chapters.length - 1;

  // Remove chapter
  if(typeof invalidateChapterDependentRecords === "function") invalidateChapterDependentRecords(state, removedNum);
  // Future snapshots were derived from the removed chapter and must be recomputed;
  // retaining them would silently resurrect deleted canon on a later rollback.
  state.chapters.slice(idx + 1).forEach(chp => {
    if(chp){ chp.stateSnapshot = null; chp.stateSnapshots = []; chp.snapshotInvalidated = true; chp.snapshotInvalidatedByChapter = removedNum; }
  });
  state.chapters.splice(idx, 1);

  if(wipe){
    const remapChapterNumber = n => {
      const num = Number(n);
      if(!Number.isFinite(num)) return n;
      if(num === removedNum) return null;
      return num > removedNum ? num - 1 : num;
    };

    // Scenes / Threads
    state.scenes = (state.scenes || []).filter(s => s.chapter !== removedNum)
      .map(s => s.chapter > removedNum ? Object.assign({}, s, { chapter: s.chapter - 1 }) : s);
    state.threads = (state.threads || []).filter(t => t.chapterIntroduced !== removedNum)
      .map(t => t.chapterIntroduced > removedNum ? Object.assign({}, t, { chapterIntroduced: t.chapterIntroduced - 1 }) : t);

    /* V12.19: xóa kèm các mục CHỈ sinh ra từ chương bị xóa (nhân vật / địa điểm / vật phẩm xuất hiện lần đầu ở chương này
       và không xuất hiện ở chương nào sau). Mục dùng lại ở chương sau thì được giữ. Áp cho cả snapshot các chương còn lại,
       để khi xóa chương cuối sau này, mục đã xóa không "sống lại" từ snapshot. */
    const createdHere = o => o && o.firstAppearance === removedNum && !(Number(o.lastAppearance) > removedNum);
    const removedCharNames = new Set((state.characters || []).filter(createdHere).map(c => normalizeName(c.name)));
    state.characters = (state.characters || []).filter(c => !createdHere(c));
    state.locations = (state.locations || []).filter(l => !createdHere(l));
    state.items = (state.items || []).filter(it => !createdHere(it));
    (state.locations || []).concat(state.items || []).forEach(o => {
      if(o.firstAppearance === removedNum) o.firstAppearance = removedNum;
      else if(o.firstAppearance > removedNum) o.firstAppearance--;
      if(o.lastAppearance === removedNum) o.lastAppearance = Math.max(0, removedNum - 1) || null;
      else if(o.lastAppearance > removedNum) o.lastAppearance--;
    });
    if(removedCharNames.size){
      (state.characters || []).forEach(c => { if(Array.isArray(c.relationships)) c.relationships = c.relationships.filter(r => !removedCharNames.has(normalizeName(r && r.withName))); });
      Object.keys(state.characterStateTracker || {}).forEach(k => { if(removedCharNames.has(k)) delete state.characterStateTracker[k]; });
    }
    state.chapters.forEach(chp => {
      const sn = chp.stateSnapshot; if(!sn) return;
      sn.characters = (sn.characters || []).filter(c => !createdHere(c));
      sn.locations = (sn.locations || []).filter(l => !createdHere(l));
      sn.items = (sn.items || []).filter(it => !createdHere(it));
    });

    // Character history + appearance/death markers
    (state.characters || []).forEach(c => {
      if(Array.isArray(c.history)){
        c.history = c.history.filter(h => h.chapter !== removedNum)
          .map(h => h.chapter > removedNum ? Object.assign({}, h, { chapter: h.chapter - 1 }) : h);
      }
      if(c.lastAppearance === removedNum) c.lastAppearance = Math.max(0, removedNum - 1) || null;
      else if(c.lastAppearance > removedNum) c.lastAppearance--;
      if(c.firstAppearance === removedNum) c.firstAppearance = removedNum; /* còn lại = mục dùng lại ở chương sau (đã dịch xuống vị trí này) */
      else if(c.firstAppearance > removedNum) c.firstAppearance--;
      if(c.deathChapter === removedNum) c.deathChapter = null;
      else if(c.deathChapter > removedNum) c.deathChapter--;
    });

    state.consentLog = (state.consentLog || []).filter(c => c.chapter !== removedNum)
      .map(c => c.chapter > removedNum ? Object.assign({}, c, { chapter: c.chapter - 1 }) : c);

    // Long-term Memory: xóa đúng dữ liệu sinh từ chương bị xóa, rồi đánh lại số chương.
    state.timeline = (state.timeline || []).filter(e => e.chapter !== removedNum)
      .map(e => e.chapter > removedNum ? Object.assign({}, e, { chapter: e.chapter - 1 }) : e);
    state.foreshadowing = (state.foreshadowing || []).filter(f => f.plantedChapter !== removedNum && f.lastUpdated !== removedNum)
      .map(f => Object.assign({}, f, {
        plantedChapter: f.plantedChapter > removedNum ? f.plantedChapter - 1 : f.plantedChapter,
        lastUpdated: f.lastUpdated > removedNum ? f.lastUpdated - 1 : f.lastUpdated
      }));
    state.knowledgeLedger = (state.knowledgeLedger || []).filter(k => k.firstChapter !== removedNum && k.lastUpdated !== removedNum)
      .map(k => Object.assign({}, k, {
        firstChapter: k.firstChapter > removedNum ? k.firstChapter - 1 : k.firstChapter,
        lastUpdated: k.lastUpdated > removedNum ? k.lastUpdated - 1 : k.lastUpdated
      }));
    state.memoryEvents = (state.memoryEvents || []).filter(e => e.chapter !== removedNum)
      .map(e => e.chapter > removedNum ? Object.assign({}, e, { chapter: e.chapter - 1 }) : e);

    // Tracker chỉ giữ trạng thái mới nhất. Nếu nó trỏ đúng chương bị xóa,
    // sẽ được phục hồi từ snapshot bên dưới nếu đây là chương cuối.
    Object.keys(state.characterStateTracker || {}).forEach(k => {
      const t = state.characterStateTracker[k];
      if(t && Number(t.chapter) === removedNum) delete state.characterStateTracker[k];
      else if(t && Number(t.chapter) > removedNum) t.chapter--;
    });

    remapSnapshotChapterNumbers(remapChapterNumber);

    // Nếu xóa CHƯƠNG CUỐI, toàn bộ bộ nhớ live phải quay chính xác về chương trước.
    // Đây là phần bản cũ còn thiếu: trước đây chỉ xóa history nhưng vẫn giữ
    // Current Status / nhân vật / Memory / Status của chương vừa xóa.
    if(wasLastChapter && previousSnapshot){
      state.currentStatus = previousSnapshot.currentStatus || "";
      state.statusState = previousSnapshot.statusState || {};
      state.storyClock = previousSnapshot.storyClock || "";
      if(previousSnapshot.mainCharProfile) state.mainCharProfile = previousSnapshot.mainCharProfile;
      state.mainCharCoreIdentity = previousSnapshot.mainCharCoreIdentity || {};
      state.femaleCharacterDefinition = previousSnapshot.femaleCharacterDefinition || state.femaleCharacterDefinition || "";
      state.characters = previousSnapshot.characters || [];
      state.locations = previousSnapshot.locations || [];
      state.items = previousSnapshot.items || [];
      state.threads = previousSnapshot.threads || [];
      state.timeline = previousSnapshot.timeline || [];
      state.foreshadowing = previousSnapshot.foreshadowing || [];
      state.knowledgeLedger = previousSnapshot.knowledgeLedger || [];
      state.memoryEvents = previousSnapshot.memoryEvents || [];
      state.characterStateTracker = previousSnapshot.characterStateTracker || {};
      state.lastStatusChapter = Math.min(Number(previousSnapshot.lastStatusChapter || idx), state.chapters.length);
      state.lastMemorySyncChapter = Math.min(Number(previousSnapshot.lastMemorySyncChapter || idx), state.chapters.length);
    } else {
      state.lastStatusChapter = Math.min(Number(state.lastStatusChapter || 0), state.chapters.length);
      state.lastMemorySyncChapter = Math.min(Number(state.lastMemorySyncChapter || 0), state.chapters.length);
    }
  }

  // Sau khi xóa chương cuối, chọn lại chương cuối còn tồn tại (tức chương trước đó).
  if(state.chapters.length === 0){
    state.currentChapterIndex = -1;
  } else if(wasLastChapter){
    state.currentChapterIndex = Math.min(idx - 1, state.chapters.length - 1);
  } else if(state.currentChapterIndex > idx){
    state.currentChapterIndex--;
  } else if(state.currentChapterIndex >= state.chapters.length){
    state.currentChapterIndex = state.chapters.length - 1;
  }

  // Xóa chương là thao tác dữ liệu quan trọng: ghi NGAY vào IndexedDB + emergency copy,
  // không chờ debounce 1,75s, để iOS/Safari không giữ lại bản memory cũ.
  persistNow({sync:true});
  renderAll();
  setStatus("Đã xóa chương " + removedNum + " và đồng bộ bộ nhớ về trạng thái còn lại.", false);
});


/* ========== MAIN CHARACTER FORM ========== */
/* V14.1: bộ trường tu luyện dùng chung cho form nhân vật chính và nhân vật phụ. [field, nhãn, "in"=một dòng | "ta"=nhiều dòng] */
const CULT_UI = [
  ["realm","Cảnh giới hiện tại (VD: Trúc Cơ đệ tam trọng)","in"],
  ["peakRealm","Cảnh giới cao nhất từng đạt (tự cập nhật)","in"],
  ["spiritRoot","Linh căn / thể chất / huyết mạch","in"],
  ["talent","Tư chất / ngộ tính","in"],
  ["element","Thuộc tính (ngũ hành, kiếm, đan, trận...)","in"],
  ["technique","Công pháp chính","ta"],
  ["arts","Thần thông / chiêu thức / võ học","ta"],
  ["combatPower","Sức chiến đấu (so với người cùng cấp)","in"],
  ["treasure","Bản mệnh pháp bảo / binh khí","in"],
  ["inventory","Túi trữ vật (vật phẩm đang giữ)","ta"],
  ["spiritStones","Linh thạch / tài sản tu sĩ","in"],
  ["apparentAge","Tuổi ngoại hình (rào chắn 18+ lấy số nhỏ hơn)","in"],
  ["lifespan","Thọ nguyên","in"],
  ["masterLine","Sư môn & bối phận (sư phụ, sư huynh/tỷ/đệ/muội)","ta"],
  ["aliasesText","Đạo hiệu / hiệu / tên gọi khác (cách nhau dấu phẩy)","in"],
  ["fortune","Cơ duyên / kỳ ngộ","ta"],
  ["grudges","Ân oán / thù hận","ta"],
  ["originSecret","Bí mật thân thế","ta"],
  ["innerDemon","Tâm ma / chấp niệm","ta"],
  ["karma","Nghiệp lực / khí vận","ta"]
];
const MC_EXTRA_FIELDS = [
  ["position","Chức vị / bối phận","in"], ["faction","Tông môn / thế lực","in"],
  ["weakness","Điểm yếu","ta"], ["fear","Nỗi sợ","ta"], ["knowledge","Điều biết (chỉ những gì NV thực sự biết)","ta"]
];
const MC_DYN = MC_EXTRA_FIELDS.concat(CULT_UI);
/* V14.1: nhãn theo thể loại — truyện tu tiên/huyền huyễn/võ hiệp dùng "thân phận, chức vị, tông môn" thay cho "nghề, vị trí, phe". */
function genreLabels(){
  const g = (typeof genreEl !== "undefined" && genreEl && genreEl.value) || state.genre || "";
  const c = isCultivationGenre(g);
  return {
    cult: c,
    age: c ? "Tuổi thực" : "Tuổi",
    occupation: c ? "Thân phận / nghề (đệ tử ngoại môn, luyện đan sư...)" : "Nghề",
    position: c ? "Chức vị / bối phận" : "Vị trí",
    faction: c ? "Tông môn / gia tộc / thế lực" : "Phe",
    currentLocation: c ? "Đang ở (địa danh, động phủ...)" : "Đang ở",
    schedule: c ? "Việc đang làm / bế quan" : "Lịch trình",
    skills: c ? "Võ học / kỹ năng" : "Kỹ năng"
  };
}
function cultSectionOpen(c){
  return genreLabels().cult || CULT_FIELDS.some(k=>c && String(c[k]||"").trim()) || !!(c && Array.isArray(c.aliases) && c.aliases.length);
}
function cultFieldHtml(f,label,kind,val,attrs){
  const ph = escapeHtml(label);
  return kind==="ta"
    ? '<textarea '+attrs+' rows="2" placeholder="'+ph+'" title="'+ph+'">'+escapeHtml(val)+'</textarea>'
    : '<input type="text" '+attrs+' value="'+escapeHtml(val)+'" placeholder="'+ph+'" title="'+ph+'" style="width:100%;margin-bottom:4px;">';
}
function buildMcExtraForm(){
  const box = $ID("mcExtraBox"); if(!box) return;
  let h = '<div class="hint" style="color:var(--purple);margin-top:4px;">🏷 Thân phận & tâm lý</div>';
  h += MC_EXTRA_FIELDS.map(([f,label,kind])=>cultFieldHtml(f,label,kind,"",'id="mcf_'+f+'"')).join("");
  h += '<details id="mcCultDetails" style="margin-top:6px;"><summary class="hint" style="cursor:pointer;color:var(--amber);font-weight:600;">🧘 Tu luyện (cảnh giới, công pháp, pháp bảo...)</summary>';
  h += CULT_UI.map(([f,label,kind])=>cultFieldHtml(f,label,kind,"",'id="mcf_'+f+'"')).join("");
  h += '</details>';
  box.innerHTML = h;
}
function applyGenreLabels(){
  const L = genreLabels();
  const set = (id,ph)=>{ const el=$ID(id); if(el){ el.placeholder=ph; el.title=ph; } };
  set("mcAgeInput", L.age); set("mcOccupationInput", L.occupation); set("mcLocationInput", L.cult ? L.currentLocation : "Đang ở đâu");
  set("mcSkillsInput", L.skills); set("mcf_position", L.cult ? L.position : "Chức vị / vị trí"); set("mcf_faction", L.cult ? L.faction : "Phe / tổ chức");
}
function saveMainCharFromForm(){
  const _old = state.mainCharProfile || {};
  state.mainCharProfile = Object.assign({}, _old, {
    name: $ID("mcNameInput").value.trim(), age: $ID("mcAgeInput").value.trim(),
    gender: $ID("mcGenderInput").value.trim(), occupation: $ID("mcOccupationInput").value.trim(),
    maritalStatus: ($ID("mcMaritalStatusInput")||{value:""}).value.trim(), spouseName: ($ID("mcSpouseNameInput")||{value:""}).value.trim(),
    currentLocation: $ID("mcLocationInput").value.trim(),
    appearance: $ID("mcAppearanceInput").value.trim(),
    height: $ID("mcHeightInput").value.trim(),
    bodyType: $ID("mcBodyTypeInput").value.trim(),
    measurements: ($ID("mcMeasurementsInput")||{value:""}).value.trim(),
    hair: $ID("mcHairInput").value.trim(),
    eyes: $ID("mcEyesInput").value.trim(),
    skin: $ID("mcSkinInput").value.trim(),
    voice: $ID("mcVoiceInput").value.trim(),
    scent: $ID("mcScentInput").value.trim(),
    style: $ID("mcStyleInput").value.trim(),
    scars: $ID("mcScarsInput").value.trim(),
    tattoos: $ID("mcTattoosInput").value.trim(),
    personality: $ID("mcPersonalityInput").value.trim(),
    speech: $ID("mcSpeechInput").value.trim(),
    goals: $ID("mcGoalsInput").value.trim(),
    skills: $ID("mcSkillsInput").value.trim(),
    physicalState: $ID("mcPhysicalInput").value.trim(),
    mentalState: $ID("mcMentalInput").value.trim(),
    secret: $ID("mcSecretInput").value.trim(),
    sexualExperience: $ID("mcSexualExpInput").value.trim(),
    boundaries: $ID("mcBoundariesInput").value.trim(),
    preferences: $ID("mcPreferencesInput").value.trim(),
    maritalNotes: _old.maritalNotes || "",
    aliases: Array.isArray(_old.aliases) ? _old.aliases : []
  });
  MC_DYN.forEach(([f])=>{
    const el = $ID("mcf_"+f); if(!el) return;
    if(f==="aliasesText") state.mainCharProfile.aliases = el.value.split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean).slice(0,8);
    else state.mainCharProfile[f] = el.value.trim();
  });
  applyCultivationUpdate(state.mainCharProfile, {}, {state});   // cập nhật peakRealm khi người dùng sửa cảnh giới
  persist();
}
const MC_FIELDS = ["mcNameInput","mcAgeInput","mcGenderInput","mcOccupationInput","mcLocationInput",
  "mcAppearanceInput","mcHeightInput","mcBodyTypeInput","mcMeasurementsInput","mcHairInput","mcEyesInput","mcSkinInput",
  "mcVoiceInput","mcScentInput","mcStyleInput","mcScarsInput","mcTattoosInput","mcMaritalStatusInput","mcSpouseNameInput",
  "mcPersonalityInput","mcSpeechInput","mcGoalsInput","mcSkillsInput",
  "mcPhysicalInput","mcMentalInput","mcSecretInput",
  "mcSexualExpInput","mcBoundariesInput","mcPreferencesInput"];
buildMcExtraForm();
MC_DYN.forEach(([f])=>MC_FIELDS.push("mcf_"+f));
if(typeof genreEl !== "undefined" && genreEl) genreEl.addEventListener("input", ()=>{ applyGenreLabels(); });
if(typeof genreEl !== "undefined" && genreEl) genreEl.addEventListener("change", ()=>{ applyGenreLabels(); try{ renderCharacters(); }catch(e){} });
MC_FIELDS.forEach(id=>{
  const el = $ID(id);
  if(!el) return;
  el.addEventListener("change", saveMainCharFromForm);
  el.addEventListener("input", ()=>{ clearTimeout(window._mcT); window._mcT = setTimeout(saveMainCharFromForm, 1500); });
});
$ID("saveMainCharBtn").addEventListener("click", ()=>{ saveMainCharFromForm(); setStatus("Đã lưu.", false); });

$ID("rescanMainCharBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  setStatus("Đang cập nhật NV chính...", true);
  const prompt = [
    "Đọc chương sau và trích xuất thông tin MỚI về NHÂN VẬT CHÍNH.",
    "Thông tin hiện tại:", JSON.stringify(state.mainCharProfile, null, 2), "",
    "Nội dung chương:", state.chapters[state.chapters.length-1].text, "",
    "Trả về DUY NHẤT object JSON cùng schema (chỉ điền những gì chương này thay đổi). Cảnh giới (realm) chỉ ghi khi chương nêu rõ, dùng đúng tên trong thang cảnh giới; nếu có đột phá/tụt cảnh thì thêm explicitCoreChange=true và changeEvidence = câu trích nguyên văn từ chương.",
    cultivationSystemBlock(state),
    JSON.stringify(newMainCharProfile())
  ].join("\n");
  try{
    const { text: raw } = await callAI(prompt, {maxTokens:1500, temperature:0.3});
    const obj = safeJsonParse(raw);
    if(obj && typeof obj === "object"){
      const lockedMain = new Set(["name","age","gender","maritalStatus","spouseName","appearance","personality","occupation","goals","position","faction"]);
      Object.keys(obj).forEach(k=>{
        if(CULT_FIELDS.includes(k) || k==="aliases" || k==="explicitCoreChange" || k==="changeEvidence") return;   // trường tu luyện đi qua applyMainCharUpdate (có kiểm soát đột phá)
        if(!obj[k] || !String(obj[k]).trim()) return;
        if(lockedMain.has(k) && state.mainCharProfile[k] && !obj.explicitCoreChange) return;
        state.mainCharProfile[k] = String(obj[k]).trim();
      });
      applyMainCharUpdate(state.mainCharProfile, obj, state.chapters[state.chapters.length-1].text, state);
      persist(); hydrateMainCharForm();
      setStatus("Đã cập nhật.", false);
    } else setStatus("Không phân tích được.", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
});

function hydrateMainCharForm(){
  const p = state.mainCharProfile || newMainCharProfile();
  const map = {
    mcNameInput:"name", mcAgeInput:"age", mcGenderInput:"gender", mcOccupationInput:"occupation", mcMaritalStatusInput:"maritalStatus", mcSpouseNameInput:"spouseName",
    mcLocationInput:"currentLocation", mcAppearanceInput:"appearance",
    mcHeightInput:"height", mcBodyTypeInput:"bodyType", mcMeasurementsInput:"measurements", mcHairInput:"hair", mcEyesInput:"eyes",
    mcSkinInput:"skin", mcVoiceInput:"voice", mcScentInput:"scent", mcStyleInput:"style",
    mcScarsInput:"scars", mcTattoosInput:"tattoos",
    mcPersonalityInput:"personality", mcSpeechInput:"speech", mcGoalsInput:"goals",
    mcSkillsInput:"skills", mcPhysicalInput:"physicalState", mcMentalInput:"mentalState",
    mcSecretInput:"secret", mcSexualExpInput:"sexualExperience",
    mcBoundariesInput:"boundaries", mcPreferencesInput:"preferences"
  };
  Object.entries(map).forEach(([id, field])=>{
    const el = $ID(id);
    if(el) el.value = p[field] || "";
  });
  MC_DYN.forEach(([f])=>{
    const el = $ID("mcf_"+f); if(!el) return;
    el.value = f==="aliasesText" ? (Array.isArray(p.aliases) ? p.aliases.join(", ") : "") : (p[f] || "");
  });
  { const d = $ID("mcCultDetails"); if(d) d.open = cultSectionOpen(p); }
  applyGenreLabels();
}

/* ========== ARCS ========== */
function renderArcs(){
  if(!state.arcs.length){ arcList.innerHTML = '<div class="empty-note">Chưa có.</div>'; return; }
  arcList.innerHTML = state.arcs.map((a,i)=>
    '<div class="arc-card"><div class="arc-card-top"><b>'+escapeHtml(a.name)+'</b><span class="arc-status arc-'+a.status+'">'+a.status+'</span></div>'
    + '<div class="hint">Chương '+ (a.startChapter||"?") +' → '+ (a.endChapterPlanned||"?") +'</div>'
    + (a.goal ? '<div style="margin-top:4px;">'+escapeHtml(a.goal)+'</div>' : '')
    + '<div class="char-actions"><select data-arc-status="'+i+'" style="font-size:11px;padding:4px 6px;width:auto;">'
      + ["planned","active","paused","completed","failed","abandoned"].map(s=>'<option value="'+s+'"'+(s===a.status?' selected':'')+'>'+s+'</option>').join("")
      + '</select><button class="btn btn-outline-red btn-sm" data-arc-del="'+i+'">Xóa</button></div></div>'
  ).join("");
  arcList.querySelectorAll("[data-arc-status]").forEach(sel=>{
    sel.addEventListener("change", ()=>{ state.arcs[parseInt(sel.getAttribute("data-arc-status"),10)].status = sel.value; persist(); renderArcs(); });
  });
  arcList.querySelectorAll("[data-arc-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{ state.arcs.splice(parseInt(btn.getAttribute("data-arc-del"),10),1); persist(); renderArcs(); });
  });
}
$ID("arcAddBtn").addEventListener("click", ()=>{
  const name = $ID("arcNameInput").value.trim();
  if(!name){ setStatus("Nhập tên Arc.", false); return; }
  state.arcs.push({
    id: genId(), name,
    startChapter: parseInt($ID("arcStartInput").value,10) || (state.chapters.length+1),
    endChapterPlanned: parseInt($ID("arcEndInput").value,10) || null,
    goal: $ID("arcGoalInput").value.trim(),
    status: state.arcs.some(a=>a.status==='active') ? 'planned' : 'active'
  });
  persist(); renderArcs();
  ["arcNameInput","arcStartInput","arcEndInput","arcGoalInput"].forEach(id=> $ID(id).value="");
});
function currentArc(){ return state.arcs.find(a=>a.status==='active') || null; }

/* ========== OUTLINE ========== */
function renderOutlines(){
  if(!state.outlinePlans.length){ outlineList.innerHTML = '<div class="empty-note">Chưa có. Mẹo: viết mỗi chương một dòng dạng "Ch12: bước tiến của chương" để AI biết chương nào làm việc gì.</div>'; return; }
  const _left = outlineCoverageLeft(state);
  const _warn = (_left !== null && _left <= 2) ? '<div class="empty-note" style="color:var(--amber,#e0a030);">⚠ ' + (_left <= 0 ? "Outline đã hết — bấm 🤖 AI đề xuất để tạo giai đoạn mới." : "Outline sắp hết (còn " + _left + " chương) — nên tạo giai đoạn tiếp theo.") + '</div>' : "";
  outlineList.innerHTML = _warn + state.outlinePlans.map((o,i)=>
    '<div class="arc-card"><div class="arc-card-top"><b>'+escapeHtml(o.name)+'</b><span class="arc-status arc-planned">Ch '+o.from+'–'+o.to+'</span></div>'
    + '<div style="margin-top:4px;font-size:11.5px;white-space:pre-wrap;">'+escapeHtml(o.content)+'</div>'
    + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-outline-del="'+i+'">Xóa</button></div></div>'
  ).join("");
  outlineList.querySelectorAll("[data-outline-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{ state.outlinePlans.splice(parseInt(btn.getAttribute("data-outline-del"),10),1); persist(); renderOutlines(); });
  });
}
$ID("outlineAddBtn").addEventListener("click", ()=>{
  const name = $ID("outlineNameInput").value.trim();
  const from = parseInt($ID("outlineFromInput").value,10);
  const to = parseInt($ID("outlineToInput").value,10);
  const content = $ID("outlineContentInput").value.trim();
  if(!name || !from || !to){ setStatus("Nhập đủ.", false); return; }
  state.outlinePlans.push({ id: genId(), name, from, to, content });
  persist(); renderOutlines();
  ["outlineNameInput","outlineFromInput","outlineToInput","outlineContentInput"].forEach(id=> $ID(id).value="");
});
$ID("outlineAIGenerateBtn").addEventListener("click", async ()=>{
  setStatus("Đang nhờ AI đề xuất...", true);
  const from = state.chapters.length + 1;
  const to = from + 9;
  const prompt = [
    "Dựa trên Story Bible và tiến trình truyện, đề xuất outline 10 chương tiếp theo (chương " + from + "-" + to + ").",
    "YÊU CẦU: chia theo TỪNG CHƯƠNG, mỗi chương một bước tiến CỤ THỂ (sự kiện/quyết định/hậu quả làm truyện đi tới), các bước nối nhau và tăng dần về phía một MỐC KẾT của giai đoạn. Không lặp lại cùng một bước; không dồn mọi thứ vào chương đầu.",
    state.arcs.some(a=>a.status==='active') ? ("Arc đang chạy: " + (currentArc().name || "") + " — " + (currentArc().goal || "")) : "",
    outlineMaturePrompt(state, 10),
    "Story Bible:", buildStoryBibleSummary(), "",
    "Current Status:", state.currentStatus || "(chưa có)", "",
    "Tóm tắt chương gần đây:", chaptersSummaryText(5) || "(chưa có)", "",
    'Trả về DUY NHẤT object JSON: {"name":"Tên giai đoạn","milestone":"Mốc kết giai đoạn","chapters":[{"chapter":' + from + ',"beat":"Bước tiến của chương này (1–2 câu)"}]} — đủ ' + 10 + ' phần tử, chapter từ ' + from + ' đến ' + to + '.',
    "Tất cả TIẾNG VIỆT."
  ].filter(Boolean).join("\n");
  try{
    const { text: raw } = await callAI(prompt, {maxTokens:3000, temperature:0.8});
    const obj = safeJsonParse(raw);
    if(obj && Array.isArray(obj.chapters) && obj.chapters.length && !obj.content){
      const rows = obj.chapters.map(c=>({ n: Number(c && c.chapter), b: String((c && (c.beat||c.content||c.summary)) || "").trim() })).filter(c=>c.n>=from && c.n<=to && c.b);
      if(rows.length){ obj.content = rows.sort((a,b)=>a.n-b.n).map(c=>"Ch"+c.n+": "+c.b).join("\n") + (obj.milestone ? "\nMốc kết giai đoạn: " + String(obj.milestone).trim() : ""); }
    }
    if(obj && obj.name && obj.content){
      const _rows = Object.entries(outlineChapterLines(obj.content, { from, to })).map(([k,v])=>({ n:Number(k), b:v }));
      const _bad = state.mature ? outlineAdultViolations(_rows, state) : [];
      if(_bad.length){ setStatus("Outline có cảnh 18+ dính nhân vật chưa đủ 18 tuổi (ch " + _bad.join(", ") + ") — đã bỏ kết quả, bấm 🤖 để tạo lại.", false); return; }
      state.outlinePlans.push({ id: genId(), name: obj.name, from, to, content: obj.content });
      persist(); renderOutlines();
      const _adultN = _rows.filter(r=>textHasNsfwKeyword(r.b)).length, _mf = normalizeChapterMatureFocus(state.chapterMatureFocus);
      setStatus(!state.mature ? "Đã tạo outline thường (🔥 Cho phép trưởng thành ở mục 4 đang TẮT)."
        : _mf === "none" ? "Đã tạo outline thường (Trọng tâm trưởng thành đang NONE — chọn SECONDARY hoặc PRIMARY ở mục 4 để outline có chương 18+)."
        : _adultN ? ("Đã tạo outline — có " + _adultN + " chương 18+.")
        : "Đã tạo outline nhưng chưa có chương 18+ nào — bấm 🤖 để tạo lại.", false);
    } else setStatus("Không phân tích được.", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
});
function currentOutline(){
  const nextCh = state.chapters.length + 1;
  return state.outlinePlans.find(o => nextCh >= o.from && nextCh <= o.to) || null;
}

/* ========== CHARACTERS ========== */
function renderCharacterStats(){
  $ID("statTotal").textContent = state.characters.length;
  $ID("statMajor").textContent = state.characters.filter(c=>c.tier==='major'||c.tier==='important').length;
  const lastCh = state.chapters.length;
  $ID("statStale").textContent = state.characters.filter(c=> c.lastAppearance!=null && (lastCh - c.lastAppearance) > 5 && !c.dead).length;
  $ID("statDead").textContent = state.characters.filter(c=> c.dead).length;
}
function relationshipRowHtml(charIdx, relIdx, rel){
  return '<div class="rel-item">'
    + '<input type="text" data-rel-field="withName" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.withName||"")+'" placeholder="Với nhân vật...">'
    + '<div class="row3" style="margin-top:4px;">'
      + '<input type="text" data-rel-field="trust" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.trust||"")+'" placeholder="Tin">'
      + '<input type="text" data-rel-field="respect" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.respect||"")+'" placeholder="Tôn trọng">'
      + '<input type="text" data-rel-field="affection" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.affection||"")+'" placeholder="Tình cảm">'
    + '</div>'
    + '<div class="row3" style="margin-top:4px;">'
      + '<input type="text" data-rel-field="attraction" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.attraction||"")+'" placeholder="Hấp dẫn">'
      + '<input type="text" data-rel-field="suspicion" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.suspicion||"")+'" placeholder="Nghi ngờ">'
      + '<input type="text" data-rel-field="stage" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.stage||"")+'" placeholder="Stage">'
    + '</div>'
    + '<div class="row2" style="margin-top:4px;">'
      + '<input type="text" data-rel-field="tension" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.tension||"")+'" placeholder="Căng thẳng">'
      + '<input type="text" data-rel-field="boundaries" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.boundaries||"")+'" placeholder="Ranh giới">'
    + '</div>'
    + '<input type="text" data-rel-field="notes" data-char="'+charIdx+'" data-rel="'+relIdx+'" value="'+escapeHtml(rel.notes||"")+'" placeholder="Ghi chú" style="margin-top:4px;">'
    + '<button class="btn btn-outline-red btn-sm" data-rel-del="'+relIdx+'" data-char-rel-owner="'+charIdx+'">Xóa quan hệ</button>'
    + '</div>';
}
function charDetailHtml(c, idx){
  const L = genreLabels();
  const classifyFields = [
    ["role","Vai trò với truyện (vd: đồng minh, phản diện phụ, nạn nhân...)"],
    ["relevanceToMC","Mức độ liên quan tới nhân vật chính"]
  ];
  const fields = [
    ["age",L.age], ["gender","Giới tính"], ["maritalStatus","Tình trạng hôn nhân"], ["spouseName","Vợ/chồng/người yêu"], ["maritalNotes","Ghi chú hôn nhân"], ["occupation",L.occupation], ["position",L.position],
    ["faction",L.faction], ["currentLocation",L.currentLocation], ["schedule",L.schedule],
    ["height","Chiều cao"], ["bodyType","Dáng người"], ["measurements","Số đo / kích thước"],
    ["hair","Tóc"], ["eyes","Mắt"], ["skin","Da"],
    ["voice","Giọng nói"], ["scent","Mùi"], ["style","Phong cách ăn mặc"],
    ["scars","Sẹo"], ["tattoos","Hình xăm"],
    ["physicalState","Thể trạng"], ["mentalState","Tâm lý"]
  ];
  const areas = [
    ["appearance","Ngoại hình tổng quát"], ["personality","Tính cách"],
    ["speech","Cách nói riêng"], ["goals","Mục tiêu"],
    ["secret","Bí mật"], ["weakness","Điểm yếu"], ["fear","Nỗi sợ"],
    ["strength","Điểm mạnh"], ["knowledge","Điều biết"], ["independentPlot","Tuyến truyện riêng"]
  ];
  const adultFields = [
    ["sexualExperience","Kinh nghiệm 18+"],
    ["boundaries","Ranh giới / Consent"],
    ["taboos","Taboo"],
    ["preferences","Sở thích / Kink"],
    ["attractionToMC","Hấp dẫn với NV chính"],
    ["tensionWithMC","Căng thẳng dục vọng với NV chính"],
    ["consentNotes","Ghi chú consent"]
  ];
  let html = '<div class="hint" style="color:var(--purple);margin-top:4px;">🏷 Phân loại vai trò</div>';
  html += classifyFields.map(([f,label])=>
    '<input type="text" data-char-field="'+f+'" data-char="'+idx+'" value="'+escapeHtml(c[f]||"")+'" placeholder="'+label+'" style="width:100%;margin-bottom:4px;">'
  ).join("");
  html += '<div class="hint" style="color:var(--purple);margin-top:4px;">🎨 Miêu tả chi tiết</div>';
  html += '<div class="row2">' + fields.map(([f,label])=>
    '<input type="text" data-char-field="'+f+'" data-char="'+idx+'" value="'+escapeHtml(c[f]||"")+'" placeholder="'+escapeHtml(label)+'" title="'+escapeHtml(label)+'">'
  ).join("") + '</div>';
  html += areas.map(([f,label])=>
    '<textarea data-char-field="'+f+'" data-char="'+idx+'" rows="2" placeholder="'+label+'">'+escapeHtml(c[f]||"")+'</textarea>'
  ).join("");
  html += '<details'+(cultSectionOpen(c)?' open':'')+' style="margin-top:6px;"><summary class="hint" style="cursor:pointer;color:var(--amber);font-weight:600;">🧘 Tu luyện (cảnh giới, công pháp, pháp bảo...)</summary>'
    + CULT_UI.map(([f,label,kind])=>cultFieldHtml(f,label,kind, f==="aliasesText" ? (Array.isArray(c.aliases)?c.aliases.join(", "):"") : (c[f]||""), 'data-char-field="'+f+'" data-char="'+idx+'"')).join("")
    + '</details>';
  html += '<div style="font-size:11px;color:var(--red);margin-top:8px;font-weight:600;">🔥 Quan hệ & Ranh giới 18+</div>';
  html += adultFields.map(([f,label])=>
    '<textarea data-char-field="'+f+'" data-char="'+idx+'" rows="2" placeholder="'+label+'" style="border-color:rgba(226,88,77,.35);">'+escapeHtml(c[f]||"")+'</textarea>'
  ).join("");
  html += '<div style="font-size:11px;color:var(--ink-dim);margin-top:4px;">Quan hệ chi tiết:</div>';
  html += (c.relationships||[]).map((r,ri)=>relationshipRowHtml(idx,ri,r)).join("");
  html += '<button class="btn btn-ghost btn-sm" data-add-rel="'+idx+'" style="margin-top:4px;">＋ Thêm quan hệ</button>';
  html += '<div class="char-actions">'
    + '<select data-char-field="tier" data-char="'+idx+'" style="font-size:11px;padding:4px 6px;width:auto;">'
      + TIERS.map(t=>'<option value="'+t+'"'+(t===c.tier?' selected':'')+'>'+t+'</option>').join("")
    + '</select>'
    + '<button class="btn btn-ghost btn-sm" data-char-togglelock="'+idx+'" title="'+(c.coreLocked!==false ? 'Hồ sơ gốc đang bị AI khóa; bấm để cho AI tự cập nhật ngoại hình/tính cách/mục tiêu sau mỗi chương' : 'AI đang được phép tự cập nhật hồ sơ gốc; bấm để khóa lại')+'">'+(c.coreLocked!==false ? '🔐 Core' : '🔓 Đang cho AI cập nhật')+'</button>'
    + '<button class="btn btn-ghost btn-sm" data-char-save="'+idx+'">💾 Lưu</button>'
    + '<button class="btn btn-outline-red btn-sm" data-char-del="'+idx+'">🗑 Xóa</button>'
    + '</div>';
  return html;
}
function renderCharacters(){ renderCharactersCore(); XTA_HOOKS.fire("chars"); }
function renderCharactersCore(){
  normalizeCharacterCoreLocks();
  const fd=$ID("femaleCharacterDefinitionInput"); if(fd && document.activeElement!==fd) fd.value=state.femaleCharacterDefinition||"";
  renderCharacterStats();
  updateCharDedupeUI();
  if(!state.characters.length){ charList.innerHTML = '<div class="empty-note">Chưa có.</div>'; return; }
  charList.innerHTML = state.characters.map((c,idx)=>{
    const stale = c.lastAppearance!=null && (state.chapters.length - c.lastAppearance) > 5 && !c.dead;
    const isOpen = openCharDetails.has(idx);
    return '<div class="char-card' + (c.dead ? ' dead' : '') + '">'
      + '<div class="char-card-top" data-char-toggle="'+idx+'">'
        + '<span class="name">'+escapeHtml(c.name||"(chưa đặt)")+'</span>'
        + '<span style="display:flex;gap:6px;align-items:center;">'
          + (c.locked ? '<span class="lock-badge">🔒</span>' : '')
          + (c.dead ? '<span class="dead-badge">💀</span>' : '')
          + (stale ? '<span class="lock-badge" style="color:var(--ink-dim);">💤</span>' : '')
          + '<span class="tier-badge tier-'+c.tier+'">'+c.tier+'</span>'
        + '</span></div>'
      + (c.role ? '<div class="hint" style="margin-top:3px;color:var(--purple);">🏷 '+escapeHtml(c.role)+'</div>' : '')
      + (c.personality ? '<div class="hint" style="margin-top:3px;">'+escapeHtml(c.personality)+'</div>' : '')
      + '<div class="char-detail' + (isOpen?' open':'') + '" id="charDetail'+idx+'">'
        + '<div class="toggle-row"><span>🔒 Khóa</span><label class="switch"><input type="checkbox" data-char-lock="'+idx+'" '+(c.locked?'checked':'')+'><span class="slider-tg"></span></label></div>'
        + '<div class="toggle-row"><span>💀 Đã chết</span><label class="switch"><input type="checkbox" data-char-dead="'+idx+'" '+(c.dead?'checked':'')+'><span class="slider-tg"></span></label></div>'
        + charDetailHtml(c, idx) + '</div></div>';
  }).join("");

  charList.querySelectorAll("[data-char-toggle]").forEach(el=>{
    el.addEventListener("click", ()=>{
      const idx = parseInt(el.getAttribute("data-char-toggle"),10);
      const d = $ID("charDetail"+idx);
      if(!d) return;
      d.classList.toggle("open");
      if(d.classList.contains("open")) openCharDetails.add(idx); else openCharDetails.delete(idx);
    });
  });
  charList.querySelectorAll("[data-char-lock]").forEach(el=>{
    el.addEventListener("change", ()=>{ state.characters[parseInt(el.getAttribute("data-char-lock"),10)].locked = el.checked; persist(); renderCharacters(); });
  });
  charList.querySelectorAll("[data-char-dead]").forEach(el=>{
    el.addEventListener("change", ()=>{
      const c = state.characters[parseInt(el.getAttribute("data-char-dead"),10)];
      c.dead = el.checked; if(c.dead) c.deathChapter = state.chapters.length;
      persist(); renderCharacters();
    });
  });
  charList.querySelectorAll("[data-add-rel]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const idx = parseInt(btn.getAttribute("data-add-rel"),10);
      state.characters[idx].relationships.push(newRelationship());
      openCharDetails.add(idx); persist(); renderCharacters();
    });
  });
  charList.querySelectorAll("[data-rel-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const idx = parseInt(btn.getAttribute("data-char-rel-owner"),10);
      const ri = parseInt(btn.getAttribute("data-rel-del"),10);
      state.characters[idx].relationships.splice(ri,1);
      openCharDetails.add(idx); persist(); renderCharacters();
    });
  });
  charList.querySelectorAll("[data-char-save]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const idx = parseInt(btn.getAttribute("data-char-save"),10);
      openCharDetails.add(idx); saveCharacterFromDom(idx);
    });
  });
  charList.querySelectorAll("[data-char-togglelock]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const idx = parseInt(btn.getAttribute("data-char-togglelock"),10);
      const c = state.characters[idx]; if(!c) return;
      c.coreLocked = (c.coreLocked===false) ? true : false;
      openCharDetails.add(idx); persist(); renderCharacters();
      setStatus(c.coreLocked ? "Đã khóa lại hồ sơ gốc của "+(c.name||"NV")+"." : "AI được phép tự cập nhật hồ sơ gốc của "+(c.name||"NV")+" từ chương sau.", false);
    });
  });
  charList.querySelectorAll("[data-char-del]").forEach(btn=>{
    btn.addEventListener("click", async ()=>{
      const idx = parseInt(btn.getAttribute("data-char-del"),10);
      const name = state.characters[idx] ? (state.characters[idx].name||"?") : "?";
      const ok = await showConfirm("Xóa nhân vật \""+name+"\"?", {okText:"Xóa", danger:true});
      if(!ok) return;
      state.characters.splice(idx,1);
      openCharDetails.clear(); persist(); renderCharacters();
    });
  });
}
function saveCharacterFromDom(idx){
  const c = state.characters[idx]; if(!c) return;
  document.querySelectorAll('[data-char-field][data-char="'+idx+'"]').forEach(el=>{ c[el.getAttribute("data-char-field")] = el.value; });
  if(Object.prototype.hasOwnProperty.call(c,"aliasesText")){
    c.aliases = String(c.aliasesText||"").split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean).slice(0,8);
    delete c.aliasesText;
  }
  applyCultivationUpdate(c, {}, {state});   // cập nhật peakRealm khi người dùng sửa cảnh giới
  /* Lưu thủ công = ý chí của người dùng. Đồng bộ lại hồ sơ gốc cho các trường cốt lõi. */
  if(!c.coreIdentity || typeof c.coreIdentity!=="object") c.coreIdentity={};
  CHARACTER_CORE_LOCK_FIELDS.forEach(k=>{ c.coreIdentity[k] = c[k] ?? ""; });
  c.coreLocked = true;
  document.querySelectorAll('[data-rel-field][data-char="'+idx+'"]').forEach(el=>{
    const ri = parseInt(el.getAttribute("data-rel"),10);
    if(c.relationships[ri]) c.relationships[ri][el.getAttribute("data-rel-field")] = el.value;
  });
  persist(); renderCharacters();
  setStatus("Đã lưu nhân vật.", false);
}

/* ========== SƠ ĐỒ QUAN HỆ NHÂN VẬT (SVG) ========== */
function buildRelationshipGraphSVG(){
  const mcName = (state.mainCharProfile && state.mainCharProfile.name) ? state.mainCharProfile.name : "Nhân vật chính";
  const chars = (state.characters || []).filter(c=>c.name);
  // Node đầu tiên luôn là nhân vật chính, rồi tới các NV theo tier (major trước)
  const tierOrder = {major:0, important:1, supporting:2, minor:3, background:4};
  const sorted = chars.slice().sort((a,b)=>(tierOrder[a.tier]??5)-(tierOrder[b.tier]??5));
  const nodes = [{name: mcName, isMC:true, tier:"major", dead:false}].concat(
    sorted.map(c=>({name:c.name, isMC:false, tier:c.tier||"supporting", dead:!!c.dead}))
  );
  if(nodes.length < 2){
    return '<div class="empty-note">Cần ít nhất 1 nhân vật để vẽ sơ đồ.</div>';
  }
  const W = 520, H = 520, cx = W/2, cy = H/2, R = Math.min(W,H)/2 - 70;
  const pos = {};
  nodes.forEach((n,i)=>{
    if(i===0){ pos[n.name] = {x:cx, y:cy}; return; }
    const ang = (2*Math.PI*(i-1))/Math.max(1,(nodes.length-1)) - Math.PI/2;
    pos[n.name] = { x: cx + R*Math.cos(ang), y: cy + R*Math.sin(ang) };
  });
  const tierColor = {major:"#e2584d", important:"#e0a83f", supporting:"#5b8cf0", minor:"#7a8599", background:"#4a5265"};
  // Cạnh: quan hệ với NVC (relationshipWithMain đã lưu vào c.relationships với withName chứa "nhan vat chinh"),
  // và quan hệ giữa các NV phụ với nhau (c.relationships[].withName khớp tên NV khác đang có trong danh sách).
  const edges = [];
  const nameSet = new Set(nodes.map(n=>n.name));
  const seenPair = new Set();
  chars.forEach(c=>{
    (c.relationships||[]).forEach(r=>{
      if(!r.withName) return;
      let targetName = r.withName;
      if(normalizeName(r.withName).includes("nhan vat chinh")) targetName = mcName;
      if(!nameSet.has(targetName) || targetName === c.name) return;
      const pairKey = [c.name, targetName].sort().join("~~");
      if(seenPair.has(pairKey)) return; // tránh vẽ 2 lần nếu cả 2 phía đều ghi quan hệ
      seenPair.add(pairKey);
      const label = r.stage || r.notes || r.trust || "";
      edges.push({ from: c.name, to: targetName, label: (label||"").slice(0,26) });
    });
  });
  const esc = (s)=>escapeHtml(String(s||""));
  let svg = '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;max-height:70vh;background:#0d0f14;border-radius:10px;">';
  svg += '<defs><marker id="rgArrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#666"/></marker></defs>';
  edges.forEach(e=>{
    const a = pos[e.from], b = pos[e.to];
    if(!a||!b) return;
    const mx = (a.x+b.x)/2, my = (a.y+b.y)/2;
    svg += '<line x1="'+a.x+'" y1="'+a.y+'" x2="'+b.x+'" y2="'+b.y+'" stroke="#555" stroke-width="1.5" marker-end="url(#rgArrow)"/>';
    if(e.label) svg += '<text x="'+mx+'" y="'+my+'" fill="#9aa4b8" font-size="9" text-anchor="middle" style="paint-order:stroke;stroke:#0d0f14;stroke-width:3px;">'+esc(e.label)+'</text>';
  });
  nodes.forEach(n=>{
    const p = pos[n.name];
    const color = n.isMC ? "#c9a24b" : (tierColor[n.tier] || "#5b8cf0");
    const rNode = n.isMC ? 30 : 24;
    svg += '<circle cx="'+p.x+'" cy="'+p.y+'" r="'+rNode+'" fill="'+color+'" opacity="'+(n.dead?0.35:0.92)+'" stroke="#0d0f14" stroke-width="2"/>';
    const label = n.name.length > 10 ? n.name.slice(0,9)+"…" : n.name;
    svg += '<text x="'+p.x+'" y="'+(p.y+rNode+13)+'" fill="#e8ecf4" font-size="11" text-anchor="middle" font-weight="'+(n.isMC?"700":"400")+'">'+esc(label)+(n.dead?" 💀":"")+'</text>';
  });
  svg += '</svg>';
  const legend = '<div class="hint" style="margin-top:8px;">'
    + '<span style="color:#c9a24b;">● NV chính</span> &nbsp; '
    + '<span style="color:#e2584d;">● Major</span> &nbsp; '
    + '<span style="color:#e0a83f;">● Important</span> &nbsp; '
    + '<span style="color:#5b8cf0;">● Supporting</span> &nbsp; '
    + '<span style="color:#7a8599;">● Minor/Background</span>'
    + '</div>'
    + (edges.length ? '' : '<div class="hint" style="margin-top:6px;">⚠ Chưa có quan hệ nào được ghi nhận giữa các nhân vật — hãy bấm "🔄 Rescan" hoặc chạy quét NV sau khi viết thêm chương.</div>');
  return svg + legend;
}
function openRelationshipGraph(){
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  const box = document.createElement("div");
  box.className = "modal-box";
  box.style.maxWidth = "600px";
  box.innerHTML = '<div class="modal-close" id="rgClose">×</div>'
    + '<h3 class="modal-title">🕸️ Sơ đồ quan hệ nhân vật</h3>'
    + '<div class="hint" style="margin-bottom:8px;">Đường nối = có quan hệ được ghi nhận trong hồ sơ. Nhãn là giai đoạn/ghi chú quan hệ mới nhất.</div>'
    + buildRelationshipGraphSVG();
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  box.querySelector("#rgClose").onclick = ()=>overlay.remove();
  overlay.onclick = (e)=>{ if(e.target===overlay) overlay.remove(); };
}
$ID("charGraphBtn").addEventListener("click", openRelationshipGraph);

/* ========== DỌN NHÂN VẬT TRÙNG (v12.18) ========== */
let charMergeUndo = null; /* chỉ giữ trong bộ nhớ: hoàn tác 1 lần gộp gần nhất (mất khi tải lại trang) */
/* V14.7.6 Cast Planner: AI đề xuất nhân vật mới, tự nạp thành bản nháp (locked=false) để tác giả sửa sau. */
async function runCastPlanner(opts){
  opts = (opts && typeof opts === "object" && !opts.target) ? opts : {};
  const btn = $ID("castPlannerBtn"), st = $ID("castPlannerStatus");
  if(btn) btn.disabled = true;
  if(st) st.textContent = opts.auto ? "Dàn nhân vật còn mỏng — đang tự dựng thêm nhân vật…" : "Đang nhờ AI dựng dàn nhân vật…";
  let added = 0;
  try{
    const raw = await callAI(buildCastPlannerPrompt(state, {count:6}), {maxTokens:6000, temperature:0.9});
    const parsed = safeJsonParse(typeof raw === "string" ? raw : String(raw && raw.text || ""));
    const arr = Array.isArray(parsed) ? parsed : (parsed && (parsed.characters || parsed.cast || parsed.nhan_vat)) || [];
    const res = normalizeCastPlannerCards(arr, state);
    res.accepted.forEach(p=>{ const ch = newCharacter(p); ch.locked = false; ch.coreLocked = false; state.characters.push(ch); });
    added = res.accepted.length;
    if(added){ state.storyControl = Object.assign({}, state.storyControl, {castAutoPlanned:true}); }
    persist(); renderCharacters();
    const rej = res.rejected.length ? " Bỏ qua " + res.rejected.length + " (" + res.rejected.map(r=>r.name+": "+r.reason).join("; ") + ")." : "";
    if(st) st.textContent = added ? "Đã thêm " + added + " nhân vật nháp — bấm vào thẻ để sửa." + rej : "Không có nhân vật hợp lệ." + rej;
  }catch(e){
    if(st) st.textContent = "Lỗi: " + String(e && e.message || e).slice(0, 200);
  }finally{ if(btn) btn.disabled = false; }
  return added;
}
/* V14.7.9: tự nạp Cast Planner đúng một lần khi bắt đầu chương ≥ 2 mà dàn nhân vật còn mỏng (< 3 người ngoài NVC). Lỗi thì bỏ qua, không chặn việc viết. */
let _castAutoTried = false;
async function ensureCastPlanned(chapterNumber){
  try{
    if(_castAutoTried || window.__XTA_TEST__) return;
    if(Number(chapterNumber) < 2 || !castIsThin(state)) return;
    if(normalizeStoryControl(state).castAutoPlanned) return;
    _castAutoTried = true;
    setStatus("🎭 Dàn nhân vật còn mỏng — tự dựng thêm nhân vật trước khi viết…", true);
    await runCastPlanner({auto:true});
  }catch(_){}
}
(function(){ const b = $ID("castPlannerBtn"); if(b) b.addEventListener("click", ()=>runCastPlanner()); })();

function updateCharDedupeUI(){
  let n = 0;
  try{ n = findDuplicateCharacterGroups(state).length; }catch(e){}
  const btn = $ID("charDedupeBtn"); if(btn) btn.textContent = "🧹 Dọn nhân vật trùng" + (n ? " (" + n + ")" : "");
  const bn = $ID("charDedupeBanner");
  if(bn){ bn.style.display = n ? "block" : "none"; bn.textContent = n ? "⚠ Có " + n + " mục nghi trùng hoặc là nhãn chung (vd. “nhân vật chính”). Bấm 🧹 Dọn nhân vật trùng để xem và gộp." : ""; }
}
function snapshotForCharUndo(label){
  charMergeUndo = { label, at: Date.now(), characters: JSON.stringify(state.characters||[]), mainCharProfile: JSON.stringify(state.mainCharProfile||null), ignored: JSON.stringify(state.ignoredDupPairs||[]) };
}
function openCharDedupe(){
  const overlay = document.createElement("div"); overlay.className = "modal-overlay";
  const box = document.createElement("div"); box.className = "modal-box"; box.style.maxWidth = "620px";
  overlay.appendChild(box); document.body.appendChild(overlay);
  const close = ()=>{ overlay.remove(); renderCharacters(); };
  overlay.onclick = (e)=>{ if(e.target===overlay) close(); };
  const draw = ()=>{
    const sugg = findDuplicateCharacterGroups(state);
    let h = '<div class="modal-close" id="cdClose">×</div><h3 class="modal-title">🧹 Dọn nhân vật trùng</h3>';
    h += '<div class="hint" style="margin-bottom:8px;">Chỉ là GỢI Ý — không có gì bị đổi nếu bạn không bấm. Gộp sẽ giữ lại mọi thông tin (điền ô trống, nối ý mới, gộp quan hệ). Hồ sơ Nhân Vật Chính chỉ được điền ô còn trống, không bị ghi đè.</div>';
    if(charMergeUndo) h += '<button class="btn btn-ghost btn-sm" id="cdUndo" style="margin-bottom:8px;">↶ Hoàn tác: ' + escapeHtml(charMergeUndo.label) + ' (đến khi tải lại trang)</button>';
    if(!sugg.length) h += '<div class="empty-note">Không thấy mục nào nghi trùng. 👍</div>';
    sugg.forEach(sg=>{
      const tgt = sg.targetId ? (sg.targetId==="MAIN" ? "hồ sơ Nhân Vật Chính — " + sg.targetName : sg.targetName) : "";
      h += '<div class="char-card"><div class="char-card-top"><span class="name">' + escapeHtml(sg.sourceName||"(chưa đặt)") + '</span>'
        + (tgt ? '<span class="tier-badge tier-supporting">→ ' + escapeHtml(tgt) + '</span>' : '') + '</div>'
        + '<div class="hint" style="margin-top:4px;">' + escapeHtml(sg.reason) + ' · độ chắc: ' + (sg.confidence==="high"?"cao":"vừa") + '</div>'
        + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">'
        + (sg.targetId ? '<button class="btn btn-purple btn-sm" data-cd-merge="' + escapeHtml(sg.key) + '">🔗 Gộp vào “' + escapeHtml(sg.targetName) + '”</button>' : '')
        + '<button class="btn btn-ghost btn-sm" data-cd-keep="' + escapeHtml(sg.key) + '">Giữ riêng</button>'
        + (sg.type==="generic_unresolved" ? '<button class="btn btn-ghost btn-sm" data-cd-del="' + escapeHtml(sg.key) + '">🗑 Xóa mục này</button>' : '')
        + '</div></div>';
    });
    box.innerHTML = h;
    box.querySelector("#cdClose").onclick = close;
    const undo = box.querySelector("#cdUndo");
    if(undo) undo.onclick = ()=>{
      state.characters = JSON.parse(charMergeUndo.characters); state.mainCharProfile = JSON.parse(charMergeUndo.mainCharProfile) || state.mainCharProfile;
      state.ignoredDupPairs = JSON.parse(charMergeUndo.ignored); charMergeUndo = null;
      persist(); renderCharacters(); setStatus("↶ Đã hoàn tác lần gộp gần nhất.", false); draw();
    };
    const byKey = (k)=>findDuplicateCharacterGroups(state).find(x=>x.key===k);
    box.querySelectorAll("[data-cd-merge]").forEach(b=>b.onclick = ()=>{
      const sg = byKey(b.getAttribute("data-cd-merge")); if(!sg) return;
      snapshotForCharUndo("gộp “" + sg.sourceName + "” → “" + sg.targetName + "”");
      const r = mergeCharacterIntoState(state, sg.sourceId, sg.targetId);
      if(!r.ok){ charMergeUndo = null; setStatus("Không gộp được: " + r.reason, false); return; }
      persist(); renderCharacters(); setStatus("🔗 Đã gộp “" + r.from + "” vào “" + r.into + "”.", false); draw();
    });
    box.querySelectorAll("[data-cd-keep]").forEach(b=>b.onclick = ()=>{
      if(!Array.isArray(state.ignoredDupPairs)) state.ignoredDupPairs = [];
      state.ignoredDupPairs.push(b.getAttribute("data-cd-keep")); persist(); renderCharacters(); draw();
    });
    box.querySelectorAll("[data-cd-del]").forEach(b=>b.onclick = async ()=>{
      const sg = byKey(b.getAttribute("data-cd-del")); if(!sg) return;
      if(!await showConfirm("Xóa mục “" + sg.sourceName + "”? (Có thể hoàn tác đến khi tải lại trang)")) return;
      snapshotForCharUndo("xóa “" + sg.sourceName + "”");
      state.characters = state.characters.filter(c=>c.id!==sg.sourceId);
      persist(); renderCharacters(); draw();
    });
  };
  draw();
}
$ID("charDedupeBtn").addEventListener("click", openCharDedupe);

/* ========== TỰ ĐỘNG XẾP HẠNG TIER ========== */
function autoAssignTiers(){
  let changed = 0, skippedLocked = 0;
  state.characters.forEach(c=>{
    if(c.locked){ skippedLocked++; return; } // tôn trọng NV đã khóa tier thủ công
    const histCount = Array.isArray(c.history) ? c.history.length : 0;
    const spanCount = (c.firstAppearance!=null && c.lastAppearance!=null) ? (c.lastAppearance - c.firstAppearance + 1) : 0;
    const appearances = Math.max(histCount, spanCount);
    let score = appearances * 2;
    score += (Array.isArray(c.relationships) ? c.relationships.length : 0) * 1.5;
    if(c.goals) score += 1;
    if(c.secret) score += 1;
    if(c.weakness || c.fear) score += 0.5;
    if(c.attractionToMC || c.tensionWithMC) score += 1.5;
    if(c.dead) score *= 0.6; // vẫn giữ trọng số cũ nhưng giảm bớt vì không còn hoạt động
    let newTier;
    if(score >= 12) newTier = "major";
    else if(score >= 7) newTier = "important";
    else if(score >= 3) newTier = "supporting";
    else if(score >= 1) newTier = "minor";
    else newTier = "background";
    if(c.tier !== newTier){ c.tier = newTier; changed++; }
  });
  persist(); renderCharacters();
  setStatus("⚙️ Đã tự động xếp hạng TIER: " + changed + " NV đổi tier — hồ sơ gốc không bị thay đổi" + (skippedLocked ? " (bỏ qua " + skippedLocked + " NV đã khóa 🔒)" : "") + ".", false);
}
$ID("autoTierBtn").addEventListener("click", ()=>{
  if(!state.characters.length){ setStatus("Chưa có nhân vật nào.", false); return; }
  autoAssignTiers();
});

$ID("saveFemaleDefinitionBtn")?.addEventListener("click", ()=>{
  state.femaleCharacterDefinition = String($ID("femaleCharacterDefinitionInput").value||"").trim();
  persist();
  setStatus("Đã lưu định nghĩa chung nhân vật nữ.", false);
});

$ID("npcAddBtn").addEventListener("click", ()=>{
  const name = $ID("npcNameInput").value.trim();
  if(!name){ setStatus("Nhập tên.", false); return; }
  if(findCharacterByName(name)){ setStatus("Đã tồn tại.", false); return; }
  state.characters.push(newCharacter({
    name, tier: $ID("npcTierInput").value,
    appearance: $ID("npcDescInput").value.trim(),
    personality: $ID("npcPersonalityInput").value.trim(),
    age: $ID("npcAgeInput").value.trim(),
    position: $ID("npcPositionInput").value.trim(),
    firstAppearance: state.chapters.length, lastAppearance: state.chapters.length
  }));
  persist(); renderCharacters();
  ["npcNameInput","npcDescInput","npcPersonalityInput","npcAgeInput","npcPositionInput"].forEach(id=> $ID(id).value="");
  setStatus("Đã thêm: " + name, false);
});

/* ========== LOCATIONS ========== */
function renderLocations(){
  if(!state.locations.length){ locationList.innerHTML = '<div class="empty-note">Chưa có.</div>'; return; }
  locationList.innerHTML = state.locations.map((l,i)=>
    '<div class="loc-item"><b>'+escapeHtml(l.name)+'</b> <span style="font-size:10px;color:var(--ink-dim);">'+l.status+'</span>'
    + (l.description ? '<div style="margin-top:3px;">'+escapeHtml(l.description)+'</div>' : '')
    + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-loc-del="'+i+'">Xóa</button></div></div>'
  ).join("");
  locationList.querySelectorAll("[data-loc-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{ state.locations.splice(parseInt(btn.getAttribute("data-loc-del"),10),1); persist(); renderLocations(); });
  });
}
$ID("locAddBtn").addEventListener("click", ()=>{
  const name = $ID("locNameInput").value.trim();
  if(!name){ setStatus("Nhập tên.", false); return; }
  if(findLocationByName(name)){ setStatus("Đã tồn tại.", false); return; }
  state.locations.push(newLocation({
    name, description: $ID("locDescInput").value.trim(),
    status: $ID("locStatusInput").value,
    firstAppearance: state.chapters.length, lastAppearance: state.chapters.length
  }));
  persist(); renderLocations();
  ["locNameInput","locDescInput"].forEach(id=> $ID(id).value="");
});

/* ========== ITEMS ========== */
function renderItems(){
  if(!state.items.length){ itemList.innerHTML = '<div class="empty-note">Chưa có.</div>'; return; }
  itemList.innerHTML = state.items.map((it,i)=>
    '<div class="item-item"><b>'+escapeHtml(it.name)+'</b> <span style="font-size:10px;color:var(--ink-dim);">'+it.status+'</span>'
    + ((it.kind||it.grade) ? ' <span class="hint" style="color:var(--amber);">['+escapeHtml([it.kind,it.grade].filter(Boolean).join(" · "))+']</span>' : '')
    + (it.bound ? ' <span class="hint" title="Đã nhận chủ / bản mệnh">🔗</span>' : '')
    + (it.owner ? ' <span class="hint">→ '+escapeHtml(it.owner)+'</span>' : '')
    + (it.effect ? '<div class="hint" style="margin-top:2px;">⚙ '+escapeHtml(it.effect)+'</div>' : '')
    + (it.description ? '<div style="margin-top:3px;">'+escapeHtml(it.description)+'</div>' : '')
    + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-item-del="'+i+'">Xóa</button></div></div>'
  ).join("");
  itemList.querySelectorAll("[data-item-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{ state.items.splice(parseInt(btn.getAttribute("data-item-del"),10),1); persist(); renderItems(); });
  });
}
$ID("itemAddBtn").addEventListener("click", ()=>{
  const name = $ID("itemNameInput").value.trim();
  if(!name){ setStatus("Nhập tên.", false); return; }
  state.items.push(newItem({
    name, description: $ID("itemDescInput").value.trim(),
    owner: $ID("itemOwnerInput").value.trim(),
    status: $ID("itemStatusInput").value,
    kind: $ID("itemKindInput").value, grade: $ID("itemGradeInput").value.trim(), effect: $ID("itemEffectInput").value.trim(),
    bound: $ID("itemBoundInput").checked,
    firstAppearance: state.chapters.length, lastAppearance: state.chapters.length
  }));
  persist(); renderItems();
  ["itemNameInput","itemDescInput","itemOwnerInput","itemKindInput","itemGradeInput","itemEffectInput"].forEach(id=> $ID(id).value="");
  $ID("itemBoundInput").checked = false;
});

/* ========== ORGANIZATION / FACTION PROFILES ========== */
function renderOrganizations(){
  const list = $ID("organizationList"); if(!list) return;
  if(!Array.isArray(state.organizations) || !state.organizations.length){ list.innerHTML = '<div class="empty-note">Chưa có hồ sơ thế lực.</div>'; return; }
  list.innerHTML = state.organizations.map((org,i)=>
    '<details class="item-item" style="margin:5px 0;"><summary><b>'+escapeHtml(org.name||"Chưa đặt tên")+'</b> <span class="hint">'+escapeHtml(org.status||"active")+'</span></summary>'+
    '<div class="field" style="margin-top:6px;"><div class="row2"><input data-org-edit="'+i+'" data-field="name" value="'+escapeHtml(org.name||"")+'" placeholder="Tên"/><input data-org-edit="'+i+'" data-field="type" value="'+escapeHtml(org.type||"")+'" placeholder="Loại"/></div>'+
    '<div class="row2" style="margin-top:5px;"><input data-org-edit="'+i+'" data-field="leader" value="'+escapeHtml(org.leader||"")+'" placeholder="Thủ lĩnh"/><input data-org-edit="'+i+'" data-field="territory" value="'+escapeHtml(org.territory||"")+'" placeholder="Lãnh địa"/></div>'+
    '<select data-org-edit="'+i+'" data-field="status" style="margin-top:5px;"><option value="active"'+(org.status==="active"?" selected":"")+'>Đang hoạt động</option><option value="allied"'+(org.status==="allied"?" selected":"")+'>Đồng minh</option><option value="hostile"'+(org.status==="hostile"?" selected":"")+'>Đối địch</option><option value="hidden"'+(org.status==="hidden"?" selected":"")+'>Ẩn danh</option><option value="dissolved"'+(org.status==="dissolved"?" selected":"")+'>Tan rã</option></select>'+
    '<textarea data-org-edit="'+i+'" data-field="description" rows="3" placeholder="Mô tả / mục tiêu">'+escapeHtml(org.description||"")+'</textarea><textarea data-org-edit="'+i+'" data-field="historyText" rows="2" placeholder="Lịch sử và thay đổi">'+escapeHtml(org.historyText||"")+'</textarea>'+
    '<div class="hint">Xuất hiện lần đầu: ch'+(Number(org.firstAppearance)||0)+' · cập nhật gần nhất: ch'+(Number(org.lastAppearance)||0)+'</div><div class="char-actions"><button class="btn btn-blue btn-sm" data-org-save="'+i+'">Lưu sửa</button><button class="btn btn-outline-red btn-sm" data-org-del="'+i+'">Xóa</button></div></div></details>'
  ).join("");
  list.querySelectorAll("[data-org-save]").forEach(btn=>btn.addEventListener("click",()=>{
    const i = Number(btn.getAttribute("data-org-save")), org = state.organizations[i]; if(!org) return;
    const box = btn.closest("details"), next = {};
    box.querySelectorAll("[data-org-edit]").forEach(el=>{ next[el.getAttribute("data-field")] = el.value.trim(); });
    if(!next.name){ setStatus("Tên thế lực không được để trống.", false); return; }
    const changed = ["name","type","leader","territory","status","description","historyText"].some(k=>String(org[k]||"")!==String(next[k]||""));
    if(!changed) return;
    const history = Array.isArray(org.history) ? org.history : [];
    history.push({ chapter: state.chapters.length, at: Date.now(), note: "Cập nhật hồ sơ: " + [org.name,next.name].filter(Boolean).join(" → ") });
    state.organizations[i] = Object.assign({}, org, next, { history, lastAppearance: state.chapters.length, updatedAt: Date.now() });
    persist(); renderOrganizations();
  }));
  list.querySelectorAll("[data-org-del]").forEach(btn=>btn.addEventListener("click",()=>{ state.organizations.splice(Number(btn.getAttribute("data-org-del")),1); persist(); renderOrganizations(); }));
}
$ID("organizationAddBtn").addEventListener("click",()=>{
  const name=$ID("organizationNameInput").value.trim(); if(!name){ setStatus("Nhập tên thế lực.",false); return; }
  if(state.organizations.some(x=>normalizeName(x.name)===normalizeName(name))){ setStatus("Thế lực này đã có hồ sơ.",false); return; }
  const nowChapter=state.chapters.length;
  state.organizations.push({id:genId(),name,type:$ID("organizationTypeInput").value.trim(),leader:$ID("organizationLeaderInput").value.trim(),territory:$ID("organizationTerritoryInput").value.trim(),status:$ID("organizationStatusInput").value,description:$ID("organizationDescInput").value.trim(),historyText:$ID("organizationHistoryInput").value.trim(),firstAppearance:nowChapter,lastAppearance:nowChapter,history:[{chapter:nowChapter,at:Date.now(),note:"Hồ sơ được tạo"}],updatedAt:Date.now()});
  persist(); renderOrganizations(); ["organizationNameInput","organizationTypeInput","organizationLeaderInput","organizationTerritoryInput","organizationDescInput","organizationHistoryInput"].forEach(id=>$ID(id).value="");
});

/* ========== THREADS ========== */
function renderThreads(){
  if(!state.threads.length){ threadList.innerHTML = '<div class="empty-note">Chưa có.</div>'; return; }
  threadList.innerHTML = state.threads.map((t,i)=>
    '<div class="thread-item"><span class="thread-type">'+escapeHtml(t.type||"open_thread")+'</span><span class="thread-status">'+escapeHtml(t.status||"seeded")+'</span>'
    + '<textarea data-thread-desc="'+i+'" rows="2" style="margin-top:5px;">'+escapeHtml(t.desc||"")+'</textarea>'
    + (t.expectedPayoff?'<div class="hint">Dự kiến: '+escapeHtml(t.expectedPayoff)+'</div>':'')
    + '<div class="row2"><span class="hint">Gieo ch'+(Number(t.chapterIntroduced)||0)+' · cập nhật ch'+(Number(t.lastUpdatedChapter)||Number(t.chapterIntroduced)||0)+'</span><select data-thread-status="'+i+'"><option value="seeded"'+(t.status==="seeded"?" selected":"")+'>Seeded</option><option value="developing"'+(t.status==="developing"?" selected":"")+'>Developing</option><option value="blocked"'+(t.status==="blocked"?" selected":"")+'>Blocked</option><option value="resolved"'+(t.status==="resolved"?" selected":"")+'>Resolved</option><option value="paid_off"'+(t.status==="paid_off"?" selected":"")+'>Paid off</option><option value="abandoned"'+(t.status==="abandoned"?" selected":"")+'>Abandoned</option></select></div>'
    + '<div class="char-actions"><button class="btn btn-outline-red btn-sm" data-thread-del="'+i+'">Xóa</button></div></div>'
  ).join("");
  threadList.querySelectorAll("[data-thread-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{ state.threads.splice(parseInt(btn.getAttribute("data-thread-del"),10),1); persist(); renderThreads(); });
  });
  threadList.querySelectorAll("[data-thread-status]").forEach(sel=>sel.addEventListener("change",()=>{
    const t=state.threads[Number(sel.getAttribute("data-thread-status"))]; if(!t) return;
    const old=t.status||"seeded", next=sel.value; if(old===next) return;
    const at=Date.now(); t.statusHistory=Array.isArray(t.statusHistory)?t.statusHistory:[]; t.statusHistory.push({from:old,to:next,chapter:state.chapters.length,storyTime:state.storyClock||"",source:"author",at});
    t.status=next; t.lastManualUpdatedAt=at; t.lastUpdatedChapter=state.chapters.length; t.lastUpdatedTime=state.storyClock||""; persist(); renderThreads();
  }));
  threadList.querySelectorAll("[data-thread-desc]").forEach(el=>el.addEventListener("change",()=>{
    const t=state.threads[Number(el.getAttribute("data-thread-desc"))]; if(!t) return;
    const next=el.value.trim(); if(!next) return; if(next!==t.desc){ t.desc=next; t.lastManualUpdatedAt=Date.now(); t.lastUpdatedChapter=state.chapters.length; t.lastUpdatedTime=state.storyClock||""; persist(); renderThreads(); }
  }));
}
$ID("threadAddBtn").addEventListener("click", ()=>{
  const desc = $ID("threadDescInput").value.trim();
  if(!desc){ setStatus("Nhập mô tả.", false); return; }
  const status=$ID("threadStatusInput").value, chapter=state.chapters.length+1;
  const createdAt=Date.now(); state.threads.push({ id: genId(), type: $ID("threadTypeInput").value, status, desc, expectedPayoff:$ID("threadExpectedInput").value.trim(), chapterIntroduced:chapter, lastUpdatedChapter:chapter, lastUpdatedTime:state.storyClock||"", lastManualUpdatedAt:createdAt, statusHistory:[{from:"",to:status,chapter,storyTime:state.storyClock||"",source:"author",at:createdAt}] });
  persist(); renderThreads(); $ID("threadDescInput").value = ""; $ID("threadExpectedInput").value = "";
});

/* ========== CHAPTER STATE SNAPSHOT (lịch sử theo chương) ========== */
/* Sau khi bất kỳ mục nào (NV, địa điểm, vật phẩm, threads, status...) được AI
   cập nhật cho một chương, ta chụp lại toàn bộ trạng thái liên quan tại thời
   điểm đó và lưu vào chapter.stateSnapshot. Vì 4 hàm update có thể chạy song
   song/không theo thứ tự cố định, hàm này luôn chụp *toàn bộ* state hiện tại
   (không chỉ phần vừa đổi) — nên bất kể hàm nào chạy xong sau cùng, snapshot
   cuối cùng vẫn đầy đủ và chính xác. */
/* Khi xóa/gộp/chèn chương, các số chương (firstAppearance, lastAppearance,
   deathChapter, history[].chapter...) sống trong LIVE state đã được code cũ
   tự đánh số lại. Nhưng dữ liệu "đông cứng" bên trong stateSnapshot của các
   chương khác cũng chứa các số chương y hệt, nên cũng phải đánh lại — nếu
   không, sau khi xóa/gộp/chèn chương, khung "Lịch Sử Theo Chương" sẽ hiện
   sai (NV xuất hiện/biến mất nhầm chương). mapFn(n) trả về số chương mới,
   hoặc null để loại bỏ mốc đó. */
function remapSnapshotChapterNumbers(mapFn){
  state.chapters.forEach(ch=>{
    const snap = ch.stateSnapshot;
    if(!snap) return;
    const remapFields = (arr, fields)=>{
      (arr||[]).forEach(o=>{
        fields.forEach(f=>{ if(o[f] != null) o[f] = mapFn(o[f]); });
      });
    };
    remapFields(snap.characters, ["firstAppearance","lastAppearance","deathChapter"]);
    (snap.characters||[]).forEach(c=>{
      if(Array.isArray(c.history)){
        c.history = c.history
          .map(h=> Object.assign({}, h, { chapter: mapFn(h.chapter) }))
          .filter(h=> h.chapter != null);
      }
    });
    remapFields(snap.locations, ["firstAppearance","lastAppearance"]);
    remapFields(snap.items, ["firstAppearance","lastAppearance"]);
  });
}
/* Đánh dấu / gỡ cờ "mục X chưa cập nhật được" cho 1 chương, để người dùng
   THẤY được thay vì bị âm thầm bỏ qua như trước. */
function markAutoUpdateIssue(chapterNumber, label, failed, skipRender){
  const ch = state.chapters[chapterNumber - 1];
  if(!ch) return;
  const issues = new Set(ch.autoUpdateIssues || []);
  if(failed) issues.add(label); else issues.delete(label);
  ch.autoUpdateIssues = Array.from(issues);
  if(skipRender) return; /* gọi hàng loạt (rescan nhiều chương) — người gọi tự persist()+renderChapterNav() 1 lần ở cuối, tránh render lại toàn bộ thanh chương sau MỖI chương */
  persist();
  renderChapterNav();
}
function captureChapterSnapshot(chapterNumber){
  try{
    const idx = chapterNumber - 1;
    const ch = state.chapters[idx];
    if(!ch) return;
    const snapshot = {
      capturedAt: Date.now(),
      currentStatus: state.currentStatus || "",
      statusState: JSON.parse(JSON.stringify(state.statusState || {})),
      storyClock: state.storyClock || "",
      mainCharProfile: state.mainCharProfile ? JSON.parse(JSON.stringify(state.mainCharProfile)) : null,
      mainCharCoreIdentity: JSON.parse(JSON.stringify(state.mainCharCoreIdentity || {})),
      femaleCharacterDefinition: state.femaleCharacterDefinition || "",
      characters: JSON.parse(JSON.stringify(state.characters || [])),
      locations: JSON.parse(JSON.stringify(state.locations || [])),
      items: JSON.parse(JSON.stringify(state.items || [])),
      threads: JSON.parse(JSON.stringify(state.threads || [])),
      timeline: JSON.parse(JSON.stringify(state.timeline || [])),
      foreshadowing: JSON.parse(JSON.stringify(state.foreshadowing || [])),
      knowledgeLedger: JSON.parse(JSON.stringify(state.knowledgeLedger || [])),
      memoryEvents: JSON.parse(JSON.stringify(state.memoryEvents || [])),
      characterStateTracker: JSON.parse(JSON.stringify(state.characterStateTracker || {})),
      lastStatusChapter: Number(state.lastStatusChapter || 0),
      lastMemorySyncChapter: Number(state.lastMemorySyncChapter || 0)
    };
    if(!Array.isArray(ch.stateSnapshots)) ch.stateSnapshots=[];
    ch.stateSnapshots.unshift(snapshot);
    const cap=Math.min(10,Math.max(5,Number(state.snapshotLimit)||7));
    ch.stateSnapshots=ch.stateSnapshots.slice(0,cap);
    ch.stateSnapshot=ch.stateSnapshots[0]||snapshot;
    persist();
    renderSnapshotChapterSelect();
    const sel = $ID("snapshotChapterSelect");
    if(sel && sel.value === String(idx)) renderSnapshotView(idx);
  }catch(e){}
}
function renderSnapshotChapterSelect(){
  const sel = $ID("snapshotChapterSelect");
  if(!sel) return;
  const prevVal = sel.value;
  if(!state.chapters.length){ sel.innerHTML = '<option value="">-- Chưa có chương --</option>'; return; }
  sel.innerHTML = '<option value="">-- Chọn chương để xem lịch sử --</option>' + state.chapters.map((c,i)=>
    '<option value="'+i+'">Chương '+(i+1)+': '+escapeHtml((c.title||"").slice(0,40))+(c.stateSnapshot ? '' : ' (chưa có snapshot)')+'</option>'
  ).join("");
  if(prevVal && state.chapters[parseInt(prevVal,10)]) sel.value = prevVal;
}
function renderSnapshotView(idx){
  const box = $ID("snapshotBox");
  if(!box) return;
  const ch = state.chapters[idx];
  if(!ch){ box.innerHTML = '<div class="empty-note">Chọn một chương ở trên để xem trạng thái tại thời điểm đó.</div>'; return; }
  const snap = ch.stateSnapshot;
  const issueBanner = (ch.autoUpdateIssues && ch.autoUpdateIssues.length)
    ? '<div class="snap-stale-badge">⚠ Chương này còn mục cập nhật lỗi: '+escapeHtml(ch.autoUpdateIssues.join(", "))+'. Bấm "🔄 Rescan từ chương này" (mục 6) để chạy lại.</div>'
    : '';
  const diagBanner = (ch.updateDiagnostics && ch.updateDiagnostics.length)
    ? '<details class="snap-stale-badge" style="background:transparent;border:1px dashed #666"><summary>🔍 Chi tiết cập nhật nền (chẩn đoán)</summary><div style="white-space:pre-wrap;font-size:12px;margin-top:6px">'+escapeHtml(ch.updateDiagnostics.join("\n"))+'</div></details>'
    : '';
  if(!snap){
    box.innerHTML = issueBanner + diagBanner + '<div class="snap-stale-badge">⚠ Chương này chưa có snapshot lịch sử (được viết trước khi có tính năng này, hoặc chưa chạy xong cập nhật nền). Dùng nút "🔄 Rescan từ chương này" hoặc "Quét toàn truyện" ở các mục NV/Địa điểm/Status để tạo lại lịch sử cho các chương cũ.</div>';
    return;
  }
  const chars = (snap.characters||[]).filter(c=> (c.lastAppearance||0) <= (idx+1) && (c.firstAppearance==null || c.firstAppearance <= (idx+1)));
  const charsHtml = chars.length ? chars.map(c=>
    '<div class="snap-card"><b>'+escapeHtml(c.name||"?")+'</b> '
    + '<span class="tier-badge tier-'+c.tier+'">'+c.tier+'</span> '
    + (c.dead ? '<span class="dead-badge">💀</span>' : '')
    + (c.currentLocation ? '<div class="snap-meta">📍 '+escapeHtml(c.currentLocation)+'</div>' : '')
    + (c.mentalState ? '<div class="snap-meta">🧠 '+escapeHtml(c.mentalState)+'</div>' : '')
    + (c.physicalState ? '<div class="snap-meta">💪 '+escapeHtml(c.physicalState)+'</div>' : '')
    + '</div>'
  ).join("") : '<div class="empty-note">Chưa có NV nào tại thời điểm này.</div>';
  const locsHtml = (snap.locations||[]).length ? snap.locations.map(l=>
    '<div class="snap-card"><b>'+escapeHtml(l.name)+'</b> <span class="snap-meta">'+escapeHtml(l.status||"")+'</span>'
    + (l.description ? '<div class="snap-meta">'+escapeHtml(l.description)+'</div>' : '') + '</div>'
  ).join("") : '<div class="empty-note">Chưa có.</div>';
  const itemsHtml = (snap.items||[]).length ? snap.items.map(it=>
    '<div class="snap-card"><b>'+escapeHtml(it.name)+'</b> <span class="snap-meta">'+escapeHtml(it.status||"")+(it.owner?(' · '+escapeHtml(it.owner)):'')+'</span></div>'
  ).join("") : '<div class="empty-note">Chưa có.</div>';
  box.innerHTML = issueBanner + diagBanner +
    '<div class="snap-group-title">🕐 Thời điểm</div><div class="snap-card">'+escapeHtml(snap.storyClock || "(chưa đặt)")+'</div>'
    + '<div class="snap-group-title">📋 Current Status</div><div class="status-box" style="max-height:160px;">'+escapeHtml(snap.currentStatus || "(chưa có)")+'</div>'
    + '<div class="snap-group-title">👤 Nhân vật</div>' + charsHtml
    + '<div class="snap-group-title">📍 Địa điểm</div>' + locsHtml
    + '<div class="snap-group-title">🎒 Vật phẩm</div>' + itemsHtml;
}
(function(){
  const sel = $ID("snapshotChapterSelect");
  if(sel) sel.addEventListener("change", ()=>{
    const v = sel.value;
    if(v === "") { renderSnapshotView(-1); return; }
    renderSnapshotView(parseInt(v,10));
  });
})();

/* ========== CHARACTER UPDATE ========== */

function extractCharacterCardsV102(text){
  const hay=normalizeName(text||"");
  const chars=state.characters||[];
  const scored=chars.map(c=>{
    const name=normalizeName(c.name);
    if(!name) return {c,score:-999};
    let score=0;
    if(hay.includes(name)) score+=20;
    if(c.tier==="major")score+=7; else if(c.tier==="important")score+=5; else if(c.tier==="supporting")score+=2;
    if(c.lastAppearance!=null && state.chapters.length-c.lastAppearance<=2)score+=5;
    return {c,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,Math.min(5,Number(state.tokenCapPerPrompt)||5));
  const cards=scored.map(({c})=>({
    id:c.id,name:c.name,keys:[c.name,c.alias,c.role,c.faction,c.currentLocation].filter(Boolean).join(", "),
    state:{location:c.currentLocation||"",physical:c.physicalState||"",mental:c.mentalState||"",dead:!!c.dead},
    profile:{appearance:c.appearance||"",personality:c.personality||"",goals:c.goals||""},
    updatedAt:Date.now()
  }));
  state.characterCards=cards;
  return cards;
}
function characterCardsForPromptV102(text){
  const cards=extractCharacterCardsV102(text);
  return cards.map(c=>"- "+c.name+" | vị trí:"+ (c.state.location||"?") +" | thể trạng:"+ (c.state.physical||"?")
    +" | tâm lý:"+ (c.state.mental||"?") +" | "+String(c.profile.appearance||"").slice(0,180)).join("\n");
}
function relevantCharacters(limit){
  limit = limit || 8;
  const chapters = Array.isArray(state.chapters) ? state.chapters : [];
  const recentText = normalizeName(chapters.slice(-2).map(c=> (c.text||"") + " " + (c.summary||"")).join(" "));
  const mainName = normalizeName(state.mainCharProfile && state.mainCharProfile.name || "");
  const scored = (state.characters || []).filter(c=>{
    if(!c || !c.name || c.dead || c.isDead) return false;
    if(mainName && normalizeName(c.name) === mainName) return false;
    const gap = c.lastAppearance == null ? 999 : chapters.length - Number(c.lastAppearance);
    if(c.tier === 'minor' && gap > 2 && !recentText.includes(normalizeName(c.name))) return false;
    if(c.tier === 'supporting' && gap > 8 && !recentText.includes(normalizeName(c.name)) && !c.locked) return false;
    return true;
  }).map(c=>{
    let score = 0;
    if(c.locked) score += 8;
    if(c.tier === 'major') score += 7;
    if(c.tier === 'important') score += 5;
    if(c.tier === 'supporting') score += 2;
    if(c.tier === 'minor') score += 0.5;
    const nName = normalizeName(c.name);
    if(nName && recentText.includes(nName)) score += 12;
    const gap = c.lastAppearance == null ? 999 : chapters.length - Number(c.lastAppearance);
    if(gap <= 1) score += 6;
    else if(gap <= 3) score += 3;
    else if(gap <= 8) score += Math.max(0, 2 - gap*0.15);
    if(c.attractionToMC || c.tensionWithMC) score += 1.5;
    return { c, score };
  });
  scored.sort((a,b)=> b.score - a.score);
  return scored.slice(0, limit).map(s=>s.c);
}
function characterSummaryForPrompt(list){
  const cut = (s, n) => {
    s = String(s || "").trim();
    if(!s) return "";
    return s.length > n ? s.slice(0, n) + "…" : s;
  };
  return list.map(c=>{
    const parts = [c.name || "?"];
    if(c.dead) parts.push("[ĐÃ CHẾT]");
    if(c.tier) parts.push("["+c.tier+"]");
    if(c.role) parts.push("vai trò:"+cut(c.role, 50));
    if(c.relevanceToMC) parts.push("liên quan NVC:"+cut(c.relevanceToMC, 60));
    if(c.age) parts.push("tuổi:"+c.age);
    if(c.gender) parts.push(c.gender);
    if(c.maritalStatus) parts.push("hôn nhân:"+cut(c.maritalStatus, 30));
    if(c.spouseName) parts.push("người phối ngẫu/người yêu:"+cut(c.spouseName, 50));
    if(c.maritalNotes) parts.push("ghi chú hôn nhân:"+cut(c.maritalNotes, 80));
    if(c.occupation) parts.push("nghề:"+cut(c.occupation, 40));
    if(c.faction) parts.push("phe:"+cut(c.faction, 40));
    if(c.position) parts.push("chức vị:"+cut(c.position, 40));
    if(c.realm) parts.push("CẢNH GIỚI:"+cut(c.realm, 40));
    if(c.technique) parts.push("công pháp:"+cut(c.technique, 50));
    if(c.arts) parts.push("thần thông:"+cut(c.arts, 60));
    if(c.treasure) parts.push("pháp bảo:"+cut(c.treasure, 50));
    if(c.combatPower) parts.push("sức chiến đấu:"+cut(c.combatPower, 40));
    if(c.masterLine) parts.push("sư môn:"+cut(c.masterLine, 50));
    if(c.apparentAge) parts.push("tuổi ngoại hình:"+cut(c.apparentAge, 20));
    if(c.lifespan) parts.push("thọ nguyên:"+cut(c.lifespan, 30));
    if(Array.isArray(c.aliases) && c.aliases.length) parts.push("tên khác:"+cut(c.aliases.join(", "), 50));
    /* Ngoại hình / số đo — ƯU TIÊN (để cảnh 18+ bám hồ sơ) */
    if(c.height) parts.push("cao:"+cut(c.height, 30));
    if(c.bodyType) parts.push("dáng:"+cut(c.bodyType, 40));
    if(c.measurements) parts.push("SỐ ĐO:"+cut(c.measurements, 60));
    if(c.appearance) parts.push("ngoại hình:"+cut(c.appearance, 160));
    if(c.hair) parts.push("tóc:"+cut(c.hair, 40));
    if(c.eyes) parts.push("mắt:"+cut(c.eyes, 40));
    if(c.skin) parts.push("da:"+cut(c.skin, 40));
    if(c.scars) parts.push("sẹo:"+cut(c.scars, 40));
    if(c.tattoos) parts.push("xăm:"+cut(c.tattoos, 40));
    if(c.sexualExperience) parts.push("18+:"+cut(c.sexualExperience, 100));
    if(c.preferences) parts.push("kink:"+cut(c.preferences, 80));
    if(c.boundaries) parts.push("ranh:"+cut(c.boundaries, 60));
    if(c.personality) parts.push("tính:"+cut(c.personality, 70));
    if(c.goals) parts.push("mục tiêu:"+cut(c.goals, 60));
    if(c.secret) parts.push("bí mật:"+cut(c.secret, 60));
    if(c.weakness) parts.push("điểm yếu:"+cut(c.weakness, 40));
    if(c.fear) parts.push("sợ:"+cut(c.fear, 40));
    if(c.knowledge) parts.push("biết:"+cut(c.knowledge, 60));
    if(c.currentLocation) parts.push("ở:"+cut(c.currentLocation, 40));
    if(c.mentalState) parts.push("tâm:"+cut(c.mentalState, 50));
    if(c.physicalState) parts.push("thể:"+cut(c.physicalState, 50));
    if(c.attractionToMC) parts.push("cảmMC:"+cut(c.attractionToMC, 40));
    if(c.tensionWithMC) parts.push("căngMC:"+cut(c.tensionWithMC, 40));
    if(Array.isArray(c.relationships) && c.relationships.length){
      const relTxt = c.relationships.filter(r=>r.withName).slice(0,4).map(r=>
        r.withName + (r.stage ? "("+cut(r.stage,20)+")" : "") + (r.notes ? ":"+cut(r.notes,40) : "")
      ).join("; ");
      if(relTxt) parts.push("quan hệ:"+relTxt);
    }
    if(c.notes) parts.push("note:"+cut(c.notes, 50));
    if(c.lastAppearance != null) parts.push("ch"+c.lastAppearance);
    return "- " + parts.join(" | ");
  }).join("\n");
}

function mergeCharacterUpdate(update, chapterNumber, sourceText){
  if(!update) return;
  const cleanName = String(update.name || "").trim();
  if(!cleanName) return;
  update = Object.assign({}, update, { name: cleanName });
  /* v12.18: tên trùng hồ sơ Nhân Vật Chính / nhãn chung "nhân vật chính" / bí danh → cập nhật hồ sơ có sẵn, KHÔNG tạo mục mới */
  const rt = resolveCharacterTarget(state, cleanName);
  if(rt.kind === "main"){
    applyMainCharUpdate(state.mainCharProfile, update, sourceText, state);
    return { name: (state.mainCharProfile&&state.mainCharProfile.name)||cleanName, isNewChar: false };
  }
  let c = rt.kind === "character" ? rt.character : null;
  const isNewChar = !c;
  if(!c){
    c = newCharacter({ name: cleanName, tier: TIERS.includes(update.tier) ? update.tier : "minor", firstAppearance: chapterNumber });
    state.characters.push(c);
  }
  /* Identity Lock: hồ sơ gốc không bị AI rescan ghi đè.
     "locked" cũ vẫn dùng cho tier, còn coreLocked là khóa nhận diện riêng.
     Chỉ một lệnh thay đổi hồ sơ có cờ explicitCoreChange + evidence mới được mở khóa. */
  const lockedFields = c.coreLocked !== false ? CHARACTER_CORE_LOCK_FIELDS : [];
  /* V12.19: bằng chứng phải trích được từ chính chương (khi biết văn bản nguồn) — AI không tự khẳng định "đã thăng chức". */
  const explicitCoreChange = update.explicitCoreChange === true && String(update.changeEvidence||"").trim().length >= 12
    && (sourceText == null || evidenceInText(update.changeEvidence, sourceText));
  const JOB_FIELDS = ["role","position","occupation","faction"];
  Object.keys(update).forEach(key=>{
    if(["name","isNew","relationshipWithMain","relationships","chapterEvent","isDead","explicitCoreChange","changeEvidence","_ghi_chu_18","aliases"].includes(key) || CULT_FIELDS.includes(key)) return;
    const wasEmpty = !String(c[key]||"").trim();
    /* V12.19: khóa hồ sơ gốc chỉ chặn GHI ĐÈ giá trị đã có; trường còn trống (giới tính, tuổi, nghề...) vẫn được điền. */
    if(lockedFields.includes(key) && !explicitCoreChange && !wasEmpty) return;
    if(update[key] === "" || update[key] == null) return;
    /* Đặc điểm thân thể ổn định: chỉ điền khi trống, không để mỗi chương đổi một kiểu. */
    if(["age","gender","height","bodyType","measurements","hair","eyes","skin","voice","scent","style","scars","tattoos"].includes(key) && !wasEmpty && !explicitCoreChange) return;
    /* Trường 18+ chỉ ghi cho NV đủ 18 tuổi (khớp rào chắn tuổi của app). */
    if(["sexualExperience","boundaries","taboos","preferences","attractionToMC","tensionWithMC","consentNotes"].includes(key)){ const ag=profileAgeNum(c,update); if(ag!==null && ag<18) return; }
    /* V12.19: nghề/chức vụ đã có thì chỉ đổi khi có sự kiện + bằng chứng trích từ chương (kể cả NV đã mở khóa). */
    if(JOB_FIELDS.includes(key) && String(c[key]||"").trim() && normalizeName(c[key]) !== normalizeName(update[key]) && !explicitCoreChange) return;
    const value=String(update[key]);
    const accumulative=["appearance","personality","goals","secret","weakness","fear","knowledge","independentPlot","strength","speech","sexualExperience","boundaries","taboos","preferences","attractionToMC","tensionWithMC","consentNotes"];
    if(accumulative.includes(key)){
      const old=String(c[key]||"").trim();
      if(!old)c[key]=value;
      else if(normalizeName(old)!==normalizeName(value) && !normalizeName(old).includes(normalizeName(value))){
        /* V12.10: bỏ đoạn trùng ý; khi đầy (2500) thì bỏ đoạn CŨ NHẤT thay vì cắt mất thông tin mới. */
        const no=normalizeName(old);
        const fresh=value.split(/;\s*/).filter(sg=>sg.trim() && !no.includes(normalizeName(sg)));
        if(fresh.length){
          const parts=old.split(/;\s*/).concat(fresh);
          while(parts.length>1 && parts.join("; ").length>2500) parts.shift();
          c[key]=parts.join("; ").slice(-2500);
        }
      }
    }else c[key]=update[key];
    if((explicitCoreChange || c.coreLocked===false || wasEmpty) && CHARACTER_CORE_LOCK_FIELDS.includes(key)){
      if(!c.coreIdentity || typeof c.coreIdentity!=="object") c.coreIdentity={};
      c.coreIdentity[key]=c[key];
    }
  });
  /* V14.1: trường tu luyện — cảnh giới chỉ đổi khi có sự kiện đột phá + bằng chứng trích từ chương; thang bậc lấy từ Story Bible. */
  const cultNotes = applyCultivationUpdate(c, update, { explicit: explicitCoreChange, evidence: update.changeEvidence, state });
  if(update.isDead === true && !c.dead){ c.dead = true; c.deathChapter = chapterNumber; }
  c.lastAppearance = chapterNumber;
  if(update.relationshipWithMain && Object.values(update.relationshipWithMain).some(v=>v)){
    let rel = (c.relationships||[]).find(r=>normalizeName(r.withName).includes("nhan vat chinh"));
    if(!rel){ rel = newRelationship({withName:"Nhân vật chính"}); c.relationships.push(rel); }
    {
      const _ag=profileAgeNum(c,update), _minor=(_ag!==null && _ag<18);
      Object.keys(update.relationshipWithMain).forEach(k=>{ const v=update.relationshipWithMain[k]; if(v==="" || v==null) return; if(_minor && (k==="attraction"||k==="boundaries")) return; rel[k]=v; });
    }
  }
  // Quan hệ với các nhân vật KHÁC (không chỉ nhân vật chính) — cập nhật theo
  // sự kiện, không reset về trạng thái cũ nếu chương này không nói ngược lại.
  if(Array.isArray(update.relationships)){
    update.relationships.forEach(ru=>{
      if(!ru || !ru.withName) return;
      let rel = c.relationships.find(r=>normalizeName(r.withName)===normalizeName(ru.withName));
      if(!rel){ rel = newRelationship({withName: ru.withName}); c.relationships.push(rel); }
      const _ag2=profileAgeNum(c,null), _minor2=(_ag2!==null && _ag2<18);
      Object.keys(ru).forEach(k=>{ if(k!=="withName" && ru[k]!=="" && ru[k]!=null && !(_minor2 && (k==="attraction"||k==="boundaries"))) rel[k]=ru[k]; });
    });
  }
  if(update.chapterEvent) c.history.push({chapter: chapterNumber, event: update.chapterEvent});
  // Continuity Engine: keep only the latest dynamic state per character.
  const trackerKey=normalizeName(c.name);
  const prevTracker=state.characterStateTracker[trackerKey]||{};
  state.characterStateTracker[trackerKey]={
    chapter:chapterNumber, name:c.name,
    powerLevel:c.realm||update.powerLevel||update.level||prevTracker.powerLevel||"",
    location:update.currentLocation||prevTracker.location||"",
    health:update.healthStatus||update.physicalState||prevTracker.health||"",
    itemsHeld:update.itemsHeld||update.heldItems||prevTracker.itemsHeld||"",
    dead:!!c.dead
  };
  return { name: c.name, isNewChar, cultNotes };
}
// Định dạng JSON mà AI phải trả về khi cập nhật nhân vật — bao gồm phân loại
// vai trò, mức liên quan tới nhân vật chính, mục tiêu, quan hệ với các NV
// khác, kiến thức. Theo nguyên tắc: KHÔNG bịa, KHÔNG xóa thông tin cũ nếu
// chương này không nhắc/mâu thuẫn, chỉ update trường có bằng chứng rõ trong chương.
const CHAR_JSON_FORMAT_HINT = [
  'Trả về DUY NHẤT một mảng JSON (không markdown, không lời dẫn), mỗi phần tử là 1 nhân vật CÓ XUẤT HIỆN hoặc ĐƯỢC NHẮC TỚI có ý nghĩa trong chương này:',
  '[{',
  '  "name": "",',
  '  "isNew": false,',
  '  "tier": "background|minor|supporting|important|major",',
  '  "role": "vai trò/phân loại của NV này đối với truyện (vd: đồng minh, phản diện phụ, nạn nhân, người cung cấp thông tin, trung lập...)",',
  '  "relevanceToMC": "mức độ + cách liên quan tới nhân vật chính (vd: liên quan trực tiếp đến vụ X, chỉ quen biết xã giao, đối thủ trong công việc...)",',
  '  "age":"", "gender":"", "maritalStatus":"độc thân|đang hẹn hò|đã kết hôn|ly thân|ly hôn|góa|khác", "spouseName":"", "maritalNotes":"", "position":"", "speech":"", "height":"", "bodyType":"", "measurements":"", "hair":"", "eyes":"", "skin":"", "appearance": "", "personality": "", "occupation": "", "faction": "",',
  '  "speech": "cách nói riêng: giọng điệu, khẩu ngữ, câu cửa miệng, cách xưng hô đặc trưng (chỉ ghi khi chương cho thấy rõ)", "strength": "điểm mạnh/kỹ năng thể hiện trong chương", "voice": "", "scent": "", "style": "phong cách ăn mặc", "scars": "", "tattoos": "", "schedule": "lịch/thói quen nếu chương nêu",',
  '  "independentPlot": "TUYẾN TRUYỆN RIÊNG của NV này đang diễn ra ngoài tuyến chính (việc họ tự làm/âm mưu/mục tiêu riêng) — chỉ ghi diễn biến MỚI trong chương",',
  '  "sexualExperience": "", "boundaries": "", "taboos": "", "preferences": "", "attractionToMC": "", "tensionWithMC": "", "consentNotes": "",',
  '  "_ghi_chu_18": "các trường 18+ ở dòng trên: CHỈ ghi khi chương thể hiện rõ (kinh nghiệm/ranh giới/taboo/sở thích/mức hấp dẫn/đồng thuận của NV trưởng thành); không suy đoán, chương không có thì để trống",',
  '  "goals": "mục tiêu hiện tại của NV (không phải mục tiêu của NVC)",',
  '  "secret": "bí mật NV đang giữ (nếu có, chỉ ghi nếu chương có gợi ý rõ)",',
  '  "weakness": "", "fear": "",',
  '  "currentLocation": "", "physicalState": "", "mentalState": "",',
  '  "knowledge": "những gì NV này BIẾT/NGHI NGỜ tính đến hết chương này — chỉ ghi điều họ thực sự đã chứng kiến/được kể/suy luận hợp lý, KHÔNG được gán kiến thức của người đọc cho nhân vật",',
  '  "powerLevel": "cấp/cảnh giới hiện tại nếu có bằng chứng", "healthStatus": "tình trạng sức khỏe/vết thương hiện tại", "itemsHeld": "vật phẩm đang giữ",',
  '  "realm": "cảnh giới hiện tại, CHỈ dùng đúng tên trong thang cảnh giới + tiểu tầng (vd: Trúc Cơ đệ tam trọng); chỉ ghi khi chương nêu rõ", "spiritRoot": "", "talent": "", "element": "", "technique": "công pháp chính", "arts": "thần thông/chiêu thức/võ học MỚI lộ ra trong chương", "combatPower": "", "treasure": "bản mệnh pháp bảo/binh khí", "inventory": "túi trữ vật hiện có", "spiritStones": "", "apparentAge": "", "lifespan": "", "masterLine": "sư phụ, sư huynh/tỷ/đệ/muội", "fortune": "cơ duyên mới", "grudges": "ân oán mới", "originSecret": "", "innerDemon": "", "karma": "", "aliases": ["đạo hiệu/biệt danh CHỈ khi chương nêu rõ là cùng một người"],',
  '  "chapterEvent": "1 câu ngắn mô tả sự kiện quan trọng nhất liên quan tới NV này trong chương (để lưu vào lịch sử)",',
  '  "relationshipWithMain": {"trust":"","respect":"","affection":"","attraction":"","suspicion":"","tension":"","boundaries":"ranh giới/giới hạn của NV với NVC (chỉ khi chương thể hiện rõ)","stage":"","notes":""},',
  '  "relationships": [{"withName": "tên NV khác", "stage": "", "trust": "", "respect": "", "affection": "", "attraction": "", "suspicion": "", "tension": "", "boundaries": "", "notes": "diễn biến quan hệ MỚI trong chương này, không lặp lại thông tin cũ"}],',
  '  "isDead": false,',
  '  "explicitCoreChange": false, "changeEvidence": ""',
  '}]',
  '',
  'QUY TẮC BẮT BUỘC:',
  '- CHỈ với NV ghi [KHÓA HỒ SƠ GỐC]: hồ sơ cốt lõi (name, age, gender, appearance, personality, goals) là dữ liệu gốc của người dùng; không GHI ĐÈ các trường này khi đã có giá trị (trường còn TRỐNG thì được điền nếu chương nêu rõ), trừ khi chương mô tả một thay đổi rõ ràng có bằng chứng trực tiếp.',
  '- Trường nằm trong mục "CHƯA CÓ" của nhân vật: hãy ĐIỀN nếu chương nêu rõ (ví dụ "nữ thư ký" → gender: nữ, occupation: thư ký; tuổi/chiều cao/tóc/mắt chỉ khi có con số hoặc mô tả trực tiếp). Trường đã có giá trị thì để trống, không ghi đè. Không đoán.',
  '- Với NV ghi [MỞ KHÓA]: BẮT BUỘC bổ sung appearance/personality/goals bằng các chi tiết CỤ THỂ, MỚI xuất hiện trong chương (mỗi trường 30-60 từ, không lặp lại mục "hiện có"); nếu chương không có gì mới thì để trống.',
  '- Nghề/chức vụ (role, occupation, position, faction) là DỮ LIỆU GỐC: KHÔNG đổi, KHÔNG suy diễn từ cách người khác xưng hô, từ việc nhân vật làm việc với giám đốc/sếp, hay từ cảnh nhân vật ngồi ghế/ở phòng của ai. Chỉ đổi khi chương KỂ RÕ một sự kiện thăng chức/bổ nhiệm/từ chức/đổi nghề đã xảy ra; khi đó đặt explicitCoreChange=true và changeEvidence phải TRÍCH NGUYÊN VĂN câu trong chương cho thấy sự kiện đó. Nếu không có, để trống role/occupation/position/faction.',
  '- Với NV bị KHÓA: không đổi tính cách, ngoại hình, nghề/vị trí hay mục tiêu gốc chỉ vì cách diễn giải của AI khác đi.',
  '- TU LUYỆN: realm CHỈ dùng tên trong thang cảnh giới của truyện (+ tiểu tầng đệ nhất…đệ cửu trọng), không tự đặt cảnh giới mới. Đột phá/tụt cảnh giới BẮT BUỘC explicitCoreChange=true và changeEvidence = câu trích NGUYÊN VĂN kể sự kiện đó; không có thì để realm trống. Nhảy từ 2 đại cảnh giới trở lên sẽ bị bác. technique/treasure đã có thì không đổi trừ khi explicitCoreChange. arts/fortune/grudges/innerDemon/karma chỉ ghi diễn biến MỚI. aliases chỉ ghi khi chương nói rõ đó là cùng một người.',
  '- Chỉ dùng explicitCoreChange=true khi có thay đổi cốt lõi xảy ra thật trong truyện và changeEvidence phải nêu bằng chứng cụ thể; nếu không thì KHÔNG đổi hồ sơ gốc.',
  '- Nếu một trường không có thông tin MỚI/thay đổi thật sự trong chương này → để trống ("") hoặc bỏ qua trường đó, ĐỪNG bịa hay đoán để điền cho đủ.',
  '- Không được suy đoán cảm xúc/kiến thức/bí mật nếu chương không có bằng chứng — thà bỏ trống còn hơn đoán sai.',
  '- "relationships" chỉ liệt kê quan hệ CÓ diễn biến/xuất hiện trong chương này, không cần liệt kê lại toàn bộ mạng lưới quan hệ cũ.',
  '- NV chỉ thoáng qua vẫn nên ghi nhận (tier: background/minor) để không bỏ sót, nhưng đừng bịa thêm chi tiết cho họ nếu chương không nói gì.'
].join('\n');
async function updateCharactersIncremental(text, chapterNumber, silent){
  if(!text) return {ok:false,reason:"empty"};
  const sourceChapter = state.chapters && state.chapters[Number(chapterNumber) - 1];
  const sourceStatus = String(sourceChapter && (sourceChapter.status || (sourceChapter.sync && sourceChapter.sync.status)) || "").toLowerCase();
  if(sourceChapter && sourceStatus && /^(draft|drafted|revision_required|rejected|failed|running|writing)$/.test(sourceStatus) && typeof isAcceptedStoryChapter === "function" && !isAcceptedStoryChapter(sourceChapter)){
    const msg = "Chương chưa được chấp nhận — Character Database chỉ nhận DRAFT UPDATE, chưa ghi Canon.";
    if(!silent) setStatus("⚠ " + msg, false);
    return {ok:false, reason:"chapter_not_accepted", draftOnly:true};
  }
  const chunks=[]; const maxChars=12000, overlap=800;
  let pos=0;
  while(pos<text.length){
    let end=Math.min(text.length,pos+maxChars);
    if(end<text.length){ const cut=text.lastIndexOf("\n",end); if(cut>pos+8000) end=cut; }
    chunks.push(text.slice(pos,end)); if(end>=text.length) break; pos=Math.max(pos+1,end-overlap);
  }
  const mcName=(state.mainCharProfile&&state.mainCharProfile.name)||"";
  let nNew=0,nUpd=0,failed=0,repaired=0;
  const nameList=state.characters.slice(0,100).map(c=>{
    const locked=c.coreLocked!==false;
    let line="- "+c.name+(c.dead?" [ĐÃ CHẾT]":"")+(locked?" [KHÓA HỒ SƠ GỐC]":" [MỞ KHÓA: được cập nhật ngoại hình/tính cách/mục tiêu]");
    if(!locked){
      const cur=["appearance","personality","goals"].map(k=>c[k]?k+": "+String(c[k]).slice(-260):"").filter(Boolean).join(" | ");
      if(cur) line+="\n    hiện có -> "+cur;
    }
    const missing=["age","gender","role","occupation","appearance","personality","goals"].filter(k=>!String(c[k]||"").trim());
    if(missing.length) line+="\n    CHƯA CÓ (hãy điền nếu chương nêu rõ) -> "+missing.join(", ");
    const job=["role","occupation","position","faction"].map(k=>c[k]?k+": "+String(c[k]).slice(0,80):"").filter(Boolean).join(" | ");
    if(job) line+="\n    nghề/chức vụ GỐC (giữ nguyên) -> "+job;
    const cult=["realm","technique","treasure"].map(k=>c[k]?k+": "+String(c[k]).slice(0,60):"").filter(Boolean).join(" | ");
    if(cult) line+="\n    tu luyện hiện có (đổi cảnh giới chỉ khi có đột phá + explicitCoreChange) -> "+cult;
    return line;
  }).join("\n")||"(chưa có)";
  for(let i=0;i<chunks.length;i++){
    const prompt=[
      "CẬP NHẬT NHÂN VẬT SAU CHƯƠNG "+chapterNumber+" — PHẦN "+(i+1)+"/"+chunks.length+".",
      mcName?"Nhân vật chính: "+mcName+" — khi ghi nhân vật chính PHẢI dùng đúng tên này; KHÔNG tạo mục tên \"nhân vật chính\".":"",
      "Chỉ ghi NV thực sự xuất hiện/được nhắc tới có ý nghĩa trong phần này. Không bịa.",
      cultivationSystemBlock(state),
      "Tên NV đã có:",nameList,
      "NỘI DUNG:",chunks[i],
      CHAR_JSON_FORMAT_HINT,
      "Mỗi trường mô tả cụ thể, súc tích. Không lặp lại nội dung \"hiện có\"; chỉ thêm chi tiết mới."
    ].filter(Boolean).join("\n\n");
    try{
      const r=await callAI(prompt,{maxTokens:9200,temperature:0.2});
      let arr=safeJsonParse(r.text), wasRepair=false;
      if(!Array.isArray(arr)){ const repaired=repairTruncatedArray(r.text); if(repaired.length){arr=repaired;wasRepair=true;} }
      if(!Array.isArray(arr)){
        const retry=await callAI("CHỈ TRẢ JSON ARRAY NHÂN VẬT. Không lời dẫn.\n"+CHAR_JSON_FORMAT_HINT+"\n\nNội dung:\n"+chunks[i].slice(0,8000),{maxTokens:12500,temperature:0.15});
        arr=safeJsonParse(retry.text); if(!Array.isArray(arr)){ const repaired=repairTruncatedArray(retry.text); if(repaired.length){arr=repaired;wasRepair=true;} }
      }
      if(!Array.isArray(arr)){failed++;continue;}
      if(wasRepair) repaired++;
      arr.forEach(u=>{const r=mergeCharacterUpdate(u,chapterNumber,chunks[i]);if(r&&r.isNewChar)nNew++;else if(r)nUpd++;});
    }catch(err){failed++;}
  }
  // Character rescan does not synchronize Long-term Memory. Keep its sync cursor unchanged.
  persist(); renderCharacters(); captureChapterSnapshot(chapterNumber);
  if(!silent) setStatus(failed?"⚠ NV ch"+chapterNumber+": "+nNew+" mới, "+nUpd+" cập nhật, "+failed+" lô lỗi." : "NV ch"+chapterNumber+": +"+nNew+" mới, "+nUpd+" cập nhật"+(repaired?"; đã cứu JSON ở "+repaired+" lô.":"."),false);
  return {ok:failed<chunks.length,nNew,nUpd,failed,chunks:chunks.length,repaired};
}
$ID("npcUpdateBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có truyện.", false); return; }
  if(generating){ setStatus("Đang bận, đợi xong rồi bấm lại.", true); return; }
  /* Trước đây nút này nhét NGUYÊN CẢ TRUYỆN (hoặc 6 chương full gần nhất)
     vào MỘT lệnh gọi duy nhất — với truyện dài, input quá lớn khiến model
     xử lý rất lâu, thậm chí có thể vượt giới hạn ngữ cảnh và bỏ sót NV.
     Giờ quét TỪNG CHƯƠNG một, dùng lại đúng logic updateCharactersIncremental
     (đã có nâng ngưỡng cắt + retry) — chậm hơn về tổng thời gian chờ nhưng
     đáng tin cậy hơn nhiều và có báo tiến độ rõ ràng. */
  setGenerating(true); setWriteProgress("write");
  const total = state.chapters.length;
  let okCount = 0, failCount = 0, stopped = false;
  try{
    for(let i=0;i<total;i++){
      const cn = i+1;
      setStatus("Đang quét NV chương " + cn + "/" + total + "...", true);
      const r = await updateCharactersIncremental(state.chapters[i].text, cn, true);
      if(r && r.ok) okCount++; else failCount++;
      markAutoUpdateIssue(cn, "NV", !r || !r.ok, true);
      if(userStopRequested){ stopped = true; break; }
    }
    persist(); renderCharacters(); renderChapterNav();
    if(stopped) setStatus("Đã dừng — quét được " + okCount + "/" + total + " chương.", false);
    else setStatus("Đã quét xong " + total + " chương (" + okCount + " OK" + (failCount ? ", " + failCount + " lỗi — xem cờ ⚠ trên thẻ chương" : "") + ").", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
  finally{ setGenerating(false); setWriteProgress(null); }
});

/* ========== LOCATION + ITEM + THREADS UPDATE (gộp 1 lệnh gọi) ========== */
/* Trước đây đây là 2 hàm riêng (updateLocationsItemsIncremental +
   updateThreadsIncremental), mỗi hàm tự gửi lại TOÀN VĂN chương cho AI —
   tức nội dung chương bị gửi lặp lại 2 lần chỉ để tách 2 việc gần giống
   nhau. Gộp làm 1 lệnh gọi giúp giảm ~1 lượt gửi lại toàn chương (tốn input
   token nhất), giảm số lệnh gọi API, và giảm số chỗ có thể "âm thầm không
   cập nhật" nếu JSON lỗi. Có thử lại 1 lần nếu không parse được. */
const WORLD_JSON_FORMAT_HINT = 'Trả về DUY NHẤT một object JSON (không thêm chữ nào khác, không markdown):\n'
  + '{"locations":[{"name":"","description":"","status":"active|destroyed|abandoned|locked"}],'
  + '"items":[{"name":"","description":"","owner":"","status":"active|lost|destroyed|stored","kind":"pháp bảo|binh khí|đan dược|công pháp/bí kíp|trận pháp/phù lục|linh thạch/tài nguyên|khác","grade":"phẩm cấp nếu chương nêu rõ","effect":"công dụng/hạn chế nếu chương nêu","bound":false}],'
  + '"threads":[{"type":"open_thread|foreshadowing|consequence","desc":"","status":"seeded|developing|blocked|resolved|paid_off|abandoned","matchExistingDesc":"","evidence":"chi tiết cụ thể trong chương chứng minh việc đổi trạng thái"}]}\n'
  + 'Chỉ liệt kê địa điểm/vật phẩm MỚI hoặc CÓ THAY ĐỔI, và thread mới/đổi trạng thái. Chỉ đóng thread khi chương có bằng chứng rõ; không mở lại thread đã resolved/paid_off/abandoned trừ khi tác giả sửa tay. Nếu không có gì đổi ở 1 mục, để mảng rỗng []. Tất cả TIẾNG VIỆT.';
function applyWorldUpdate(obj, chapterNumber){
  let touched = false;
  (obj.locations||[]).forEach(u=>{
    if(!u.name) return; touched = true;
    let l = findLocationByName(u.name);
    if(!l){ l = newLocation({ name: u.name, firstAppearance: chapterNumber }); state.locations.push(l); }
    if(u.description) l.description = u.description;
    if(u.status) l.status = u.status;
    l.lastAppearance = chapterNumber;
  });
  (obj.items||[]).forEach(u=>{
    if(!u.name) return; touched = true;
    let it = findItemByName(u.name);
    if(!it){ it = newItem({ name: u.name, firstAppearance: chapterNumber }); state.items.push(it); }
    if(u.description) it.description = u.description;
    if(u.owner) it.owner = u.owner;
    if(u.status) it.status = u.status;
    /* V14.1: phân loại/phẩm cấp là thuộc tính ổn định — chỉ điền khi còn trống; "bound" chỉ bật, không tự tắt. */
    if(u.kind && !it.kind) it.kind = String(u.kind).slice(0,40);
    if(u.grade && !it.grade) it.grade = String(u.grade).slice(0,80);
    if(u.effect && !it.effect) it.effect = String(u.effect).slice(0,200);
    if(u.bound === true) it.bound = true;
    it.lastAppearance = chapterNumber;
  });
  (obj.threads||[]).forEach(t=>{
    if(!t.desc) return; touched = true;
    let match = null;
    if(t.matchExistingDesc){
      const key = t.matchExistingDesc.toLowerCase().slice(0,20);
      match = state.threads.find(x=> x.desc.toLowerCase().includes(key));
    }
    if(match){
      const prior=match.status||"seeded", next=t.status||prior, terminal=["paid_off","abandoned","resolved","completed"].includes(String(prior).toLowerCase());
      if(!terminal||String(next).toLowerCase()===String(prior).toLowerCase()){
        if(next!==prior){match.statusHistory=Array.isArray(match.statusHistory)?match.statusHistory:[];match.statusHistory.push({from:prior,to:next,chapter:chapterNumber,source:"postprocess",evidence:String(t.evidence||"").slice(0,240),at:Date.now()});}
        match.status=next; match.lastUpdatedChapter=chapterNumber; match.lastUpdatedTime=state.storyClock||"";
      }
    }
    else state.threads.push({ id: genId(), type: t.type||"open_thread", status:["paid_off","abandoned","resolved"].includes(String(t.status||"").toLowerCase())?"seeded":(t.status||"seeded"), desc: t.desc, chapterIntroduced: chapterNumber, lastUpdatedChapter:chapterNumber, statusHistory:[] });
  });
  return touched;
}
async function updateWorldIncremental(text, chapterNumber, silent){
  if(!text) return { ok:false, reason:"empty" };
  const existingLocs = state.locations.map(l=>l.name + " (" + l.status + ")").join(", ") || "(chưa có)";
  const existingItems = state.items.map(it=>it.name + " (" + it.status + (it.owner? ", của "+it.owner:"") + ")").join(", ") || "(chưa có)";
  const existingThreads = state.threads.map(t=>t.type+": "+t.desc+" ("+t.status+")").join("\n") || "(chưa có)";
  let body = text;
  /* Xem giải thích ở updateCharactersIncremental — nâng ngưỡng cắt tương tự. */
  if(body.length > 32000) body = body.slice(0, 13000) + "\n\n[...]\n\n" + body.slice(-15000);
  const prompt = [
    "Địa điểm hiện có:", existingLocs, "",
    "Vật phẩm hiện có:", existingItems, "",
    "Threads hiện có:", existingThreads, "",
    "Chương " + chapterNumber + ":", body, "", WORLD_JSON_FORMAT_HINT
  ].join("\n");
  const attempt = async (p, maxTokens)=>{
    const { text: raw } = await callAI(p, {maxTokens, temperature:0.3});
    return safeJsonParse(raw);
  };
  try{
    let obj = await attempt(prompt, 3200);
    if(!obj || typeof obj !== "object"){
      /* Thử lại 1 lần với lệnh ngắn gọn, nghiêm khắc hơn — thay vì âm thầm bỏ qua như trước */
      try{ obj = await attempt("CHỈ trả JSON object đúng định dạng, không thêm chữ nào khác.\n" + WORLD_JSON_FORMAT_HINT + "\n\nChương " + chapterNumber + ":\n" + body.slice(0, 8000), 5000); }catch(e2){}
    }
    if(!obj || typeof obj !== "object"){
      if(!silent) setStatus("⚠ Không đọc được cập nhật địa điểm/vật phẩm/thread ch" + chapterNumber + " (lỗi định dạng AI trả về).", false);
      return { ok:false, reason:"parse" };
    }
    applyWorldUpdate(obj, chapterNumber);
    persist(); renderLocations(); renderItems(); renderThreads();
    captureChapterSnapshot(chapterNumber);
    return { ok:true };
  }catch(err){
    if(!silent) setStatus("Lỗi địa điểm/vật phẩm/thread ch" + chapterNumber + ": " + err.message, false);
    return { ok:false, reason: err.message };
  }
}
/* Giữ lại 2 tên hàm cũ (đã gộp bên trong) để không phải sửa chỗ nào khác lỡ còn tham chiếu */
async function updateLocationsItemsIncremental(text, chapterNumber, silent){ return updateWorldIncremental(text, chapterNumber, silent); }
async function updateThreadsIncremental(text, chapterNumber, silent){ return { ok:true, skipped:true }; /* đã gộp vào updateWorldIncremental */ }

/* ========== CURRENT STATUS ========== */
async function updateCurrentStatusIncremental(text, chapterNumber, silent){
  if(!text) return {ok:false,reason:"empty"};

  /* Current Status V2: CHANGE → VALIDATE → MERGE + EVIDENCE.
     Không tái tạo toàn bộ status ở mỗi chương. */
  const old=state.currentStatus||"";
  const previousState=(state.statusState && typeof state.statusState==="object") ? JSON.parse(JSON.stringify(state.statusState)) : {};
  if(!previousState.schemaVersion){
    previousState.schemaVersion=2;
    if(old && !Object.keys(previousState).length) previousState.legacyText=old;
  }
  if(!previousState.currentState || typeof previousState.currentState!=="object") previousState.currentState={};
  if(!previousState.longTerm || typeof previousState.longTerm!=="object") previousState.longTerm={};
  if(!Array.isArray(previousState.characterStates)) previousState.characterStates=[];
  if(!Array.isArray(previousState.changeLog)) previousState.changeLog=[];
  if(!Array.isArray(previousState.conflicts)) previousState.conflicts=[];

  const prevSummaries=state.chapters.slice(Math.max(0,chapterNumber-4),chapterNumber)
    .map((c,i)=>"Ch"+(Math.max(0,chapterNumber-4)+i+1)+": "+(c.summary||c.title||"")).join("\n");
  const body=text.length>24000?text.slice(0,9000)+"\n\n[...giữa...]\n\n"+text.slice(-11000):text;
  const roster=(state.characters||[]).map(c=>({id:c.id,name:c.name,role:c.role||"",tier:c.tier||""}));
  if(state.mainCharProfile?.name && !roster.some(c=>c.name===state.mainCharProfile.name))
    roster.unshift({id:"main",name:state.mainCharProfile.name,role:"main",tier:"main"});

  const prompt=[
    "CẬP NHẬT CURRENT STATUS SAU CHƯƠNG "+chapterNumber+" — CHỈ TRÍCH XUẤT THAY ĐỔI.",
    "Dùng CHANGE → VALIDATE → MERGE. Không viết lại toàn bộ status.",
    "Không xóa dữ liệu cũ chỉ vì không nhắc lại.",
    "Chỉ cập nhật khi chương có bằng chứng rõ ràng.",
    "Không tự tạo nhân vật mới; chỉ dùng ID/tên trong danh sách nhân vật.",
    "Mỗi thay đổi phải có evidence ngắn, bám trực tiếp nội dung chương.",
    "Mâu thuẫn chưa đủ căn cứ phải đưa vào conflicts, không ghi đè.",
    "TIẾNG VIỆT.",
    "STATUS CŨ:",old||"(chưa có)","",
    "DANH SÁCH NHÂN VẬT:",roster.map(c=>"- "+c.id+" | "+c.name+" | "+c.role+" | "+c.tier).join("\n")||"(không có)","",
    "TÓM TẮT CHƯƠNG GẦN:",prevSummaries||"(không)","",
    "CHƯƠNG:",body,"",
    'JSON DUY NHẤT: {"changes":{"time":{"status":"updated|unchanged","value":"","evidence":""},"situation":{"status":"updated|unchanged","value":"","evidence":""},"mainEvent":{"status":"updated|unchanged","value":"","evidence":""},"location":{"status":"updated|unchanged","value":"","evidence":""},"overall":{"status":"updated|unchanged","value":"","evidence":""},"mainCharacter":{"status":"updated|unchanged","value":"","evidence":""},"relationships":{"status":"updated|unchanged","value":"","evidence":""},"power":{"status":"updated|unchanged","value":"","evidence":""},"rules":{"status":"added|updated|unchanged","value":"","evidence":""},"conflict":{"status":"added|updated|unchanged","value":"","evidence":""},"nextGoal":{"status":"updated|unchanged","value":"","evidence":""},"knowledge":{"status":"added|updated|unchanged","value":"","evidence":""},"unresolved":{"status":"added|resolved|updated|unchanged","value":"","evidence":""},"secrets":{"status":"added|resolved|updated|unchanged","value":"","evidence":""},"weaknesses":{"status":"added|updated|unchanged","value":"","evidence":""},"characterChanges":[{"characterId":"","characterName":"","status":"updated|unchanged","changes":{"age":"","appearance":"","body":"","clothing":"","marks":"","cultivation":"","cultivationState":"","emotion":"","submission":"","ruleCompliance":"","socialStatus":"","occupation":"","residence":"","romance":"","weakness":"","goals":"","items":"","publicPersonality":"","privatePersonality":"","psychology":"","relationships":"","physicalState":"","mentalState":"","knowledge":""},"evidence":""}],"conflicts":[{"characterName":"","field":"","oldValue":"","newValue":"","description":"","evidence":""}]}}',
    "Không điền giá trị cho trường không thay đổi. Không markdown."
  ].join("\n");

  try{
    const r=await callAI(prompt,{maxTokens:7600,temperature:0.12});
    let obj=safeJsonParse(r.text);
    if(!obj||Array.isArray(obj)||typeof obj!=="object"||!obj.changes){
      const retry=await callAI("CHỈ TRẢ JSON OBJECT ĐÚNG SCHEMA.\n"+prompt,{maxTokens:9500,temperature:0.08});
      obj=safeJsonParse(retry.text);
    }
    if(!obj||Array.isArray(obj)||typeof obj!=="object"||!obj.changes){
      if(!silent)setStatus("⚠ Status ch"+chapterNumber+": không parse được change JSON, giữ Status cũ.",false);
      return {ok:false,reason:"parse"};
    }

    const cs=previousState.currentState, lt=previousState.longTerm;
    const validStatuses=["updated","added","resolved"];
    let applied=0;
    const setField=(target,key,item)=>{
      if(!item||typeof item!=="object")return;
      const st=String(item.status||"").toLowerCase(), ev=String(item.evidence||"").trim(), val=item.value;
      if(!validStatuses.includes(st)||!ev||val==null||String(val).trim()==="")return;
      target[key]=val; applied++;
    };
    ["time","situation","mainEvent","location","overall","mainCharacter","relationships","power","rules","conflict","nextGoal","knowledge","unresolved"]
      .forEach(k=>setField(cs,k,obj.changes[k]));
    ["secrets","weaknesses"].forEach(k=>setField(lt,k,obj.changes[k]));

    const known=new Map(roster.filter(c=>c.id&&c.name).map(c=>[String(c.id),c]));
    const byName=new Map(roster.filter(c=>c.name).map(c=>[String(c.name).trim().toLowerCase(),c]));
    const incoming=Array.isArray(obj.changes.characterChanges)?obj.changes.characterChanges:[];
    const priorChars=Array.isArray(previousState.characterStates)?previousState.characterStates:[];
    const priorCharById=new Map(priorChars.map(c=>[String(c.characterId||c.id||""),c]));
    const priorCharByName=new Map(priorChars.map(c=>[String(c.name||c.characterName||"").trim().toLowerCase(),c]));
    const chars=incoming.map(c=>{
      const knownC=known.get(String(c.characterId||""))||byName.get(String(c.characterName||"").trim().toLowerCase());
      if(!knownC)return null;
      const changes={};
      Object.entries(c.changes||{}).forEach(([k,v])=>{if(v!=null&&String(v).trim()!=="")changes[k]=v;});
      const evidence=String(c.evidence||"").trim();
      const accepted=Object.keys(changes).length && evidence && String(c.status||"updated").toLowerCase()==="updated";
      /* V14.5.12: TÍCH LŨY hồ sơ trạng thái theo nhân vật (nghề, nơi ở, trang phục, địa vị, tính cách công khai/riêng tư...). Trước đây mỗi chương ghi đè bằng đúng phần thay đổi của chương đó nên mọi thông tin cũ rơi mất. */
      const prior=priorCharById.get(String(knownC.id))||priorCharByName.get(String(knownC.name).trim().toLowerCase())||null;
      const merged=Object.assign({}, prior&&prior.changes&&typeof prior.changes==="object"?prior.changes:{}, accepted?changes:{});
      return {characterId:knownC.id,name:knownC.name,status:accepted?"updated":"unchanged",changes:merged,evidence:accepted?evidence:String((prior&&prior.evidence)||"")};
    }).filter(Boolean);
    const charMap=new Map(chars.map(c=>[c.characterId,c]));
    roster.forEach(c=>{if(c.id&&!charMap.has(c.id)){const prior=priorCharById.get(String(c.id))||priorCharByName.get(String(c.name).trim().toLowerCase())||null; chars.push({characterId:c.id,name:c.name,status:"unchanged",changes:(prior&&prior.changes&&typeof prior.changes==="object")?prior.changes:{},evidence:String((prior&&prior.evidence)||"")});}});
    previousState.characterStates=chars;

    const conflicts=(Array.isArray(obj.changes.conflicts)?obj.changes.conflicts:[])
      .filter(c=>c&&String(c.evidence||"").trim())
      .map(c=>({chapter:chapterNumber,characterName:c.characterName||"",field:c.field||"",oldValue:c.oldValue||"",newValue:c.newValue||"",description:c.description||"",evidence:String(c.evidence).trim()}));
    previousState.conflicts=previousState.conflicts.concat(conflicts).slice(-50);
    previousState.changeLog=previousState.changeLog.concat([{
      chapter:chapterNumber,appliedAt:Date.now(),appliedCount:applied,conflicts:conflicts.length,changes:obj.changes
    }]).slice(-50);
    previousState.schemaVersion=2;

    const lines=["Current Status Update - Sau Chương "+chapterNumber];
    const add=(k,v)=>{if(v!=null&&String(v).trim())lines.push("- "+k+": "+String(v).trim());};
    add("Thời điểm hiện tại",cs.time); add("Sự kiện chính vừa xảy ra",cs.mainEvent||cs.situation);
    add("Địa điểm",cs.location); add("Tình trạng tổng thể",cs.overall); add("Nhân vật chính",cs.mainCharacter);
    add("Phát triển mối quan hệ",cs.relationships); add("Tiến triển sức mạnh / tu vi / kỹ năng",cs.power);
    add("Quy tắc do nhân vật chính đặt ra",cs.rules); add("Điểm nhấn / xung đột mới",cs.conflict);
    add("Mục tiêu / hướng chương sau",cs.nextGoal); add("Thông tin / kiến thức mới",cs.knowledge);
    add("Vấn đề chưa giải quyết",cs.unresolved); add("Bí mật / lời hứa / sự kiện dài hạn",lt.secrets);
    add("Điểm yếu / rủi ro",lt.weaknesses);
    if(previousState.legacyText){ lines.push("- Current Status trước khi nâng cấp:"); lines.push(String(previousState.legacyText).trim()); }
    if(chars.length){
      lines.push("- Thông tin nhân vật cập nhật:");
      chars.forEach(c=>{ const kv=Object.entries(c.changes||{}).map(([k,v])=>k+": "+v).join(" | "); lines.push("  • "+c.name+": "+(kv?(c.status==="unchanged"?"Không có thay đổi đáng kể | ":"")+kv:"Không có thay đổi đáng kể")); });
    }
    if(conflicts.length){
      lines.push("- XUNG ĐỘT CẦN GIỮ LẠI, CHƯA TỰ Ý GHI ĐÈ:");
      conflicts.forEach(c=>lines.push("  • "+(c.characterName||c.field)+": "+(c.description||c.newValue)+" [Bằng chứng: "+c.evidence+"]"));
    }

    state.statusState=previousState;
    state.currentStatus=lines.join("\n");
    state.lastStatusChapter=chapterNumber;
    /* V14.5.13: thẻ nhân vật ĐẦY ĐỦ (khởi tạo từ hồ sơ gốc, cộng dồn, thay đổi phải có câu trích thật). Lỗi AI/JSON -> giữ khối cũ. */
    try{
      const cr=await runStatusCardUpdate({st:state,text,n:chapterNumber,maxCards:8,callText:async p=>{ const r2=await callAI(p,{maxTokens:6500,temperature:0.1}); return String((r2&&r2.text)||""); }});
      if(cr&&cr.ok){ applied+=cr.changed; if(!silent&&cr.dropped) console.warn("[StatusCards] bỏ qua "+cr.dropped+" trường không có evidence:",(cr.droppedFields||[]).join(", ")); }
    }catch(_){}
    // Current Status update is not a Long-term Memory sync; do not advance that cursor here.
    persist(); if(statusBox)statusBox.textContent=state.currentStatus; captureChapterSnapshot(chapterNumber);
    if(!silent)setStatus("Đã cập nhật Current Status → ch"+chapterNumber+" ("+applied+" thay đổi, "+conflicts.length+" xung đột).",false);
    return {ok:true,applied,conflicts:conflicts.length};
  }catch(err){
    if(!silent)setStatus("Lỗi status: "+err.message+" — giữ Status cũ.",false);
    return {ok:false,reason:err.message};
  }
}
$ID("statusFullRescanBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có truyện.", false); return; }
  if(generating){ setStatus("Đang bận, đợi xong rồi bấm lại.", true); return; }
  setGenerating(true);
  setStatus("Đang tổng hợp Current Status toàn truyện...", true);
  try{
    /* Trước đây với truyện ≤8 chương, code nhét NGUYÊN VĂN 8 chương vào 1
       lệnh gọi — nhưng với chương mặc định 5000+ từ, 8 chương đã là
       ~40.000 từ (~230k ký tự), vẫn quá lớn/chậm y như lỗi "Quét toàn
       truyện" đã vá. Giờ luôn quét TỪNG CHƯƠNG một cho chắc, bất kể
       truyện dài hay ngắn. */
    const oldStatusBackup = state.currentStatus || "";
    state.currentStatus = oldStatusBackup;
    for(let i = 0; i < state.chapters.length; i++){
      setStatus("Status: chương " + (i+1) + "/" + state.chapters.length + "...", true);
      const r = await updateCurrentStatusIncremental(state.chapters[i].text, i+1, true);
      markAutoUpdateIssue(i+1, "Status", !r || !r.ok);
    }
    state.lastStatusChapter = state.chapters.length;
    persist();
    statusBox.textContent = state.currentStatus || "";
    setStatus("Đã đồng bộ Current Status tới ch" + state.chapters.length + ".", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
  finally{ setGenerating(false); }
});
$ID("statusEditToggle").addEventListener("click", ()=>{
  const editing = statusEdit.style.display !== "none";
  if(editing){
    state.currentStatus = statusEdit.value;
    persist();
    statusBox.textContent = state.currentStatus || "Chưa có dữ liệu.";
    statusBox.style.display = "block"; statusEdit.style.display = "none";
    $ID("statusEditToggle").textContent = "✎ Sửa";
  } else {
    statusEdit.value = state.currentStatus;
    statusBox.style.display = "none"; statusEdit.style.display = "block";
    $ID("statusEditToggle").textContent = "✓ Lưu";
  }
});

/* ========== CONTINUITY ========== */
function renderContinuityWarnings(warnings){
  if(!warnings || !warnings.length){ continuityList.innerHTML = '<div class="empty-note">Chưa có cảnh báo.</div>'; return; }
  continuityList.innerHTML = warnings.map(w=>
    '<div class="warn-item sev-'+(w.severity||'low')+'">'
    + (w.character ? '<b>'+escapeHtml(w.character)+'</b> — ' : '') + escapeHtml(w.problem||'')
    + (w.suggestion ? '<div class="hint" style="margin-top:3px;">Gợi ý: '+escapeHtml(w.suggestion)+'</div>' : '')
    + '</div>'
  ).join("");
}
const CONTINUITY_JSON_HINT = 'Trả về DUY NHẤT một mảng JSON cảnh báo (có thể []): [{"severity":"low|medium|high","character":"","problem":"","suggestion":""}]. TIẾNG VIỆT.';
async function runContinuityCheck(text, chapterNumber, contextSummary, silent){
  if(!text) return [];
  const prompt = ["Bối cảnh:", contextSummary, "", "Chương " + chapterNumber + ":", text, "", CONTINUITY_JSON_HINT].join("\n");
  try{
    const { text: raw } = await callAI(prompt, {maxTokens:1200, temperature:0.2});
    const arr = safeJsonParse(raw);
    return Array.isArray(arr) ? arr : [];
  }catch(err){ if(!silent) setStatus("Lỗi check: " + err.message, false); return []; }
}
$ID("integrityScanBtn").addEventListener("click", async ()=>{
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  setStatus("Đang chạy Integrity Scan...", true);
  /* Trước đây dùng fullStoryText() = TOÀN VĂN không nén — với truyện dài
     là input khổng lồ, dễ treo lâu hoặc vượt giới hạn ngữ cảnh model.
     Đổi sang bản đã nén (chỉ giữ toàn văn 6 chương gần nhất + tóm tắt
     chương cũ) như các chỗ khác đã dùng. */
  const prompt = ["Story Bible:", buildStoryBibleSummary(), "", "Nhân vật:", characterSummaryForPrompt(state.characters), "", "TRUYỆN (chương cũ đã tóm tắt để đỡ quá tải):", fullStoryTextCompressed(), "", CONTINUITY_JSON_HINT].join("\n");
  try{
    const { text: raw } = await callAI(prompt, {maxTokens:4600, temperature:0.2});
    const arr = safeJsonParse(raw);
    const warnings = Array.isArray(arr) ? arr : [];
    renderContinuityWarnings(warnings);
    setStatus("Scan xong — " + warnings.length + " cảnh báo.", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
});
function fullStoryText(){
  return state.chapters.map((c,i)=>"Chương "+(i+1)+": "+c.title+"\n"+c.text).join("\n\n");
}

function fullStoryTextCompressed(){
  /* v10.2 Sliding Window: 1 chương gần nhất, tối đa ~1.500 từ; cũ hơn chỉ summary. */
  if(!state.chapters.length) return "";
  const keepWords=Math.max(500,Number(state.slidingWindowWords)||1500);
  const old=state.chapters.slice(0,-1);
  const last=state.chapters[state.chapters.length-1];
  const oldPart=old.map((c,i)=>"Chương "+(i+1)+": "+(c.summary||"(chưa tóm tắt)").slice(0, (old.length-i)<=3 ? 900 : 350)).join("\n");
  const words=(last.text||"").trim().split(/\s+/);
  const recent=words.length>keepWords ? words.slice(-keepWords).join(" ") : (last.text||"");
  return (oldPart ? "=== TÓM TẮT CHƯƠNG CŨ ===\n"+oldPart+"\n\n" : "")
    +"=== CỬA SỔ CHƯƠNG GẦN ===\nChương "+state.chapters.length+" ("+(last.title||"")+")\n"+recent;
}
/* ========== SUMMARY ========== */
/* V12.10: chống tóm tắt bịa — kiểm tra tên/từ trong bản tóm tắt có thật trong chương không. */

function adultModelFor(text){
  // V12.15: tóm tắt/gợi ý chương 18+ dùng model 18+ (model chính hay nói giảm nói tránh)
  if(!state.mature || (state.nsfwMode || "auto") === "never" || !state.modelNsfw) return undefined;
  if(!matureFocusAllowsRouting()) return undefined;
  if((state.nsfwMode || "auto") === "always") return state.modelNsfw; // V14.7.3: "Luôn dùng" = mọi bước phụ (tóm tắt, gợi ý chương) cũng qua model 18+, không đòi từ khóa
  return textHasNsfwKeyword(String(text || "").slice(-24000)) ? state.modelNsfw : undefined;
}
async function generateChapterSummary(text, chapterNumber, silent){
  if(!text) return "";
  const names = summaryNameList(text, state.characters);
  const _mo = adultModelFor(text);
  const prompt = buildSummaryPrompt(text, chapterNumber, names, !!_mo);
  const looksMeta = s => !/\*\*Tóm tắt chương:?\*\*/i.test(s) || /^(Ngắn gọn|Súc tích|Đủ chi tiết|Cấu trúc rõ|Trung lập)\s*[:：]/im.test(s);
  try{
    let { text: summary } = await callAI(prompt, {maxTokens:1400, temperature:0.2, modelOverride:_mo});
    summary = (summary||"").trim();
    let g = summaryGrounded(summary, text);
    if(looksMeta(summary) || !g.ok){
      try{
        const retry = await callAI(prompt + summaryRetryNote(g), {maxTokens:1400, temperature:0.1, modelOverride:_mo});
        if(retry.text && retry.text.trim()) summary = retry.text.trim();
      }catch(_){}
    }
    const wc = t => (String(t).trim().match(/\S+/g) || []).length;
    if(wc(summary) > 450){
      try{
        const rc = "Rút gọn bản tóm tắt sau xuống 300-400 từ tiếng Việt. Giữ dòng mở đầu \"**Tóm tắt chương:**\", giữ trình tự thời gian, tên đầy đủ; bỏ chi tiết phụ; không thêm gì mới. Chỉ trả về bản đã rút gọn.\n\n" + summary;
        const r3 = await callAI(rc, {maxTokens:1400, temperature:0.15, modelOverride:_mo});
        if(r3.text && r3.text.trim() && wc(r3.text) < wc(summary)) summary = r3.text.trim();
      }catch(_){}
      if(wc(summary) > 450){
        const words = summary.split(/\s+/).slice(0,420).join(" ");
        const cut = Math.max(words.lastIndexOf(". "), words.lastIndexOf("! "), words.lastIndexOf("? "));
        summary = cut > words.length*0.6 ? words.slice(0,cut+1) : words;
      }
    }
    if(!summaryGrounded(summary, text).ok){
      const ex = extractiveSummary(text);
      if(ex){ summary = ex; if(!silent) setStatus("AI tóm tắt lệch khỏi chương nên app dùng bản trích tự động từ văn bản.", false); }
    }
    return summary;
  }catch(err){ console.warn("[Summary]", err.message); return ""; }
}

/* Tự động đề xuất định hướng cho (các) chương SAU chương vừa viết xong.
   Chỉ là gợi ý tham khảo — không ép chương kế phải làm theo ngay,
   người dùng luôn có thể sửa tay trong ô "Gợi ý chương sau". */
const HINT_STYLES = {"auto": "TỰ CHỌN hướng phù hợp nhất cho chương sau dựa trên: mạch truyện và đoạn kết chương vừa rồi, thể loại/văn phong, Story bible, arc và dàn ý hiện tại, nhịp độ các chương gần đây (nếu vừa căng thì có thể chậm lại, nếu vừa chậm thì tăng nhịp), và mức 18+ đã cài. Không mặc định cứ \"bình thường\"; không ép bước ngoặt hay leo thang nếu mạch chưa cần.", "normal": "Diễn tiến tự nhiên, tiếp nối mạch hiện tại.", "resist": "Nhân vật bị khống chế/yếu thế PHẢN KHÁNG rõ rệt trong chương này (hành động chống cự cụ thể); bên kia đáp trả và siết chặt hơn, hệ quả làm quan hệ quyền lực nặng thêm.", "twist": "Có một bước ngoặt/đảo chiều bất ngờ (lộ bí mật, lợi thế đổi bên, kế hoạch bị phá) nhưng vẫn hợp lý với thông tin đã có.", "escalate": "Leo thang: mức độ căng thẳng, rủi ro hoặc mức nóng cao hơn chương trước, có cú chốt gây hồi hộp.", "slow": "Nhịp chậm hơn: đào sâu nội tâm, quan hệ và hệ quả cảm xúc; ít biến cố mới."};
async function generateNextChapterHint(text, summary, chapterNumber, opts){
  if(!text) return "";
  const userIdea = String((opts && opts.userIdea) || "").trim();
  // Chỉ đưa các thread/foreshadowing đang mở vào prompt khi chúng thực sự liên quan đến mạch chính.
  // Không nhồi toàn bộ tuyến phụ vào hint vì dễ khiến AI tự mở rộng phạm vi truyện.
  const openThreads = (state.threads||[])
    .filter(t=>!['paid_off','abandoned','completed','resolved'].includes(String(t.status||'').toLowerCase()))
    .slice(0,3)
    .map(t=>"- "+t.desc).join("\n");
  const openForeshadowing = (state.foreshadowing||[])
    .filter(f=>!['paid_off','abandoned','resolved'].includes(f.status))
    .slice(-3)
    .map(f=>"- "+f.description).join("\n");
  const names = (state.characters||[]).filter(c=>!c.dead).slice(0,40).map(c=>c.name).filter(Boolean).join(", ");
  const styleKey = state.hintStyle || "auto";
  const _mo = adultModelFor(text + "\n" + (summary || "") + (userIdea ? "\n" + userIdea : ""));
  const beats = (state.hintFormat || "detail") === "beats";
  let hLo = beats ? (_mo ? 230 : 150) : (_mo ? 600 : 400), hHi = beats ? (_mo ? 380 : 260) : (_mo ? 850 : 600);
  /* Ý tưởng dài của người dùng: nới trần để không bị nén mất chi tiết. */
  if(userIdea){ const iw = userIdea.split(/\s+/).filter(Boolean).length; hHi = Math.max(hHi, Math.ceil(iw * 1.8)); }
  /* V12.25: đưa NGỮ CẢNH TRUYỆN (story bible, style, arc, dàn ý, thẻ nhân vật, địa điểm, vật phẩm, 3 tóm tắt gần...) như lúc viết chương.
     Tạm xóa brief (gợi ý/mệnh lệnh) của chương vừa viết để AI không chép lại gợi ý cũ. */
  let ctxBlock = "";
  try{
    const _kh = state.nextChapterHint, _kd = state.directive;
    state.nextChapterHint = ""; state.directive = "";
    try{ ctxBlock = String(buildContextBlock() || ""); }finally{ state.nextChapterHint = _kh; state.directive = _kd; }
    if(ctxBlock.length > 7000) ctxBlock = ctxBlock.slice(0, 2800) + "\n[...]\n" + ctxBlock.slice(-4000);
  }catch(_e){ ctxBlock = ""; }
  const prompt = [
    "Bạn vừa đọc xong CHƯƠNG " + chapterNumber + " của một truyện dài kỳ. Hãy viết GỢI Ý CHI TIẾT cho CHƯƠNG " + (chapterNumber+1) + ".",
    userIdea ? ("Ý TƯỞNG CỦA NGƯỜI DÙNG — ƯU TIÊN TUYỆT ĐỐI, cao hơn mọi quy tắc gợi ý khác bên dưới:\n<y_tuong>\n" + userIdea + "\n</y_tuong>\nHãy VIẾT LẠI gợi ý chương sau để triển khai ĐÚNG và ĐẦY ĐỦ ý tưởng này: giữ nguyên mọi chi tiết, thứ tự, nhân vật, địa điểm, đạo cụ, hành động, câu thoại và điểm kết chương mà người dùng đã nêu; chỉ bổ sung những nhịp nối, địa điểm, hệ quả còn thiếu cho liền mạch với đoạn kết chương trước. KHÔNG bỏ ý, KHÔNG đổi ý, KHÔNG thay bằng hướng khác, KHÔNG thêm tuyến mới. Nếu ý tưởng chỉ nêu một phần thì chỉ viết phần đó và dừng ở mốc người dùng ghi.") : "",
    /* V14.3.6: gợi ý chương sau từng KHÔNG hề nhận dàn ý chương đó một cách rõ ràng (chỉ lọt trong khối ngữ cảnh, và bị cắt khi ngữ cảnh > 7000 ký tự) nên hay lệch Outline. */
    (()=>{ try{ const ap=String(arcProgressPrompt(state, chapterNumber+1)||"").trim(); return ap ? ("DÀN Ý / VIỆC BẮT BUỘC CỦA CHƯƠNG "+(chapterNumber+1)+" (NGUỒN CHUẨN — gợi ý PHẢI triển khai đúng dàn ý này: không đổi sự kiện, lời thoại hay thứ tự bắt buộc, không thêm tuyến ngoài dàn ý; chỉ bổ sung nhịp nối và chi tiết còn thiếu):\n<dan_y>\n"+ap.slice(0,2600)+"\n</dan_y>") : ""; }catch(_e){ return ""; } })(),
    beats
      ? ("ĐỊNH DẠNG GỌN THEO NHỊP: mở đầu bằng dòng \"**Gợi ý ngắn Chương " + (chapterNumber+1) + ":**\", sau đó 1–3 đoạn ngắn kể lần lượt các nhịp chính theo đúng thứ tự diễn ra, mỗi nhịp 1–2 câu (ai làm gì, ở đâu, với đạo cụ/thiết lập nào, hệ quả), giữ nhịp độ liền mạch. Câu cuối là dòng riêng bắt đầu bằng \"→ Kết chương ở:\" nêu rõ khoảnh khắc chương dừng lại. Không liệt kê gạch đầu dòng, không bình luận.")
      : ("ĐỊNH DẠNG: mở đầu bằng dòng \"**Gợi ý ngắn Chương " + (chapterNumber+1) + ":**\", sau đó 4-6 đoạn ngắn, mỗi đoạn là một cảnh/nhịp truyện theo thứ tự: (1) mở chương — nối TRỰC TIẾP từ đoạn kết chương trước, (2) cảnh chính, (3) cảnh phát triển/căng thẳng, (4) cú chốt cuối chương."),
    "Mỗi đoạn phải dùng TÊN NHÂN VẬT cụ thể, nêu rõ hành động, địa điểm, giờ giấc nếu có, xung đột, cảm xúc và hệ quả — KHÔNG nói chung chung. Các mốc đã hẹn trong chương trước (giờ họp, lệnh, hạn chót) phải được xử lý.",
    "THỨ TỰ ƯU TIÊN TUYỆT ĐỐI: (0) nếu có DÀN Ý CHƯƠNG SAU ở trên thì bám đúng dàn ý đó (ý tưởng người dùng vẫn cao hơn); (1) mạch truyện chính đang diễn ra và đoạn kết chương vừa viết, (2) yêu cầu/mệnh lệnh người dùng, (3) nhân vật chính và quan hệ trung tâm, (4) nếu đang có tuyến trưởng thành/18+ là trọng tâm thì phải tiếp tục đúng tuyến đó và tập trung vào diễn biến trực tiếp của tuyến chính, (5) hậu quả trực tiếp của chương vừa viết, (6) chỉ dùng THREADS/FORESHADOWING nếu chúng liên quan trực tiếp đến 5 mục trên.",
    "KHÔNG ĐƯỢC biến GỢI Ý CHƯƠNG SAU thành kế hoạch mở rộng thế giới hoặc mở nhiều tuyến phụ. Không mở tuyến truyện mới, không tự tạo mục tiêu mới, không đưa thêm nhân vật quan trọng, địa điểm lớn hoặc bí mật mới chỉ để làm truyện phong phú hơn.",
    "Nếu có nhiều thread/foreshadowing đang mở, chỉ chọn TỐI ĐA 1 thread và 1 foreshadowing có liên quan trực tiếp nhất đến mạch chính. Những mục còn lại phải bỏ qua trong gợi ý này.",
    "Nếu chương vừa viết đang tập trung vào một quan hệ/tuyến chính cụ thể, chương sau phải tiếp tục hoặc xử lý hậu quả của chính tuyến đó trước; KHÔNG chuyển trọng tâm sang tuyến phụ chỉ vì thread đó đang mở.",
    "Nếu truyện đang bật 18+ nhưng chương vừa viết không có tuyến trưởng thành là trọng tâm, không được tự ép thêm tuyến trưởng thành mới. Ngược lại, nếu mạch chính hiện tại đã đặt tuyến trưởng thành làm trọng tâm, phải ưu tiên tiếp nối mạch đó thay vì mở tuyến khác.",
    "ĐỊA ĐIỂM MỞ CHƯƠNG: nhịp mở chương PHẢI ở cùng địa điểm, thời điểm và với những người đang có mặt ở ĐOẠN KẾT CHƯƠNG (nếu chương kết ở biệt thự của A thì chương sau vẫn mở ở biệt thự của A). Chỉ chuyển địa điểm nếu đoạn kết đã báo trước, và khi đó phải ghi rõ cách chuyển. Mỗi nhịp có đổi địa điểm phải ghi rõ địa điểm mới.",
    "Bám sát giọng điệu, thể loại, cách xưng hô và dữ kiện của chính truyện; không mâu thuẫn dữ kiện đã có.",
    _mo ? "ĐỘ TRỰC DIỆN (truyện 18+): mạch chính đang có cảnh người lớn/khống chế nên hãy mô tả các nhịp đó THẲNG và CỤ THỂ đúng như cách chương vừa viết đã làm — nêu rõ hành động, đạo cụ, tư thế/vị trí và diễn biến bằng đúng từ ngữ của truyện. KHÔNG nói giảm nói tránh, không lược bỏ, không thay bằng cụm chung chung như \"cảnh nóng\"/\"cảnh thân mật\", không nhắc nhở hay bình luận đạo đức. Mọi nhân vật liên quan đều là người trưởng thành." : "",
    _mo ? "NHỊP CẢNH 18+: nếu chương sau có cảnh nóng, gợi ý PHẢI tách 3 phần và dành chỗ cho từng phần — (a) DẪN VÀO: không khí, lời nói/mệnh lệnh, từng bước áp sát và phản ứng đầu tiên; (b) DIỄN BIẾN + cao trào; (c) SAU CẢNH: dư chấn cơ thể, cảm xúc, thoại và hậu quả với quan hệ. Mỗi phần ít nhất 2–3 câu, không dồn hết vào cao trào." : "",
    "HƯỚNG CHƯƠNG SAU: " + (HINT_STYLES[styleKey] || HINT_STYLES.normal),
    names ? ("NHÂN VẬT (dùng đúng tên): " + names) : "",
    ctxBlock ? ("\n===== THIẾT LẬP & NGỮ CẢNH TRUYỆN (gợi ý PHẢI nhất quán với phần này) =====\n" + ctxBlock + "\n===== HẾT NGỮ CẢNH =====") : "",
    "", "TÓM TẮT CHƯƠNG VỪA VIẾT:", summary || text.slice(-3500),
    "", "ĐOẠN KẾT CHƯƠNG (để nối mạch):", text.slice(-1500),
    openThreads ? ("\nTHREADS ĐANG MỞ — CHỈ THAM KHẢO NẾU LIÊN QUAN TRỰC TIẾP:\n" + openThreads) : "",
    openForeshadowing ? ("\nFORESHADOWING — CHỈ THAM KHẢO NẾU LIÊN QUAN TRỰC TIẾP:\n" + openForeshadowing) : "",
    "\nNGÔN NGỮ ĐẦU RA BẮT BUỘC: 100% tiếng Việt có dấu.",
    "KHÔNG viết phân tích, không viết quá trình suy luận, không dùng tiếng Anh để giải thích yêu cầu.",
    "KHÔNG được bắt đầu bằng các cụm như \"For Chapter\", \"Let me start\", \"based on\", \"Requirements\" hoặc bất kỳ phần phân tích nào.",
    "ĐỘ DÀI BẮT BUỘC: khoảng " + hLo + "–" + hHi + " từ, không được vượt quá " + hHi + " từ." + (beats ? " Viết cô đọng, không lan man." : " Nếu nội dung có thể nói ngắn hơn thì vẫn phải đủ chi tiết trong khoảng này."),
    "Chỉ trả về NỘI DUNG CUỐI CÙNG của gợi ý chương theo đúng định dạng đã yêu cầu."
  ].filter(x=>x!=="" && x!=null).join("\n");
  try{
    // Aion 3.5 Mini là model reasoning: dành đủ ngân sách cho reasoning nhưng khóa FINAL ở khoảng 400–600 từ.
    /* V12.25: model reasoning hay dùng hết token để "nghĩ" -> nội dung cuối rỗng. Thử tối đa 3 lần:
       lần 1 như cũ; lần 2 tăng token; lần 3 tăng nữa và chuyển sang model chính nếu đang dùng model 18+. */
    const _tries = [
      { maxTokens:(_mo ? 5500 : 4000), modelOverride:_mo },
      { maxTokens:(_mo ? 8000 : 6000), modelOverride:_mo },
      { maxTokens:5000, modelOverride:undefined }
    ];
    /* V12.25c: nhận diện gợi ý BỊ CẮT (hết token / ngắt kết nối giữa chừng) để thử lại thay vì lưu nửa chừng. */
    const _endsOk = (t)=> /[.!?…。]["”'’»)\]*_~]*\s*$/.test(String(t||"").trim());
    const _isCut = (r, t)=>{
      const fr = String((r && r.finishReason) || "").toLowerCase();
      if(fr === "length" || fr === "max_tokens") return true;
      if(fr === "stop" || fr === "end_turn" || fr === "eos") return false;
      return !_endsOk(t);
    };
    const _trimToSentence = (t)=>{
      t = String(t||"").trim();
      const m = [...t.matchAll(/[.!?…]["”'’»)\]*_~]*(?=\s|$)/g)];
      if(!m.length) return t;
      const last = m[m.length-1]; const end = last.index + last[0].length;
      return end > t.length * 0.4 ? t.slice(0, end).trim() : t;
    };
    const _wc = (v)=> String(v||"").trim().split(/\s+/).filter(Boolean).length;
    /* gọi AI cho bước phụ (sửa tiếng Việt / rút gọn): chỉ nhận kết quả đầy đủ, không bị cắt */
    const _aux = async (promptStr, o)=>{
      try{
        const r = await callAI(promptStr, Object.assign({ reasoningEffort:"low" }, o));
        const t = String((r && r.text) || "").trim();
        if(!t || _isCut(r, t)) return null;
        return t;
      }catch(e){ if(e && e.userAbort) throw e; return null; }
    };
    let out = "", _lastErr = null, _partial = "";
    for(let _i = 0; _i < _tries.length && !out; _i++){
      if(typeof userStopRequested !== "undefined" && userStopRequested) break;
      try{
        const _o = { maxTokens:_tries[_i].maxTokens, temperature:0.55, modelOverride:_tries[_i].modelOverride, reasoningEffort:(_i < 2 ? "low" : undefined) };
        if(_i === 0 && opts && typeof opts.onPartial === "function"){ _o.streaming = true; _o.onChunk = (d, full)=>{ try{ opts.onPartial(full); }catch(_){} }; }
        const r = await callAI(prompt, _o);
        const _t = String((r && r.text) || "").trim();
        if(!_t){ _lastErr = new Error("AI trả nội dung rỗng"); }
        else if(_isCut(r, _t)){
          if(_t.length > _partial.length) _partial = _t;
          _lastErr = new Error("Gợi ý bị cắt giữa chừng (hết giới hạn token hoặc mất kết nối)");
          console.warn("[NextHint] lần " + (_i+1) + " bị cắt, finish=", r && r.finishReason);
        } else out = _t;
      }catch(e){
        if(e && e.userAbort) throw e;
        _lastErr = e;
        console.warn("[NextHint] lần " + (_i+1) + " lỗi:", e && e.message);
        if(e && /^(Chưa cấu hình|Chưa có API key|Chưa nhập model)/.test(e.message||"")) throw e;
      }
    }
    /* Cả 3 lần đều bị cắt: nếu đã được phần lớn thì cắt gọn ở câu cuối hoàn chỉnh, còn quá ngắn thì báo lỗi. */
    if(!out && _partial && _wc(_partial) >= Math.floor(hLo * 0.6)) out = _trimToSentence(_partial);
    if(!out){ if(_lastErr) throw _lastErr; return ""; }
    // Nếu final content vẫn lẫn tiếng Anh, yêu cầu model viết lại phần FINAL bằng tiếng Việt.
    if(detectNonVietnamese(out)){
      const fixPrompt = [
        "Viết lại NỘI DUNG GỢI Ý CHƯƠNG dưới đây thành 100% tiếng Việt có dấu.",
        "Không phân tích, không giải thích, không nhắc tới prompt hay yêu cầu.",
        "Giữ nguyên các nhân vật, sự kiện, địa điểm, trình tự và ý nghĩa; chỉ chuyển phần diễn đạt sang tiếng Việt tự nhiên.",
        "CHỈ TRẢ VỀ BẢN GỢI Ý CUỐI CÙNG.",
        "\nNỘI DUNG CẦN SỬA:\n" + out
      ].join("\n");
      {
        const fixed = await _aux(fixPrompt + "\n\nĐỘ DÀI: giữ trong khoảng " + hLo + "–" + hHi + " từ, tuyệt đối không vượt " + hHi + " từ." + (beats ? " Giữ dòng cuối bắt đầu bằng \"→ Kết chương ở:\"." : ""), {maxTokens:(_mo ? 4500 : 3000), temperature:0.25, modelOverride:_mo});
        if(fixed && !detectNonVietnamese(fixed)) out = fixed;
      }
    }

    // Giữ gợi ý ở quy mô vừa phải (theo kiểu đã chọn). Nếu model trả quá dài, yêu cầu nén lại.
    const countHintWords = (value)=>String(value||"").trim().split(/\s+/).filter(Boolean).length;
    let hintWords = countHintWords(out);
    if(hintWords > Math.ceil(hHi * 1.3)){   /* vượt nhiều mới tốn thêm 1 lượt gọi AI để rút gọn; vượt ít thì chỉ cắt ở cuối câu bên dưới */
      const compactPrompt = [
        "RÚT GỌN GỢI Ý CHƯƠNG DƯỚI ĐÂY.",
        "Giữ nguyên nhân vật, sự kiện, địa điểm, trình tự, xung đột và cú chốt.",
        "Không bỏ các chi tiết quan trọng; chỉ loại bỏ diễn giải, lặp ý và câu thừa.",
        beats ? "Giữ đúng định dạng **Gợi ý ngắn Chương ...:**, các đoạn kể nhịp và dòng cuối \"→ Kết chương ở: ...\"." : "Giữ đúng định dạng **Gợi ý ngắn Chương ...:** và 4–6 đoạn cảnh.",
        "ĐỘ DÀI BẮT BUỘC: " + hLo + "–" + hHi + " từ, tuyệt đối không vượt " + hHi + " từ.",
        "CHỈ TRẢ BẢN GỢI Ý CUỐI CÙNG, 100% tiếng Việt có dấu.",
        "\nGỢI Ý CẦN RÚT GỌN:\n" + out
      ].join("\n");
      {
        const compact = await _aux(compactPrompt, {maxTokens:(_mo ? 4500 : 3000), temperature:0.2, modelOverride:_mo});
        if(compact && !detectNonVietnamese(compact) && countHintWords(compact) <= hHi * 1.15) out = compact;
      }
      hintWords = countHintWords(out);
    }

    // Hard cap cuối cùng để không bao giờ lưu một gợi ý quá dài vào state.
    /* V12.25c: chỉ cắt khi vượt rõ (>15%), luôn cắt ở CUỐI CÂU, và giữ dòng "→ Kết chương ở" nếu có (không cắt cứng giữa câu). */
    if(hintWords > Math.ceil(hHi * 1.15)){
      let tail = "", body = out;
      const _ln = out.split("\n");
      if(_ln.length > 1 && /^\s*→/.test(_ln[_ln.length-1])){ tail = _ln.pop().trim(); body = _ln.join("\n").trim(); }
      const room = Math.max(40, hHi - countHintWords(tail));
      const words = body.split(/\s+/).filter(Boolean);
      if(words.length > room){
        body = _trimToSentence(words.slice(0, room).join(" "));
        out = (body + (tail ? "\n" + tail : "")).trim();
      }
    }
    return out;
  }catch(err){ console.warn("[NextHint]", err.message); throw err; }
}
$ID("regenSummaryBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  setStatus("Đang tạo lại tóm tắt...", true);
  try{
    const sum = await generateChapterSummary(state.chapters[idx].text, idx+1, false);
    if(sum){ state.chapters[idx].summary = sum; persist(); renderChapterNav(); renderCurrentChapter(); setStatus("Đã tạo lại tóm tắt.", false); }
    else setStatus("Không tạo được.", false);
  }catch(e){ setStatus("Lỗi: " + e.message, false); }
});


/* V12.19: viết lại gợi ý THEO Ý NGƯỜI DÙNG (nội dung đang ghi ở ô Gợi ý chương sau được coi là ý tưởng ưu tiên tuyệt đối). */
let _hintBackup = null;
$ID("rewriteHintBtn").addEventListener("click", async ()=>{
  const idx = state.chapters.length-1;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  const idea = String(nextChapterHintEl.value || "").trim();
  if(!idea){ setStatus("Hãy gõ ý tưởng của bạn vào ô Gợi ý chương sau trước, rồi bấm lại.", false); return; }
  const hs=$ID("hintStyle"); if(hs) state.hintStyle=hs.value; const hf=$ID("hintFormat"); if(hf) state.hintFormat=hf.value;
  setStatus("Đang viết lại gợi ý theo ý bạn...", true);
  try{
    const ch = state.chapters[idx];
    const hint = await generateNextChapterHint(ch.text, ch.summary, idx+1, { userIdea: idea });
    if(hint){ _hintBackup = idea; state.nextChapterHint = hint; state.nextChapterHintMeta = { targetChapter: idx + 2, version: Number(state.nextChapterHintMeta && state.nextChapterHintMeta.version || 0) + 1, status: "active", updatedAt: Date.now(), source: "ai_rewrite" }; nextChapterHintEl.value = hint; persist(); setStatus("Đã viết lại gợi ý theo ý bạn. Bấm ↩ Khôi phục nếu muốn quay lại bản bạn gõ.", false); }
    else setStatus("Không viết lại được gợi ý (giữ nguyên nội dung của bạn).", false);
  }catch(e){ setStatus("Lỗi: " + e.message + " (giữ nguyên nội dung của bạn)", false); }
});
$ID("undoHintBtn").addEventListener("click", ()=>{
  if(_hintBackup == null){ setStatus("Chưa có bản nào để khôi phục.", false); return; }
  state.nextChapterHint = _hintBackup; state.nextChapterHintMeta = { targetChapter: (state.chapters || []).length + 1, version: Number(state.nextChapterHintMeta && state.nextChapterHintMeta.version || 0) + 1, status: _hintBackup ? "active" : "inactive", updatedAt: Date.now(), source: "user_restore" }; nextChapterHintEl.value = _hintBackup; _hintBackup = null; persist();
  setStatus("Đã khôi phục nội dung gợi ý bạn đã gõ.", false);
});
$ID("regenHintBtn").addEventListener("click", async ()=>{
  const idx = state.chapters.length-1;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  const hs=$ID("hintStyle"); if(hs) state.hintStyle=hs.value; const hf=$ID("hintFormat"); if(hf) state.hintFormat=hf.value;
  setStatus("Đang tạo gợi ý chương sau...", true);
  try{
    const ch = state.chapters[idx];
    const hint = await generateNextChapterHint(ch.text, ch.summary, idx+1);
    if(hint){ state.nextChapterHint = hint; state.nextChapterHintMeta = { targetChapter: idx + 2, version: Number(state.nextChapterHintMeta && state.nextChapterHintMeta.version || 0) + 1, status: "active", updatedAt: Date.now(), source: "ai" }; nextChapterHintEl.value = hint; persist(); setStatus("Đã tạo gợi ý chương sau.", false); }
    else setStatus("Không tạo được gợi ý.", false);
  }catch(e){ setStatus("Lỗi: " + e.message, false); }
});

/* ========== DUPLICATE CHECK ========== */
function checkDuplicates(newText){
  if(!state.dupCheckEnabled) return [];
  const warnings = [];
  const sentences = newText.split(/[.!?]\s+/).map(s=>s.trim()).filter(s=>s.length > 40);
  const recentOld = state.chapters.slice(-8).map(c=>normalizeName(c.text));
  sentences.slice(0, 30).forEach(s=>{
    const sn = normalizeName(s);
    if(sn.length < 30) return;
    recentOld.forEach(oldText=>{
      if(oldText.includes(sn.slice(0, 60))){
        warnings.push({ severity: "low", problem: "Câu có thể trùng với chương trước: \"" + s.slice(0, 80) + "...\"", suggestion: "Cân nhắc diễn đạt lại." });
      }
    });
  });
  return warnings.slice(0, 5);
}

/* ========== STORY CONTROL LAYER ========== */
function storyControlPromptClient(){ return storyControlPrompt(state); }
/* V12.32.4: HỒ SƠ KHÓA cho prompt viết chương: NVC + tối đa 8 nhân vật liên quan nhất (short=true cho các lượt viết tiếp). */
function characterLockPromptClient(short){
  try{ return characterLockPrompt(state.mainCharProfile, relevantCharacters(8), !!short); }catch(e){ return ""; }
}

/* V12.23: prompt viết chương chính — MỘT nguồn duy nhất cho viết thường (index.html) và viết nền (worker, được scripts/sync-shared.js sao chép nguyên văn).
   o.proseOnly=true: viết nền chỉ nhận văn xuôi (tên chương do hệ thống tạo). */
function buildMainWritePrompt(o){
  const chapterHint = o.hintVerified === false ? "" : String(state.nextChapterHint || "");
  const { chapterNumber, isRegen, regenIndex, regenMode, descPrompt, explicitPrompt, vocabBlock, usingNsfw, context, lastChapterEnding, recentFullText, olderSummaries, plan } = o;
  const regenInstructions = {
      full: "Viết lại toàn bộ chương với văn phong tự nhiên, không lặp ý cũ.",
      continuity: "Chỉ sửa lỗi continuity, giữ nguyên cốt truyện và giọng văn.",
      depth: "Giữ sự kiện, đào sâu nội tâm và phản ứng cơ thể.",
      describe: "Giữ sự kiện, TĂNG CƯỜNG miêu tả: ngoại hình nhân vật, không khí, giác quan, chi tiết nhỏ. Không lặp lại.",
      world: "Giữ cốt truyện, bổ sung world-building qua giác quan.",
      pacing: "Giữ sự kiện, cải thiện nhịp.",
      nsfw_rewrite: "Viết lại với chi tiết 18+ táo bạo, giác quan, nội tâm."
    };

  return [
    "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU. Không tiếng Anh/Trung/Nhật/Hàn.",
    "GIỌNG VĂN: Tự nhiên như người viết thật. Câu có nhịp, có chỗ ngắn chỗ dài, có khoảng lặng.",
    vietnameseNovelWritingPrompt(),
    "",
    "Bạn là tiểu thuyết gia chuyên viết truyện dài kỳ tiếng Việt.",
    "BẮT BUỘC: Bạn đang viết CHƯƠNG THỨ " + chapterNumber + ".",
    "Truyện hiện có " + o.priorCount + " chương trước đó.",
    "",
    "🎨 " + descPrompt,
    "",
    "Bối cảnh:", context || "(chưa có — tự sáng tạo hợp lý)", "",
    storyControlPromptClient(), "",
    characterLockPromptClient(false), "",
    progressRulesPrompt(state), "",
    appearanceAnchorPrompt(state, usingNsfw), "",
    lastChapterEnding ? ("===== ĐOẠN KẾT CHƯƠNG TRƯỚC (PHẢI TIẾP NỐI) =====\n" + lastChapterEnding + "\n===== HẾT =====\n\nChương mới tiếp nối đoạn kết trên: nếu đoạn kết còn một cảnh đang dở thì PHẢI bắt đầu từ đúng cảnh đó; nếu sự kiện đã khép trọn thì ĐƯỢC cho thời gian trôi bằng một câu chuyển tự nhiên trong mạch kể (hôm sau, vài ngày sau… — không dùng nhãn ngày giờ) theo mục THỜI GIAN TRUYỆN.\nĐỊA ĐIỂM MỞ CHƯƠNG — KHÓA CỨNG: đoạn mở đầu PHẢI diễn ra ĐÚNG địa điểm, thời điểm và với đúng những người đang có mặt như trong đoạn kết chương trước (ví dụ chương trước kết ở biệt thự của A thì chương này vẫn bắt đầu ở biệt thự của A). Chỉ được chuyển địa điểm khi đoạn kết đã nói rõ nhân vật sắp rời đi/đến nơi khác, hoặc sau một câu chuyển cảnh tự nhiên trong mạch kể (di chuyển, thời gian trôi). Tuyệt đối không nhảy sang nhà/phòng trọ/nơi ở của nhân vật khác ngay từ câu đầu.") : "",
    recentFullText ? ("\nChương gần (tránh lặp sự kiện / cấu trúc):\n" + recentFullText) : "",
    olderSummaries ? ("\nTÓM TẮT CHƯƠNG XA:\n" + olderSummaries) : "",
    plan ? ("\nKẾ HOẠCH CHƯƠNG " + chapterNumber + ":\n" + plan) : "",
    plan ? "\nBEAT LEDGER — CÁCH THI HÀNH: mã [R1], [R2]... là Required Beat bắt buộc; mã [S1], [S2]... là Support Beat do AI đề xuất, chỉ dùng khi giúp mạch truyện tự nhiên. Viết các [R] theo đúng thứ tự và để lại bằng chứng rõ trong văn xuôi bằng hành động, lời thoại, thông tin hoặc hậu quả. Trước khi viết đoạn kết, tự kiểm tra từng [R]. Nếu còn [R] chưa có bằng chứng, KHÔNG được kết chương; phải viết beat còn thiếu trước rồi mới đi tới Ending Anchor. Không được biến [S] thành nghĩa vụ hoặc mở tuyến độc lập." : "",
    "\nNGÂN SÁCH SỰ KIỆN — BẮT BUỘC:",
    "- Toàn chương chỉ có 1–3 SỰ KIỆN CHÍNH. Không thêm sự kiện lớn thứ 4 dù còn dung lượng từ.",
    "- Các cảnh/beat nhỏ là bước triển khai, phản ứng hoặc hậu quả của 1–3 sự kiện trục. Được phép có biến cố lớn lồng bên trong một sự kiện trục khi có quan hệ nhân-quả trực tiếp và thật sự cần; ghi rõ nó thuộc sự kiện nào, không mở thành tuyến độc lập, không tính là sự kiện chính thứ 4 và không tự thêm nếu không cần.",
    "- Nếu chương cần dài hơn, trước hết đào sâu diễn biến, đối thoại, nội tâm, nguyên nhân–hậu quả và chi tiết cảnh. Chỉ thêm biến cố lồng khi nó làm rõ hoặc đẩy một sự kiện trục tiến lên; không nhồi thêm cho đủ chữ. Mỗi sự kiện trục phải là một BƯỚC TIẾN thật về phía mục tiêu Arc/Outline (nếu có mục TIẾN ĐỘ ARC/OUTLINE thì thực hiện đúng việc bắt buộc của chương), không dừng lại ở bước đã làm.",
    "\nNHÂN VẬT PHỤ — BẮT BUỘC:",
    "- GIỚI HẠN CỨNG: TỐI ĐA " + normalizeStoryControl(state).maxNamedCharacters + " NHÂN VẬT CÓ TÊN RIÊNG xuất hiện TRỰC TIẾP (có lời thoại hoặc hành động cụ thể) trong toàn chương, tính cả nhân vật chính. Đám đông/người qua đường không tên không tính vào số này.",
    "- Nếu chương 1 hoặc mở đầu một arc mới cần giới thiệu bối cảnh, KHÔNG dồn hết dàn nhân vật vào 1 chương — chỉ giới thiệu những ai TRỰC TIẾP tham gia 1-3 sự kiện chính của CHƯƠNG NÀY; người còn lại để dành cho chương sau.",
    "- Ưu tiên sử dụng nhân vật đã tồn tại trong hồ sơ truyện (xem mục NHÂN VẬT ĐÃ CÓ TRONG TRUYỆN ở Bối cảnh phía trên); không tùy tiện tạo nhân vật quan trọng mới.",
    "- Mỗi nhân vật xuất hiện phải có LÝ DO rõ ràng và VAI TRÒ cụ thể đối với một trong 1–3 sự kiện chính.",
    "- Nếu một nhân vật mới không thực sự cần cho cốt truyện, KHÔNG được tạo chỉ để lấp cảnh, đối thoại hoặc làm nền.",
    "- Nhân vật mới có vai trò quan trọng chỉ được xuất hiện khi kế hoạch đã chứng minh nhu cầu cốt truyện; nếu không có trong kế hoạch, không tự ý nâng một nhân vật mới thành nhân vật quan trọng.",
    "- TRƯỚC KHI VIẾT: tự đếm lại số nhân vật có tên riêng dự kiến xuất hiện; nếu quá " + normalizeStoryControl(state).maxNamedCharacters + ", cắt bớt hoặc chuyển bớt sang không tên.",
    (relevantCharacters(1).length === 0) ? "- CHƯA CÓ NHÂN VẬT PHỤ NÀO ĐƯỢC KHAI BÁO TRƯỚC. Người chỉ thoáng qua (người gác cổng, khách quán, người qua đường) để KHÔNG TÊN. Nhân vật có vai trò lặp lại hoặc gắn với mạch truyện (đối tác, người thân, đồng nghiệp, đối thủ, người tình, cấp trên) thì ĐẶT TÊN RIÊNG ngay khi xuất hiện, kèm vai trò/lý do rõ ràng để hồ sơ ghi nhận. Truyện dài cần dàn nhân vật mở rộng dần theo outline: nếu brief/outline cho phép, được giới thiệu thêm một nhân vật phụ có tên và có vai trò lặp lại khi cốt truyện cần." : "",
    isRegen ? ("\nVIẾT LẠI chương " + chapterNumber + ". Chế độ: " + (regenInstructions[regenMode]||regenInstructions.full)) : "",
    vocabBlock ? ("\n" + vocabBlock) : "",
    "",
    "ĐỘ DÀI & TỰ DO SÁNG TÁC: mục tiêu " + (state.minChapterWords || 5000) + " từ, tối thiểu " + Math.round((state.minChapterWords || 5000) * 0.95) + " từ. GỢI Ý/BRIEF LÀ XƯƠNG SỐNG, không phải kịch bản từng câu: bạn được TỰ DO sáng tác phần thân chương — thêm cảnh phụ, chuyển cảnh, hội thoại, nội tâm, cảm xúc, phản ứng, giác quan, hành động nhỏ, nguyên nhân–hậu quả, các nhịp nhỏ bên trong sự kiện — để chương tự nhiên và dài. Mỗi ý/nhịp trong brief phải thành MỘT CẢNH ĐẦY ĐỦ (bối cảnh, hành động, thoại, phản ứng, hệ quả), không tóm tắt, không nhảy cóc thời gian. Mọi cảnh phụ phải mang thông tin/cảm xúc/quyết định/thế chủ động MỚI; không lặp ý, không độn chữ. GIỚI HẠN: chỉ các sự kiện chính có trong brief, không thêm biến cố lớn ngoài brief; không phá canon; không mở arc lớn, không thêm nhân vật quan trọng mới, không tiết lộ thông tin để dành chương sau, không đổi hướng truyện. ENDING ANCHOR (điểm kết của brief) là điểm đích DUY NHẤT bắt buộc: chỉ chạm tới ở ĐOẠN CUỐI sau khi đã đủ độ dài; viết xong thì DỪNG HẲN.",
    "CHỐNG LẶP: Không lặp sự kiện, cách giải quyết, cấu trúc, cụm từ, hình ảnh đã dùng.",
    state.pronounRules ? ("\nQUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
    usingNsfw ? ("\n" + EROTIC_STYLE_PROMPT) : "",
    usingNsfw ? ("\nMỨC 18+ BẮT BUỘC: " + explicitPrompt) : "",
    state.mature && !usingNsfw ? "Văn phong trưởng thành được phép." : "",
    "",
    o.proseOnly ? "QUY TẮC ĐẦU RA: CHỈ viết văn xuôi của chương; tên chương do hệ thống quản lý riêng." : "QUY TẮC TIÊU ĐỀ: Chỉ TÊN CHƯƠNG tiếng Việt, KHÔNG chữ 'Chương', KHÔNG số.",
    "",
    "===== NHẮC LẠI =====",
    "1. 100% TIẾNG VIỆT CÓ DẤU.",
    o.proseOnly ? "2. Chỉ văn xuôi của chương, không tiêu đề." : "2. Tiêu đề tiếng Việt, không chữ 'Chương', không số.",
    "3. Tiếp nối liền mạch từ đoạn kết chương trước.",
    "4. Xưng hô nhất quán.",
    "5. Không lặp ý, không lặp câu.",
    ((state.directive || state.nextChapterHint) ? "6. SỰ KIỆN: đúng các nhịp trong brief, mỗi nhịp phải viết đủ dài; không thêm biến cố lớn ngoài brief." : "6. MỖI CHƯƠNG CHỈ 1–3 SỰ KIỆN CHÍNH; không nhồi biến cố mới ngoài ngân sách."),
    "7. MỖI NHÂN VẬT XUẤT HIỆN PHẢI CÓ LÝ DO + VAI TRÒ; ưu tiên nhân vật đã có ở danh sách NHÂN VẬT ĐÃ CÓ TRONG TRUYỆN phía trên, không tùy tiện tạo nhân vật quan trọng mới.",
    "8. MIÊU TẢ: khi nhân vật mới xuất hiện hoặc cảnh mới mở, TẢ ngoại hình + không khí qua chi tiết cụ thể.",
    "9. BỐ CỤC: chia thành nhiều đoạn ngắn 2–4 câu (tối đa ~90 từ/đoạn), các đoạn cách nhau MỘT DÒNG TRỐNG. Mỗi lượt thoại nằm trên MỘT ĐOẠN RIÊNG (mở bằng dấu “ hoặc —). Đổi cảnh/đổi người nói/đổi nhịp thì xuống đoạn mới. TUYỆT ĐỐI không viết một khối văn liền dài.",
    state.directive ? ("===== BRIEF NGƯỜI DÙNG — ƯU TIÊN CAO NHẤT =====\nMỆNH LỆNH TOÀN VẸN (KHÔNG ĐƯỢC CẮT):\n" + String(state.directive) + "\n===== HẾT MỆNH LỆNH =====") : "",
    chapterHint ? ("===== GỢI Ý NGƯỜI DÙNG — PHẢI BÁM ĐẦY ĐỦ =====\n" + chapterHint + "\n===== HẾT GỢI Ý =====") : "",
    (state.directive || state.nextChapterHint) ? [
      "QUY TẮC BÁM BRIEF NGƯỜI DÙNG:",
      "- Phải thực hiện ĐẦY ĐỦ từng yêu cầu, chi tiết, hành động và mốc mà người dùng đã ghi; không được bỏ qua chỉ vì kế hoạch tự tạo khác.",
      "- Nếu người dùng nêu KHÚC ĐẦU và KHÚC KẾT của cùng một cảnh, hai điểm đó là ANCHOR BẮT BUỘC. Viết cầu nối giữa chúng nhưng không được đổi điểm bắt đầu hoặc điểm kết thúc.",
      "- Được thêm cảnh phụ, thoại, nội tâm, chi tiết đời thường bên trong các sự kiện của brief. Không tự mở tuyến truyện mới, không thêm mục tiêu phụ lớn, không thêm biến cố lớn, không đưa nhân vật mới quan trọng vào nếu brief không yêu cầu.",
      "- Không dùng phần bối cảnh/threads/foreshadowing để lấn át brief. Những thứ đó chỉ dùng để giữ continuity khi không mâu thuẫn.",
      "- Đạt độ dài bằng cách đào sâu diễn biến bên trong brief (không bơm tuyến khác, không kéo dài hậu cảnh sau điểm kết). Chỉ kết khi đã đủ độ dài VÀ đã tới Ending Anchor; viết xong anchor thì dừng.",
      "- Trước khi kết thúc, tự kiểm tra: (1) đã triển khai đủ các điểm người dùng yêu cầu chưa; (2) đã đi tới mốc kết thúc chưa; (3) có tự thêm tuyến/nhân vật/biến cố ngoài brief không."
    ].join("\n") : "",
    buildLengthPlan(chapterHint || state.directive, (state.minChapterWords || 5000)),
    (state.mainCharProfile && state.mainCharProfile.name) ? ("10. NHÂN VẬT CHÍNH LÀ TRỤC CỦA CHƯƠNG NÀY (phải có mặt; nhân vật phụ vẫn được có cảnh/việc riêng và hành động chủ động): " + state.mainCharProfile.name + (state.mainCharProfile.appearance ? (" — " + String(state.mainCharProfile.appearance).slice(0,150)) : "") + ". TUYỆT ĐỐI không viết chương mà thiếu hẳn nhân vật này, và không đổi tên/nhầm sang nhân vật khác.") : "",
    usingNsfw ? "7. CẢNH 18+ ƯU TIÊN CAO NHẤT — đủ 4 lớp: cơ thể (số đo hồ sơ) + cảm giác thể xác + nội tâm đa lớp + âm thanh/nhịp. Cấm chỉ kể hành động bên ngoài. Cấm bỏ cảm giác và nội tâm." : "7. (không có yêu cầu 18+ đặc biệt)",
    ...(o.proseOnly ? ["8. Định dạng: CHỈ văn xuôi của chương — KHÔNG xuất 'TIÊU ĐỀ:', 'NỘI DUNG:', markdown, ghi chú hay lời giải thích."] : ["8. Định dạng:", "TIÊU ĐỀ: <tên chương>", "NỘI DUNG:", "<toàn bộ chương>"])
  ].filter(Boolean).join("\n");
}

/* V14.7.7: số chương liền trước chưa có cảnh nóng (dựa trên từ khóa NSFW của chương). */
function heatFreeStreakBefore(chapterNumber){
  let n = 0;
  for(let i = Number(chapterNumber) - 2; i >= 0; i--){
    const ch = state.chapters && state.chapters[i];
    const txt = String(ch && (ch.text || ch.content || ch.body) || "");
    if(!txt) break;
    if(textHasNsfwKeyword(txt)) break;
    n++;
  }
  return n;
}
/* ========== BUILD PLAN ========== */
async function buildChapterPlan(context, recent, chapterNumber){
  const hintMeta = chapterHintVerification(state, chapterNumber);
  const prompt = buildChapterPlanPrompt({ chapterNumber, context, recent, directive: state.directive, hint: hintMeta.text,
    hintVerified: hintMeta.verified, maxNamedCharacters: normalizeStoryControl(state).maxNamedCharacters,
    mainCharName: state.mainCharProfile && state.mainCharProfile.name, storyControl: storyControlPromptClient(),
    mature: !!state.mature, matureFocus: state.chapterMatureFocus, heatFreeStreak: heatFreeStreakBefore(chapterNumber), castPool: castPoolForPlan(state, chapterNumber) });
  try{
    let r = await callAI(prompt, {maxTokens:2400, temperature:0.4});
    if(String(r && r.finishReason || "").toLowerCase()==="length"){
      r = await callAI(prompt + "\n\nCẢNH BÁO: Kế hoạch trước bị cắt. Bắt buộc trả đủ Chapter Contract, toàn bộ [R] và [S], REQUIRED_DONE, STOP_AFTER và CONFLICT nếu có; không dừng giữa một beat.", {maxTokens:3200, temperature:0.25});
    }
    return String(r && r.text || "").trim();
  }catch(err){ return ""; }
}

/* V12.24: hỏi AI xem chương đã VIẾT TỚI điểm kết của gợi ý chưa. reached: true | false | null (lỗi/không đọc được -> coi là không biết). */
async function checkChapterEnding(text, ending, hint, directive){
  try{
    const { text: raw } = await callAI(buildEndingCheckPrompt({ text: text, ending: ending, hint: hint, directive: directive, wc: countWords(text) }), {
      maxTokens: 400, temperature: 0.1, modelOverride: state.model, skipTracking: true
    });
    return parseEndingCheck(raw);
  }catch(e){
    if(e && e.userAbort) throw e;
    console.warn("[EndingCheck]", e && e.message);
    return { reached: null, missing: "" };
  }
}

/* V12.24: brief + điểm kết của MỘT chương đã viết. Chương mới có briefUsed (lưu lúc viết). Chương cũ chưa có thì lấy dòng
   "Kết chương" trong kế hoạch của chương. KHÔNG dùng ô Gợi ý hiện tại: sau khi viết xong, ô đó là gợi ý của chương SAU. */
function chapterBriefFor(ch){
  const b = ch && ch.briefUsed;
  if(b && (String(b.hint||"").trim() || String(b.directive||"").trim())){
    return { hint: String(b.hint||""), directive: String(b.directive||""), ending: getEndingTarget(b.hint, b.directive) };
  }
  return { hint: "", directive: "", ending: (ch && ch.plan) ? extractClosingBeat(ch.plan) : "" };
}

/* V12.31: context tiếp chương không nhập Gợi ý của chương sau; briefUsed chỉ dùng ở prompt hoàn tất/điểm kết riêng của chính chương đó. */
function buildContextBlockForChapter(ch){
  const b = ch && ch.briefUsed;
  if(!b || !(String(b.hint||"").trim() || String(b.directive||"").trim())) return buildContextBlock({includeChapterInstructions:false});
  const keepH = state.nextChapterHint, keepD = state.directive;
  state.nextChapterHint = String(b.hint||""); state.directive = String(b.directive||"");
  try{ return buildContextBlock({includeChapterInstructions:false}); }
  finally{ state.nextChapterHint = keepH; state.directive = keepD; }
}

async function autoContinueUntilDone(chapterObj, chapterNumber, initialModel, initialNsfw, onChunk){
  let targetModel = initialModel;
  let usingNsfw = initialNsfw;
  if(!state.autoContinueEnabled || state.adaptiveScenePipeline !== false) return chapterObj;
  const limits=chapterWordLimits();
  const minWords=limits.target, maxWords=limits.hardMax;
  const maxAttempts = state.autoContinueMax || 4;
  let attempts = 0, insertUsed = 0;
  // V12.24: điểm kết cần chạm tới (chỉ khi có gợi ý). endChk = kết quả kiểm tra mới nhất; null = chưa kiểm tra / đã cũ (văn bản vừa đổi).
  const endingTarget = getEndingTarget(state.nextChapterHint, state.directive);
  const canCheckEnding = !!endingTarget && !!(String(state.directive||"").trim() || String(state.nextChapterHint||"").trim());
  let endChk = null;
  const stopReasons = [];   // V12.23: lý do từng lượt thất bại / lý do dừng, báo ra status + chẩn đoán chương
  const failAttempt = (why) => { stopReasons.push("#" + attempts + ": " + why); console.warn("[Auto-continue] #" + attempts + " " + why); };
  let endNote = "";
  while(true){
    const wc = countWords(chapterObj.text);
    const hasUserBrief = !!(String(state.directive||"").trim() || String(state.nextChapterHint||"").trim());
    if(wc >= maxWords){ endNote = "đã chạm giới hạn tối đa " + maxWords + " từ"; break; }
    // V12.24: KIỂM TRA ĐIỂM KẾT — trước đây chỉ đếm số từ nên chương dừng khi chưa tới kết, và "chèn diễn biến" còn chèn vào giữa
    // truyện (vì tưởng mấy đoạn cuối đã là đoạn kết). Giờ hỏi AI chương đã tới điểm kết chưa.
    if(canCheckEnding && !endChk){
      setStatus("Kiểm tra chương đã tới điểm kết chưa (" + wc + " từ)...", true);
      endChk = await checkChapterEnding(chapterObj.text, endingTarget, state.nextChapterHint, state.directive);
    }
    const endMissing = !!(endChk && endChk.reached === false);
    // V12.22: có brief -> mục tiêu 95% target; không brief -> 100% target.
    const goalWords = hasUserBrief ? Math.round(minWords*0.95) : minWords;
    if(wc >= goalWords && !endMissing){ endNote = ""; break; }
    // V12.23: số lượt viết thêm = ĐÚNG số Auto-continue đã đặt. V12.24: chưa tới điểm kết thì được thêm tối đa ENDING_FINISH_EXTRA lượt "chốt kết".
    const attemptLimit = maxAttempts + ((endMissing && maxAttempts > 0) ? ENDING_FINISH_EXTRA : 0);
    if(attempts >= attemptLimit){ endNote = endMissing ? ("đã dùng hết " + attempts + " lượt mà chương vẫn chưa tới điểm kết") : ("đã dùng hết " + maxAttempts + "/" + maxAttempts + " lượt Auto-continue"); break; }
    // V12.24: chưa tới điểm kết -> VIẾT TIẾP ĐỂ CHẠM KẾT (không chèn vào giữa).
    const finishMode = endMissing;
    // Có brief + model đã kết (không bị cắt) mà còn ngắn -> CHÈN thêm diễn biến trước đoạn kết (giữ Ending Anchor).
    const insertMode = !finishMode && hasUserBrief && chapterObj.truncated !== true;
    attempts++;

    /* Auto NSFW giữa chương: từ khóa + nhiệt độ */
    if(state.nsfwMode === "auto" && matureFocusAllowsRouting() && state.modelNsfw && !usingNsfw){
      try{
        const tailMid = chapterObj.text.slice(-2000);
        if(shouldForceNsfwByKeyword(chapterObj.plan, tailMid)){
          targetModel = state.modelNsfw;
          usingNsfw = true;
          chapterObj.modelUsed = targetModel;
          chapterObj.isNsfw = true;
          setStatus("🔥 Giữa chương — từ khóa 18+ → " + shortModelName(targetModel), true);
        } else {
          const heat = await detectHeatLevel(tailMid, chapterObj.plan);
          if(heat >= (state.nsfwAutoThreshold || 6)){
            targetModel = state.modelNsfw;
            usingNsfw = true;
            chapterObj.modelUsed = targetModel;
            chapterObj.isNsfw = true;
            setStatus("🔥 Giữa chương nóng (" + heat + "/10) → " + shortModelName(targetModel), true);
          }
        }
      }catch(e){}
    }

    setStatus("Auto-continue #" + attempts + " (đang " + wc + "/" + minWords + " từ)...", true);
    const tail = chapterObj.text.slice(-2200);
    const headHint = chapterObj.text.slice(0, 250);
    const prompt = [
      "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU. Giọng tự nhiên.",
      "",
      "Bạn đang VIẾT TIẾP chương " + chapterNumber + " (KHÔNG mở chương mới, KHÔNG tóm tắt).",
      ((wc < minWords * 0.85)
        ? ("Chương mới được " + wc + "/" + minWords + " từ, CÒN THIẾU NHIỀU. Hãy viết tiếp diễn biến mới hợp lý, liền mạch (thêm cảnh, hội thoại, nội tâm, hành động, hệ quả) để tiến tới khoảng " + minWords + " từ; KHÔNG kết chương sớm. GIỚI HẠN CỨNG " + maxWords + " từ.")
        : ("Chỉ viết tiếp khi đoạn hiện tại thực sự bị cắt giữa chừng. Không kéo dài để đạt chỉ tiêu từ nếu brief/ngữ cảnh đã hoàn tất. GIỚI HẠN CỨNG " + maxWords + " từ. Hiện " + wc + " từ.")),
      "",
      "===== ĐOẠN CUỐI HIỆN TẠI (PHẢI TIẾP NỐI TỪ ĐÂY) =====",
      tail,
      "===== HẾT =====",
      "",
      "YÊU CẦU LIỀN MẠCH:",
      "- Bắt đầu ngay từ câu tiếp theo của đoạn cuối. Không nhảy cảnh, không 'sau đó'.",
      "- Giữ đúng nhân vật, địa điểm, trạng thái cảm xúc / dục vọng đang diễn ra.",
      "- Không lặp ý, không lặp cụm từ, không lặp hình ảnh đã có.",
      "- Câu văn có nhịp người thật: chỗ ngắn chỗ dài, có khoảng lặng.",
      "MỨC MIÊU TẢ: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
      characterLockPromptClient(true),
      "NGOẠI HÌNH: khi tả cơ thể/ngoại hình phải kèm kích thước hoặc so sánh cụ thể (bám SỐ ĐO trong hồ sơ nếu có), không chỉ tính từ chung chung.",
      "TIẾN TRIỂN: lượt viết tiếp phải đẩy tình huống sang BƯỚC KẾ TIẾP (quan hệ/thông tin/hậu quả thay đổi), không lặp hành động hay miêu tả đã có.",
      chapterObj.plan ? ("Kế hoạch còn lại:\n" + chapterObj.plan) : "",
      usingNsfw ? ("\n" + EROTIC_STYLE_PROMPT) : "",
      usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
      state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
      "",
      "CHỈ TRẢ VỀ phần viết tiếp (không tiêu đề, không giải thích). TUYỆT ĐỐI không xuất \"TIÊU ĐỀ:\"/\"NỘI DUNG:\" và không viết lại chương từ đầu, kể cả dưới dạng diễn đạt khác."
    ].filter(Boolean).join("\n");
    let ins = null, insertPrompt = "", finishPrompt = "";
    if(finishMode){
      finishPrompt = buildFinishPrompt({
        chapterNumber: chapterNumber, wc: wc, goal: goalWords, maxWords: maxWords,
        ending: endingTarget, missing: endChk.missing, hint: state.nextChapterHint, directive: state.directive,
        tail: chapterObj.text.slice(-3500),
        style: [ "MỨC MIÊU TẢ: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
                 usingNsfw ? EROTIC_STYLE_PROMPT : "", usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
                 state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "", characterLockPromptClient(true) ].filter(Boolean).join("\n")
      });
      setStatus("Chương chưa tới điểm kết — viết tiếp để chốt kết #" + attempts + " (đang " + wc + " từ)...", true);
    }
    if(insertMode){
      insertUsed++;
      const ps = String(chapterObj.text).split(/\n\s*\n/).map(x=>x.trim()).filter(Boolean);
      let k = ps.length, ew = 0;
      while(k > 1 && ew < 150 && ps.length - k < 4){ k--; ew += countWords(ps[k]); }
      ins = { body: ps.slice(0,k).join("\n\n"), ending: ps.slice(k).join("\n\n") };
      if(!ins.body || !ins.ending){ failAttempt("không tách được đoạn kết để chèn diễn biến"); break; }
      const closingIns = extractClosingBeat(state.nextChapterHint) || extractClosingBeat(state.directive);
      insertPrompt = [
        "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU. Giọng tự nhiên.",
        "",
        "CHÈN THÊM DIỄN BIẾN vào GIỮA chương " + chapterNumber + ". Hiện " + wc + " từ, cần thêm khoảng " + Math.max(400, Math.ceil(Math.min(minWords - wc, maxWords - wc) / Math.max(1, maxAttempts - attempts + 1))) + " từ (tối thiểu). Mục tiêu " + minWords + " từ, tuyệt đối không vượt " + maxWords + " từ.",
        "Bản nháp đã đi tới đoạn kết quá nhanh. Viết PHẦN NỐI nằm GIỮA 'ĐOẠN TRƯỚC' và 'ĐOẠN KẾT': thêm cảnh phụ, chuyển cảnh, hội thoại, nội tâm, phản ứng, giác quan, hành động nhỏ, nguyên nhân–hậu quả; mỗi nhịp phải mang thông tin/cảm xúc/quyết định MỚI, không lặp ý, không độn chữ.",
        "CẤM: viết lại hoặc tóm tắt nội dung đã có; viết nội dung của đoạn kết; kết chương; thêm biến cố lớn, nhân vật quan trọng mới, arc mới, thông tin để dành chương sau. Câu cuối phần nối phải dẫn tự nhiên vào câu đầu của đoạn kết.",
        "MỨC MIÊU TẢ: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
        usingNsfw ? ("\n" + EROTIC_STYLE_PROMPT) : "",
        usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
        state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
        characterLockPromptClient(true),
        "TIẾN TRIỂN: phần nối phải có diễn biến mới dẫn tới đoạn kết (không lặp lại hành động đã có, không đứng yên).",
        state.directive ? ("MỆNH LỆNH: " + String(state.directive).trim()) : "",
        state.nextChapterHint ? ("GỢI Ý: " + String(state.nextChapterHint).trim()) : "",
        closingIns ? ("ENDING ANCHOR: " + closingIns) : "",
        "",
        "===== ĐOẠN TRƯỚC (đã viết; giữ giọng văn, nhịp câu, POV, thì kể, xưng hô) =====", ins.body.slice(-3500),
        "===== ĐOẠN KẾT (đã viết, nằm NGAY SAU phần bạn viết; KHÔNG viết lại) =====", ins.ending,
        "",
        "CHỈ TRẢ VỀ văn xuôi của phần nối, bắt đầu ngay sau câu cuối của ĐOẠN TRƯỚC."
      ].filter(x => x !== null && x !== undefined).join("\n");
    }
    try{
      const mainPrompt = ins ? insertPrompt : (finishMode ? finishPrompt : prompt);
      let { text: contText, finishReason } = await callAI(mainPrompt, ins ? {
        maxTokens: 12000, temperature: 0.82, modelOverride: targetModel,
        frequency_penalty: 0.15, presence_penalty: 0.1
      } : {
        maxTokens: 12000, temperature: 0.82, modelOverride: targetModel,
        frequency_penalty: 0.15, presence_penalty: 0.1,
        streaming: true, onChunk: onChunk
      });
      if(finishMode && isFinishDoneReply(contText)){ endChk = { reached: true, missing: "" }; console.log("[Chốt kết] AI xác nhận điểm kết đã được viết."); continue; }
      if(!contText || contText.length < 50){ failAttempt("AI trả rỗng/quá ngắn"); continue; }
      if(detectNonVietnamese(contText)){
        console.warn("[Auto-continue] phát hiện ngôn ngữ khác, yêu cầu viết lại bằng tiếng Việt.");
        try{
          const r2=await callAI(mainPrompt+"\n\nCẢNH BÁO NGÔN NGỮ: Bắt buộc 100% TIẾNG VIỆT CÓ DẤU; không dùng chữ Hán/Nhật/Hàn/Cyrillic.",{maxTokens:12000,temperature:0.55,modelOverride:targetModel});
          if(r2.text) contText=r2.text;
        }catch(e){}
        if(detectNonVietnamese(contText)){ failAttempt("AI trả sai ngôn ngữ (không phải tiếng Việt)"); continue; }
      }
      { const dd = dropRestartedContinuation(chapterObj.text, contText);
        if(!dd.trim() || countWords(dd) < (finishMode ? 12 : 40)){ failAttempt("phần viết tiếp lặp lại nội dung đã có nên bị bỏ"); continue; }   // V12.24: lượt chốt kết có thể chỉ cần vài câu khép chương
        contText = dd; }
      contText = formatParagraphs(stripForeign(stripThinkingOutput(contText)));
      let cleaned = contText.trim();
      const lastSentences = tail.slice(-200).replace(/\s+/g, " ");
      if(cleaned.slice(0, 120).replace(/\s+/g, " ").includes(lastSentences.slice(-80))){
        const cut = cleaned.indexOf("\n");
        if(cut > 40) cleaned = cleaned.slice(cut).trim();
      }
      const remaining=maxWords-wc;
      if(remaining<=0){ endNote = "đã chạm giới hạn tối đa " + maxWords + " từ"; break; }
      const capped=trimToWordLimit(cleaned,remaining);
      if(ins){
        const mid = trimToLastSentence(capped.text, 0.6).text.trim();
        if(countWords(mid) < 120){ failAttempt("phần chèn diễn biến quá ngắn (<120 từ) nên bị bỏ"); continue; }
        chapterObj.text = ins.body.replace(/\s+$/,"") + "\n\n" + mid + "\n\n" + ins.ending;
        chapterObj.wordCount = countWords(chapterObj.text);
        chapterObj.truncated = false;
        console.log("[Chèn diễn biến] +" + countWords(mid) + " từ trước đoạn kết (giữ Ending Anchor)");
        continue;
      }
      chapterObj.text = chapterObj.text.replace(/\s+$/,"") + "\n\n" + capped.text;
      chapterObj.wordCount = countWords(chapterObj.text);
      chapterObj.truncated = finishReason === "length" || capped.trimmed;
      endChk = null;   // V12.24: văn bản vừa đổi ở phần cuối -> phải kiểm tra điểm kết lại
      if(capped.trimmed){ endNote = "đã chạm giới hạn tối đa " + maxWords + " từ"; break; }
    }catch(err){
      if(err.userAbort) throw err;
      failAttempt("API lỗi — " + (err && err.message ? err.message : err));
    }
  }
  // V12.24: vòng lặp có thể dừng ngay sau một lượt nối (kết quả kiểm tra điểm kết đã cũ) -> kiểm tra lại trước khi quyết định mở rộng/báo cáo.
  if(canCheckEnding && !endChk){
    setStatus("Kiểm tra lần cuối: chương đã tới điểm kết chưa...", true);
    endChk = await checkChapterEnding(chapterObj.text, endingTarget, state.nextChapterHint, state.directive);
  }
  const endStillMissing = !!(endChk && endChk.reached === false);
  // V12.23: MỞ RỘNG CUỐI — hết lượt viết thêm mà vẫn thiếu từ -> nhờ AI viết lại toàn bộ chương dài hơn (tối đa 2 lần).
  // V12.24: chương CHƯA TỚI điểm kết thì KHÔNG mở rộng (viết lại dài hơn cũng không tới kết, chỉ tốn lượt và làm loãng chương).
  if(!endStillMissing){ const _hb = !!(String(state.directive||"").trim() || String(state.nextChapterHint||"").trim());
    const _goal = _hb ? Math.round(minWords*0.95) : minWords;
    for(let ex = 1; ex <= 2 && state.autoContinueEnabled !== false; ex++){
      const w0 = countWords(chapterObj.text);
      if(w0 >= _goal || w0 >= maxWords || w0 < 800) break;
      setStatus("Mở rộng chương lần " + ex + "/2 (đang " + w0 + "/" + _goal + " từ)...", true);
      try{
        const exPrompt = buildExpandInsertPrompt({
          text: chapterObj.text, wc: w0, goal: _goal, target: minWords, maxWords: maxWords,
          directive: state.directive, hint: state.nextChapterHint,
          closing: extractClosingBeat(state.nextChapterHint) || extractClosingBeat(state.directive),
          style: [ "MỨC MIÊU TẢ: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
                   usingNsfw ? EROTIC_STYLE_PROMPT : "", usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
                   state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "" ].filter(Boolean).join("\n")
        });
        const r = await callAI(exPrompt, { maxTokens: expandMaxTokens(_goal * 1.04 - w0), temperature: 0.8, modelOverride: targetModel, frequency_penalty: 0.1, presence_penalty: 0.1 });
        let t = String((r && r.text) || "");
        if(detectNonVietnamese(t)){ stopReasons.push("mở rộng #" + ex + ": AI trả sai ngôn ngữ"); continue; }
        /* V12.32.13: AI chỉ trả các đoạn mới + chỗ chèn (không viết lại cả chương — vượt trần output ~7800 token). */
        const exRes = applyExpandInserts(chapterObj.text, parseInsertBlocks(stripThinkingOutput(t)), maxWords);
        const acc = acceptExpandInserts(chapterObj.text, exRes);
        if(!acc.ok){ stopReasons.push("mở rộng #" + ex + ": " + acc.reason); continue; }
        chapterObj.text = formatParagraphs(stripForeign(acc.text)); chapterObj.wordCount = countWords(chapterObj.text); chapterObj.truncated = false;
        console.log("[Mở rộng cuối] " + w0 + " → " + chapterObj.wordCount + " từ");
      }catch(err){
        if(err.userAbort) throw err;
        stopReasons.push("mở rộng #" + ex + ": API lỗi — " + (err && err.message ? err.message : err));
      }
    }
  }
  // V12.46: kiểm tra ngữ nghĩa theo từng câu trước Quality Gate.
  if(state.semanticProseAuto === true){
  try{
    setStatus("🔎 Semantic Prose Check: rà câu chữ theo ngữ cảnh...", true);
    const sem = await semanticProseCheckInText(chapterObj.text, {modelOverride: targetModel});
    chapterObj.text = sem.text; chapterObj.wordCount = countWords(sem.text);
    if(sem.fixed.length) chapterObj.autoUpdateIssues = (chapterObj.autoUpdateIssues || []).concat(["Semantic Prose Check đã sửa " + sem.fixed.length + " cụm chắc chắn: " + sem.fixed.slice(0,3).map(x => x.phrase + " → " + x.replacement).join("; ")]);
    if(sem.warnings.length) chapterObj.autoUpdateIssues = (chapterObj.autoUpdateIssues || []).concat(["Semantic Prose Check cần người dùng xem: " + sem.warnings.slice(0,5).map(x => x.phrase || x.reason).join("; ")]);
  }catch(e){ chapterObj.autoUpdateIssues = (chapterObj.autoUpdateIssues || []).concat(["Semantic Prose Check không hoàn tất: " + (e.message || e)]); }
  }
  // V12.23: báo rõ lý do dừng khi chương chưa đạt mục tiêu.
  const finalWc = countWords(chapterObj.text);
  // V12.24: chưa tới điểm kết -> báo riêng (quan trọng hơn thiếu từ) kèm các nhịp còn thiếu.
  if(endStillMissing){
    const why = "CHƯƠNG CHƯA TỚI ĐIỂM KẾT" + (endChk.missing ? (" — còn thiếu: " + endChk.missing) : "") + (endNote ? (" | " + endNote) : "") + (stopReasons.length ? " | " + stopReasons.join("; ") : "") + ". Bấm 'Viết tiếp' để nối nốt.";
    chapterObj.updateDiagnostics = (chapterObj.updateDiagnostics || []).concat([why + " (" + finalWc + "/" + minWords + " từ)"]);
    setStatus("⚠ " + why, false);
  } else if(finalWc < (!!(String(state.directive||"").trim() || String(state.nextChapterHint||"").trim()) ? Math.round(minWords*0.95) : minWords)){
    const why = (endNote ? endNote : "dừng sớm") + (stopReasons.length ? " | " + stopReasons.join("; ") : "");
    chapterObj.updateDiagnostics = (chapterObj.updateDiagnostics || []).concat(["Auto-continue dừng ở " + finalWc + "/" + minWords + " từ: " + why]);
    setStatus("⚠ Auto-continue dừng ở " + finalWc + "/" + minWords + " từ — " + why, false);
  }
  return chapterObj;
}


/* ========== v10.2 UI / ARCHITECTURE ========== */


function moveAuthoringSectionsToWriter(){
  const layout=document.querySelector('.layout'), main=document.querySelector('.main');
  const sidebar=layout?.querySelector(':scope > .sidebar'), stack=document.getElementById('authoringStack');
  if(!layout||!main||!sidebar||!stack)return;
  // v10.2.1 DOM contract: settings sections live inside .sidebar; only 5/6 live in writer.
  // Migration safeguard for older cached markup where sections were direct children of .layout.
  [...layout.querySelectorAll(':scope > .section')].forEach(sec=>{
    const label=(sec.querySelector('.section-head')?.innerText||'').trim();
    const isWriter=/^5\.\s*Công Cụ Sáng Tác/i.test(label)||/^6\.\s*Quản Lý Dữ Liệu/i.test(label);
    if(isWriter) stack.appendChild(sec); else sidebar.appendChild(sec);
  });
  // Also recover misplaced 5/6 that might still be direct sidebar children in older builds.
  [...sidebar.querySelectorAll(':scope > .section')].forEach(sec=>{
    const label=(sec.querySelector('.section-head')?.innerText||'').trim();
    if(/^5\.\s*Công Cụ Sáng Tác/i.test(label)||/^6\.\s*Quản Lý Dữ Liệu/i.test(label)) stack.appendChild(sec);
  });
  if(window.innerWidth>=901){
    layout.style.gridTemplateColumns='minmax(0,1fr) minmax(330px,420px)';
    main.style.gridColumn='1'; main.style.gridRow='1';
    sidebar.style.gridColumn='2'; sidebar.style.gridRow='1';
  }
}
function ensureUpgradePanel(){
  const stack=$ID("authoringStack"); if(!stack || $ID("v102Panel")) return;
  const sec=document.createElement("div");
  sec.className="section tone-blue open"; sec.id="v102Panel"; sec.setAttribute("data-section","");
  sec.innerHTML=`<div class="section-head" data-toggle><span>⚡ 10.2. Hiệu năng & Hậu kỳ iOS</span><span class="chev">▾</span></div>
  <div class="section-body">
    <div class="writer-tools-note">IndexedDB + debounce 1.75s · tối đa 5 thẻ nhân vật · 5–10 snapshot/chương (mặc định 7) · backup JSON 1-click.</div>
    <div class="token-estimator" id="tokenEstimator">Token dự tính: <b id="tokenEstimate">—</b> · Chi phí: <b id="costEstimate">—</b></div>
    <div class="row2">
      <button class="btn btn-amber" id="exportBackupV102">⬇ Backup JSON</button>
      <button class="btn btn-ghost" id="cleanTextV102">🧹 Làm sạch văn bản</button>
    </div>
    <div class="field"><label>Cấm từ / Anti-AI tropes</label><textarea id="banWordsV102" rows="3" placeholder="Mỗi dòng một từ/cụm từ..."></textarea></div>
    <div class="row2">
      <button class="btn btn-purple" id="auditTextV102">🔎 Quét lặp / cấm từ</button>
      <button class="btn btn-ghost" id="wakeLockV102">🔆 Wake Lock: Bật</button>
    </div>
    <div class="field"><label>Glossary Lock — xưng hô cố định</label><textarea id="glossaryV102" rows="2" placeholder="Ví dụ: Ta - Ngươi\nHuynh - Muội"></textarea></div>
    <div id="auditResultV102" class="hint"></div>
  </div>`;
  stack.appendChild(sec);
  sec.querySelector("[data-toggle]").addEventListener("click",()=>sec.classList.toggle("open"));
  $ID("banWordsV102").value=(state.banWords||[]).join("\n");
  $ID("glossaryV102").value=(state.glossaryLock||[]).join("\n");
  $ID("banWordsV102").addEventListener("input",()=>{state.banWords=$ID("banWordsV102").value.split(/\n|,/).map(x=>x.trim()).filter(Boolean);persist();});
  $ID("glossaryV102").addEventListener("input",()=>{state.glossaryLock=$ID("glossaryV102").value.split(/\n/).map(x=>x.trim()).filter(Boolean);persist();});
  $ID("exportBackupV102").addEventListener("click",exportFullBackupV102);
  $ID("cleanTextV102").addEventListener("click",cleanCurrentChapterTextV102);
  $ID("auditTextV102").addEventListener("click",()=>{ auditCurrentChapterV102(); highlightAuditMatchesV102(); });
  $ID("wakeLockV102").addEventListener("click",async()=>{
    state.wakeLockEnabled=!state.wakeLockEnabled;
    if(state.wakeLockEnabled) await acquireWakeLock(); else releaseWakeLock();
    $ID("wakeLockV102").textContent="🔆 Wake Lock: "+(state.wakeLockEnabled?"Bật":"Tắt");
    persist();
  });
}
function syncApiSettingsV102(){
  state.apiSettings={
    endpoint:state.apiEndpoint||"",
    key:state.apiKey||"",
    primaryModel:state.model||"",
    nsfwModel:state.modelNsfw||"",
    nsfwMode:state.nsfwMode||"auto",
    nsfwThreshold:Number(state.nsfwAutoThreshold||6),
    chapterMatureFocus:normalizeChapterMatureFocus(state.chapterMatureFocus)
  };
  state.storyMetaData=buildStoryMetaData(state);
}
function estimateCurrentPromptV102(){
  try{
    const c=state.chapters[state.currentChapterIndex];
    const context=buildContextBlock({includeChapterInstructions:false});
    const brief=[state.directive||"",state.nextChapterHint||""].filter(x=>String(x).trim()).join("\n");
    const conflicts=auditPromptInstructions();
    const tokens=estimateTokens(context+"\n"+brief+(conflicts.length?"\n"+conflicts.join("\n"):""));
    const out=Math.min(6000,Math.max(500,Number(state.minChapterWords)||5000))*1.15;
    const p=priceForModel(state.model);
    const cost=(tokens/1000000)*p.in+(out/1000000)*p.out;
    if($ID("tokenEstimate")) $ID("tokenEstimate").textContent=(tokens+Math.round(out)).toLocaleString("vi-VN")+" (~"+tokens.toLocaleString("vi-VN")+" input)";
    if($ID("costEstimate")) $ID("costEstimate").textContent="$"+cost.toFixed(4);
    return {tokens:tokens+Math.round(out),cost};
  }catch(e){return null;}
}
function exportFullBackupV102(){
  syncApiSettingsV102();
  const safe=JSON.parse(JSON.stringify(state));
  if(!state.includeKeyOnExport && safe.apiSettings) safe.apiSettings.key="";
  if(!state.includeKeyOnExport) safe.apiKey="";
  const payload={format:"xuong-truyen-ai-backup",version:10.2,exportedAt:new Date().toISOString(),StoryMetaData:buildStoryMetaData(safe),ChapterData:buildChapterData(safe)};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob);
  a.download=(state.storyName||"xuong-truyen")+"-backup-"+new Date().toISOString().slice(0,10)+".json";
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  setStatus("Đã xuất backup JSON.","saved");
}
function cleanVietnameseTextV102(text){
  return String(text||"").replace(/\u00A0/g," ")
    .replace(/[ \t]{2,}/g," ")
    .replace(/[ \t]+\n/g,"\n")
    .replace(/\n{3,}/g,"\n\n")
    .replace(/[ \t]+([,.;:!?…])/g,"$1")
    .replace(/([,;:!?…])(?=\p{L})/gu,"$1 ")
    .trim();
}
function cleanCurrentChapterTextV102(){
  const idx=state.currentChapterIndex, c=state.chapters[idx];
  if(!c) return;
  const before=c.text||""; const after=cleanVietnameseTextV102(before);
  c.text=after; c.wordCount=countWords(after);
  chapterTextEl.textContent=after;
  persistNow(); renderCurrentChapter();
  setStatus("Đã làm sạch văn bản.","saved");
}
function auditCurrentChapterV102(){
  const idx=state.currentChapterIndex, c=state.chapters[idx]; if(!c) return;
  const text=c.text||"", lower=text.toLocaleLowerCase("vi");
  const banned=(state.banWords||[]).filter(w=>w && lower.includes(w.toLocaleLowerCase("vi")));
  const words=lower.normalize("NFC").match(/[\p{L}\p{N}']+/gu)||[];
  const freq={}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
  const repeats=Object.entries(freq).filter(([w,n])=>n>=4&&w.length>=4).sort((a,b)=>b[1]-a[1]).slice(0,12);
  const el=$ID("auditResultV102"); if(!el)return;
  el.innerHTML=(banned.length?"<b>🚫 Cấm:</b> "+banned.map(escapeHtml).join(", ")+"<br>":"")
    +(repeats.length?"<b>🔁 Lặp ≥4:</b> "+repeats.map(([w,n])=>escapeHtml(w)+" ×"+n).join(", "):"Không phát hiện từ lặp đáng chú ý.");
}
function updateV102Estimator(){ setTimeout(estimateCurrentPromptV102,0); }

// Manual editing in the contenteditable editor must be persisted too.
let chapterEditTimer=null;
chapterTextEl.addEventListener("input",()=>{
  const idx=state.currentChapterIndex, c=state.chapters[idx];
  if(!c || generating) return;
  c.text=chapterTextEl.textContent||"";
  c.wordCount=countWords(c.text);
  c.polished=false;
  if(c.status==="SYNCED" || c.status==="SYNCED_WITH_WARNINGS") { c.status="MODIFIED_AFTER_SYNC"; c.sync=Object.assign(c.sync||{},{status:"STALE",staleAt:Date.now()}); }
  if(c.review) c.review.verdict="PENDING_REVIEW";
  clearTimeout(chapterEditTimer);
  chapterEditTimer=setTimeout(()=>persist(),650);
});

function highlightAuditMatchesV102(){
  const idx=state.currentChapterIndex, c=state.chapters[idx];
  if(!c) return;
  const text=c.text||"";
  const lower=text.toLocaleLowerCase("vi");
  const banned=(state.banWords||[]).filter(Boolean);
  const words=lower.normalize("NFC").match(/[\p{L}\p{N}']+/gu)||[];
  const freq={}; words.forEach(w=>freq[w]=(freq[w]||0)+1);
  const repeated=Object.entries(freq).filter(([w,n])=>n>=4&&w.length>=4).map(([w])=>w);
  const terms=[...banned,...repeated].sort((a,b)=>b.length-a.length).filter(Boolean);
  if(!terms.length){ chapterTextEl.textContent=text; return; }
  const escaped=terms.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
  try{
    const re=new RegExp(escaped,'giu');
    let pos=0, html="", m;
    while((m=re.exec(text))){
      html+=escapeHtml(text.slice(pos,m.index));
      html+='<mark class="audit-hit" title="Từ/cụm cần xem lại">'+escapeHtml(m[0])+'</mark>';
      pos=m.index+m[0].length;
      if(!m[0].length) re.lastIndex++;
    }
    html+=escapeHtml(text.slice(pos));
    chapterTextEl.innerHTML=html;
  }catch(e){ chapterTextEl.textContent=text; }
}

function setGenerating(on){
  generating = on;
  if(on) userStopRequested = false; /* bắt đầu lượt mới thì xoá cờ "đã dừng" của lượt trước */
  stopBtn.style.display = on ? "flex" : "none";
  ["writeChapterBtn","regenBtn","continueChapterBtn","regenNsfwBtn","versionsBtn","reviewChapterBtn"].forEach(id=>{
    if($ID(id)) $ID(id).disabled = on;
  });
  if(on) acquireWakeLock(); else releaseWakeLock();
}

/* ========== WAKE LOCK + DRAFT AUTOSAVE (chống ngắt khi khoá màn hình / chuyển app trên iOS) ========== */
/* iOS Safari tự khoá màn hình sau vài phút không chạm, và khi chuyển sang
   app khác thì tab Safari bị "đóng băng" JS gần như ngay lập tức — đây là
   giới hạn hệ điều hành, web app không có cách nào bắt buộc chạy nền 100%.
   2 việc có thể làm để giảm thiệt hại:
   1) Wake Lock: xin trình duyệt ĐỪNG tự khoá màn hình trong lúc đang viết
      (chỉ chống được TRƯỜNG HỢP tự khoá màn hình, không chống được việc
      người dùng chủ động bấm Home / chuyển app).
   2) Lưu tạm phần văn bản đang stream ra IndexedDB mỗi ~1.5s. Nếu bị
      ngắt giữa chừng (mất mạng, tab bị hệ điều hành giết), lần mở lại app
      sẽ phát hiện bản nháp dở dang và cho khôi phục thay vì mất trắng. */
let wakeLockRef = null;
let wakeLockUnsupportedWarned = false;
async function acquireWakeLock(){
  try{
    if(state && state.wakeLockEnabled === false) return;
    if('wakeLock' in navigator){
      wakeLockRef = await navigator.wakeLock.request('screen');
    } else if(!wakeLockUnsupportedWarned){
      wakeLockUnsupportedWarned = true;
      setStatus("⚠ Máy/trình duyệt không hỗ trợ giữ màn hình sáng — vào Cài đặt > Màn hình > Tự khoá, chọn \"Không bao giờ\" khi viết chương dài để tránh bị ngắt giữa chừng.", true);
    }
  }catch(e){ /* không hỗ trợ / bị từ chối — im lặng bỏ qua, không chặn viết */ }
}
function releaseWakeLock(){
  try{ if(wakeLockRef){ wakeLockRef.release(); wakeLockRef = null; } }catch(e){}
}
document.addEventListener("visibilitychange", ()=>{
  /* Wake Lock tự bị trình duyệt thu hồi khi tab ẩn đi, nên khi quay lại
     (mở khoá màn hình / quay lại tab) mà vẫn đang generate thì xin lại. */
  if(document.visibilityState === "visible" && typeof generating !== "undefined" && generating){
    acquireWakeLock();
  }
});

const DRAFT_KEY_PREFIX = "aiStoryWorkshop_draft_";
let lastDraftSaveAt = 0;

function saveDraftProgress(displayText, meta){
  try{
    if(!state.storyId) return;
    const now=Date.now();
    if(now-lastDraftSaveAt<1500) return;
    if(!displayText||displayText.length<200)return;
    lastDraftSaveAt=now;
    idbPut(IDB_DRAFT_STORE,state.storyId,{
      text:displayText,savedAt:now,chapterCountAtSave:state.chapters.length,
      mode:(meta&&meta.mode)||"new",idx:meta?meta.idx:null,
      isNsfw: meta ? !!meta.isNsfw : false
    }).catch(()=>{});
  }catch(e){}
}
function clearDraftProgress(){
  try{if(state.storyId)idbDelete(IDB_DRAFT_STORE,state.storyId);}catch(e){}
}
async function checkForRecoverableDraft(){
  try{
    if(!state.storyId)return;
    const d=await idbGet(IDB_DRAFT_STORE,state.storyId);
    if(!d||!d.text||d.text.length<200){if(d)clearDraftProgress();return;}
    if(d.mode==="continue"){
      const target=state.chapters[d.idx];
      if(!target||target.text.length>=d.text.length){clearDraftProgress();return;}
      showDraftRecoveryBanner(d);return;
    }
    if(d.chapterCountAtSave!=null&&state.chapters.length>d.chapterCountAtSave){clearDraftProgress();return;}
    showDraftRecoveryBanner(d);
  }catch(e){console.warn("[draft]",e);}
}
async function showDraftRecoveryBanner(d){
  if(d.mode === "continue"){
    const target = state.chapters[d.idx];
    if(!target){ clearDraftProgress(); return; }
    const ok = await showConfirm(
      "Phát hiện lượt \"Viết Tiếp\" chương " + (d.idx+1) + " bị ngắt giữa chừng lúc " +
      new Date(d.savedAt).toLocaleString("vi-VN") + " (có thể do khoá màn hình / chuyển app).\n\n" +
      "Khôi phục phần đã viết được vào chương " + (d.idx+1) + "? (Sau đó có thể bấm \"➕ Viết Tiếp\" lần nữa nếu chưa đủ ý.)",
      { okText: "Khôi phục", cancelText: "Bỏ qua" }
    );
    if(ok){
      target.text = d.text.trim();
      target.wordCount = countWords(target.text);
      target.truncated = true;
      persist(); renderAll();
      setStatus("Đã khôi phục phần viết tiếp dở dang vào chương " + (d.idx+1) + ".", false);
    }
    clearDraftProgress();
    return;
  }
  const ok = await showConfirm(
    "Phát hiện bản nháp dở dang từ lần trước (~" + countWords(d.text) + " từ, lưu lúc " +
    new Date(d.savedAt).toLocaleString("vi-VN") + ").\n\nCó thể do màn hình khoá / chuyển app khi đang viết khiến chương bị ngắt giữa chừng.\n\nKhôi phục vào 1 chương mới để dùng \"Viết Tiếp\" hoàn thiện nốt?",
    { okText: "Khôi phục", cancelText: "Bỏ qua" }
  );
  if(ok){
    state.chapters.push({
      title: "Bản nháp khôi phục", text: d.text.trim(), wordCount: countWords(d.text),
      truncated: true, plan: "", continuityWarnings: [], modelUsed: null, isNsfw: !!d.isNsfw,
      polished: false, summary: "", versions: [], compressed: false
    });
    state.currentChapterIndex = state.chapters.length - 1;
    persist(); renderAll();
    setStatus("Đã khôi phục bản nháp — bấm \"➕ Viết Tiếp\" để AI hoàn thiện nốt phần còn thiếu.", false);
  }
  clearDraftProgress();
}

/* ========== QUALITY GATE / CANON PIPELINE V12.16 ========== */
function normalizeChapterPipelineState(ch){
  if(!ch) return ch;
  if(!ch.id) ch.id=genId();
  if(!ch.status) ch.status = ch.sync && ch.sync.status ? (ch.sync.status === "SYNCED" ? "SYNCED" : "DRAFTED") : "SYNCED";
  if(!ch.selfCheck) ch.selfCheck={status:"unknown",checks:[],checkedAt:null};
  if(!ch.review) ch.review={status:"pending",score:null,verdict:null,dimensions:{},hardFailures:[],warnings:[],suggestions:[],rewriteInstructions:[],attempt:0,reviewedAt:null};
  if(!ch.sync) ch.sync={status:ch.status==="SYNCED"?"SYNCED":"pending",canonVersion:ch.canonVersion||null,syncedAt:null,changes:[]};
  return ch;
}
function normalizeAllChapterPipelineState(){ (state.chapters||[]).forEach(normalizeChapterPipelineState); }
function chapterStatusLabel(status){ return ({PLANNED:"🟡 Lên kế hoạch",DRAFTING:"🟡 Đang viết",DRAFTED:"🟡 Bản nháp",SELF_CHECKING:"🔎 Tự kiểm",REVIEWING:"🔎 Đang review",REVISION_REQUIRED:"🟠 Cần sửa",APPROVED:"🟢 Đã duyệt",SYNCING:"🔄 Đang sync",SYNCED:"🟢 Canon",SYNCED_WITH_WARNINGS:"🟡 Canon + cảnh báo",SYNC_FAILED:"🔴 Sync lỗi",MODIFIED_AFTER_SYNC:"🟠 Đã sửa sau Sync"}[status]||String(status||"Chưa xác định")); }
function renderQualityReview(ch){
  const box=$ID("qualityBox"); if(!box) return;
  if(!ch){box.style.display="none";return;}
  normalizeChapterPipelineState(ch);
  const r=ch.review||{}; const status=ch.status||"DRAFTED";
  const score=r.score==null?"—":String(r.score);
  const cls=(r.verdict==="PASS"||status==="SYNCED"||status==="SYNCED_WITH_WARNINGS")?"quality-pass":(r.verdict?"quality-fail":"quality-warn");
  const dims=Object.entries(r.dimensions||{}).map(([k,v])=>escapeHtml(k)+": "+escapeHtml(String(v))).join(" · ");
  const hard=(r.hardFailures||[]).map(x=>"• "+escapeHtml(typeof x==="string"?x:(x.description||x.problem||JSON.stringify(x)))).join("\n");
  const warn=(r.warnings||[]).slice(0,8).map(x=>"• "+escapeHtml(typeof x==="string"?x:(x.description||x.problem||JSON.stringify(x)))).join("\n");
  const aa=ch.accuracyAudit||null, beatAudit=aa&&aa.beatAudit||{}, required=beatAudit.requiredCodes||[], verified=beatAudit.verifiedCodes||[], repeats=aa&&aa.repeatedParagraphs||[];
  const accuracyState=!aa?"chưa chạy":aa.status!=="complete"?"audit chưa hoàn tất":aa.draftFingerprint===accuracyTextFingerprint(ch.text)?"bản thảo hiện tại":"bản thảo đã đổi sau audit";
  const repeatSummary=repeats.slice(0,5).map(x=>"đoạn "+x.paragraphs[0]+"↔"+x.paragraphs[1]).join(", ");
  const accuracyHtml=(state.accuracyMode||aa)?'<div style="margin-top:7px;"><b>🎯 Ưu tiên độ chính xác:</b> '+escapeHtml(accuracyState)+(beatAudit.status?" · beat "+verified.length+"/"+required.length:"")+" · đoạn lặp "+repeats.length+(repeatSummary?" ("+escapeHtml(repeatSummary)+")":"")+'</div>':'';
  box.className="quality-box "+cls; box.style.display="block";
  box.innerHTML='<b>'+escapeHtml(chapterStatusLabel(status))+'</b> · Quality: <b>'+escapeHtml(score)+'/100</b>'
    +(dims?'<div style="margin-top:5px;">'+dims+'</div>':'')
    +accuracyHtml
    +(hard?'<div style="margin-top:7px;"><b>Hard failure:</b>\n'+hard+'</div>':'')
    +(warn?'<div style="margin-top:7px;"><b>Cảnh báo:</b>\n'+warn+'</div>':'')
    +((r.rewriteInstructions||[]).length?'<div style="margin-top:7px;"><b>Hướng sửa:</b>\n'+r.rewriteInstructions.map(x=>'• '+escapeHtml(x)).join('\n')+'</div>':'')
    +((r.revisionTrace||[]).length?'<div style="margin-top:7px;"><b>AI đã thử sửa:</b>\n'+r.revisionTrace.slice(-4).map(x=>'• Lượt '+escapeHtml(String(x.attempt))+': '+escapeHtml(String(x.patched||0))+' patch'+(x.trace&&x.trace.length?' — '+x.trace.map(t=>escapeHtml((t.op||'')+(t.anchor?' tại “'+t.anchor+'”':''))).join('; '):'')+(x.skippedReasons&&x.skippedReasons.length?' | bỏ qua: '+escapeHtml(x.skippedReasons.join('; ')):'')).join('\n')+'</div>':'')
    +(ch.sync&&ch.sync.canonVersion?'<div style="margin-top:7px;">Canon v'+escapeHtml(String(ch.sync.canonVersion))+'</div>':'');
}
function accuracyTextFingerprint(text){
  const value=String(text||""); let hash=2166136261;
  for(let i=0;i<value.length;i++){ hash^=value.charCodeAt(i); hash=Math.imul(hash,16777619); }
  return "fnv1a:"+(hash>>>0).toString(16)+":"+value.length;
}
function buildAccuracyBeatAuditPrompt(requiredItems,draft){
  const beats=(requiredItems||[]).map(x=>x.code+" "+(x.text||"(không có mô tả thêm)")).join("\n");
  return [
    "Bạn là bộ kiểm tra độc lập Required Beat cho tiểu thuyết. Chỉ xác minh các beat dưới đây có thực sự xảy ra trong bản thảo hay không.",
    "Với từng mã, status chỉ được là present khi sự kiện được thể hiện rõ ràng; nếu thiếu hoặc mơ hồ, chọn missing/uncertain. Không suy diễn từ ý định hoặc Outline.",
    "Mỗi present phải trích một đoạn NGUYÊN VĂN, liên tục, đúng dấu câu/khoảng trắng từ bản thảo. Không diễn đạt lại. Trích đủ một câu hoặc cụm có nghĩa (tối thiểu 3 từ, khoảng 12 ký tự trở lên). Mỗi mã xuất hiện đúng một lần.",
    'Chỉ trả JSON: {"items":[{"code":"[R1]","status":"present|missing|uncertain","evidence":"trích nguyên văn hoặc chuỗi rỗng"}]}',
    "REQUIRED BEATS:\n"+beats,
    "BẢN THẢO CHƯƠNG (nguồn duy nhất để trích bằng chứng):\n"+String(draft||"")
  ].join("\n\n");
}
async function runAccuracyBeatAudit(chapter,plan){
  const required=extractRequiredBeatItems(plan||""), draft=String(chapter&&chapter.text||"");
  if(!required.length) return auditRequiredBeatEvidence([],draft,{items:[]});
  try{
    const response=await callAI(buildAccuracyBeatAuditPrompt(required,draft),{maxTokens:1800,temperature:0.1,modelOverride:chapter.modelUsed||state.model});
    return auditRequiredBeatEvidence(required,draft,safeJsonParse(response&&response.text||""));
  }catch(error){
    return {status:"error",requiredCodes:required.map(x=>x.code),verifiedCodes:[],missingCodes:required.map(x=>x.code),issues:["Không gọi được audit Required Beat."],error:String(error&&error.message||error)};
  }
}
async function qualityReviewDraft(chapter, chapterNumber, plan, contextSummary){
  const sc=normalizeStoryControl(state);
  const hardChecks=gateHardChecks(chapter);
  const names=knownNameMentions(chapter.text,gateKnownNames(state));
  const prompt=buildQualityReviewPrompt({arcProgress:arcProgressPrompt(state,chapterNumber),storyControl:storyControlPrompt(state),characterLock:characterLockPrompt(state.mainCharProfile,lockCharsForText(state,chapter.text),true),contract:plan,contractLabel:"CHAPTER CONTRACT / OUTLINE",context:contextSummary,warnings:chapter.continuityWarnings,draft:chapter.text,prevEnding:((state.chapters[chapterNumber-2]||{}).text||"").slice(-1500),hardChecks,knownNames:names,maxMainEvents:sc.maxMainEvents,maxNamedCharacters:sc.maxNamedCharacters});
  try{
    const r=await callAI(prompt,{maxTokens:2200,temperature:0.1,modelOverride:chapter.modelUsed||state.model});
    const obj=safeJsonParse(r.text);
    const og=outlineGateCheck(state,chapterNumber,chapter.text,gateKnownNames(state));
    const review=evaluateReview(obj,{maxMainEvents:sc.maxMainEvents,maxNamedCharacters:sc.maxNamedCharacters,passScore:state.qualityPassScore,softFailScore:state.qualitySoftFailScore,extraHard:hardChecks.filter(x=>!x.ok).map(x=>x.message).concat(og.hard),extraWarnings:og.warn});
    if(!review) return {ok:false,reason:"review_parse"};
    if(state.accuracyMode===true){
      const repeatedParagraphs=findRepeatedParagraphs(String(chapter.text||""));
      const beatAudit=await runAccuracyBeatAudit(chapter,plan);
      chapter.accuracyAudit={status:beatAudit.status==="error"?"error":"complete",draftFingerprint:accuracyTextFingerprint(chapter.text),beatAudit,repeatedParagraphs,auditedAt:Date.now()};
      if(beatAudit.status==="error") return {ok:false,reason:"accuracy_beat_audit:"+(beatAudit.error||"unavailable")};
      const accuracyFailures=[];
      if(beatAudit.status!=="verified") accuracyFailures.push("Accuracy Mode: thiếu hoặc chưa xác minh Required Beat bằng trích dẫn nguyên văn — "+(beatAudit.missingCodes||[]).join(", ")+". Kiểm tra đủ mọi mã [R#].");
      repeatedParagraphs.forEach(x=>accuracyFailures.push("Accuracy Mode: đoạn văn "+(x.exact?"trùng nguyên văn":"gần trùng")+" giữa đoạn "+x.paragraphs[0]+" và đoạn "+x.paragraphs[1]+" (độ giống "+Math.round(x.similarity*100)+"%): “"+x.excerpt+"”. Chỉ sửa/xóa phần lặp, giữ nguyên sự kiện riêng."));
      if(accuracyFailures.length){
        review.hardFailures=[].concat(review.hardFailures||[],accuracyFailures);
        review.rewriteInstructions=[].concat(review.rewriteInstructions||[],accuracyFailures);
        review.verdict="HARD_FAIL";
        review.score=Math.min(Number(review.score)||100,Math.max(0,Number(state.qualitySoftFailScore||75)-1));
      }
    }
    return {ok:true,review};
  }catch(e){ return {ok:false,reason:e.message}; }
}
/* V12.32.10: sửa theo từng đoạn (patch) trước; chỉ khi không vá được mới thử viết lại cả chương. */
async function patchDraftFromReview(chapter, review, chapterNumber, plan, contextSummary){
  const oldText=String(chapter.text||"");
  const prompt=buildPatchPrompt({chapterNumber,storyControl:storyControlPrompt(state),characterLock:characterLockPrompt(state.mainCharProfile,lockCharsForText(state,chapter.text),true),contract:plan,contractLabel:"OUTLINE/CONTRACT",context:contextSummary,review,draft:oldText,prevEnding:((state.chapters[chapterNumber-2]||{}).text||"").slice(-1500)});
  try{
    const r=await callAI(prompt,{maxTokens:4000,temperature:0.3,modelOverride:chapter.modelUsed||state.model});
    let patches=parsePatchResponse(r.text);
    if(!patches||!patches.length) return {ok:false,reason:"AI không trả danh sách vá hợp lệ"};
    let res=applyChapterPatches(oldText,patches);
    // Missing Required Beat thường bị AI neo vào mã [R2]/[R3] không tồn tại trong văn bản.
    if(!res.applied && (review.hardFailures||[]).some(x=>/thiếu.*\[R\d+\]/i.test(gateItemText(x)))) {
      const retryPrompt=buildPatchPrompt({chapterNumber,storyControl:storyControlPrompt(state),characterLock:characterLockPrompt(state.mainCharProfile,lockCharsForText(state,chapter.text),true),contract:plan,contractLabel:"OUTLINE/CONTRACT",context:contextSummary,review,draft:oldText,prevEnding:((state.chapters[chapterNumber-2]||{}).text||"").slice(-1500),retryNote:res.skipped.map(x=>x.reason).join("; ")||"không có thao tác nào được ghép"});
      const retry=await callAI(retryPrompt,{maxTokens:4000,temperature:0.2,modelOverride:chapter.modelUsed||state.model});
      patches=parsePatchResponse(retry.text);
      if(patches&&patches.length) res=applyChapterPatches(oldText,patches);
    }
    const acc=checkPatchAcceptable(oldText,res);
    if(!acc.ok) return Object.assign(acc,{skipped:res.skipped||[]});
    backupBeforeRewrite(chapter,"Trước khi AI vá cục bộ (lần "+(((chapter.review||{}).attempt)||1)+", "+res.applied+" chỗ)");
    chapter.text=res.text; chapter.wordCount=acc.wordCount;
    return {ok:true,patched:res.applied,skipped:res.skipped.length,trace:patches.slice(0,res.applied).map(x=>({op:x.op,anchor:String(x.find||x.from||"").slice(0,90),text:String(x.text||"").slice(0,160)})),skippedReasons:res.skipped.slice(0,4).map(x=>x.reason)};
  }catch(e){
    if(e && e.userAbort) return {ok:false,stopped:true,reason:"Đã dừng"};
    return {ok:false,reason:(e&&e.message)||"lỗi gọi AI"};
  }
}
async function rewriteDraftFromReview(chapter, review, chapterNumber, plan, contextSummary){
  const pr=await patchDraftFromReview(chapter,review,chapterNumber,plan,contextSummary);
  if(pr.ok||pr.stopped) return pr;
  // V12.45: chương dài không thể rewrite toàn bộ trong trần output; chuyển sang sửa đúng một vùng lỗi.
  const fit = wholeRewriteFits(String(chapter.text||""));
  if(state.accuracyMode===true || !fit.fits){
    setStatus(state.accuracyMode===true?"🎯 Accuracy Mode: đang sửa đúng vùng lỗi, không viết lại toàn chương...":"⚙ Vá câu neo không ghép được — AI đang sửa theo vùng lỗi trong chương dài...",true);
    try{
      const segPrompt=buildSegmentRepairPrompt({
        chapterNumber, storyControl:storyControlPrompt(state),
        characterLock:characterLockPrompt(state.mainCharProfile,lockCharsForText(state,chapter.text),true),
        contract:plan, contractLabel:"OUTLINE/CONTRACT", context:contextSummary,
        review, draft:String(chapter.text||"")
      });
      const sr=await callAI(segPrompt,{maxTokens:5200,temperature:0.35,modelOverride:chapter.modelUsed||state.model});
      const repair=parseSegmentRepairResponse(sr.text);
      const applied=applySegmentRepair(chapter.text,repair);
      if(applied.ok){
        backupBeforeRewrite(chapter,"Trước khi AI sửa theo vùng (Quality Gate lần "+(((chapter.review||{}).attempt)||1)+")");
        chapter.text=applied.text; chapter.wordCount=applied.wordCount;
        return {ok:true,patched:1,segmentRepair:true,trace:[{op:"segment_replace",anchor:applied.start+" … "+applied.end,text:String(repair.replacement).slice(0,180)}],skippedReasons:[]};
      }
      setStatus("⚠ AI sửa theo vùng không được: "+applied.reason,true);
    }catch(e){
      if(e && e.userAbort) return {ok:false,stopped:true,reason:"Đã dừng"};
      console.warn("[Targeted Segment Repair]",e);
    }
  }
  if(state.accuracyMode===true){
    setStatus("⛔ Accuracy Mode: vá cục bộ không áp dụng được; giữ bản tốt nhất, không viết lại toàn chương.",false);
    return {ok:false,reason:"Accuracy Mode chỉ cho phép vá cục bộ/sửa theo vùng; không fallback viết lại toàn chương."};
  }
  setStatus("⚠ Vá cục bộ không được ("+pr.reason+") — thử viết lại cả chương...",true);
  const wr=await rewriteWholeDraft(chapter,review,chapterNumber,plan,contextSummary);
  if(wr.ok||wr.stopped) return wr;
  return {ok:false,reason:"Vá cục bộ: "+pr.reason+(fit.fits?"":" | Sửa theo vùng không ghép được")+" | Viết lại cả chương: "+wr.reason};
}
async function rewriteWholeDraft(chapter, review, chapterNumber, plan, contextSummary){
  const oldText=String(chapter.text||""), oldWc=countWords(oldText);
  const fit=wholeRewriteFits(oldText);
  if(!fit.fits) return {ok:false,reason:"chương "+oldWc+" từ (≈"+fit.est+" token) quá dài để AI viết lại cả chương trong giới hạn "+fit.cap+" token — bỏ qua, chỉ dùng vá cục bộ"};
  const prompt=buildRewritePrompt({chapterNumber,storyControl:storyControlPrompt(state),characterLock:characterLockPrompt(state.mainCharProfile,lockCharsForText(state,chapter.text),true),contract:plan,contractLabel:"OUTLINE/CONTRACT",context:contextSummary,review,draft:chapter.text,prevEnding:((state.chapters[chapterNumber-2]||{}).text||"").slice(-1500)});
  try{
    const r=await callAI(prompt,{maxTokens:AI_MAX_OUTPUT_TOKENS,temperature:0.55,modelOverride:chapter.modelUsed||state.model});
    let text=String(r.text||"").trim().replace(/^\s*(?:TIÊU ĐỀ|TITLE)\s*:\s*[^\n]+\n+/i,"").replace(/^\s*NỘI DUNG\s*:\s*/i,"").trim();
    text=formatParagraphs(dedupeRepeatedScene(stripForeign(stripThinkingOutput(text))));
    const cap=trimToWordLimit(text,chapterWordLimits().hardMax);
    const newWc=countWords(cap.text);
    const acc=checkRewriteAcceptable(oldWc,cap.text,newWc);
    if(!acc.ok) return acc;
    backupBeforeRewrite(chapter,"Trước khi Quality Gate sửa (lần "+(((chapter.review||{}).attempt)||1)+")");
    chapter.text=cap.text; chapter.wordCount=newWc; chapter.truncated=chapter.truncated||cap.trimmed;
    return {ok:true};
  }catch(e){
    if(e && e.userAbort) return {ok:false,stopped:true,reason:"Đã dừng"};
    return {ok:false,reason:(e&&e.message)||"lỗi gọi AI"};
  }
}
async function runQualityGate(chapter, chapterNumber, plan, contextSummary, opts){
  opts=opts||{};
  normalizeChapterPipelineState(chapter);
  return runGateLoop(chapter,{
    selfCheck:async(attempt)=>{
      chapter.selfCheck={status:"running",checks:gateHardChecks(chapter),checkedAt:null}; renderQualityReview(chapter);
      /* V12.32.3: gọi AI kiểm tra continuity (gửi cả chương) CHỈ ở vòng 1; các vòng sau chỉ chạy kiểm tra cứng (không tốn token).
         Review và hậu kỳ server vẫn kiểm continuity lại. */
      if(!attempt||attempt<=1){
        const warnings=await runContinuityCheck(chapter.text,chapterNumber,contextSummary,true);
        /* mỗi lượt thay cảnh báo AI cũ bằng cảnh báo mới, không cộng dồn */
        chapter.continuityWarnings=mergeAiContinuityWarnings(chapter.continuityWarnings,warnings,20);
      }
      chapter.selfCheck={status:"passed",checks:gateHardChecks(chapter),checkedAt:Date.now()};
    },
    review:()=>qualityReviewDraft(chapter,chapterNumber,plan,contextSummary),
    rewrite:(review)=>rewriteDraftFromReview(chapter,review,chapterNumber,plan,contextSummary),
    onStatus:(m)=>setStatus("⚠ "+m,true),
    onChange:()=>renderQualityReview(chapter),
    shouldStop:()=>userStopRequested
  },accuracyModeQualityGateOptions(state,opts));
}
/* V12.23: gợi ý chương sau phải HIỆN ở ô Gợi ý (trước đây chỉ lưu vào biến ẩn autoNextChapterHint nên ô luôn trống).
   - Ô trống, hoặc vẫn đúng là gợi ý đã dùng để viết chương vừa xong -> thay bằng gợi ý chương sau.
   - Người dùng đã tự sửa/gõ gợi ý mới trong lúc viết -> giữ nguyên, không ghi đè.
   - Tạo thất bại: xóa gợi ý cũ (đã dùng) để chương sau không bị ép viết lại kế hoạch cũ. */
let _writeBriefSnapshot = null;
/* V12.25: hiện gợi ý DẦN vào ô khi AI đang stream (chỉ đổi ô, chưa lưu state). Dừng nếu bạn đang gõ/sửa ô. */
let _hintPreviewLast = null;
async function runCanonPostProcess(chapterObj, cn, text, rawForPolish, briefUsed){
  _hintPreviewLast = null;
  if(!chapterObj || !String(chapterObj.text || text || "").trim()) throw new Error("Chương không có nội dung để đồng bộ Canon.");
  // V12.30: một job hậu kỳ tổng hợp cho Summary/NV/World/Status/Memory/Gợi ý.
  // Không chạy các extractor client-side song song vì chúng có thể ghi đè chéo dữ liệu.
  await startBackgroundPostProcess(chapterObj, cn, String(chapterObj.text || text || ""), briefUsed);
}

function chapterAccuracyBarrierStatus(chapter){
  if(state.accuracyMode!==true) return {ok:true,missing:[]};
  const missing=[], audit=chapter&&chapter.accuracyAudit;
  if(!audit||audit.status!=="complete") missing.push("Accuracy audit chưa hoàn tất");
  else{
    if(audit.draftFingerprint!==accuracyTextFingerprint(chapter.text)) missing.push("Bản thảo đã đổi sau audit; cần duyệt lại");
    if(!chapter.review||chapter.review.verdict!=="PASS") missing.push("Quality Gate chưa PASS");
    const beats=audit.beatAudit||{};
    if(beats.status!=="verified") missing.push("Required Beat chưa xác minh: "+((beats.missingCodes||[]).join(", ")||"cần chạy lại audit"));
    const repeats=audit.repeatedParagraphs||[];
    if(repeats.length) missing.push("Còn "+repeats.length+" cặp đoạn dài trùng/gần trùng");
  }
  return {ok:missing.length===0,missing};
}
function requiredBeatBarrierStatus(chapter){
  if(state.requiredBeatBarrier===false&&state.accuracyMode!==true) return {ok:true,missing:[]};
  const review=chapter&&chapter.review||{};
  const items=[].concat(review.hardFailures||[]).map(gateItemText);
  const missing=[];
  items.forEach(t=>{
    if(!/thiếu|missing|chưa có|chưa được thực hiện|chưa có bằng chứng/i.test(t)) return;
    const codes=t.match(/\[R\d+\]/gi)||[];
    codes.forEach(c=>{ if(!missing.includes(c.toUpperCase())) missing.push(c.toUpperCase()); });
  });
  const accuracy=chapterAccuracyBarrierStatus(chapter);
  if(!accuracy.ok) accuracy.missing.forEach(item=>{ if(!missing.includes(item)) missing.push(item); });
  return {ok:missing.length===0,missing};
}
function blockIfRequiredBeatsMissing(chapterOrChapters, action){
  const list=Array.isArray(chapterOrChapters)?chapterOrChapters:[chapterOrChapters];
  const missingByChapter=[];
  list.forEach((ch,i)=>{ const b=requiredBeatBarrierStatus(ch); if(!b.ok) missingByChapter.push("Ch"+(i+1)+": "+b.missing.join(", ")); });
  if(missingByChapter.length){
    const label=state.accuracyMode===true?"còn thiếu Required Beat hoặc Accuracy audit":"còn thiếu Required Beat";
    setStatus("⛔ Đã chặn "+action+": "+label+" — "+missingByChapter.join("; ")+". Hãy sửa và chạy lại Quality Gate.",false);
    return true;
  }
  return false;
}

async function reviewCurrentChapter(opts){
  const autoFix=!!(opts&&opts.autoFix===true); /* V12.32.10: nút 🛠 AI tự sửa */
  if(generating) return;
  const idx=state.currentChapterIndex, ch=state.chapters[idx];
  if(!ch){ setStatus("Chưa có chương.",false); return; }
  if(!String(ch.text||"").trim()){ setStatus("Chương đang trống.",false); return; }
  normalizeChapterPipelineState(ch);
  const n=idx+1, isLast=idx===state.chapters.length-1;
  const wasSynced=!!(ch.sync&&ch.sync.syncedAt);
  setGenerating(true);
  try{
    const ctx=buildStoryBibleSummary()+"\n"+characterSummaryForPrompt(relevantCharacters(20));
    setStatus(autoFix?("🛠 AI đang tự sửa chương "+n+"..."):("🔎 Đang duyệt lại chương "+n+"..."),true);
    if(autoFix){
      setStatus("🔎 Semantic Prose Check: rà các cụm từ theo ngữ cảnh...",true);
      const sem=await semanticProseCheckInText(ch.text,{modelOverride:ch.modelUsed||state.model});
      if(sem.fixed.length){
        backupBeforeRewrite(ch,"Trước khi Semantic Prose Check sửa chương "+n);
        ch.text=sem.text; ch.wordCount=countWords(sem.text); ch.polished=false;
        ch.review=Object.assign({},ch.review||{},{verdict:"PENDING_REVIEW",status:"pending"});
        ch.autoUpdateIssues=(ch.autoUpdateIssues||[]).concat(["Semantic Prose Check đã sửa "+sem.fixed.length+" cụm chắc chắn: "+sem.fixed.slice(0,3).map(x=>x.phrase+" → "+x.replacement).join("; ")]);
        persist(); renderCurrentChapter();
      }
      if(sem.warnings.length) ch.autoUpdateIssues=(ch.autoUpdateIssues||[]).concat(["Semantic Prose Check cần người dùng xem: "+sem.warnings.slice(0,5).map(x=>x.phrase||x.reason).join("; ")]);
    }
    const gate=await runQualityGate(ch,n,ch.plan||"",ctx,{rewrite:autoFix,forceWarnings:autoFix});
    if(gate.stopped){ ch.status=wasSynced?"MODIFIED_AFTER_SYNC":"REVISION_REQUIRED"; persist(); renderChapterNav(); renderCurrentChapter(); setStatus(autoFix?"Đã dừng tự sửa (bản thảo giữ nguyên hoặc đã vá đến lượt trước; xem 🕘 phiên bản để khôi phục).":"Đã dừng duyệt lại.",false); return; }
    if(blockIfRequiredBeatsMissing(ch,"Sync Canon / xuất bản")) return;
    if(!gate.approved){
      if(state.accuracyMode===true){ ch.status=wasSynced?"MODIFIED_AFTER_SYNC":"REVISION_REQUIRED"; persist(); renderChapterNav(); renderCurrentChapter(); setStatus("⛔ Ưu tiên độ chính xác: Quality Gate chưa PASS; không Manual Override khi chế độ này đang bật. Bản thảo được giữ lại để sửa cục bộ.",false); return; }
      const why=gate.error?("Không đọc được kết quả review ("+gate.error+")"):("Quality Gate: "+((ch.review&&ch.review.verdict)||"chưa đạt"));
      if(!await showConfirm(why+".\nVẫn duyệt thủ công chương "+n+" và đồng bộ vào Canon?")){
        ch.status=wasSynced?"MODIFIED_AFTER_SYNC":"REVISION_REQUIRED";
        persist(); renderChapterNav(); renderCurrentChapter();
        setStatus("Chương "+n+" chưa được duyệt. Bấm 🛠 AI tự sửa, hoặc sửa tay theo khung Quality rồi bấm 🔍 Duyệt lại.",false);
        return;
      }
      ch.review=Object.assign({},ch.review,{verdict:"MANUAL_OVERRIDE",status:"completed",overriddenAt:Date.now()});
      ch.status="APPROVED";
    }
    let doSync=isLast;
    if(isLast && wasSynced) doSync=await showConfirm("Chương "+n+" đã từng Sync. Chạy lại cập nhật Canon (tóm tắt, NV, thế giới, status, memory) theo bản đã sửa?\n(Hủy = chỉ đánh dấu đã duyệt, giữ nguyên Canon cũ.)");
    if(doSync){
      persist(); renderChapterNav(); renderCurrentChapter();
      await runCanonPostProcess(ch,n,ch.text,ch.text);
    }else{
      ch.sync=Object.assign(ch.sync||{},{status:(ch.autoUpdateIssues&&ch.autoUpdateIssues.length)?"SYNCED_WITH_WARNINGS":"SYNCED",reviewedAt:Date.now()});
      if(!ch.sync.syncedAt) ch.sync.syncedAt=Date.now();
      ch.status=ch.sync.status;
      persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
      setStatus("🟢 Đã duyệt lại chương "+n+(isLast?" (giữ nguyên Canon cũ).":". Chương không phải chương cuối — dùng 🔄 Rescan nếu cần cập nhật Canon."),false);
    }
  }catch(err){
    setStatus("Lỗi duyệt lại: "+(err&&err.message||err),false);
  }finally{ setGenerating(false); }
}

/* ========== GENERATE CHAPTER (chính) ========== */
function compactSceneStyleLock(usingNsfw){
  const sb = state.styleBible || {}, parts = [
    "desc=" + String(state.descriptionLevel || "balanced").slice(0, 20),
    "pov=" + String(sb.pov || "third_limited").slice(0, 24),
    "tense=" + String(sb.tense || "past").slice(0, 16)
  ];
  if(sb.tone) parts.push("tone=" + String(sb.tone).replace(/\s+/g, " ").slice(0, 100));
  if(state.pronounRules) parts.push("xưng_hô=" + String(state.pronounRules).replace(/\s+/g, " ").slice(0, 180));
  if(usingNsfw || state.mature){
    parts.unshift("RÀO_CHẮN_TUỔI_BẮT_BUỘC=" + ageGuardPrompt(state).replace(/\s+/g, " ").replace(/^RÀO CHẮN TUỔI \(bắt buộc\):\s*/, "").slice(0, 420));
    const lvl = String(state.explicitLevel || "sensual");
    parts.push("adult_level=" + lvl.slice(0, 20));
    /* V14.7.3: dùng ĐÚNG mức người dùng chọn (trước đây "wild" bị hạ xuống "strong" và cắt 330 ký tự); mức Mạnh/Cực mạnh mang thêm bộ quy tắc cảnh nóng. */
    parts.push("mức_18+=" + String(EXPLICIT_PROMPTS[lvl] || EXPLICIT_PROMPTS.sensual).replace(/\s+/g, " ").slice(0, 600));
    if(lvl === "strong" || lvl === "wild") parts.push(EROTIC_SCENE_LOCK);
  }
  const vocab = buildVocabularyBlock();
  if(vocab) parts.push("từ_khóa=" + vocab.replace(/\s+/g, " ").slice(0, 260));
  return parts.join("; ");
}
function buildChapterContractForGeneration(st, chapterNumber, priorChapters){
  const n = Number(chapterNumber) || (((st && st.chapters) || []).length + 1);
  const arc = activeArcOf(st), ol = outlineOf(st, n), per = ol ? outlineChapterLines(ol.content, ol) : {};
  const arcGoal = arc ? String(arc.goal || arc.name || "").trim() : "";
  // V14.5.6: chỉ lùi về 900 ký tự đầu khi outline KHÔNG đánh số chương; nếu có đánh số mà thiếu chương này thì để trống (không được lấy dòng của chương khác).
  const outlineLine = per[n] || (ol && !Object.keys(per).length ? String(ol.content || "").slice(0, 900) : "");
  // Dùng toàn bộ outline/arc làm nguồn cast: một nhân vật canon có thể được
  // nhắc ở phần setup hoặc consequence chứ không xuất hiện ngay trong dòng Ch[n].
  const arcSource = arc ? JSON.stringify(arc) : "";
  const outlineSource = ol ? String(ol.content || "") : "";
  const source = [arcGoal, arcSource, outlineSource, outlineLine, st && st.directive, st && st.nextChapterHint,
    priorChapters && priorChapters.length ? priorChapters[priorChapters.length - 1].text.slice(-1800) : ""].join(" ").toLowerCase();
  const allowed = [], known = [];
  const add = (arr, v) => { const s = String(v || "").replace(/\s+/g, " ").trim(); if(s && !arr.some(x => normalizeName(x) === normalizeName(s))) arr.push(s); };
  if(st && st.mainCharProfile){ add(allowed, st.mainCharProfile.name); add(known, st.mainCharProfile.name); (st.mainCharProfile.aliases||[]).forEach(a => { add(allowed, a); add(known, a); }); }
  ((st && st.characters) || []).forEach(c => { const name = c && (c.name || c.fullName); if(!name) return; add(known, name); (c.aliases||[]).forEach(a => add(known, a)); if(source.includes(String(name).toLowerCase())) add(allowed, name); });
  const itemsInfo = ol ? outlineChapterItems(ol.content, ol)[n] : null;
  const required = [];
  if(outlineLine) required.push("[OUTLINE Ch" + n + "] " + outlineLine);
  if(arcGoal) required.push("[ARC] " + arcGoal);
  return { chapterNumber:n, arcGoal, chapterOutline:outlineLine, requiredBeats:required,
    outlineItems:(itemsInfo && itemsInfo.items.length >= 3) ? itemsInfo.items.slice(0, 10) : [], outlineMeta:(itemsInfo && itemsInfo.meta) || {},
    allowedCharacters:allowed, canonicalCharacters:known, knownCharacters:known,
    forbiddenDrift:["Không đổi mục tiêu Arc/Outline của chương.","Không tự biến nhân vật ngoài allowed cast thành tuyến chính.","Không đổi nghề, tài nguyên, địa vị hoặc lớp vỏ sinh tồn của nhân vật chính.","Không mở tuyến vệ sĩ, khách sạn, shop váy cưới hoặc tuyến xã hội khác nếu Outline không ghi rõ."],
    userBrief:[st && st.directive, st && st.nextChapterHint].filter(Boolean).join(" "),
    // Nguồn đối chiếu TÊN cho validator (không đưa vào prompt): toàn bộ Outline/Arc + Mệnh lệnh/Gợi ý + 2 chương gần nhất.
    // Nhân vật đã có tên trong Outline/chương trước nhưng chưa được hậu kỳ thêm vào Character Database vẫn hợp lệ.
    nameSource:[arcGoal, arcSource, outlineSource, st && st.directive, st && st.nextChapterHint].concat((priorChapters||[]).slice(-2).map(c => String(c && c.text || "").slice(-6000))).filter(Boolean).join(" ").slice(0, 30000),
    openingContinuity:priorChapters && priorChapters.length ? priorChapters[priorChapters.length-1].text.slice(-1500) : "",
    mustChange:outlineLine || arcGoal || "Chương phải tạo một bước tiến không thể đảo ngược.", minWords:adaptiveChapterWordLimits(st).minAccept, maxWords:adaptiveChapterWordLimits(st).maxAccept };
}
function adaptiveRequiredBeatBlock(st, chapterNumber){
  const lines = [], n = Number(chapterNumber) || (((st && st.chapters) || []).length + 1);
  const ol = outlineOf(st, n);
  let hasOutlineBeat = false;
  if(ol){
    const per = outlineChapterLines(ol.content, ol);
    if(per[n]) { hasOutlineBeat = true; lines.push("[OUTLINE Ch" + n + "] " + String(per[n]).replace(/\s+/g, " ").slice(0, 1000)); }
  }
  // buildAdaptiveScenePlanPrompt đã nhận brief/hint riêng; chỉ lặp chúng vào từng scene khi không có Outline.
  if(!hasOutlineBeat && st && st.directive) lines.push("[BRIEF] " + String(st.directive).replace(/\s+/g, " ").slice(0, 700));
  if(!hasOutlineBeat && st && st.nextChapterHint) lines.push("[HINT] " + String(st.nextChapterHint).replace(/\s+/g, " ").slice(0, 700));
  return lines.join("\n");
}
function adaptiveAllowedCastBlock(st){
  const names = [];
  const add = v => { const n = String(v || '').replace(/\s+/g, ' ').trim(); if(n && !names.some(x => normalizeName(x) === normalizeName(n))) names.push(n); };
  if(st && st.mainCharProfile) add(st.mainCharProfile.name);
  ((st && st.characters) || []).forEach(c => add(c && (c.name || c.fullName)));
  return names.length ? names.join(', ') : '';
}
function adaptiveForbiddenDrift(st){
  const arc = activeArcOf(st), goal = arc && (arc.goal || arc.name) ? String(arc.goal || arc.name) : '';
  return [
    goal ? 'Không rời mục tiêu Arc hiện tại: ' + goal : '',
    'Không tự thêm nhân vật mới thành tuyến chính nếu không có trong Story Bible/Outline.',
    'Không đổi trạng thái tài nguyên, nghề nghiệp, địa vị hoặc lớp vỏ sinh tồn đã khóa của nhân vật chính.',
    'Không chuyển sang tuyến bảo vệ/vệ sĩ, khách sạn, shop váy cưới hoặc tuyến xã hội khác nếu Outline chương không ghi rõ.'
  ].filter(Boolean).join(' ');
}
// V14.0.5: định tuyến model theo TỪNG scene. Trước đây model NSFW chỉ được chọn một lần cho cả chương
// dựa trên đoạn cuối chương trước + mệnh lệnh, nên cảnh nóng nằm trong Outline/Scene Graph của chương mới
// vẫn bị viết bằng model chính. Nay mỗi scene tự chọn model theo beat/purpose của chính nó.
function adaptiveSceneRoute(scene, o, tail){
  const base = { model: o.model, nsfw: !!o.usingNsfw };
  if(base.nsfw) return base;
  const mode = state.nsfwMode || 'auto';
  if(!state.mature || !matureFocusAllowsRouting() || !state.modelNsfw || mode === 'never') return base;
  if(mode === 'always' || mode === 'mature_only') return { model: state.modelNsfw, nsfw: true };
  const sc = scene || {};
  // tail: đoạn cuối scene trước — scene nóng kéo dài sang scene sau thì không được tụt về model chính giữa chừng.
  const text = [sc.purpose, (sc.beats || []).join(' '), sc.mustChange, sc.handoff, String(tail || '').slice(-800)].join('\n');
  return textHasNsfwKeyword(text) ? { model: state.modelNsfw, nsfw: true } : base;
}
let _lastSceneNote = ""; // V14.3: tóm tắt cảnh báo scene của lần viết gần nhất, hiện ở dòng trạng thái
async function generateAdaptiveChapterText(o){
  // V14.0.6: vòng điều phối nằm ở shared/core.js (runAdaptiveChapterPipeline) để worker nền dùng ĐÚNG cùng code.
  return runAdaptiveChapterPipeline(o, {
    state, callAI,
    clean: t => safeDedupeRepeatedScene(formatParagraphs(stripForeign(stripThinkingOutput(String(t||""))))),
    buildContract: buildChapterContractForGeneration,
    requiredBeats: adaptiveRequiredBeatBlock,
    style: compactSceneStyleLock,
    route: adaptiveSceneRoute,
    sceneRetries: 1, outlineComplete: true, sceneAiReview: state.sceneAiReview === true, sceneBeatCheck: state.beatLedgerCheck === true, beatLedger: state.beatLedgerCheck === true, sceneReviewModel: (typeof modelForStep === 'function' ? modelForStep(state, 'gate', o && o.model) : (o && o.model)),
    onNsfw: (scene, route) => { try{ setStatus('🔥 Scene ' + scene.id + ' có nội dung 18+ → ' + shortModelName(route.model), true); }catch(_){} },
    warn: (...a) => console.warn(...a)
  });
}

// V13.4: hàng rào cuối cho mọi nhánh tạo chương. Nếu Scene Graph lỗi/không parse được,
// fallback cũ vẫn phải được bù từ; không để bản 1.000–2.000 từ lọt qua vì adaptive trả null.
async function topUpShortDraftText(initialText, o){
  let text = String(initialText || '').trim(), attempts = 0;
  const limits = adaptiveChapterWordLimits(state);
  const requiredBeats = adaptiveRequiredBeatBlock(state, Number(o && o.chapterNumber) || (state.chapters.length + 1));
  while(countWords(text) < limits.minAccept && attempts < 6){
    const currentWords = countWords(text), needWords = Math.min(1800, limits.minAccept - currentWords);
    attempts++;
    try{
      const r = await callAI(buildAdaptiveSceneTopUpPrompt({
        state, currentWords, needWords,
        chapterGoal:'Hoàn thiện chương hiện tại theo Outline/Brief; tạo diễn biến mới và kết nối tự nhiên.',
        endingAnchor:'Chỉ kết thúc sau khi chương đạt tối thiểu 4.500 từ và đã xử lý các Required Beat.',
        previousTail:text.slice(-2400), requiredBeats,
        allowedCast: adaptiveAllowedCastBlock(state), forbiddenDrift: adaptiveForbiddenDrift(state),
        style:compactSceneStyleLock(!!(o && o.usingNsfw))
      }), {
        maxTokens:Math.min(4200, Math.max(1800, Math.ceil(needWords * 2.1) + 450)),
        temperature:o && o.usingNsfw ? 0.76 : 0.70, modelOverride:o && o.model,
        frequency_penalty:0.22, presence_penalty:0.18, streaming:false
      });
      let extra = formatParagraphs(stripForeign(stripThinkingOutput(String(r && r.text || '')))).trim();
      if(detectNonVietnamese(extra)) extra = stripForeign(extra);
      if(countWords(extra) < 80) break;
      const before = currentWords;
      text = text + '\n\n' + extra;
      if(countWords(text) <= before) break;
    }catch(e){
      console.warn('[AdaptiveScene] fallback top-up failed', e && e.message);
      break;
    }
  }
  return text;
}

async function condenseChapterToBounds(chapterObj, chapterNumber, chapterPlan, model){
  const limits=chapterWordLimits(), start=String(chapterObj&&chapterObj.text||""); let best=start, before=countWords(start), attempts=0;
  if(before<=limits.maxAccept) return {ok:true,reduced:false,wordCount:before};
  while(countWords(best)>limits.maxAccept && attempts<2){
    attempts++;
    const prompt=["RÚT GỌN CHƯƠNG "+chapterNumber+" ĐỂ ĐẠT GIỚI HẠN ĐỘ DÀI TÁC GIẢ ĐẶT TRƯỚC.",
      "Mục tiêu: tối đa "+limits.maxAccept+" từ; tối thiểu "+limits.minAccept+" từ. Bản hiện tại "+countWords(best)+" từ.",
      "Rút gọn bằng cách gộp câu/đoạn lặp, giảm diễn giải trùng và miêu tả dư. BẮT BUỘC giữ mọi sự kiện nhân quả, nhân vật có mặt, lựa chọn, chuyển trạng thái, thông tin mới, thoại chứa dữ kiện, thứ tự thời gian, đoạn kết/handoff và toàn bộ beat bắt buộc. Không tự sáng tác, không xóa cảnh/sự kiện để đạt số từ. Không chèn tiêu đề/nhận xét; chỉ trả văn bản chương đã biên tập.",
      "TIÊU ĐỀ: "+String(chapterObj.title||""),"OUTLINE / CONTRACT CẦN GIỮ:\n"+String(chapterPlan||chapterObj.plan||"").slice(0,10000),
      "BẢN CHƯƠNG:\n"+best].join("\n\n");
    try{
      const response=await callAI(prompt,{maxTokens:Math.min(7600,Math.max(1500,Math.ceil(limits.maxAccept*1.7)+900)),temperature:0.18,modelOverride:model,streaming:false});
      let candidate=formatParagraphs(stripForeign(stripThinkingOutput(String(response&&response.text||"")))).trim();
      if(detectNonVietnamese(candidate)) candidate=stripForeign(candidate);
      const words=countWords(candidate), priorWords=countWords(best);
      if(!candidate||words<limits.minAccept||words>=priorWords) break;
      best=candidate;
    }catch(e){ console.warn("[ChapterLength] safe condensation failed",e&&e.message); break; }
  }
  const resultWords=countWords(best), reduced=resultWords<before;
  if(reduced){
    const versions=Array.isArray(chapterObj.versions)?chapterObj.versions:[];
    versions.push({text:start,wordCount:before,label:"Trước khi rút gọn theo min/max",at:Date.now()});
    chapterObj.versions=versions.slice(-12); chapterObj.text=best; chapterObj.wordCount=resultWords; chapterObj.condensedForBounds=true;
  }
  return {ok:resultWords<=limits.maxAccept,reduced,wordCount:resultWords,attempts,warning:resultWords>limits.maxAccept?"Không thể rút gọn đủ mà vẫn giữ mức tối thiểu; giữ bản tốt nhất, không cắt cụt.":""};
}

function recordStoryTimeMark(chapterNumber, chapterObj){
  const n=Number(chapterNumber)||0; if(!n)return null;
  if(!state.statusState||typeof state.statusState!=="object")state.statusState={};
  if(!Array.isArray(state.statusState.timeLog))state.statusState.timeLog=[];
  const time=String(chapterObj&&chapterObj.storyTimeMark||currentTimeMark(state)||"").trim(); if(!time)return null;
  const log=state.statusState.timeLog, row={chapter:n,time,source:state.storyClock?"storyClock":"statusState",updatedAt:Date.now()};
  const index=log.findIndex(x=>x&&Number(x.chapter)===n); if(index>=0)log[index]=Object.assign({},log[index],row);else log.push(row);
  log.sort((a,b)=>(Number(a.chapter)||0)-(Number(b.chapter)||0)); state.statusState.timeLog=log.slice(-500);
  if(chapterObj)chapterObj.storyTimeMark=time;
  return row;
}
function recordChapterPostWriteAudit(chapterObj, chapterNumber){
  if(!chapterObj)return null;
  const n=Number(chapterNumber)||0, chapters=state.chapters.slice();
  if(n>0&&n<=chapters.length)chapters[n-1]=chapterObj;else if(n===chapters.length+1)chapters.push(chapterObj);
  const audit=buildChapterPostWriteAudit(Object.assign({},state,{chapters}),n);
  chapterObj.postWriteAudit=audit; return audit;
}
async function enforceChapterLengthBounds(chapterObj, chapterNumber, chapterPlan, model){
  const before=String(chapterObj.text||""), action=chapterLengthAction(state,countWords(before)); let result={reduced:false,ok:true};
  if(action.action==="expand"){
    const expanded=await topUpShortDraftText(before,{chapterNumber,model,usingNsfw:!!chapterObj.isNsfw});
    if(countWords(expanded)>countWords(before))chapterObj.text=expanded;
  }else if(action.action==="condense"){
    setStatus("📏 Chương vượt giới hạn — đang rút gọn có bảo toàn sự kiện...",true);
    result=await condenseChapterToBounds(chapterObj,chapterNumber,chapterPlan,model);
  }
  chapterObj.wordCount=countWords(chapterObj.text||"");
  const after=chapterLengthAction(state,chapterObj.wordCount);
  if(after.action!=="within") chapterObj.lengthWarning=after.action==="expand"?"Chương còn dưới mức tối thiểu sau khi thử mở rộng; giữ bản tốt nhất để tác giả xem lại.":"Chương còn vượt max sau hai lần rút gọn; giữ bản tốt nhất, không cắt cụt sự kiện.";
  else if(result.ok) chapterObj.lengthWarning="";
  return {changed:String(chapterObj.text||"")!==before,action:after.action,result};
}

/* V14.4.0: kiểm tra Outline TRƯỚC khi tốn thời gian viết. 'high' -> hỏi xác nhận; 'warn' -> chỉ nhắc ở dòng trạng thái; chương đã chọn "vẫn viết" không bị hỏi lại cho tới khi Outline đổi. */
function outlinePreflightReport(st, n){
  const ol = outlineOf(st, n); if(!ol) return null;
  const line = outlineChapterLines(ol.content, ol)[n]; if(!line) return null;
  const rep = lintChapterOutline(line); rep.n = n; return rep;
}
async function outlinePreflight(n){
  if(window.__XTA_TEST__) return true;
  const rep = outlinePreflightReport(state, n);
  if(!rep || rep.level === "ok") return true;
  window.__outlineLintAck = window.__outlineLintAck || {};
  const key = n + ":" + rep.chars;
  if(window.__outlineLintAck[key]) return true;
  if(rep.level === "warn"){ window.__outlineLintAck[key] = 1; setStatus("ℹ Outline Ch" + n + " hơi nhiều ràng buộc: " + outlineLintShort(rep) + " (bấm 🔎 Kiểm tra Outline để xem gợi ý).", true); return true; }
  const ok = await showConfirm(formatOutlineLint(rep, n) + "\n\nBấm “Vẫn viết” nếu bạn chắc Outline này, hoặc “Sửa Outline” để gọn lại trước.", { okText:"Vẫn viết", cancelText:"Sửa Outline" });
  if(ok) window.__outlineLintAck[key] = 1;
  return ok;
}
(function(){ const b = document.getElementById("outlineLintBtn"); if(!b) return; b.addEventListener("click", async ()=>{
  const start = state.chapters.length + 1, rows = [];
  ((state.outlinePlans)||[]).forEach(ol => { const per = outlineChapterLines(ol.content, ol); Object.keys(per).map(Number).sort((a,b)=>a-b).forEach(n => { if(n < start) return; const rep = lintChapterOutline(per[n]); if(rep.level !== "ok") rows.push("Ch" + n + (rep.level === "high" ? " [NẶNG]" : " [nhẹ]") + ": " + outlineLintShort(rep)); }); });
  await showAlert(rows.length ? ("Các chương chưa viết có Outline cần gọn lại:\n\n" + rows.slice(0, 15).join("\n") + (rows.length > 15 ? "\n… và " + (rows.length - 15) + " chương nữa" : "") + "\n\nGợi ý: mỗi chương 1–2 sự kiện chính, 3–6 beat, mỗi beat một ý; chỉ ghi số lần/thứ tự/câu thoại khi thật sự bắt buộc.") : "Outline các chương chưa viết đều gọn, không thấy chi tiết ép buộc quá mức.");
}); })();
async function generateChapter(regenIndex, regenMode, forceNsfw){
  if(generating){ setStatus("Đang bận...", true); return; }
  setWriteProgress("plan");
  if((!state.apiEndpoint && !apiEndpointInput.value.trim()) || (!state.apiKey && !apiKeyInput.value.trim())){
    setStatus("Cấu hình endpoint + key trước.", false); return;
  }
  const isRegen = typeof regenIndex === "number";
  _callLog = []; _chapterStartAt = Date.now();
  if(!window.__XTA_TEST__ && !isRegen && state.chapters.length===0 && (
    (state.mainPlot && state.mainPlot.trim()) ||
    (state.characters && state.characters.length>0) ||
    (state.mainCharProfile && state.mainCharProfile.name && state.mainCharProfile.name.trim())
  )){
    const ok = await showConfirm("Truyện này chưa có chương nào trong bộ nhớ hiện tại, nhưng lại đã có nhân vật/cốt truyện — có thể do vừa Lên JSON chưa tải kịp hoặc mở nhầm truyện.\n\nBấm OK để VẪN viết Chương 1 (nếu bạn chắc đây đúng là truyện mới).\nBấm Hủy để dừng lại và kiểm tra trước.");
    if(!ok){ return; }
  }
  if(!(await outlinePreflight(isRegen ? regenIndex + 1 : state.chapters.length + 1))) return;
  if(!isRegen) await ensureCastPlanned(state.chapters.length + 1);
  const basePick = pickWritingModel(!!forceNsfw);
  if(!basePick.model){ setStatus("Chưa cấu hình model.", false); return; }
  normalizeAllChapterPipelineState();
  if(!isRegen && state.chapters.length){
    const last=state.chapters[state.chapters.length-1];
    if(last && !["SYNCED","SYNCED_WITH_WARNINGS","MODIFIED_AFTER_SYNC"].includes(last.status || "SYNCED")){
      setStatus("⛔ Chương "+state.chapters.length+" chưa hoàn tất Quality Gate/Sync. Bấm 🔍 Duyệt lại (hoặc ↻ Viết lại) trước khi viết chương kế tiếp.", false);
      return;
    }
    if(last && last.status==="MODIFIED_AFTER_SYNC") setStatus("ℹ Chương "+state.chapters.length+" đã sửa tay sau Sync — vẫn viết tiếp. Bấm 🔍 Duyệt lại nếu muốn cập nhật Canon.", true);
  }

  setGenerating(true); setWriteProgress("write");
  let targetModel = basePick.model;
  let usingNsfw = basePick.isNsfw;
  let modeTag = usingNsfw ? "🔥 [NSFW] " : "";
  setStatus((isRegen ? "Đang chuẩn bị viết lại" : "Đang chuẩn bị viết chương mới") + "...", true);

  let streamingTarget = null;
  if(state.streamingEnabled){
    if(!isRegen){
      const nextIdx = state.chapters.length;
      streamingTarget = { mode: "new" };
      chapterTitleEl.textContent = "Chương " + (nextIdx+1) + " (đang viết...)";
      chapterTextEl.textContent = "";
      chapterTextEl.classList.add("streaming");
    } else {
      streamingTarget = { mode: "regen", idx: regenIndex };
      chapterTextEl.classList.add("streaming");
    }
  }

  try{
    const context = buildContextBlock({includeChapterInstructions:false, priorChapters: isRegen ? state.chapters.slice(0, regenIndex) : undefined});
    const preflightConflicts = auditPromptInstructions();
    if(preflightConflicts.length) setStatus("⚠ Phát hiện " + preflightConflicts.length + " xung đột quy tắc tiềm năng; đã gắn cảnh báo vào ngữ cảnh trước khi gọi AI.", true);
    const priorChapters = isRegen ? state.chapters.slice(0, regenIndex) : state.chapters;
    const chapterNumber = isRegen ? regenIndex + 1 : state.chapters.length + 1;

    const lastChapterEnding = priorChapters.length ? priorChapters[priorChapters.length - 1].text.slice(-1000) : "";

    function clipChapterText(t, maxChars){
      t = t || "";
      if(t.length <= maxChars) return t;
      return t.slice(0, Math.floor(maxChars*0.3)) + "\n\n[...]\n\n" + t.slice(-Math.floor(maxChars*0.6));
    }
    /* Chỉ: summary ch.trước + đoạn cuối ch.gần (không full 2–3 chương) — dùng chung với viết nền (shared/core.js) */
    const _rb = buildRecentBlocks(priorChapters);
    let recentFullText = _rb.recentFullText, olderSummaries = _rb.olderSummaries;

    let plan = "";
    if(!isRegen && state.adaptiveScenePipeline === false) plan = await buildChapterPlan(context, recentFullText, chapterNumber);

    /* Auto NSFW pre-flight: từ khóa trước, rồi mới chấm nhiệt */
    if(state.nsfwMode === "auto" && matureFocusAllowsRouting() && state.modelNsfw && !forceNsfw){
      const tailHeat = isRegen
        ? (state.chapters[regenIndex] ? state.chapters[regenIndex].text.slice(-2000) : "")
        : (priorChapters.length ? priorChapters[priorChapters.length - 1].text.slice(-1800) : "");
      if(shouldForceNsfwByKeyword(plan, tailHeat)){
        targetModel = state.modelNsfw;
        usingNsfw = true;
        modeTag = "🔥 [NSFW] ";
        setStatus("🔥 Phát hiện từ khóa 18+ trong mệnh lệnh/kế hoạch → " + shortModelName(targetModel), true);
      } else {
        setStatus("🔍 Đang chấm nhiệt độ cảnh...", true);
        const heat = await detectHeatLevel(tailHeat, plan);
        const threshold = state.nsfwAutoThreshold || 6;
        if(heat >= threshold){
          targetModel = state.modelNsfw;
          usingNsfw = true;
          modeTag = "🔥 [NSFW] ";
          setStatus("🔥 Nhiệt độ " + heat + "/10 → " + shortModelName(targetModel), true);
        } else {
          setStatus("🌡 Nhiệt độ " + heat + "/10 → " + shortModelName(targetModel), true);
        }
      }
    }

    const descPrompt = DESCRIPTION_PROMPTS[state.descriptionLevel] || DESCRIPTION_PROMPTS.balanced;
    const explicitPrompt = EXPLICIT_PROMPTS[state.explicitLevel] || EXPLICIT_PROMPTS.sensual;
    const vocabBlock = buildVocabularyBlock();

    const prompt = buildMainWritePrompt({ chapterNumber, isRegen, regenIndex, regenMode, descPrompt, explicitPrompt, vocabBlock, usingNsfw,
      hintVerified: chapterHintVerification(state, chapterNumber).verified,
      context, lastChapterEnding, recentFullText, olderSummaries, plan, priorCount: (isRegen ? regenIndex : state.chapters.length) });

    const promptTokens = estimateTokens(prompt);
    if(promptTokens > 90000) setStatus("⚠ Prompt ~" + promptTokens + " token — có thể vượt context.", true);

    /* v12.4: giới hạn tần suất vẽ lại khung chữ (~8 lần/giây) thay vì mỗi chunk — vẽ lại toàn văn
       + regex trên chuỗi dài mỗi chunk làm iPhone giật và chậm dần theo độ dài chương. */
    let streamLastAt = 0, streamTimer = null, streamLatest = "";
    const renderStream = (full) => {
      const bodyMatch = full.match(/NỘI DUNG:\s*([\s\S]*)/i);
      const displayText = bodyMatch ? bodyMatch[1] : "";
      if(displayText){ chapterTextEl.textContent = displayText; saveDraftProgress(displayText, { mode: "new", isNsfw: usingNsfw }); }
    };
    const cancelStream = () => { if(streamTimer){ clearTimeout(streamTimer); streamTimer = null; } };
    const onChunk = streamingTarget ? (delta, full) => {
      streamLatest = full;
      const now = Date.now();
      if(now - streamLastAt >= 120){ streamLastAt = now; cancelStream(); renderStream(full); }
      else if(!streamTimer){ streamTimer = setTimeout(()=>{ streamTimer = null; streamLastAt = Date.now(); renderStream(streamLatest); }, 120); }
    } : null;

    let rawText = "", finishReason = null, adaptiveStats = null;
    let firstResult = null;
    // V13.3: viết lại chương cũng phải đi qua Adaptive Scene + Top-up.
    // Trước đây chỉ chương mới đi qua nhánh này; nút Viết lại vì thế có thể
    // quay về pipeline cũ và kết thúc ở 1.000–1.500 từ mà không bù độ dài.
    _lastSceneNote = "";
    if(state.adaptiveScenePipeline !== false){
      const adaptive = await generateAdaptiveChapterText({
        context, priorChapters, model: targetModel, usingNsfw
      });
      if(adaptive && adaptive.rejected){
        clearDraftProgress();
        chapterTextEl.classList.remove("streaming");
        setStatus("⛔ V14 từ chối kế hoạch/chương để tránh lệch Arc: " + adaptive.reason, false);
        return;
      }
      if(adaptive && adaptive.text){
        rawText = adaptive.text;
        plan = adaptive.plan;
        adaptiveStats = adaptive.stats || null;
        if(adaptive.usedNsfw && !usingNsfw){ usingNsfw = true; modeTag = "🔥 [NSFW] "; }
        if(adaptive.underTarget) setStatus("⚠ Scene Graph tạo chương dưới 4.500 từ; giữ bản nháp để người dùng quyết định.", true);
        _lastSceneNote = formatSceneNote(adaptive.stats);
        if(_lastSceneNote) setStatus("📝 " + _lastSceneNote, true);
      }
    }
    if(!rawText){
      firstResult = await callAI(prompt, {
        maxTokens: 7800, temperature: 0.85, modelOverride: targetModel,
        frequency_penalty: usingNsfw ? 0.25 : 0.45,
        presence_penalty: usingNsfw ? 0.25 : 0.35,
        streaming: !!streamingTarget, onChunk: onChunk
      });
      rawText = firstResult.text;
      finishReason = firstResult.finishReason;
    }
    cancelStream(); if(streamingTarget && streamLatest) renderStream(streamLatest);
    chapterTextEl.classList.remove("streaming");

    if(detectNonVietnamese(rawText)){
      setStatus("Phát hiện ngôn ngữ khác, viết lại...", true);
      try{
        const retry = await callAI(prompt + "\n\nCẢNH BÁO: BẮT BUỘC 100% TIẾNG VIỆT.", {maxTokens:16000, temperature:0.85, modelOverride: targetModel});
        if(retry.text){ rawText = retry.text; finishReason = retry.finishReason; }
      }catch(e){}
    }

    rawText = formatParagraphs((/^V14 CHAPTER CONTRACT/.test(String(plan||"")) ? safeDedupeRepeatedScene : dedupeRepeatedScene)(stripForeign(stripThinkingOutput(rawText))));
    // V13.5: Hard minimum là hợp đồng của chương, không phụ thuộc cờ pipeline
    // cũ được lưu trong Story Record. Kể cả adaptive=false/fallback cũ vẫn phải bù.
    if(countWords(rawText) < adaptiveChapterWordLimits(state).minAccept){
      setStatus('⚙ Bản nháp còn ' + countWords(rawText) + ' từ — đang bù đến tối thiểu 4.500 từ...', true);
      rawText = await topUpShortDraftText(rawText, {chapterNumber, model:targetModel, usingNsfw});
    }
    const titleMatch = rawText.match(/TIÊU ĐỀ:\s*(.+)/i);
    const bodyMatch = rawText.match(/NỘI DUNG:\s*([\s\S]*)/i);

    let title = titleMatch ? titleMatch[1].trim() : "";
    title = title.replace(/^[\s"'“”‘’]+|[\s"'“”‘’]+$/g, "")
      .replace(/^chương\s*\d+\s*[:\-–—.]\s*/i, "").replace(/^chương\s*\d+\s*$/i, "")
      .replace(/^\d+\s*[:\-–—.]\s*/, "").trim();
    if(!title) title = "Không có tiêu đề";

    let text = bodyMatch ? bodyMatch[1].trim() : rawText;

    const chapterObj = {
      id: genId(), title, text, wordCount: countWords(text), truncated: finishReason === "length",
      plan, adaptiveStats, continuityWarnings: [], modelUsed: targetModel, isNsfw: usingNsfw, storyTimeMark: currentTimeMark(state),
      polished: false, summary: "", versions: [], compressed: false,
      briefUsed: { hint: String(state.nextChapterHint || "").slice(0, 4000), directive: String(state.directive || "").slice(0, 4000) },   // V12.24
      status: "DRAFTED",
      selfCheck: { status: "pending", checks: [], checkedAt: null },
      review: { status: "pending", score: null, verdict: null, dimensions: {}, hardFailures: [], warnings: [], suggestions: [], rewriteInstructions: [], attempt: 0, reviewedAt: null },
      sync: { status: "pending", canonVersion: null, syncedAt: null, changes: [] },
      canonVersion: null
    };

    _writeBriefSnapshot = String(state.nextChapterHint || "");
    await autoContinueUntilDone(chapterObj, chapterNumber, targetModel, usingNsfw, onChunk);
    cancelStream();
    await enforceChapterLengthBounds(chapterObj,chapterNumber,plan,targetModel);
    /* V12.22: ĐÃ BỎ bước 'chia đoạn làm dày'. Độ dài do prompt tự do + chế độ chèn diễn biến trong autoContinueUntilDone. */
    const finalLimits=chapterWordLimits();
    const finalCapped=trimToWordLimit(chapterObj.text,finalLimits.hardMax);
    const explicitWordBounds=Number(state.chapterWordMin)>=300&&Number(state.chapterWordMax)>=Number(state.chapterWordMin)&&Number(state.chapterWordMax)<=12000;
    if(finalCapped.trimmed){
      chapterObj.truncated=true;
      if(explicitWordBounds) chapterObj.lengthWarning=chapterObj.lengthWarning||"Vượt max đã đặt; văn bản được giữ nguyên để tránh cắt cụt cảnh/sự kiện.";
      else chapterObj.text=finalCapped.text;
    }else chapterObj.text=finalCapped.text;
    chapterObj.wordCount=countWords(chapterObj.text);
    text = chapterObj.text;

    /* v11.1: rà chính tả KHÔNG còn chặn việc lưu chương. Chương được lưu + hiện ngay bằng bản gốc;
       bước rà chạy song song với các tác vụ hậu xử lý (tóm tắt, NV, thế giới...) rồi thay thế
       nếu nội dung chưa bị ai sửa trong lúc đó. Tổng thời gian = max(rà, hậu xử lý) thay vì cộng dồn. */
    let rawForPolish = text;
    chapterObj.text = text;
    chapterObj.wordCount = countWords(text);

    const dupWarnings = checkDuplicates(text);
    if(dupWarnings.length) chapterObj.continuityWarnings = dupWarnings;

    const reviewContext = buildStoryBibleSummary() + "\n" + characterSummaryForPrompt(relevantCharacters(20));
    const autonomousRepair = state.accuracyMode===true || (state.autoRepairOnCreate !== false && state.qualityGateEnabled !== false);
    setStatus(autonomousRepair ? "✦ Đang tự hoàn thiện chương " + chapterNumber + ": Quality Gate + sửa lỗi..." : "🔎 Quality Gate đang kiểm tra chương " + chapterNumber + "...", true); setWriteProgress("gate");
    let gate = await runQualityGate(chapterObj, chapterNumber, plan, reviewContext, {rewrite:autonomousRepair,forceWarnings:autonomousRepair});
    if(gate.approved){
      const beforeGateText=chapterObj.text, adjusted=await enforceChapterLengthBounds(chapterObj,chapterNumber,plan,targetModel);
      if(adjusted.changed||chapterObj.text!==beforeGateText){
        setStatus("🔎 Kiểm tra lại chương sau khi áp dụng min/max...",true);
        gate=await runQualityGate(chapterObj,chapterNumber,plan,reviewContext,{rewrite:false,forceWarnings:false});
      }
    }
    if(!gate.approved){
      clearDraftProgress();
      chapterObj.status = gate.stopped ? "DRAFTED" : "REVISION_REQUIRED";
      if(!Array.isArray(state.chapterDrafts)) state.chapterDrafts=[];
      const draftRecord=Object.assign({},chapterObj,{sourceChapter:isRegen?chapterNumber:null,savedAt:Date.now()});
      state.chapterDrafts = state.chapterDrafts.filter(d=>!(d && d.sourceChapter===chapterNumber));
      state.chapterDrafts.push(draftRecord);
      if(!isRegen){
        state.chapters.push(chapterObj);
        state.currentChapterIndex=state.chapters.length-1;
        state.chaptersSinceBackup++;
        recordStoryTimeMark(chapterNumber,chapterObj);
      }
      recordChapterPostWriteAudit(chapterObj,chapterNumber);
      persist(); renderChapterNav(); renderCurrentChapter();
      if(gate.stopped) setStatus("Đã dừng trước khi Sync — bản nháp được giữ lại, chưa thành canon.", false);
      else setStatus("⛔ Chương "+chapterNumber+" chưa vượt Quality Gate. Bản nháp đã được giữ lại để sửa, chưa ghi vào Canon.", false);
      return;
    }

    if(Array.isArray(state.chapterDrafts)) state.chapterDrafts=state.chapterDrafts.filter(d=>!(d && d.sourceChapter===chapterNumber));
    text = chapterObj.text; rawForPolish = text; /* v12.16b: Gate có thể đã viết lại bản thảo — hậu xử lý phải dùng bản mới */
    if(isRegen && state.chapters[regenIndex]){
      pushChapterVersion(regenIndex, "Trước khi viết lại (" + (regenMode||"full") + ")");
      const oldVersions = state.chapters[regenIndex].versions || [];
      chapterObj.versions = oldVersions.concat(chapterObj.versions || []).slice(-12);
      chapterObj.status="APPROVED"; chapterObj.sync={status:"pending",canonVersion:null,syncedAt:null,changes:[]};
      state.chapters[regenIndex] = chapterObj;
      state.currentChapterIndex = regenIndex;
    } else {
      state.chapters.push(chapterObj);
      state.currentChapterIndex = state.chapters.length - 1;
      state.chaptersSinceBackup++;
    }
    recordStoryTimeMark(chapterNumber,chapterObj);
    recordChapterPostWriteAudit(chapterObj,chapterNumber);
    persist(); renderChapterNav(); renderCurrentChapter(); refreshBackupBanner(); refreshStatBar();
    clearDraftProgress();
    /* V12.27 FAST WRITE: chương đã được Quality PASS + persist ở trên.
       Tuyệt đối không chờ hậu kỳ trên đường viết chính.
       Hậu kỳ chạy fire-and-forget; lỗi hậu kỳ không được làm fail chương đã lưu. */
    chapterObj.postProcess = Object.assign({}, chapterObj.postProcess || {}, {
      status: "QUEUED", queuedAt: Date.now(), finishedAt: null, error: null
    });
    persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
    setStatus(modeTag + "✓ Đã viết xong · " + chapterObj.wordCount + " từ · đã lưu chương. Hậu kỳ đang chạy nền..." + (_lastSceneNote ? "  📝 " + _lastSceneNote : ""), false);

    // V12.28: hậu kỳ KHÔNG còn chạy trong browser. Gửi riêng snapshot chương đã lưu
    // lên Netlify Background Function; sau khi nhận 202, iPhone có thể bị khóa/thoát app.
    startBackgroundPostProcess(chapterObj, chapterNumber, text, _writeBriefSnapshot).catch(e=>{
      chapterObj.postProcess = Object.assign({}, chapterObj.postProcess || {}, {
        status: "FAILED", finishedAt: Date.now(), error: String(e && e.message || e)
      });
      persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
      setStatus("⚠ Không khởi động được hậu kỳ server: " + String(e && e.message || e), false);
    });
    /* Rà chính tả nền: không chặn chương đã lưu, chỉ thay bản nếu chương vẫn còn nguyên. */
    if(state.spellCheckEnabled&&state.accuracyMode!==true){
      const polishSource=String(chapterObj.text||"");
      polishVietnamese(polishSource,{modelOverride:state.model}).then(fixed=>{
        const live=state.chapters[state.currentChapterIndex];
        if(!live || live.id!==chapterObj.id || String(live.text||"")!==polishSource) return;
        const next=String(fixed||polishSource).trim();
        if(next && next!==polishSource){ live.text=next; live.wordCount=countWords(next); }
        live.polished=true; live.polishedAt=Date.now(); persist(); renderChapterNav(); renderCurrentChapter();
      }).catch(()=>{});
    }


  }catch(err){
    if(err.userAbort) setStatus("Đã dừng bởi người dùng.", false);
    else setStatus("Lỗi: " + err.message, false);
  }finally{
    setGenerating(false);
    setWriteProgress(null);
    chapterTextEl.classList.remove("streaming");
  }
}

$ID("writeChapterBtn").addEventListener("click", ()=>generateChapter());
$ID("regenBtn").addEventListener("click", ()=>{
  if(state.currentChapterIndex >= 0) generateChapter(state.currentChapterIndex, regenModeSelect.value, false);
  else setStatus("Chưa có chương.", false);
});
$ID("regenNsfwBtn").addEventListener("click", ()=>{
  if(state.currentChapterIndex < 0){ setStatus("Chưa có chương.", false); return; }
  if(!state.modelNsfw){ setStatus("Chưa cấu hình NSFW.", false); return; }
  generateChapter(state.currentChapterIndex, "nsfw_rewrite", true);
});

/* ========== CONTINUE CHAPTER ========== */
$ID("continueChapterBtn").addEventListener("click", async ()=>{
  if(generating){ setStatus("Đang bận...", true); return; }
  const idx = state.currentChapterIndex;
  if(idx < 0 || !state.chapters[idx]){ setStatus("Chưa có chương.", false); return; }
  const wasNsfw = state.chapters[idx].isNsfw === true;
  const pick = pickWritingModel(wasNsfw);
  let targetModel = pick.model;
  let usingNsfw = pick.isNsfw;
  if(state.nsfwMode === "auto" && matureFocusAllowsRouting() && state.modelNsfw && !usingNsfw){
    try{
      const tailC = state.chapters[idx].text.slice(-2000);
      const planC = state.chapters[idx].plan || "";
      if(shouldForceNsfwByKeyword(planC, tailC)){
        targetModel = state.modelNsfw;
        usingNsfw = true;
      } else {
        const heat = await detectHeatLevel(tailC, planC);
        if(heat >= (state.nsfwAutoThreshold || 6)){
          targetModel = state.modelNsfw;
          usingNsfw = true;
        }
      }
    }catch(e){}
  }

  setGenerating(true);
  setStatus((usingNsfw ? "🔥 [NSFW] " : "") + "Đang viết tiếp...", true);
  try{
    const chapter = state.chapters[idx];
    /* V12.24: điểm kết của CHƯƠNG NÀY. Ô Gợi ý lúc này đã là gợi ý của chương SAU nên không dùng; lấy brief đã lưu theo chương
       (briefUsed), chương cũ chưa có thì lấy dòng "Kết chương" trong kế hoạch của chương. */
    const cb = chapterBriefFor(chapter);
    let endChkC = null;
    if(cb.ending){
      setStatus("Kiểm tra chương đã tới điểm kết chưa...", true);
      endChkC = await checkChapterEnding(chapter.text, cb.ending, cb.hint, cb.directive);
    }
    const finishC = !!(endChkC && endChkC.reached === false);
    pushChapterVersion(idx, "Trước khi viết tiếp");
    const baseText = chapter.text;
    const tail = chapter.text.slice(-3200);
    const headHint = chapter.text.slice(0, 400);
    const vocabBlock = buildVocabularyBlock();
    const limC = chapterWordLimits();
    const finishPromptC = finishC ? [
      buildFinishPrompt({
        chapterNumber: idx + 1, wc: countWords(chapter.text), goal: Math.round(limC.target * 0.95), maxWords: limC.hardMax, minCap: 700,
        ending: cb.ending, missing: endChkC.missing, hint: cb.hint, directive: cb.directive, tail: tail,
        style: [ "🎨 " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""), vocabBlock,
                 state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
                 usingNsfw ? EROTIC_STYLE_PROMPT : "", usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "" ].filter(Boolean).join("\n")
      }),
      "", buildContextBlockForChapter(chapter)
    ].join("\n") : "";
    if(finishC) setStatus("Chương chưa tới điểm kết — viết tiếp để chốt kết...", true);
    const prompt = finishC ? finishPromptC : [
      "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU. Giọng tự nhiên.",
      "",
      "Bạn đang VIẾT TIẾP chương " + (idx + 1) + " (không mở chương mới).",
      "===== ĐOẠN CUỐI (PHẢI TIẾP NỐI) =====", tail, "===== HẾT =====",
      "",
      "Viết TIẾP liền mạch 1500-2500 từ. Bắt đầu ngay từ câu tiếp theo. Không tóm tắt, không nhảy cảnh, không lặp ý/cụm từ.",
      "🎨 " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
      chapter.plan ? ("Kế hoạch:\n" + chapter.plan) : "",
      vocabBlock,
      state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
      usingNsfw ? ("\n" + EROTIC_STYLE_PROMPT) : "",
      usingNsfw ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
      "", buildContextBlockForChapter(chapter)
    ].filter(Boolean).join("\n");

    const canStream = state.streamingEnabled;
    if(canStream) chapterTextEl.classList.add("streaming");
    const onChunk = canStream ? (delta, full) => {
      const combined = baseText.replace(/\s+$/,"") + "\n\n" + full;
      chapterTextEl.textContent = combined;
      saveDraftProgress(combined, { mode: "continue", idx: idx, isNsfw: usingNsfw });
    } : null;

    let contText = "", contFinish = null;
    const r = await callAI(prompt, {
      maxTokens:12000, temperature:0.82, modelOverride: targetModel,
      frequency_penalty: 0.15, presence_penalty: 0.1,
      streaming: canStream, onChunk: onChunk
    });
    contText = r.text; contFinish = r.finishReason;
    chapterTextEl.classList.remove("streaming");
    if(finishC && isFinishDoneReply(contText)){   // V12.24: AI xác nhận điểm kết thực ra đã được viết
      chapterTextEl.textContent = baseText;
      setStatus("Chương đã có điểm kết rồi — không nối thêm.", false);
      setGenerating(false); return;
    }

    if(detectNonVietnamese(contText)){
      try{ const r2 = await callAI(prompt + "\n\nBẮT BUỘC 100% TIẾNG VIỆT.", {maxTokens:12000, temperature:0.9, modelOverride: targetModel}); contText = r2.text; contFinish = r2.finishReason; }catch(e){}
    }
    { const dd = dropRestartedContinuation(baseText, contText);
      if(!dd.trim() || countWords(dd) < (finishC ? 12 : 40)){ setStatus("Phần viết tiếp lặp lại nội dung đã có nên bị bỏ.", false); setGenerating(false); return; }
      contText = dd; }
    contText = formatParagraphs(stripForeign(stripThinkingOutput(contText)));
    if(state.spellCheckEnabled && contText){
      const fixed = await polishVietnamese(contText, { modelOverride: state.model });
      if(fixed) contText = fixed;
    }

    chapter.text = chapter.text.replace(/\s+$/,"") + "\n\n" + contText.trim();
    chapter.wordCount = countWords(chapter.text);
    chapter.truncated = contFinish === "length";
    if(usingNsfw){ chapter.modelUsed = targetModel; chapter.isNsfw = true; }
    clearDraftProgress();
    persist(); renderChapterNav(); renderCurrentChapter();
    setStatus("Đã viết tiếp.", false);
    /* V12.24: kiểm tra lại sau khi nối — báo rõ chương đã tới điểm kết hay còn thiếu, ghi vào chẩn đoán chương. */
    let endNoteC = "";
    if(cb.ending){
      setStatus("Đã viết tiếp — đang kiểm tra điểm kết...", true);
      const after = await checkChapterEnding(chapter.text, cb.ending, cb.hint, cb.directive);
      const keep = (chapter.updateDiagnostics || []).filter(x => !/CHƯA TỚI ĐIỂM KẾT/.test(x));
      if(after.reached === false){
        endNoteC = "⚠ Đã viết tiếp nhưng CHƯƠNG VẪN CHƯA TỚI ĐIỂM KẾT" + (after.missing ? (" — còn thiếu: " + after.missing) : "") + ". Bấm 'Viết tiếp' thêm lần nữa.";
        chapter.updateDiagnostics = keep.concat([endNoteC.replace(/^⚠\s*/, "")]);
      } else {
        chapter.updateDiagnostics = keep;
        if(after.reached === true) endNoteC = "✓ Đã viết tiếp — chương đã tới điểm kết.";
      }
      persist(); renderCurrentChapter();
      setStatus(endNoteC || "Đã viết tiếp.", false);
    }
    const cn = idx + 1;
    if(state.accuracyMode===true){
      const accuracyContext=buildStoryBibleSummary()+"\n"+characterSummaryForPrompt(relevantCharacters(20));
      setStatus("🎯 Ưu tiên độ chính xác: đang review và vá cục bộ phần viết tiếp trước khi Sync...",true);
      const continuationGate=await runQualityGate(chapter,cn,chapter.plan||"",accuracyContext,{rewrite:true,forceWarnings:true});
      if(!continuationGate.approved){
        chapter.status=chapter.sync&&chapter.sync.syncedAt?"MODIFIED_AFTER_SYNC":"REVISION_REQUIRED";
        chapter.postProcess=Object.assign({},chapter.postProcess||{},{status:"BLOCKED_ACCURACY",error:"Chương viết tiếp chưa vượt Quality Gate ở Accuracy Mode."});
        persist(); renderChapterNav(); renderCurrentChapter();
        setStatus("⛔ Viết tiếp đã được lưu thành bản nháp nhưng chưa Sync: Accuracy Mode chưa xác minh đủ Required Beat/chất lượng. Dùng 🛠 AI tự sửa hoặc chỉnh tay rồi 🔍 Duyệt lại.",false);
        return;
      }
      if(blockIfRequiredBeatsMissing(chapter,"Sync Canon / xuất bản")){
        chapter.status=chapter.sync&&chapter.sync.syncedAt?"MODIFIED_AFTER_SYNC":"REVISION_REQUIRED";
        persist(); renderChapterNav(); renderCurrentChapter(); return;
      }
      chapter.status="APPROVED";
      persist(); renderChapterNav(); renderCurrentChapter();
    }
    // V12.30: continuation cũng đi qua cùng một job hậu kỳ tổng hợp trên server.
    await startBackgroundPostProcess(chapter, cn, chapter.text, chapter.briefUsed || state.nextChapterHint || "");
    if(endNoteC) setStatus(endNoteC, false);

  }catch(err){
    chapterTextEl.classList.remove("streaming");
    if(err.userAbort) setStatus("Đã dừng.", false);
    else setStatus("Lỗi: " + err.message, false);
  }finally{ setGenerating(false); }
});

/* ========== CHECKPOINTS ========== */
const CHECKPOINTS = [
  { at: 10, id: "review_10", title: "📖 Checkpoint 10 chương — Review đầu tiên",
    msg: "Đã viết 10 chương. Nên đọc lại, sửa Story Bible, xoá arc chưa cần.",
    actions: [{ label: "🔍 Integrity Scan", fn: ()=> $ID("integrityScanBtn").click() },
              { label: "🎬 Rescan Scene", fn: ()=> $ID("rescanScenesBtn").click() }]
  },
  { at: 20, id: "rescan_20", title: "🔄 Checkpoint 20 chương — Đồng bộ bộ nhớ",
    msg: "Đã 20 chương. Nên rescan Character DB + Current Status + Threads + Scene.",
    actions: [{ label: "👤 Rescan NV", fn: ()=> $ID("npcUpdateBtn").click() },
              { label: "📊 Rescan Status", fn: ()=> $ID("statusFullRescanBtn").click() },
              { label: "🎬 Rescan Scene", fn: ()=> $ID("rescanScenesBtn").click() }]
  },
  { at: 30, id: "outline_30", title: "📋 Checkpoint 30 chương — Lập Outline dài hạn",
    msg: "Đã 30 chương. Nên lập Outline 10-15 chương tới.",
    actions: [{ label: "🤖 AI Outline", fn: ()=> $ID("outlineAIGenerateBtn").click() }]
  },
  { at: 40, id: "consolidate_40", title: "🧹 Checkpoint 40 chương — Consolidate",
    msg: "Đã 40 chương. Nên dọn DB: xoá NV/địa điểm không dùng, đóng thread cũ, NÉN chương cũ.",
    actions: [{ label: "🗜️ Nén chương cũ", fn: ()=> $ID("compressOldBtn").click() },
              { label: "🔍 Integrity Scan", fn: ()=> $ID("integrityScanBtn").click() }]
  },
  { at: 60, id: "slow_60", title: "🐢 Checkpoint 60 chương — Slow Mode",
    msg: "Đã 60 chương. Khuyên: viết 2-3 chương/ngày, đọc lại toàn bộ mỗi tuần.",
    actions: [{ label: "🗜️ Nén chương cũ", fn: ()=> $ID("compressOldBtn").click() },
              { label: "📋 Lập Outline", fn: ()=> $ID("outlineAIGenerateBtn").click() }]
  },
  { at: 80, id: "audit_80", title: "🔎 Checkpoint 80 chương — Full Audit",
    msg: "Đã 80 chương. Nên chạy Integrity Scan + rescan toàn bộ.",
    actions: [{ label: "🔍 Full Scan", fn: ()=> $ID("integrityScanBtn").click() },
              { label: "👤 Rescan NV", fn: ()=> $ID("npcUpdateBtn").click() },
              { label: "🎬 Rescan Scene", fn: ()=> $ID("rescanScenesBtn").click() }]
  },
  { at: 100, id: "major_100", title: "🏆 Checkpoint 100 chương — Major Review",
    msg: "Đã 100 chương! Đọc lại 10 chương đầu, so sánh giọng văn, điều chỉnh Style Bible nếu cần.",
    actions: [{ label: "🔍 Full Scan", fn: ()=> $ID("integrityScanBtn").click() }]
  }
];

/* ========== RESCAN DOWNSTREAM ========== */
async function rescanFrom(startChapterNum){
  if(startChapterNum < 1 || startChapterNum > state.chapters.length){
    setStatus("Chương không hợp lệ.", false); return;
  }
  const ok = await showConfirm(
    "Rescan từ chương " + startChapterNum + " đến " + state.chapters.length + "?\n\nSẽ chạy: summary + character + loc/item + thread + status + scene + continuity.\n\nCó thể mất vài phút.",
    { okText: "Bắt đầu" }
  );
  if(!ok) return;
  setGenerating(true);
  try{
    const ch = state.chapters[startChapterNum - 1];
    if(ch) state.currentStatus = "";
    for(let i = startChapterNum - 1; i < state.chapters.length; i++){
      state.chapters[i].summary = "";
      state.chapters[i].continuityWarnings = [];
    }
    state.characters.forEach(c=>{ c.history = (c.history||[]).filter(h=> h.chapter < startChapterNum); });
    state.threads = state.threads.filter(t=> t.chapterIntroduced < startChapterNum);
    state.scenes = state.scenes.filter(s=> (s.chapter||0) < startChapterNum);
    persist();

    for(let i = startChapterNum - 1; i < state.chapters.length; i++){
      const cn = i + 1;
      const c = state.chapters[i];
      setStatus("Rescan chương " + cn + "/" + state.chapters.length + "...", true);
      try{
        const sum = await generateChapterSummary(c.text, cn, true);
        if(sum) c.summary = sum;
        const rc = await updateCharactersIncremental(c.text, cn, true);
        const rw = await updateWorldIncremental(c.text, cn, true);
        const rs = await updateCurrentStatusIncremental(c.text, cn, true);
        markAutoUpdateIssue(cn, "NV", !rc || !rc.ok, true);
        markAutoUpdateIssue(cn, "Thế giới", !rw || !rw.ok, true);
        markAutoUpdateIssue(cn, "Status", !rs || !rs.ok, true);
        if(state.mature && state.autoSceneEnabled){
          try{ await scanScenesForChapter(cn); }catch(e){}
        }
        persist();
      }catch(e){ console.warn("Rescan ch " + cn + " lỗi:", e); }
      if(userStopRequested){
        renderAll();
        setStatus("Đã dừng — rescan được tới chương " + cn + "/" + state.chapters.length + ".", false);
        return;
      }
    }
    renderAll();
    setStatus("Đã rescan từ chương " + startChapterNum + ".", false);
  }catch(err){
    setStatus("Lỗi rescan: " + err.message, false);
  }finally{ setGenerating(false); }
}
$ID("rescanFromBtn").addEventListener("click", ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  rescanFrom(idx + 1);
});

/* ========== SPLIT / MERGE / INSERT ========== */
async function offerFixStray(idx, stray){
  const c = state.chapters[idx]; if(!c) return;
  const ok = await showConfirm("Phát hiện từ lạ: " + stray.slice(0,8).join(", ") + ".\nĐể AI sửa các đoạn chứa từ lạ (chỉ những đoạn đó, không viết lại cả chương)?", { okText: "Sửa từ lạ" });
  let r = { fixed: 0, text: c.text, remaining: stray };
  if(ok){
    setStatus("Đang sửa từ lạ…", true);
    r = await fixStrayWordsInText(c.text, { modelOverride: state.model });
    if(r.fixed > 0){ c.text = r.text; c.wordCount = countWords(r.text); persist(); renderCurrentChapter(); }
  }
  if(ok) setStatus(r.fixed > 0 ? ("Đã sửa " + r.fixed + " đoạn." + (r.remaining.length ? " Còn từ lạ: " + r.remaining.slice(0,8).join(", ") + "." : "")) : "AI không sửa được đoạn nào.", false);
  /* V12.32.6c: những từ lạ còn lại -> hỏi xóa hẳn khỏi chương (khớp nguyên từ) thay vì bắt sửa tay. */
  const left = (r.fixed > 0 ? r.remaining : stray) || [];
  if(left.length){
    const base = r.fixed > 0 ? r.text : c.text;
    const ok2 = await showConfirm("Còn các từ lạ: " + left.slice(0,10).join(", ") + ".\nXóa hẳn các từ này khỏi chương (chỉ khớp nguyên từ, các chữ khác giữ nguyên)?", { okText: "Xóa các từ lạ" });
    if(ok2){
      const cleaned = formatParagraphs(removeStrayWords(base, left));
      c.text = cleaned; c.wordCount = countWords(cleaned); persist(); renderCurrentChapter();
      setStatus("Đã xóa " + left.length + " từ lạ khỏi chương.", false);
    } else if(r.fixed > 0){ /* giữ bản AI đã sửa */ }
  }
}
$ID("reviewChapterBtn").addEventListener("click", ()=>reviewCurrentChapter());
$ID("autoFixChapterBtn").addEventListener("click", ()=>reviewCurrentChapter({autoFix:true}));
// V14.3.1: bỏ RIÊNG các đoạn gần như trùng nguyên văn với một đoạn đứng trước (>=80% trigram), giữ mọi đoạn còn lại. Không bao giờ cắt cụt phần đuôi.
function dropInnerDuplicateParagraphs(text) {
  const paras = _splitParas(text), seen = [], kept = [];
  paras.forEach(p => {
    const w = _normWords(p);
    if (w.length >= 8) { const g = _grams(w, 3); if (seen.some(x => _sim(g, x) >= 0.8)) return; seen.push(g); }
    kept.push(p);
  });
  return kept.length === paras.length ? String(text || "") : kept.join("\n\n");
}
$ID("fmtParaBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  const c = state.chapters[idx];
  const orig = String(c.text||"");
  /* V12.32.6c: nút này là bước CHUẨN HÓA: dọn ký tự/chữ lạ, markdown/emoji, ghi chú AI, lặp bất thường -> bỏ cảnh viết lặp -> ngắt đoạn. */
  const sanitized = sanitizeChapterText(orig);
  const cleanedChars = Math.max(0, orig.length - sanitized.length);
  /* V14.3.1: dedupeRepeatedScene CẮT TỪ CHỖ LẶP ĐẦU TIÊN TRỞ ĐI nên chương 5.000 từ có thể còn ~1.500 từ nếu bị nhận nhầm là "viết lặp từ đầu".
     Nay: cắt chỉ khi mất ≤ 20% số từ; nếu mất nhiều hơn thì chỉ bỏ riêng các đoạn trùng gần nguyên văn, giữ phần còn lại. */
  let deduped = dedupeRepeatedScene(sanitized), dupNote = "";
  {
    const wBefore = countWords(sanitized), wAfter = countWords(deduped);
    if(deduped.length < sanitized.length && wAfter < wBefore * 0.8){
      let lite = dropInnerDuplicateParagraphs(sanitized);
      if(countWords(lite) < wBefore * 0.8) lite = sanitized; // bỏ đoạn trùng mà vẫn mất >20% => đáng ngờ, không động vào
      dupNote = " (Phát hiện lặp nhưng cắt hết sẽ mất " + (wBefore - wAfter) + " từ nên KHÔNG cắt cụt; " + (lite.length < sanitized.length ? "chỉ bỏ các đoạn trùng lẻ" : "giữ nguyên, hãy tự kiểm tra") + ".)";
      deduped = lite;
    }
  }
  const cutDup = deduped.length < sanitized.length;
  const next = formatParagraphs(deduped);
  const stray = findStrayWords(next, charNameList());
  const strayMsg = stray.length ? " Từ lạ cần kiểm tra: " + stray.slice(0,8).join(", ") + "." : "";
  const cleanMsg = cleanedChars > 0 ? " Đã dọn ~" + cleanedChars + " ký tự rác/lạ." : "";
  if(next === orig.trim()){ setStatus("Chương này đã sạch và ngắt đoạn ổn rồi." + strayMsg, false); if(stray.length){ await offerFixStray(idx, stray); } return; }
  if(cutDup){
    const ok = await showConfirm("Phát hiện chương bị viết lặp lại từ đầu. Cắt bỏ phần lặp (còn ~" + countWords(next) + " từ)?", { okText: "Cắt phần lặp" });
    if(!ok){ c.text = formatParagraphs(sanitized); c.wordCount = countWords(c.text); persist(); renderCurrentChapter(); setStatus("Đã chuẩn hóa + ngắt đoạn (giữ nguyên phần lặp)." + cleanMsg + strayMsg + dupNote, false); return; }
  }
  c.text = next; c.wordCount = countWords(next);
  persist(); renderCurrentChapter();
  setStatus((cutDup ? "Đã cắt phần lặp, chuẩn hóa và ngắt đoạn chương " : "Đã chuẩn hóa và ngắt đoạn chương ") + (idx+1) + "." + cleanMsg + strayMsg + dupNote, false);
  if(stray.length){ await offerFixStray(idx, stray); }
});
$ID("splitChapterBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  const c = state.chapters[idx];
  const text = c.text;
  const mid = Math.floor(text.length / 2);
  const before = text.lastIndexOf("\n\n", mid);
  const after = text.indexOf("\n\n", mid);
  let splitAt = mid;
  if(before > 0 && (mid - before) < 500) splitAt = before;
  else if(after > 0 && (mid - after) < 500) splitAt = after;
  const part1 = text.slice(0, splitAt).trim();
  const part2 = text.slice(splitAt).trim();
  if(!part1 || !part2){ setStatus("Không tách được.", false); return; }
  const ok = await showConfirm(
    "Tách chương "+(idx+1)+" thành 2 chương?\n\nPhần 1: ~" + countWords(part1) + " từ\nPhần 2: ~" + countWords(part2) + " từ",
    { okText: "Tách" }
  );
  if(!ok) return;
  const newChapter = {
    title: c.title + " (phần 2)", text: part2, wordCount: countWords(part2),
    truncated: false, plan: "", continuityWarnings: [], modelUsed: c.modelUsed,
    isNsfw: c.isNsfw, polished: false, summary: "", versions: [], compressed: false
  };
  c.text = part1; c.wordCount = countWords(part1);
  c.title = c.title + " (phần 1)";
  c.stateSnapshot = null; // nội dung đổi + số chương sau đó bị lệch, cần rescan để tạo lại lịch sử
  state.chapters.splice(idx + 1, 0, newChapter);
  persist(); renderChapterNav(); renderCurrentChapter();
  setStatus("Đã tách chương.", false);
  if(await showConfirm("Rescan bộ nhớ từ chương "+(idx+1)+" để đồng bộ?", {okText:"Rescan"})) rescanFrom(idx + 1);
});

$ID("mergeChapterBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0 || idx >= state.chapters.length - 1){ setStatus("Không có chương sau.", false); return; }
  const a = state.chapters[idx], b = state.chapters[idx + 1];
  const ok = await showConfirm("Gộp chương "+(idx+1)+" và "+(idx+2)+" thành 1?", { okText: "Gộp" });
  if(!ok) return;
  a.text = a.text.replace(/\s+$/,"") + "\n\n" + b.text;
  a.wordCount = countWords(a.text);
  a.title = a.title + " + " + b.title;
  a.summary = "";
  a.continuityWarnings = [];
  a.stateSnapshot = null; // nội dung đã đổi (gộp thêm ch sau) nên snapshot cũ không còn đúng, cần rescan lại
  state.chapters.splice(idx + 1, 1);
  wipeChapterMemoryAfterMerge(idx + 2);
  persist(); renderChapterNav(); renderCurrentChapter();
  setStatus("Đã gộp chương.", false);
  if(await showConfirm("Rescan bộ nhớ từ chương "+(idx+1)+"?", {okText:"Rescan"})) rescanFrom(idx + 1);
});

function wipeChapterMemoryAfterMerge(mergedNum){
  state.characters.forEach(c=>{
    if(Array.isArray(c.history)){
      c.history = c.history.filter(h=> h.chapter !== mergedNum)
        .map(h=> h.chapter > mergedNum ? Object.assign({}, h, {chapter: h.chapter - 1}) : h);
    }
    if(c.lastAppearance === mergedNum) c.lastAppearance = Math.max(1, mergedNum - 1);
    else if(c.lastAppearance > mergedNum) c.lastAppearance--;
    if(c.firstAppearance === mergedNum) c.firstAppearance = Math.max(1, mergedNum - 1);
    else if(c.firstAppearance > mergedNum) c.firstAppearance--;
  });
  state.threads = state.threads.filter(t=> t.chapterIntroduced !== mergedNum)
    .map(t=> t.chapterIntroduced > mergedNum ? Object.assign({}, t, {chapterIntroduced: t.chapterIntroduced - 1}) : t);
  state.scenes = state.scenes.map(s=>{
    if(s.chapter === mergedNum) s.chapter = Math.max(1, mergedNum - 1);
    else if(s.chapter > mergedNum) s.chapter--;
    return s;
  });
  remapSnapshotChapterNumbers(n=>{
    if(n === mergedNum) return Math.max(1, mergedNum - 1);
    if(n > mergedNum) return n - 1;
    return n;
  });
}

$ID("insertChapterBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0){ setStatus("Chưa có chương.", false); return; }
  const title = await askText("Tiêu đề chương mới (chèn sau chương "+(idx+1)+")", "Chương chèn");
  if(title == null) return;
  const newChapter = {
    title: title.trim() || "Chương chèn", text: "", wordCount: 0, truncated: false,
    plan: "", continuityWarnings: [], modelUsed: null, isNsfw: false,
    polished: false, summary: "", versions: [], compressed: false
  };
  state.chapters.splice(idx + 1, 0, newChapter);
  state.characters.forEach(c=>{
    if(Array.isArray(c.history)) c.history = c.history.map(h=> h.chapter > idx + 1 ? Object.assign({}, h, {chapter: h.chapter + 1}) : h);
    if(c.lastAppearance != null && c.lastAppearance > idx + 1) c.lastAppearance++;
    if(c.firstAppearance != null && c.firstAppearance > idx + 1) c.firstAppearance++;
  });
  state.threads.forEach(t=>{ if(t.chapterIntroduced > idx + 1) t.chapterIntroduced++; });
  state.scenes.forEach(s=>{ if(s.chapter > idx + 1) s.chapter++; });
  remapSnapshotChapterNumbers(n=> n > idx + 1 ? n + 1 : n);
  state.currentChapterIndex = idx + 1;
  persist(); renderChapterNav(); renderCurrentChapter();
  setStatus("Đã chèn chương trống.", false);
});

/* ========== SCENE-LEVEL REWRITE ========== */
$ID("splitScenesBtn").addEventListener("click", async ()=>{
  const idx = state.currentChapterIndex;
  if(idx < 0 || !state.chapters[idx]){ setStatus("Chưa có chương.", false); return; }
  const c = state.chapters[idx];
  const text = c.text || "";
  if(!text.trim()){ setStatus("Chương trống.", false); return; }
  /* Tách theo dấu xuống dòng đôi */
  let parts = text.split(/\n\s*\n+/).filter(p=> p.trim().length > 30);
  if(parts.length < 2){ setStatus("Không đủ đoạn để tách cảnh.", false); return; }
  const overlay = document.createElement("div"); overlay.className = "modal-overlay";
  const box = document.createElement("div"); box.className = "modal-box";
  let html = '<div class="modal-close" id="sceneSplitClose">×</div>';
  html += '<h3 class="modal-title">🎬 Tách chương '+(idx+1)+' thành '+parts.length+' cảnh</h3>';
  html += '<div class="hint" style="margin-bottom:10px;">Chọn cảnh để viết lại riêng</div>';
  html += parts.map((p,i)=>{
    const wc = countWords(p);
    return '<div class="version-item">'
      + '<div class="arc-card-top"><b>Cảnh '+(i+1)+'</b><span class="hint">'+wc+' từ</span></div>'
      + '<div class="hint" style="max-height:80px;overflow:hidden;">'+escapeHtml(p.slice(0,180))+'...</div>'
      + '<div class="char-actions">'
        + '<button class="btn btn-pink btn-sm" data-rw-scene="'+i+'">✨ Viết lại</button>'
        + '<button class="btn btn-ghost btn-sm" data-del-scene="'+i+'">🗑 Xoá đoạn</button>'
      + '</div></div>';
  }).join("");
  html += '<button class="btn btn-ghost" id="sceneSplitCancel" style="margin-top:10px;">Đóng</button>';
  box.innerHTML = html;
  overlay.appendChild(box); document.body.appendChild(overlay);
  $ID("sceneSplitClose").onclick = ()=>overlay.remove();
  $ID("sceneSplitCancel").onclick = ()=>overlay.remove();
  overlay.onclick = e => { if(e.target === overlay) overlay.remove(); };
  box.querySelectorAll("[data-rw-scene]").forEach(btn=>{
    btn.addEventListener("click", async ()=>{
      const si = parseInt(btn.getAttribute("data-rw-scene"),10);
      await rewriteScene(idx, si, parts[si], overlay);
    });
  });
  box.querySelectorAll("[data-del-scene]").forEach(btn=>{
    btn.addEventListener("click", async ()=>{
      const si = parseInt(btn.getAttribute("data-del-scene"),10);
      const ok = await showConfirm("Xoá cảnh "+(si+1)+" khỏi chương?", {okText:"Xoá", danger:true});
      if(!ok) return;
      parts.splice(si, 1);
      c.text = parts.join("\n\n");
      c.wordCount = countWords(c.text);
      persist(); renderChapterNav(); renderCurrentChapter();
      overlay.remove();
      setStatus("Đã xoá cảnh.", false);
    });
  });
});

async function rewriteScene(chapterIdx, sceneIdx, sceneText, overlay){
  const instruction = await askChoice("Viết lại cảnh này theo hướng nào?", [["1","Tăng miêu tả"],["2","Tự nhiên hơn (giảm mùi AI)"],["3","Tăng 18+"],["4","Tăng kịch tính"],["5","Mở rộng chi tiết"],["6","Rút gọn"],["7","Đào sâu nội tâm"]], "1");
  if(instruction == null) return;
  const map = {
    "1": "Viết lại cảnh này, TĂNG CƯỜNG MIÊU TẢ ngoại hình, không khí, chi tiết giác quan (mùi, ánh sáng, âm thanh, nhiệt độ). Giữ nguyên sự kiện.",
    "2": "Viết lại tự nhiên hơn như người viết thật: câu có nhịp, không sáo rỗng, giảm mùi AI. Giữ nguyên sự kiện.",
    "3": "Viết lại cảnh này thành cảnh 18+ mạnh, chi tiết, giác quan. Giữ đúng tính cách nhân vật.",
    "4": "Thêm kịch tính, căng thẳng, xung đột. Giữ sự kiện chính.",
    "5": "Mở rộng chi tiết, thêm hành động nhỏ, biểu cảm vi mô. Giữ sự kiện.",
    "6": "Rút gọn xuống ~60-70% độ dài, giữ ý chính.",
    "7": "Đào sâu nội tâm, cảm xúc, động cơ nhân vật."
  };
  const mode = map[String(instruction).trim()] || map["1"];
  setStatus("Đang viết lại cảnh...", true);
  const isErotic = String(instruction).trim() === "3";
  const prompt2 = [
    "BẮT BUỘC: 100% TIẾNG VIỆT CÓ DẤU. Giọng tự nhiên.",
    "🎨 Mức miêu tả: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
    "Bối cảnh:", buildStoryBibleSummary(),
    isErotic ? EROTIC_STYLE_PROMPT : "",
    isErotic ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
    "YÊU CẦU: " + mode,
    state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
    "",
    "CHỈ TRẢ VỀ cảnh đã viết lại.",
    "", "===== CẢNH GỐC =====", sceneText
  ].filter(Boolean).join("\n");
  try{
    const { text } = await callAI(prompt2, {
      maxTokens: Math.min(8000, Math.ceil(sceneText.length/2) + 800),
      temperature: isErotic ? 0.9 : 0.9,
      modelOverride: isErotic ? (state.modelNsfw || undefined) : undefined
    });
    const cleaned = text.replace(/^```[a-z]*\n?/i, "").replace(/\n?```$/,"").trim();
    const c = state.chapters[chapterIdx];
    if(!c) return;
    pushChapterVersion(chapterIdx, "Trước khi rewrite cảnh");
    /* Thay thế đoạn */
    const newText = c.text.replace(sceneText, cleaned);
    if(newText === c.text){ setStatus("Không thay được cảnh gốc.", false); return; }
    c.text = newText;
    c.wordCount = countWords(newText);
    persist(); renderChapterNav(); renderCurrentChapter();
    if(overlay) overlay.remove();
    setStatus("Đã viết lại cảnh.", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
}
/* ========== REWRITE SELECTION (floating) ========== */
function updateFloatingRewrite(){
  const sel = window.getSelection();
  const hide = ()=>{ if(Date.now() < (floatingRewrite._pressUntil||0)) return; floatingRewrite.style.display = "none"; };
  if(!sel || sel.rangeCount === 0 || sel.isCollapsed || !chapterTextEl.contains(sel.anchorNode)) return hide();
  const text = sel.toString().trim();
  if(text.length < 10) return hide();
  const rect = sel.getRangeAt(0).getBoundingClientRect();
  floatingRewrite.style.display = "block";
  const left = Math.min(Math.max(8, rect.left), window.innerWidth - (floatingRewrite.offsetWidth||150) - 8);
  let top = rect.bottom + 14; if(top > window.innerHeight - 70) top = Math.max(8, rect.top - 52);
  floatingRewrite.style.left = left + "px"; floatingRewrite.style.top = top + "px";
  floatingRewrite._selectedText = text;
}
let _selTimer = null;
document.addEventListener("selectionchange", ()=>{ clearTimeout(_selTimer); _selTimer = setTimeout(updateFloatingRewrite, 250); });
document.addEventListener("mouseup", ()=>setTimeout(updateFloatingRewrite, 0));
floatingRewrite.addEventListener("touchstart", ()=>{ floatingRewrite._pressUntil = Date.now() + 1500; }, {passive:true});
floatingRewrite.addEventListener("mousedown", e=>e.preventDefault());
floatingRewrite.addEventListener("click", async ()=>{
  const selText = floatingRewrite._selectedText;
  if(!selText){ floatingRewrite.style.display = "none"; return; }
  floatingRewrite.style.display = "none";
  const mode = await askChoice("Viết lại đoạn đã chọn theo hướng nào?", [["1","Văn phong tự nhiên"],["2","Sửa chính tả"],["3","Đào sâu tâm lý"],["4","Tăng miêu tả"],["5","Thêm world-building"],["6","Tăng kịch tính"],["7","Rút ngắn"],["8","Mở rộng"],["9","18+ nóng"]], "4");
  if(mode == null) return;
  const modes = {
    "1": "Viết lại đoạn này với văn phong tự nhiên như người viết thật: nhịp câu đa dạng, giảm mùi AI, ưu tiên giác quan và hành động.",
    "2": "Sửa chính tả, dấu câu, ngữ pháp đoạn này.",
    "3": "Đào sâu hơn nội tâm, cảm xúc, động cơ nhân vật. Giữ sự kiện.",
    "4": "TĂNG CƯỜNG MIÊU TẢ: tả ngoại hình nhân vật (khuôn mặt, mắt, tóc, da, giọng, mùi), không khí cảnh, chi tiết giác quan (ánh sáng, âm thanh, nhiệt độ, cảm giác trên da). Giữ nguyên sự kiện và độ dài gần bằng.",
    "5": "Thêm chi tiết world-building, không khí, bối cảnh qua giác quan.",
    "6": "Thêm kịch tính, căng thẳng. Giữ sự kiện chính.",
    "7": "Rút ngắn xuống ~60-70% độ dài, giữ ý chính.",
    "8": "Mở rộng lên ~150-200% độ dài, thêm chi tiết, cảm xúc, miêu tả.",
    "9": "Viết lại đoạn này thành cảnh 18+ mạnh, chi tiết, giác quan, nội tâm. Hạn chế bạo lực thừa. Giữ đúng tính cách và ranh giới nhân vật."
  };
  const key = String(mode).trim();
  const instruction = modes[key] || modes["4"];
  const isErotic = key === "9";
  setStatus("Đang viết lại đoạn...", true);
  const prompt2 = [
    "BẮT BUỘC NGÔN NGỮ: 100% TIẾNG VIỆT CÓ DẤU. Giọng tự nhiên như người viết thật.",
    "🎨 Mức miêu tả: " + (DESCRIPTION_PROMPTS[state.descriptionLevel] || ""),
    "",
    "Bối cảnh:", buildStoryBibleSummary(),
    isErotic ? EROTIC_STYLE_PROMPT : "",
    isErotic ? ("MỨC 18+: " + (EXPLICIT_PROMPTS[state.explicitLevel] || "")) : "",
    "YÊU CẦU: " + instruction,
    state.pronounRules ? ("QUY TẮC XƯNG HÔ:\n" + state.pronounRules) : "",
    "",
    "CHỈ TRẢ VỀ đoạn đã viết lại.",
    "", "===== GỐC =====", selText
  ].filter(Boolean).join("\n");
  try{
    const { text } = await callAI(prompt2, {
      maxTokens: Math.min(8000, Math.ceil(selText.length/2) + 1000),
      temperature: isErotic ? 0.9 : 0.9,
      frequency_penalty: 0.4, presence_penalty: 0.3,
      modelOverride: isErotic ? (state.modelNsfw || undefined) : undefined
    });
    const cleaned = text.replace(/^```[a-z]*\n?/i, "").replace(/\n?```$/,"").trim();
    const fullText = chapterTextEl.textContent;
    const newText = fullText.replace(selText, cleaned);
    if(newText === fullText){ setStatus("Không tìm thấy đoạn gốc.", false); return; }
    const idx = state.currentChapterIndex;
    if(idx >= 0 && state.chapters[idx]){
      pushChapterVersion(idx, "Trước khi rewrite đoạn");
      state.chapters[idx].text = newText;
      state.chapters[idx].wordCount = countWords(newText);
      persist(); renderChapterNav(); renderCurrentChapter();
    }
    setStatus("Đã viết lại đoạn.", false);
  }catch(err){ setStatus("Lỗi: " + err.message, false); }
});
document.addEventListener("mousedown", (e)=>{
  if(e.target === floatingRewrite) return;
  if(!chapterTextEl.contains(e.target) && !floatingRewrite.contains(e.target)){
    floatingRewrite.style.display = "none";
  }
});

/* ========== JSON EXPORT / IMPORT ========== */
function downloadJson(){
  const payload = JSON.parse(JSON.stringify(state));
  if(!state.includeKeyOnExport) payload.apiKey = "";
  payload.chaptersSinceBackup = 0;
  const jsonText = JSON.stringify(payload, null, 2);
  /* Thử tải xuống trước */
  let downloaded = false;
  try{
    const blob = new Blob([jsonText], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = (state.storyName ? state.storyName.replace(/\s+/g,"-") : "truyen-ai") + "-" + Date.now() + ".json";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    downloaded = true;
  }catch(e){ console.warn("[Export] blob bị chặn:", e); }

  if(downloaded){ state.chaptersSinceBackup = 0; persist(); refreshBackupBanner(); setStatus("Đã tải file backup JSON.", false); return; }
  /* Hiện textarea dự phòng (chỉ khi tải thất bại) */
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  const box = document.createElement("div");
  box.className = "modal-box";
  box.style.maxWidth = "600px";
  box.innerHTML = '<div class="modal-close" id="expClose">×</div>'
    + '<h3 class="modal-title">' + (downloaded ? '✓ Đã tải xuống (nếu không thấy file, copy tay bên dưới)' : '⚠ Copy JSON bên dưới') + '</h3>'
    + '<div class="hint" style="margin-bottom:8px;">Chạm vào ô → giữ 2 giây → <b>Chọn tất cả</b> → <b>Copy</b>. Dán vào Notes hoặc lưu thành file backup.json.</div>'
    + '<textarea id="expTextarea" readonly style="width:100%;height:50vh;font-family:monospace;font-size:11px;padding:8px;background:#000;color:#0f0;border:1px solid #333;box-sizing:border-box;"></textarea>'
    + '<button class="btn btn-gold" id="expSelectAll" style="margin-top:8px;">📋 Chọn tất cả</button>';
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  const ta = box.querySelector("#expTextarea");
  ta.value = jsonText;
  box.querySelector("#expClose").onclick = ()=>overlay.remove();
  overlay.onclick = (e)=>{ if(e.target === overlay) overlay.remove(); };
  box.querySelector("#expSelectAll").onclick = ()=>{
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, ta.value.length);
  };
  state.chaptersSinceBackup = 0;
  persist(); refreshBackupBanner();
}
$ID("downloadJsonBtn").addEventListener("click", downloadJson);
$ID("uploadJsonBtn").addEventListener("click", ()=> $ID("jsonFileInput").click());
$ID("jsonFileInput").addEventListener("change", (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async ()=>{
    try{
      const parsed = JSON.parse(reader.result);
      if(!parsed || typeof parsed !== "object") throw new Error("JSON không đúng.");
      if(!parsed.storyId || storiesIndex.some(x=>x.id===parsed.storyId)) parsed.storyId = newStoryId();
      if(!parsed.storyName) parsed.storyName = "Truyện nhập " + new Date().toLocaleDateString("vi-VN");
      GLOBAL_KEYS.forEach(k=>{ if(parsed[k] !== undefined) state[k] = parsed[k]; });
      const storyBlob = Object.assign({}, parsed);
      GLOBAL_KEYS.forEach(k=> delete storyBlob[k]);
      if(!Array.isArray(storyBlob.chapters)) storyBlob.chapters = [];
      if(!Array.isArray(storyBlob.characters)) storyBlob.characters = [];
      if(!Array.isArray(storyBlob.arcs)) storyBlob.arcs = [];
      if(!Array.isArray(storyBlob.threads)) storyBlob.threads = [];
      if(!Array.isArray(storyBlob.locations)) storyBlob.locations = [];
      if(!Array.isArray(storyBlob.items)) storyBlob.items = [];
      if(!Array.isArray(storyBlob.outlinePlans)) storyBlob.outlinePlans = [];
      if(!Array.isArray(storyBlob.triggeredCheckpoints)) storyBlob.triggeredCheckpoints = [];
      if(!Array.isArray(storyBlob.scenes)) storyBlob.scenes = [];
      if(!Array.isArray(storyBlob.consentLog)) storyBlob.consentLog = [];
      if(!storyBlob.timeline) storyBlob.timeline = [];
      if(!storyBlob.foreshadowing) storyBlob.foreshadowing = [];
      if(!storyBlob.knowledgeLedger) storyBlob.knowledgeLedger = [];
      if(!storyBlob.memoryEvents) storyBlob.memoryEvents = [];
      if(!storyBlob.statusState) storyBlob.statusState = {};
      if(!storyBlob.mainCharProfile) storyBlob.mainCharProfile = newMainCharProfile();
      if(!storyBlob.styleBible) storyBlob.styleBible = { pov:"third_limited", tense:"past", tone:"", sample:"", extra:"" };
      if(!storyBlob.vocabulary) storyBlob.vocabulary = { preferred:"", banned:"", overused:"", anatomy:"" };
      storyBlob.schemaVersion = 9;
      persist();
      saveStoryStateToDisk(storyBlob.storyId, storyBlob);
      storiesIndex.push({ id: storyBlob.storyId, name: storyBlob.storyName, updatedAt: Date.now() });
      saveStoriesIndex();
      currentStoryId = storyBlob.storyId;
      localStorage.setItem(LAST_STORY_KEY, currentStoryId);
      openCharDetails.clear();
      // V12.9: BẮT BUỘC đợi state.chapters được nạp xong trước khi vẽ lại/để người dùng
      // thao tác tiếp — nếu không đợi, bấm "Tạo Chương Mới" ngay sau import có thể đọc
      // phải state.chapters còn rỗng (chưa kịp gán) và ghi đè thành "chương 1".
      await loadCurrentStoryIntoState(); hydrateFormFromState(); renderAll(); renderStoryTabs();
      setStatus("Đã tải JSON — " + (state.chapters ? state.chapters.length : 0) + " chương.", false);
    }catch(err){ setStatus("JSON lỗi: " + err.message, false); }
  };
  reader.readAsText(file);
  e.target.value = "";
});

/* ========== EXPORT TEXT / MD / DOC ========== */
function novelTitle(){
  return state.storyName || (state.mainPlot ? state.mainPlot.split(/[.\n]/)[0].slice(0,60) : "Tiểu Thuyết");
}
function downloadBlob(content, filename, mime, addBom){
  const parts = addBom ? ["\ufeff", content] : [content];
  const blob = new Blob(parts, {type: mime});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}
$ID("exportTxtBtn").addEventListener("click", ()=>{
  if(blockIfRequiredBeatsMissing(state.chapters,"xuất bản")) return;
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  const lines = [novelTitle(), "", "MỤC LỤC", ""];
  state.chapters.forEach((c,i)=> lines.push((i+1)+". "+c.title));
  lines.push("", "".padEnd(40,"="), "");
  state.chapters.forEach((c,i)=>{
    lines.push("Chương "+(i+1)+": "+c.title, "", c.text, "", "".padEnd(40,"-"), "");
  });
  downloadBlob(lines.join("\n"), "tieu-thuyet-" + Date.now() + ".txt", "text/plain;charset=utf-8", true);
});
$ID("exportMdBtn").addEventListener("click", ()=>{
  if(blockIfRequiredBeatsMissing(state.chapters,"xuất bản")) return;
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  const lines = ["# " + novelTitle(), "", "## Mục lục", ""];
  state.chapters.forEach((c,i)=> lines.push("- ["+ (i+1) +". "+c.title+"](#chuong-"+(i+1)+")"));
  lines.push("");
  state.chapters.forEach((c,i)=>{
    lines.push('<a id="chuong-'+(i+1)+'"></a>', "## Chương " + (i+1) + ": " + c.title, "", c.text, "");
  });
  downloadBlob(lines.join("\n"), "tieu-thuyet-" + Date.now() + ".md", "text/markdown;charset=utf-8");
});
$ID("exportDocBtn").addEventListener("click", ()=>{
  if(blockIfRequiredBeatsMissing(state.chapters,"xuất bản")) return;
  if(!state.chapters.length){ setStatus("Chưa có chương.", false); return; }
  const esc = s => escapeHtml(s).replace(/\n/g,"<br>");
  let toc = state.chapters.map((c,i)=>'<p style="margin:2px 0;">'+(i+1)+'. '+escapeHtml(c.title)+'</p>').join("");
  let body = state.chapters.map((c,i)=>
    '<h2 style="font-family:Georgia,serif;">Chương '+(i+1)+': '+escapeHtml(c.title)+'</h2>'
    + '<p style="font-family:Georgia,serif;font-size:14pt;line-height:1.6;white-space:pre-wrap;">'+esc(c.text)+'</p>'
    + '<p style="page-break-after:always;"></p>'
  ).join("");
  const html = '<html xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>'
    + '<h1 style="font-family:Georgia,serif;">'+escapeHtml(novelTitle())+'</h1>'
    + '<h3 style="font-family:Georgia,serif;">Mục lục</h3>' + toc
    + '<p style="page-break-after:always;"></p>' + body + '</body></html>';
  downloadBlob(html, "tieu-thuyet-" + Date.now() + ".doc", "application/msword;charset=utf-8", true);
});

/* ========== PROMPT PREVIEW ========== */
$ID("promptPreviewBtn").addEventListener("click", ()=>{
  if(!lastPromptSent){ showAlert("Chưa có prompt nào được gửi."); return; }
  const overlay = document.createElement("div"); overlay.className = "modal-overlay";
  const box = document.createElement("div"); box.className = "modal-box";
  box.innerHTML = '<div class="modal-close" id="ppClose">×</div>'
    + '<h3 class="modal-title">Prompt cuối cùng đã gửi</h3>'
    + '<div class="hint" style="margin-bottom:8px;">≈ ' + estimateTokens(lastPromptSent) + ' token · ' + lastPromptSent.length + ' ký tự</div>'
    + '<div class="prompt-pre">' + escapeHtml(lastPromptSent) + '</div>';
  overlay.appendChild(box); document.body.appendChild(overlay);
  $ID("ppClose").onclick = ()=>overlay.remove();
  overlay.onclick = e => { if(e.target === overlay) overlay.remove(); };
});

/* ========== COST PANEL ========== */
$ID("costBtn").addEventListener("click", ()=>{
  const overlay = document.createElement("div"); overlay.className = "modal-overlay";
  const box = document.createElement("div"); box.className = "modal-box"; box.style.maxWidth = "520px";
  const avgPerChapter = state.chapters.length ? (state.totalCostUSD / state.chapters.length) : 0;
  box.innerHTML = '<div class="modal-close" id="costClose">×</div>'
    + '<h3 class="modal-title">💰 Chi phí & Thống kê</h3>'
    + '<div class="cost-panel">'
      + '<div class="item">Tổng chi phí<b>$' + (state.totalCostUSD||0).toFixed(4) + '</b></div>'
      + '<div class="item">Số lần gọi API<b>' + (state.totalCalls||0) + '</b></div>'
      + '<div class="item">Token vào<b>' + (state.totalTokensIn||0).toLocaleString() + '</b></div>'
      + '<div class="item">Token ra<b>' + (state.totalTokensOut||0).toLocaleString() + '</b></div>'
      + '<div class="item">Tổng chương<b>' + state.chapters.length + '</b></div>'
      + '<div class="item">Trung bình/chương<b>$' + avgPerChapter.toFixed(4) + '</b></div>'
    + '</div>'
    + '<div class="hint" style="margin-top:12px;">* Ước lượng dựa trên bảng giá OpenRouter. Chi phí thật có thể khác.</div>'
    + '<button class="btn btn-outline-red" id="resetCostBtn" style="margin-top:12px;">🔄 Reset bộ đếm</button>';
  overlay.appendChild(box); document.body.appendChild(overlay);
  $ID("costClose").onclick = ()=>overlay.remove();
  overlay.onclick = e => { if(e.target === overlay) overlay.remove(); };
  XTA_HOOKS.fire("cost");
  $ID("resetCostBtn").onclick = ()=>{
    state.totalCalls = 0; state.totalTokensIn = 0; state.totalTokensOut = 0; state.totalCostUSD = 0;
    persist(); refreshStatBar(); overlay.remove();
    setStatus("Đã reset bộ đếm chi phí.", false);
  };
});

/* ========== HELP ========== */
$ID("helpBtn").addEventListener("click", ()=>{
  showAlert(
    "XƯỞNG TRUYỆN AI PRO MAX v12.24 — HƯỚNG DẪN:\n\n" +
    "🎬 SCENE TRACKER: Tự động phát hiện cảnh 18+ sau mỗi chương. Ghi log ai, làm gì, intensity, structure. Chống lặp cấu trúc.\n\n" +
    "" +
    "📚 VOCABULARY: Từ muốn dùng / tránh + mức độ explicit 5 bậc (nhẹ → cực mạnh).\n\n" +
    "🤖 AUTO NSFW: Nhận từ khóa trong mệnh lệnh (cảnh nóng, sex, âu yếm…) → ép NSFW ngay. Không có từ khóa thì chấm 0-10, ≥ ngưỡng mới chuyển. Re-check giữa chương.\n\n" +
    "🎨 MIÊU TẢ: 4 mức (nhẹ/cân bằng/phong phú/sâu đậm). Bật để AI tả ngoại hình + không khí kỹ hơn.\n\n" +
    "⏱️ PACING GUARD: Cảnh báo nếu quá nhiều/ít cảnh 18+, cấu trúc lặp.\n\n" +
    "💾 STORAGE GUARD: Cảnh báo khi gần đầy. Nút 'Nén chương cũ' giảm dung lượng.\n\n" +
    "⚡ PARALLEL: Chạy post-process song song → nhanh hơn ~30%.\n\n" +
    "🔍 SEARCH & REPLACE: Đổi tên, đổi xưng hô toàn truyện.\n\n" +
    "🎬 SCENE-LEVEL REWRITE: Tách chương thành cảnh, rewrite riêng từng đoạn.\n\n" +
    "🕐 LỊCH SỬ 3 bản · ✂ TÁCH/GỘP/CHÈN · 🔄 RESCAN · 💰 CHI PHÍ · ⏹ STOP"
  );
});


/* ========== KEYBOARD SHORTCUTS ========== */
document.addEventListener("keydown", (e)=>{
  /* Ctrl/Cmd + S = save */
  if((e.ctrlKey || e.metaKey) && e.key === "s"){
    e.preventDefault();
    persist();
    setStatus("Đã lưu.", false);
  }
  /* Escape = stop generation */
  if(e.key === "Escape" && generating){
    stopGeneration();
  }
  });

/* ========== HYDRATE FORM ========== */
function hydrateFormFromState(){
  apiEndpointInput.value = state.apiEndpoint || "https://openrouter.ai/api/v1/chat/completions";
  apiKeyInput.value = state.apiKey || "";
  modelSelect.value = state.model || "deepseek/deepseek-v3.2";
  modelNsfwSelect.value = state.modelNsfw || "aion-labs/aion-2.0";
  nsfwModeSelect.value = state.nsfwMode || "auto";
  nsfwAutoThresholdInput.value = state.nsfwAutoThreshold || 6;
  chapterMatureFocusEl.value = normalizeChapterMatureFocus(state.chapterMatureFocus);
  toggleAutoOpts();
  const sb = state.styleBible || {};
  $ID("povSelect").value = sb.pov || "third_limited";
  $ID("tenseSelect").value = sb.tense || "past";
  $ID("toneInput").value = sb.tone || "";
  $ID("sampleStyleInput").value = sb.sample || "";
  $ID("styleExtraInput").value = sb.extra || "";
  mainPlotEl.value = state.mainPlot || "";
  genreEl.value = state.genre || "";
  worldSettingEl.value = state.worldSetting || "";
  worldRulesEl.value = state.worldRules || "";
  antagonistEl.value = state.antagonist || "";
  { const cs=$ID("cultivationSystem"), rl=$ID("realmLadder");
    if(cs) cs.value = state.cultivationSystem || "";
    if(rl) rl.value = Array.isArray(state.realmLadder) ? state.realmLadder.join(", ") : (state.realmLadder || ""); }
  pronounRulesEl.value = state.pronounRules || "";
  worldDescriptionEl.value = state.worldDescription || "";
  storyBibleLockEl.checked = !!state.storyBibleLocked;
  storyClockEl.value = state.storyClock || "";
  { const tp=$ID("timePace"); if(tp) tp.value = (state.storyControl && state.storyControl.timePace) || ""; }
  { const mn=$ID("maxNamedChars"); if(mn) mn.value = String(normalizeStoryControl(state).maxNamedCharacters); }
  directiveEl.value = state.directive || "";
  nextChapterHintEl.value = state.nextChapterHint || ""; { const hs=$ID("hintStyle"); if(hs) hs.value = state.hintStyle || "auto"; const hf=$ID("hintFormat"); if(hf) hf.value = state.hintFormat || "detail"; }
  advancedRulesEl.value = state.advancedRules || DEFAULT_ADVANCED_RULES;
  difficultyEl.value = state.difficulty || "vua";
  matureToggle.checked = !!state.mature;
  autoIntervalInput.value = state.autoIntervalSec || 180;
  includeKeyToggle.checked = !!state.includeKeyOnExport;
  spellCheckToggle.checked = state.spellCheckEnabled !== false;
  // V14.5.8: Quality Gate (chấm + tự sửa) mặc định TẮT; truyện cũ được chuyển sang tắt MỘT lần (cờ qgOffV1458), sau đó người dùng bật lại tùy ý.
  if(!state.qgOffV1458){ state.qgOffV1458 = true; state.qualityGateEnabled = false; persist(); }
  $ID("qualityGateToggle").checked = state.qualityGateEnabled !== false;
  $ID("autoRepairOnCreateToggle").checked = state.autoRepairOnCreate !== false;
  $ID("sceneAiReviewToggle").checked = state.sceneAiReview === true;
  $ID("beatLedgerToggle").checked = state.beatLedgerCheck === true;
  $ID("qualityAcceptSoftToggle").checked = state.qualityAcceptSoft === false;
  $ID("requiredBeatBarrierToggle").checked = state.requiredBeatBarrier !== false;
  $ID("outlineBeatGateToggle").checked = state.outlineBeatGate !== false;
  syncAccuracyModeControls();
  autoContinueToggle.checked = state.autoContinueEnabled !== false;
  autoSummaryToggle.checked = state.autoSummaryEnabled !== false;
  autoSceneToggle.checked = state.autoSceneEnabled !== false;
  dupCheckToggle.checked = state.dupCheckEnabled !== false;
  streamingToggle.checked = state.streamingEnabled !== false;
  queueToggle.checked = state.queueEnabled !== false;
  parallelToggle.checked = state.parallelEnabled !== false;
  checkpointToggle.checked = state.checkpointEnabled !== false;
  minWordsInput.value = state.minChapterWords || 5000;
  chapterWordMinInput.value = state.chapterWordMin || ""; chapterWordMaxInput.value = state.chapterWordMax || "";
  autoContinueMaxInput.value = state.autoContinueMax || 4;
  descriptionLevelSelect.value = state.descriptionLevel || "balanced";
  explicitLevelSelect.value = state.explicitLevel || "sensual";
  const v = state.vocabulary || {};
  $ID("vocabPreferred").value = v.preferred || "";
  $ID("vocabBanned").value = v.banned || "";
  $ID("vocabOverused").value = v.overused || "";
  $ID("vocabAnatomy").value = v.anatomy || "";
  const sceneBtn = $ID("showScenesInPromptBtn");
  if(sceneBtn){
    sceneBtn.style.background = state.includeScenesInPrompt ? "rgba(232,107,154,.25)" : "";
    sceneBtn.textContent = state.includeScenesInPrompt ? "👁 Đang gửi vào prompt" : "👁 Đang TẮT";
  }
  hydrateMainCharForm();
  updateNsfwHint();
}

function renderMemoryEngine(){
  if(!memoryStats)return;
  const tl=state.timeline||[], fs=state.foreshadowing||[], kl=state.knowledgeLedger||[];
  const openFs=fs.filter(x=>!['paid_off','abandoned','resolved'].includes(x.status));
  const recent=tl.slice(-5).map(e=>"- Ch"+e.chapter+": "+escapeHtml(e.summary||"")).join("\n");
  const hooks=openFs.slice(-5).map(f=>"- ["+(f.status||"seeded")+"] "+escapeHtml(f.description||"")).join("\n");
  memoryStats.innerHTML="<b>Timeline:</b> "+tl.length+" sự kiện<br><b>Foreshadowing:</b> "+fs.length+" (đang mở: "+openFs.length+")<br><b>Knowledge Ledger:</b> "+kl.length+" dữ kiện<br><b>Đồng bộ tới:</b> chương "+(state.lastMemorySyncChapter||0)+"<hr style=\"border:0;border-top:1px solid var(--line);\"><b>Diễn biến gần:</b><br>"+(recent||"Chưa có")+"<br><br><b>Foreshadowing đang mở:</b><br>"+(hooks||"Không có");
}
async function updateLongMemoryIncremental(text, chapterNumber, silent){
  if(!text)return {ok:false,reason:"empty"};
  const source=(state.chapters[chapterNumber-1]?.summary||"")+"\n\n"+text.slice(0,3500)+"\n\n[ĐOẠN CUỐI]\n"+text.slice(-7500);
  const prompt=["CẬP NHẬT LONG-TERM MEMORY SAU CHƯƠNG "+chapterNumber,"Chỉ ghi điều có bằng chứng. Không bịa.","FORESHADOWING MỞ:",(state.foreshadowing||[]).filter(x=>!['paid_off','abandoned','resolved'].includes(x.status)).slice(-20).map(x=>x.description+" ["+x.status+"]").join("\n"),"NỘI DUNG:",source,'Trả DUY NHẤT JSON: {"events":[{"type":"event|consequence|reveal|death|power_change","summary":"","causes":"","consequences":""}],"foreshadowing":[{"description":"","status":"seeded|developing|paid_off|abandoned","match":"","characters":""}],"knowledge":[{"character":"","fact":"","confidence":"direct|inferred|reported"}]}'].join("\n\n");
  try{
    const r=await callAI(prompt,{maxTokens:6900,temperature:0.15});
    let obj=safeJsonParse(r.text);
    if(!obj||Array.isArray(obj)){const rr=await callAI("CHỈ TRẢ JSON OBJECT. "+prompt,{maxTokens:9500,temperature:0.1});obj=safeJsonParse(rr.text);}
    if(!obj||Array.isArray(obj))return {ok:false,reason:"parse"};
    if(!Array.isArray(state.timeline))state.timeline=[]; if(!Array.isArray(state.foreshadowing))state.foreshadowing=[]; if(!Array.isArray(state.knowledgeLedger))state.knowledgeLedger=[];
    (obj.events||[]).forEach(e=>{if(!e||!e.summary)return;const key=normalizeName(e.summary);if(state.timeline.some(x=>x.chapter===chapterNumber&&normalizeName(x.summary)===key))return;state.timeline.push({id:genId(),chapter:chapterNumber,type:e.type||"event",summary:e.summary,causes:e.causes||"",consequences:e.consequences||""});});
    (obj.foreshadowing||[]).forEach(f=>{if(!f||!f.description)return;const key=normalizeName(f.match||f.description).slice(0,60);let x=state.foreshadowing.find(a=>normalizeName(a.description).slice(0,60)===key||normalizeName(a.description).includes(key.slice(0,30)));if(!x)state.foreshadowing.push({id:genId(),description:f.description,status:f.status||"seeded",plantedChapter:chapterNumber,lastUpdated:chapterNumber,characters:f.characters||""});else{const terminal=["paid_off","abandoned","resolved"].includes(String(x.status||"").toLowerCase());if(f.status&&(!terminal||String(f.status).toLowerCase()===String(x.status).toLowerCase()))x.status=f.status;x.lastUpdated=chapterNumber;if(f.characters)x.characters=f.characters;}});
    (obj.knowledge||[]).forEach(k=>{if(!k||!k.character||!k.fact)return;const key=normalizeName(k.character)+"|"+normalizeName(k.fact).slice(0,80);let x=state.knowledgeLedger.find(a=>normalizeName(a.character)+"|"+normalizeName(a.fact).slice(0,80)===key);if(!x)state.knowledgeLedger.push({id:genId(),character:k.character,fact:k.fact,confidence:k.confidence||"direct",firstChapter:chapterNumber,lastUpdated:chapterNumber});else x.lastUpdated=chapterNumber;});
    state.lastMemorySyncChapter=Math.max(Number(state.lastMemorySyncChapter)||0,chapterNumber);persist();renderMemoryEngine();return {ok:true};
  }catch(err){if(!silent)setStatus("Lỗi Memory ch"+chapterNumber+": "+err.message,false);return {ok:false,reason:err.message};}
}
$ID("memoryRescanBtn").addEventListener("click",async()=>{
  if(!state.chapters.length){setStatus("Chưa có chương.",false);return;} if(generating){setStatus("Đang bận.",true);return;}
  setGenerating(true);let ok=0,fail=0;try{for(let i=0;i<state.chapters.length;i++){setStatus("Memory: chương "+(i+1)+"/"+state.chapters.length+"...",true);const r=await updateLongMemoryIncremental(state.chapters[i].text,i+1,true);if(r&&r.ok)ok++;else fail++;if(userStopRequested)break;}persist();renderMemoryEngine();setStatus("Memory scan xong: "+ok+" OK"+(fail?", "+fail+" lỗi.":"."),false);}catch(e){setStatus("Lỗi Memory: "+e.message,false);}finally{setGenerating(false);}
});

/* ========== RENDER ALL ========== */

/* ========== v10 LOREBOOK ENGINE ==========
   Thẻ tri thức tự kích hoạt theo từ khóa (khớp nguyên từ, không phân biệt hoa/thường,
   hỗ trợ /regex/), sắp theo priority, cắt theo ngân sách token. */
let loreEditId = null, lastLoreInfo = null;
function loreCards(){ if(!Array.isArray(state.lorebook)) state.lorebook = []; return state.lorebook; }
function loreKeyList(c){ return String(c.keys||"").split(/[,;\n]+/).map(s=>s.trim()).filter(Boolean); }
function loreCompileKey(k){
  const m = k.match(/^\/(.+)\/([a-z]*)$/i);
  try{
    if(m) return new RegExp(m[1], Array.from(new Set((m[2].replace(/[gy]/g,"")+"iu").split(""))).join(""));
    const esc = k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/\s+/g,"\\s+");
    return new RegExp("(?:^|[^\\p{L}\\p{N}_])" + esc + "(?![\\p{L}\\p{N}_])", "iu");
  }catch(e){ return null; }
}
function loreScan(cards, text){
  const hits = [];
  for(const c of cards){
    if(c.enabled === false || !String(c.content||"").trim()) continue;
    if(c.always){ hits.push({ c, why:"luôn bật" }); continue; }
    for(const k of loreKeyList(c)){
      const re = loreCompileKey(k);
      if(re && re.test(text)){ hits.push({ c, why:k }); break; }
    }
  }
  return hits;
}
function loreScanText(){
  const recent = (state.chapters||[]).slice(-2).map(c=>c.text||"").join("\n\n").slice(-12000);
  return recent + "\n" + (state.directive||"") + "\n" + (state.currentStatus||"").slice(0,1500);
}
function loreBuild(cards, text, budget){
  const hits = loreScan(cards, text).sort((a,b)=> (Number(b.c.priority)||50) - (Number(a.c.priority)||50));
  const parts = [], active = [], dropped = []; let used = 0;
  for(const h of hits){
    if(active.length >= 5){ dropped.push(h.c.name||"?"); continue; }
    const block = "• " + (h.c.name||"?") + ": " + String(h.c.content).trim();
    const t = estimateTokens(block);
    if(used + t > budget){ dropped.push(h.c.name||"?"); continue; }
    used += t; parts.push(block); active.push(h.c.name||"?");
  }
  return { text: parts.length ? "THẺ TRI THỨC (Lorebook — bắt buộc tuân thủ khi nhân vật/đối tượng xuất hiện):\n" + parts.join("\n") : "", active, dropped, used, total: cards.length, budget };
}
function loreForPrompt(){
  const budget = Math.max(200, Number(state.loreBudgetTokens) || 2000);
  lastLoreInfo = loreBuild(loreCards(), loreScanText(), budget);
  renderLoreStatus();
  return lastLoreInfo.text;
}
function renderLoreStatus(){
  const i = lastLoreInfo, sb = $ID("statLoreBar");
  if(sb) sb.textContent = i ? i.active.length : 0;
  const el = $ID("loreStatus"); if(!el) return;
  if(!i){ el.textContent = "Chưa có lượt viết nào."; return; }
  el.textContent = "⚡ Lượt gần nhất: " + i.active.length + "/" + i.total + " thẻ · ~" + i.used + "/" + i.budget + " token" +
    (i.active.length ? "\n✓ " + i.active.join(", ") : "") + (i.dropped.length ? "\n✂ Bỏ (hết ngân sách): " + i.dropped.join(", ") : "");
}
function renderLore(){
  const list = $ID("loreList"); if(!list) return;
  const q = normalizeName($ID("loreSearch").value || "");
  const cards = loreCards().filter(c=> !q || normalizeName((c.name||"")+" "+(c.keys||"")).includes(q))
    .sort((a,b)=> (Number(b.priority)||50) - (Number(a.priority)||50));
  list.innerHTML = cards.length ? cards.map(c=>
    '<div class="char-item" style="display:flex;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid var(--line);' + (c.enabled===false?'opacity:.5;':'') + '">' +
    '<input type="checkbox" data-act="toggle" data-id="' + c.id + '"' + (c.enabled===false?'':' checked') + '>' +
    '<div style="flex:1;min-width:0;"><b>' + escapeHtml(c.name||"?") + '</b> <small>P' + (c.priority||50) + (c.always?' · luôn bật':'') + '</small><br>' +
    '<small style="opacity:.7;overflow-wrap:anywhere;">' + escapeHtml(c.keys||"") + '</small></div>' +
    '<button class="btn btn-sm" data-act="edit" data-id="' + c.id + '">✎</button>' +
    '<button class="btn btn-sm" data-act="del" data-id="' + c.id + '">🗑</button></div>').join("")
    : '<div class="empty-note">Chưa có thẻ nào.</div>';
  $ID("loreBudget").value = state.loreBudgetTokens || 2000;
  renderLoreStatus();
}
function loreResetForm(){
  loreEditId = null;
  ["loreName","loreKeys","loreContent"].forEach(id=> $ID(id).value = "");
  $ID("lorePriority").value = 50; $ID("loreAlways").checked = false;
  $ID("loreSaveBtn").textContent = "💾 Thêm thẻ";
}
$ID("loreSaveBtn").addEventListener("click", ()=>{
  const name = $ID("loreName").value.trim(), keys = $ID("loreKeys").value.trim(), content = $ID("loreContent").value.trim();
  const always = $ID("loreAlways").checked;
  if(!name || !content || (!keys && !always)){ showAlert("Cần Tên, Nội dung và Từ khóa (hoặc bật 'Luôn bật')."); return; }
  const data = { name, keys, content, always, priority: Math.min(100, Math.max(1, parseInt($ID("lorePriority").value)||50)) };
  const cur = loreEditId && loreCards().find(c=>c.id===loreEditId);
  if(cur) Object.assign(cur, data); else loreCards().push(Object.assign({ id: genId(), enabled: true }, data));
  persist(); loreResetForm(); renderLore();
});
$ID("loreCancelBtn").addEventListener("click", loreResetForm);
$ID("loreSearch").addEventListener("input", renderLore);
$ID("loreBudget").addEventListener("change", e=>{ state.loreBudgetTokens = Math.min(20000, Math.max(200, parseInt(e.target.value)||2000)); persist(); });
$ID("loreList").addEventListener("click", async e=>{
  const b = e.target.closest("[data-act]"); if(!b) return;
  const c = loreCards().find(x=>x.id===b.dataset.id); if(!c) return;
  if(b.dataset.act === "edit"){
    loreEditId = c.id; $ID("loreName").value = c.name||""; $ID("loreKeys").value = c.keys||""; $ID("loreContent").value = c.content||"";
    $ID("lorePriority").value = c.priority||50; $ID("loreAlways").checked = !!c.always; $ID("loreSaveBtn").textContent = "💾 Cập nhật thẻ";
  } else if(b.dataset.act === "del"){
    if(!await showConfirm("Xóa thẻ \"" + (c.name||"?") + "\"?")) return;
    state.lorebook = loreCards().filter(x=>x.id!==c.id); persist(); renderLore();
  }
});
$ID("loreList").addEventListener("change", e=>{
  if(e.target.dataset.act !== "toggle") return;
  const c = loreCards().find(x=>x.id===e.target.dataset.id); if(c){ c.enabled = e.target.checked; persist(); renderLore(); }
});
$ID("loreExportBtn").addEventListener("click", ()=>{
  const blob = new Blob([JSON.stringify({ type:"xuong-truyen-lorebook", version:10, lorebook: loreCards() }, null, 2)], { type:"application/json" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = "lorebook-" + new Date().toISOString().slice(0,10) + ".json";
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(a.href), 4000);
});
$ID("loreImportBtn").addEventListener("click", ()=> $ID("loreImportFile").click());
$ID("loreImportFile").addEventListener("change", async e=>{
  const f = e.target.files[0]; e.target.value = ""; if(!f) return;
  try{
    const j = JSON.parse(await f.text());
    const arr = Array.isArray(j) ? j : (j.lorebook || j.entries || []);
    let add = 0, upd = 0;
    arr.forEach(r=>{
      if(!r || !r.name) return;
      const n = { id: r.id || genId(), name:String(r.name), keys: Array.isArray(r.keys) ? r.keys.join(", ") : String(r.keys||""),
        content:String(r.content||""), priority: Math.min(100, Math.max(1, parseInt(r.priority)||50)), enabled: r.enabled !== false, always: !!r.always };
      const ex = loreCards().find(c=> c.id === n.id || normalizeName(c.name) === normalizeName(n.name));
      if(ex){ Object.assign(ex, n, { id: ex.id }); upd++; } else { loreCards().push(n); add++; }
    });
    persist(); renderLore(); showAlert("Import xong: thêm " + add + ", cập nhật " + upd + " thẻ.");
  }catch(err){ showAlert("File Lorebook không hợp lệ: " + err.message); }
});

/* v10.1: tab 2 cột + tắt tác vụ nền không cần cho việc viết */
(function(){
  let p="side"; try{ p=localStorage.getItem("xt_pane")||"side"; }catch(e){}
  const set=v=>{ document.body.dataset.pane=v; document.querySelectorAll("#paneTabs button").forEach(b=>b.classList.toggle("on",b.dataset.pane===v)); try{localStorage.setItem("xt_pane",v);}catch(e){} window.scrollTo(0,0); };
  document.getElementById("paneTabs").addEventListener("click",e=>{ const b=e.target.closest("button"); if(b) set(b.dataset.pane); });
  set(p);
})();
const SKIPPED_TASKS = new Set(["scene","continuity","checkpoint","pacing"]);

function renderAll(){ renderAllCore(); XTA_HOOKS.fire("all"); }
function renderAllCore(){
  renderLore();
  renderCharacters();
  renderArcs();
  renderOutlines();
  renderLocations();
  renderItems();
  renderOrganizations();
  renderThreads();
  renderScenes();
  renderConsentLog();
  renderMemoryEngine();
  renderChapterNav();
  renderCurrentChapter();
  renderSnapshotChapterSelect();
  statusBox.textContent = state.currentStatus || "AI sẽ tự tạo Current Status Update sau mỗi chương...";
  statusBox.style.display = "block";
  statusEdit.style.display = "none";
  renderContinuityWarnings([]);
  refreshBackupBanner();
  refreshStatBar();
  updateStorageBar();
}


/* ========== BACKGROUND JOB (Netlify) ========== */
const BG_JOB_KEY = "aiStoryWorkshop_bgJobId_v9";
const BG_FUNCTIONS_BASE = "/.netlify/functions"; // khi deploy Netlify sẽ đúng path
/* V14.2.3: khi create-job lỗi mạng ("Load failed"/hết giờ), thử gọi một hàm nhẹ (security-status, GET) để phân biệt:
   mạng/Netlify không tới được hay chỉ riêng create-job (payload/hàm chạy quá lâu/Blobs). Trả chuỗi chẩn đoán ngắn. */
/* V14.3.4: gửi create-job bằng XHR để biết TIẾN ĐỘ UPLOAD (fetch không cho biết) và nén gzip body khi trình duyệt hỗ trợ.
   Kẹt khi đang tải lên (không tiến thêm 30 giây) -> báo rõ "kẹt ở x%"; tải xong 100% mà server im lặng -> lỗi nằm ở hàm/Blobs. */
async function bgPostCreateJob(url, headers, bodyStr, timeoutMs){
  let payload=bodyStr, hdrs=Object.assign({}, headers), gz=false;
  try{
    if(typeof CompressionStream!=="undefined" && typeof Response!=="undefined"){
      const cs=new Blob([bodyStr]).stream().pipeThrough(new CompressionStream("gzip"));
      const buf=await new Response(cs).arrayBuffer();
      if(buf.byteLength && buf.byteLength<bodyStr.length){ payload=new Uint8Array(buf); hdrs["Content-Type"]="application/octet-stream"; hdrs["X-Body-Encoding"]="gzip"; gz=true; }
    }
  }catch(_){ payload=bodyStr; }
  const wire=gz?payload.byteLength:new TextEncoder().encode(bodyStr).length;
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest(); const info={gz, wireBytes:wire, sent:0, uploadDone:false};
    let lastProgress=Date.now(), finished=false;
    const fail=(name,msg)=>{ if(finished)return; finished=true; clearInterval(iv); clearTimeout(tm); try{xhr.abort();}catch(_){} const e=new Error(msg); e.name=name; e.bgInfo=info; reject(e); };
    const tm=setTimeout(()=>fail("AbortError","timeout"), timeoutMs);
    const iv=setInterval(()=>{ if(!info.uploadDone && Date.now()-lastProgress>30000) fail("AbortError","upload stall"); },2000);
    xhr.open("POST",url);
    Object.keys(hdrs).forEach(k=>xhr.setRequestHeader(k,hdrs[k]));
    xhr.upload.onprogress=ev=>{ info.sent=ev.loaded; lastProgress=Date.now(); try{ setBgStatus("☁ Đang tải lên server… "+Math.round(100*ev.loaded/Math.max(1,ev.total||wire))+"% ("+Math.round(ev.loaded/1024)+"/"+Math.round((ev.total||wire)/1024)+" KB"+(gz?", đã nén":"")+")",true); }catch(_){} };
    xhr.upload.onload=()=>{ info.uploadDone=true; info.sent=wire; lastProgress=Date.now(); try{ setBgStatus("☁ Đã tải lên xong, chờ server tạo job…",true); }catch(_){} };
    xhr.onerror=()=>fail("NetworkError","Network error");
    xhr.onload=()=>{ if(finished)return; finished=true; clearInterval(iv); clearTimeout(tm); resolve({status:xhr.status, ok:xhr.status>=200&&xhr.status<300, text:async()=>xhr.responseText||"", bgInfo:info}); };
    xhr.send(payload);
  });
}
/* V14.7.8: create-job im lặng sau khi tải lên xong thường là phản hồi bị mất chứ job đã tạo. App tự sinh jobId + token,
   khi hết giờ thì hỏi job-status vài lần; thấy job thì coi như tạo thành công (khỏi bắt người dùng gửi lại và tạo job trùng). */
function bgNewJobCreds(){
  const rnd=n=>{ try{ const a=new Uint8Array(n); crypto.getRandomValues(a); return Array.from(a,x=>(x%36).toString(36)).join(""); }catch(_){ let s=""; for(let i=0;i<n;i++) s+=Math.floor(Math.random()*36).toString(36); return s; } };
  return { jobId:"job_"+Date.now().toString(36)+"_"+rnd(12), token:rnd(48) };
}
async function bgRecoverJob(cr, tries, waitMs){
  for(let i=0;i<(tries||5);i++){
    await new Promise(r=>setTimeout(r, waitMs==null?4000:waitMs));
    try{
      const r=await fetch(BG_FUNCTIONS_BASE+"/job-status?jobId="+encodeURIComponent(cr.jobId)+"&token="+encodeURIComponent(cr.token));
      if(r.status===200) return true;
    }catch(_){}
  }
  return false;
}
async function bgPostCreateJobRecover(url, headers, bodyStr, timeoutMs, cr){
  try{ return await bgPostCreateJob(url, headers, bodyStr, timeoutMs); }
  catch(e){
    if(e && e.name==="AbortError" && cr && e.bgInfo && e.bgInfo.uploadDone){
      try{ setBgStatus("☁ Server chưa trả lời — đang kiểm tra xem job đã được tạo chưa…",true); }catch(_){}
      if(await bgRecoverJob(cr)){
        const body=JSON.stringify({success:true, jobId:cr.jobId, accessToken:cr.token, warnings:["Phản hồi create-job bị mất nhưng job đã được tạo (tự khôi phục)."]});
        return { status:200, ok:true, text:async()=>body, bgInfo:e.bgInfo };
      }
    }
    throw e;
  }
}
function bgUploadNote(e){
  const i=e&&e.bgInfo; if(!i) return "";
  const pct=Math.round(100*i.sent/Math.max(1,i.wireBytes));
  return i.uploadDone ? " [Tải lên ĐÃ xong 100% ("+Math.round(i.wireBytes/1024)+" KB"+(i.gz?", nén gzip":"")+") nhưng server không trả lời → lỗi ở phía hàm create-job/Netlify Blobs; xem Netlify → Functions → create-job → Logs (có dòng \"received\" không?).]"
    : " [Tải lên KẸT ở "+pct+"% ("+Math.round(i.sent/1024)+"/"+Math.round(i.wireBytes/1024)+" KB"+(i.gz?", nén gzip":"")+") → lỗi nằm ở đường mạng của máy/iPhone (Wi-Fi/4G, VPN, trình chặn), chưa tới được hàm. Thử đổi Wi-Fi↔4G hoặc tắt VPN.]";
}
async function bgDiagnoseServer(){
  const t0=Date.now(); const ac=new AbortController(); const tm=setTimeout(()=>ac.abort(),8000);
  try{
    const r=await fetch(BG_FUNCTIONS_BASE+"/security-status?_="+Date.now(),{cache:"no-store",signal:ac.signal});
    const ms=Date.now()-t0;
    if(r.ok) return " Chẩn đoán: server Netlify vẫn tới được ("+ms+"ms) → lỗi nằm ở riêng create-job (hàm chạy quá lâu/Netlify Blobs/kết nối bị ngắt giữa lúc tải lên) — thử lại; nếu lặp lại hãy xem Netlify → Functions → create-job → Logs.";
    return " Chẩn đoán: server trả HTTP "+r.status+" cho hàm kiểm tra → site/hàm Netlify có vấn đề (hết hạn mức, tạm dừng, hoặc hàm chưa deploy) — kiểm tra Netlify dashboard.";
  }catch(e){
    return " Chẩn đoán: KHÔNG gọi được cả hàm kiểm tra nhẹ → mạng của máy/iPhone (Wi-Fi/4G, VPN, chế độ dữ liệu thấp, trình chặn quảng cáo) hoặc site Netlify đang không phản hồi. Thử đổi Wi-Fi↔4G, tắt VPN, mở thẳng trang /.netlify/functions/security-status trên Safari.";
  }finally{ clearTimeout(tm); }
}
// Netlify Background Function tối đa 15 phút (DEADLINE trong write-chapter-background.js = 13.5 phút).
// Cộng thêm thời gian trigger + polling trễ 12s → coi job là "có thể đã chết" nếu quá ngưỡng này mà vẫn pending/running.
const BG_JOB_STALE_MS = 18 * 60 * 1000;
const BG_HEAVY_STATE_KEYS = ["storyMetaData","chapterDrafts"];   // V14.3.1: khóa cấp truyện không gửi lên server (storyMetaData = bản sao dẫn xuất của state; chapterDrafts = nháp chờ duyệt, worker không đọc)
const BG_HEAVY_CHAPTER_KEYS = ["stateSnapshots","stateSnapshot","versions","briefUsed"];   // lịch sử nặng của từng chương — không gửi lên server (V12.24: gồm briefUsed của chương cũ; chương mới do worker tạo tự mang briefUsed riêng)
const BG_SOFT_POST_ISSUES = /^(Status|Memory)(?:\b|:)/i; // lỗi hậu kỳ tùy chọn không được biến thành lỗi của chương đã viết/lưu

function getBgStatusEl(){ return $ID("bgJobStatus"); }

function setBgStatus(msg, show){
  const el = getBgStatusEl();
  if(!el) return;
  el.style.display = show ? "block" : "none";
  el.textContent = msg || "";
}

async function startBackgroundPostProcess(chapterObj, chapterNumber, text, briefUsed){
  if(!chapterObj || !chapterObj.text) throw new Error("Chương hậu kỳ không có nội dung.");
  if(state.accuracyMode===true&&blockIfRequiredBeatsMissing(chapterObj,"Sync Canon / hậu kỳ")) throw new Error("Accuracy Mode chặn hậu kỳ/Sync vì Quality Gate, Required Beat hoặc audit chưa đạt.");
  const key=(state.apiKey||apiKeyInput.value||"").trim();
  if(!key) throw new Error("Thiếu API Key để chạy hậu kỳ server.");
  if(!state.apiEndpoint&&!apiEndpointInput.value) throw new Error("Thiếu endpoint để chạy hậu kỳ server.");
  const old=localStorage.getItem(BG_JOB_KEY);
  if(old) throw new Error("Đã có Background Job khác đang chạy. Hãy chờ job đó xong.");

  const storyBlob={};
  Object.keys(state).forEach(k=>{if(!GLOBAL_KEYS.includes(k))storyBlob[k]=state[k];});
  BG_HEAVY_STATE_KEYS.forEach(k=>{ delete storyBlob[k]; }); // V14.3.1: bỏ bản sao thừa (storyMetaData, chapterDrafts) — worker không đọc, giảm ~50% payload
  if(Array.isArray(storyBlob.chapters)) storyBlob.chapters=storyBlob.chapters.map(ch=>{
    if(!ch||typeof ch!=="object") return ch;
    const o=Object.assign({},ch);
    BG_HEAVY_CHAPTER_KEYS.forEach(k=>{ delete o[k]; });
    return o;
  });
  // Gửi riêng chương hiện tại + brief đã dùng; không gửi các lịch sử nặng của chương cũ.
  if(Array.isArray(storyBlob.chapters) && storyBlob.chapters[chapterNumber-1]){
    const c=Object.assign({},storyBlob.chapters[chapterNumber-1]);
    c.text=String(text||c.text||"");
    c.briefUsed=briefUsed==null?c.briefUsed:briefUsed;
    storyBlob.chapters[chapterNumber-1]=c;
  }
  ["minChapterWords","descriptionLevel","explicitLevel","nsfwMode","nsfwAutoThreshold","chapterMatureFocus","modelNsfw","advancedRules","includeScenesInPrompt","autoContinueMax","spellCheckEnabled","adaptiveScenePipeline","semanticProseAuto","beatLedgerCheck","sceneAiReview","accuracyMode","qualityMaxAttempts","stepModels"].forEach(k=>{if(state[k]!==undefined)storyBlob[k]=state[k];});
  const payload={
    mode:"postprocess", chapterNumber:Number(chapterNumber),
    hintStyle:state.hintStyle||"normal", hintFormat:state.hintFormat||"detail",
    storyState:storyBlob, apiKey:key,
    apiEndpoint:state.apiEndpoint||apiEndpointInput.value.trim(),
    model:state.model||"deepseek/deepseek-v3.2",
    modelNsfw:state.modelNsfw||"aion-labs/aion-2.0", forceNsfw:false
  };
  /* V14.1.9: Netlify chặn request > ~6MB (Safari chỉ báo "Load failed"). Tiếng Việt UTF-8 ~2 byte/ký tự nên phải đo BYTE, không đo số ký tự.
     Quá ~1.5MB: rút gọn văn bản các chương cũ (giữ chương đang hậu kỳ + 2 chương trước + tóm tắt); phần rút gọn được khôi phục từ bản local khi hợp nhất. */
  const _bytes=s=>{ try{ return new TextEncoder().encode(s).length; }catch(_){ return s.length*2; } };
  const _cr=bgNewJobCreds(); payload.clientJobId=_cr.jobId; payload.clientAccessToken=_cr.token;
  let bodyStr=JSON.stringify(payload), bodyBytes=_bytes(bodyStr), trimmedN=0;
  if(bodyBytes>1500000 && Array.isArray(storyBlob.chapters)){
    storyBlob.chapters=storyBlob.chapters.map((c,i)=>{
      if(!c||typeof c!=="object"||i>=chapterNumber-3&&i<=chapterNumber-1||i>chapterNumber-1) return c;
      const t=String(c.text||""); if(t.length<=2000) return c;
      trimmedN++; return Object.assign({},c,{text:t.slice(-1500),_bgTrimmed:true});
    });
    bodyStr=JSON.stringify(payload); bodyBytes=_bytes(bodyStr);
  }
  if(bodyBytes>5500000) throw new Error("Dữ liệu hậu kỳ quá lớn ("+Math.round(bodyBytes/1024)+" KB, giới hạn Netlify ~6MB). Hãy backup và giảm dữ liệu lịch sử (Timeline/Memory/NV) trước khi chạy hậu kỳ.");
  const pc=getAppPasscode(); const headers={"Content-Type":"application/json"}; if(pc)headers["X-App-Passcode"]=pc;
  setBgStatus("☁ Đang gửi hậu kỳ lên server...",true);
  const ac=new AbortController(); const timer=setTimeout(()=>ac.abort(),90000);
  let res;
  try{ res=await bgPostCreateJobRecover(BG_FUNCTIONS_BASE+"/create-job",headers,bodyStr,90000,_cr); }
  catch(e){
    if(e&&e.name==="AbortError"){
      /* V14.1.10: kèm phân tích dung lượng để biết phần nào nặng (upload chậm trên mạng di động là nguyên nhân thường gặp). */
      let top=""; try{ top=Object.keys(storyBlob).map(k=>[k,JSON.stringify(storyBlob[k]||"").length]).sort((a,b)=>b[1]-a[1]).slice(0,4).map(x=>x[0]+" "+Math.round(x[1]/1024)+"KB").join(", "); }catch(_){}
      throw new Error("create-job không phản hồi sau 90 giây (đã gửi "+Math.round(bodyBytes/1024)+" KB"+(trimmedN?", đã rút gọn "+trimmedN+" chương cũ":"")+"; nặng nhất: "+top+")."+bgUploadNote(e)+(await bgDiagnoseServer())+" Job có thể đã được tạo — đợi vài phút rồi mở lại app trước khi gửi lại.");
    }
    throw new Error(String(e&&e.message||e)+" — request không tới được server (đã gửi "+Math.round(bodyBytes/1024)+" KB"+(trimmedN?", đã rút gọn "+trimmedN+" chương cũ":"")+")."+(await bgDiagnoseServer()));
  }
  finally{ clearTimeout(timer); }
  const raw=await res.text().catch(()=>""); let data={}; try{data=JSON.parse(raw)||{};}catch(_){}
  if(res.status===401) throw new Error("Sai hoặc thiếu Mã truy cập server (mục 🔒).");
  if(res.status===413) throw new Error("Server từ chối vì dữ liệu quá lớn ("+Math.round(bodyBytes/1024)+" KB). Hãy backup và giảm dữ liệu lịch sử.");
  if(!res.ok || !data.jobId || !data.accessToken) throw new Error(data.error || ("HTTP "+res.status));
  bgWarnText=Array.isArray(data.warnings)&&data.warnings.length ? " ⚠ "+data.warnings.join(" | ") : "";
  const record={jobId:data.jobId,accessToken:data.accessToken,storyId:state.storyId,baseChapterCount:state.chapters.length,createdAt:Date.now(),briefAtStart:String(state.nextChapterHint||""),mode:"postprocess",chapterNumber:Number(chapterNumber)};
  localStorage.setItem(BG_JOB_KEY,JSON.stringify(record));
  chapterObj.postProcess=Object.assign({},chapterObj.postProcess||{},{status:"RUNNING",startedAt:Date.now(),serverSide:true,error:null,jobId:data.jobId});
  persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
  setStatus("☁ Đã gửi hậu kỳ lên Netlify. Có thể khóa iPhone/thoát app.",false);
  setBgStatus("✓ Hậu kỳ server đang chạy — có thể tắt iPhone.",true);
  pollBackgroundJob(record);
}

let bgPollTimer=null;
let bgWarnText=""; // cảnh báo cấu hình server (JOB_SECRET/APP_PASSCODE) — giữ hiển thị suốt lúc job chạy
function normalizeBgRecord(raw){
  if(!raw)return null;
  try{const o=JSON.parse(raw);if(o&&o.jobId)return o;}catch(e){}
  return {jobId:raw,accessToken:""};
}
/* V12.14: mã truy cập server — lưu riêng trên thiết bị (không nằm trong truyện/backup/export). */
function getAppPasscode(){ try{ const el=$ID("appPasscode"); return ((el&&el.value)||localStorage.getItem("xta_passcode")||"").trim(); }catch(e){ return ""; } }
(function initPasscodeField(){
  const el=$ID("appPasscode"); if(!el) return;
  try{ el.value=localStorage.getItem("xta_passcode")||""; }catch(e){}
  el.addEventListener("change",()=>{ try{ if(el.value.trim()) localStorage.setItem("xta_passcode",el.value.trim()); else localStorage.removeItem("xta_passcode"); }catch(e){} });
})();
/* V12.14: sau khi đã hợp nhất xong, báo server xoá job (truyện + dữ liệu) khỏi Blobs ngay. */
async function ackBackgroundJob(record){
  try{ await fetch(BG_FUNCTIONS_BASE+"/job-status?jobId="+encodeURIComponent(record.jobId)+"&token="+encodeURIComponent(record.accessToken||"")+"&ack=1"); }catch(e){}
}
function pollBackgroundJob(record){
  if(!record||!record.jobId)return;
  if(bgPollTimer)clearInterval(bgPollTimer);
  const poll=async()=>{
    const createdAt=Number(record.createdAt)||Date.now();
    const age=Date.now()-createdAt;
    try{
      const token=encodeURIComponent(record.accessToken||"");
      const res=await fetch(BG_FUNCTIONS_BASE+"/job-status?jobId="+encodeURIComponent(record.jobId)+"&token="+token);
      if(res.status===403){clearInterval(bgPollTimer);bgPollTimer=null;setBgStatus("⚠ Job còn tồn tại nhưng token theo dõi trên iPhone không hợp lệ. Có thể cần mở backup/job cũ để đồng bộ thủ công.",true);return;}
      if(res.status===404 && !(await res.clone().json().catch(()=>null)||{}).status){clearInterval(bgPollTimer);bgPollTimer=null;setBgStatus("⚠ job-status trả 404 tại "+location.origin+" — hàm Netlify chưa được deploy hoặc job đã bị xóa. Đã dừng theo dõi; kiểm tra Netlify → Functions rồi tạo job mới.",true);return;}
      if(!res.ok){
        if(age>BG_JOB_STALE_MS){
          clearInterval(bgPollTimer);bgPollTimer=null;
          setBgStatus("⚠ Không lấy được trạng thái job sau "+Math.round(BG_JOB_STALE_MS/60000)+" phút — nhiều khả năng job đã chết. Đã dừng theo dõi, bạn có thể tạo job mới.",true);
          localStorage.removeItem(BG_JOB_KEY);
        }
        return;
      }
      const data=await res.json();
      if(data.status==="running"||data.status==="pending"){
        if(age>BG_JOB_STALE_MS){
          clearInterval(bgPollTimer);bgPollTimer=null;
          setBgStatus("⚠ Job nền đã chạy quá "+Math.round(BG_JOB_STALE_MS/60000)+" phút mà vẫn báo '"+data.status+"' — nhiều khả năng tiến trình trên server đã chết mà không kịp ghi lỗi. Đã dừng theo dõi (job cũ vẫn còn trên server, chưa mất dữ liệu), bạn có thể bấm 'Viết chương nền' để tạo job mới.",true);
          localStorage.removeItem(BG_JOB_KEY);
          return;
        }
        setBgStatus((record.mode==="postprocess"?"☁ Đang hậu kỳ server... ":"☁ Đang viết nền... ")+(data.progress||data.status)+bgWarnText,true);
      }
      else if(data.status==="completed"){
        clearInterval(bgPollTimer);bgPollTimer=null;setBgStatus(record.mode==="postprocess"?"✓ Hậu kỳ server đã xong — đang hợp nhất an toàn...":"✓ Chương nền đã xong — đang hợp nhất an toàn...",true);
        await mergeBackgroundChapter(data,record);
        if(record.mode==="postprocess"&&record.storyId===state.storyId&&record.chapterNumber){
          const mergedChapter=state.chapters[record.chapterNumber-1];
          if(mergedChapter){recordStoryTimeMark(record.chapterNumber,mergedChapter);recordChapterPostWriteAudit(mergedChapter,record.chapterNumber);}
        }
        if(record.mode==="postprocess" && record.storyId===state.storyId && record.chapterNumber && data.postProcessStatus==="DONE" && !isGateFailedResult(data)){
          const layerEngine=window.__XTA_LAYERED_MEMORY__;
          if(layerEngine&&typeof layerEngine.autoBuildLayeredMemory==="function") Promise.resolve().then(()=>layerEngine.autoBuildLayeredMemory(record.chapterNumber)).catch(e=>setBgStatus("⚠ Chương đã lưu; đồng bộ Memory lỗi: "+String(e&&e.message||e),true));
        }
        try{ if(typeof persistNow==="function") await persistNow(); }catch(e){}
        if((!record.storyId||record.storyId===state.storyId)&&data.storyState&&Array.isArray(data.storyState.chapters)&&state.chapters.length>=data.storyState.chapters.length) ackBackgroundJob(record);
        localStorage.removeItem(BG_JOB_KEY);setBgStatus(data.draftOnly?"✓ Đã có bản nháp nền."+draftQuickLabel(data.resultChapter):isGateFailedResult(data)?"⚠ Background xong nhưng chưa vượt Quality Gate — chưa ghi Canon.":(data.postProcessStatus&&data.postProcessStatus!=="DONE"?"⚠ Hậu kỳ "+(data.postProcessStatus==="FAILED"?"thất bại":"chỉ cập nhật một phần")+(data.postProcessError?": "+data.postProcessError:""):record.mode==="postprocess"?"✓ Đã hoàn tất hậu kỳ server và đồng bộ Canon.":"✓ Đã đồng bộ background v9."),true);setTimeout(()=>setBgStatus("",false),9000);
      }else if(data.status==="failed"){
        clearInterval(bgPollTimer);bgPollTimer=null;
        if(record.mode==="postprocess" && record.storyId===state.storyId && record.chapterNumber && state.chapters[record.chapterNumber-1]){
          const ch=state.chapters[record.chapterNumber-1];
          ch.postProcess=Object.assign({},ch.postProcess||{},{status:"FAILED",finishedAt:Date.now(),serverSide:true,error:data.error||"unknown"});
          persist(); renderChapterNav(); renderCurrentChapter(); refreshStatBar();
        }
        setBgStatus("⚠ Job lỗi: "+(data.error||"unknown"),true);ackBackgroundJob(record);localStorage.removeItem(BG_JOB_KEY);
      }
    }catch(e){}
  };
  poll(); bgPollTimer=setInterval(poll,window.__XTA_TEST__?1000:12000);
}

function mergeArrayByIdOrName(localArr,incomingArr,nameKey="name"){
  const out=Array.isArray(localArr)?localArr.slice():[];
  (incomingArr||[]).forEach(item=>{
    const idx=out.findIndex(x=>(item.id&&x.id===item.id)||(item[nameKey]&&normalizeName(x[nameKey])===normalizeName(item[nameKey])));
    if(idx<0)out.push(item);else out[idx]=Object.assign({},out[idx],item);
  });
  return out;
}
async function mergeBackgroundChapter(statusData,record){
  if(!statusData)return;
  const incoming=statusData.storyState;
  if(!incoming||!Array.isArray(incoming.chapters))return;
  /* v10.2.4: job nền có thể đã được tạo cho MỘT TRUYỆN KHÁC (đã bị xoá, hoặc người dùng đã
     chuyển/viết lại truyện mới trong lúc job vẫn chạy trên server). Trước đây hàm này merge
     thẳng vào state hiện tại bất kể storyId, khiến timeline/NV/threads của truyện cũ "sống lại"
     trong truyện mới dù đã xoá truyện cũ. Chỉ merge nếu job thực sự thuộc truyện đang mở. */
  const jobStoryId = record && record.storyId;
  if(jobStoryId && state.storyId && jobStoryId !== state.storyId){
    const stillExists = storiesIndex.some(x=>x.id===jobStoryId);
    setStatus("⚠ Job nền thuộc truyện khác (" + (stillExists ? "đã chuyển sang truyện khác" : "truyện đó đã bị xoá") + ") — đã BỎ QUA, không hợp nhất vào truyện đang mở.", false);
    return;
  }
  const base=Number(statusData.baseChapterCount!=null?statusData.baseChapterCount:(record&&record.baseChapterCount)||0);
  const localCount=state.chapters.length;
  const serverNew=incoming.chapters.slice(Math.min(base,incoming.chapters.length));
  if(localCount>base){
    // Local đã có thêm chương sau khi job bắt đầu: tuyệt đối KHÔNG ghi đè toàn bộ state.
    const known=new Set(state.chapters.map(c=>String(c.title||"")+"|"+(c.wordCount||0)));
    serverNew.forEach(ch=>{const k=String(ch.title||"")+"|"+(ch.wordCount||0);if(!known.has(k)){state.chapters.push(ch);known.add(k);}});
    /* V12.32.2: hậu kỳ chương N xong khi người dùng đã viết thêm chương -> trước đây kết quả của chương N
       (tóm tắt, continuity, trạng thái hậu kỳ) bị bỏ, chip kẹt "RUNNING". Chỉ chép các trường hậu kỳ vào đúng chương N. */
    if(record && record.mode==="postprocess" && statusData.resultChapter){
      const rc=statusData.resultChapter, li=Number(record.chapterNumber||statusData.chapterNumber||0)-1, lc=state.chapters[li];
      if(lc && String(lc.title||"")===String(rc.title||"")){
        ["summary","continuityWarnings","autoUpdateIssues","updateDiagnostics","postProcess","review","canonDiff"].forEach(k=>{ if(rc[k]!==undefined) lc[k]=rc[k]; });
      }
    }
    setStatus("✓ Background hoàn tất. Đã hợp nhất chương mới mà không ghi đè các chương local.",false);
  }else{
    /* V14.1.9: chương cũ bị rút gọn văn bản khi gửi hậu kỳ -> trả lại văn bản đầy đủ từ bản local (khớp tiêu đề); không có bản local thì giữ nguyên local, không ghi đè bằng bản cụt. */
    if(incoming.chapters.some(c=>c&&c._bgTrimmed)){
      incoming.chapters=incoming.chapters.map((ich,i)=>{
        if(!ich||!ich._bgTrimmed) return ich;
        const lch=state.chapters[i]&&String(state.chapters[i].title||"")===String(ich.title||"")?state.chapters[i]:state.chapters.find(c=>c&&String(c.title||"")===String(ich.title||"")&&(c.wordCount||0)===(ich.wordCount||0));
        if(lch&&typeof lch.text==="string"){ const o=Object.assign({},ich,{text:lch.text}); delete o._bgTrimmed; return o; }
        return lch||ich;
      });
    }
    /* V12.23: payload đã bỏ stateSnapshots/versions của các chương cũ -> khôi phục từ bản local (khớp theo vị trí + tiêu đề). */
    incoming.chapters.forEach((ich,i)=>{
      const lch=state.chapters[i];
      if(!ich||!lch||i>=base||String(lch.title||"")!==String(ich.title||"")) return;
      BG_HEAVY_CHAPTER_KEYS.forEach(k=>{ if(ich[k]===undefined && lch[k]!==undefined) ich[k]=lch[k]; });
      ["polished","polishedAt"].forEach(k=>{ if(ich[k]===undefined && lch[k]!==undefined) ich[k]=lch[k]; });
    });
    state.chapters=incoming.chapters;
    state.currentChapterIndex=state.chapters.length-1;
  }
  state.characters=mergeArrayByIdOrName(state.characters,incoming.characters||[]);
  state.locations=mergeArrayByIdOrName(state.locations,incoming.locations||[]);
  state.items=mergeArrayByIdOrName(state.items,incoming.items||[]);
  const localThreadSnapshot=(state.threads||[]).slice(), incomingThreadSnapshot=incoming.threads||[];
  state.threads=mergeArrayByIdOrName(state.threads,incomingThreadSnapshot,"desc").map(thread=>{
    const key=normalizeName(thread.desc||"");
    const local=localThreadSnapshot.find(x=>(thread.id&&x.id===thread.id)||normalizeName(x.desc||"")===key);
    if(!local)return thread;
    const localManualAt=Number(local.lastManualUpdatedAt)||Math.max(0,...(local.statusHistory||[]).filter(h=>h&&h.source==="author").map(h=>Number(h.at)||0));
    const incomingMatch=incomingThreadSnapshot.find(x=>(thread.id&&x.id===thread.id)||normalizeName(x.desc||"")===key);
    const remoteManualAt=Number(incomingMatch&&incomingMatch.lastManualUpdatedAt)||Math.max(0,...((incomingMatch&&incomingMatch.statusHistory)||[]).filter(h=>h&&h.source==="author").map(h=>Number(h.at)||0));
    if(localManualAt>remoteManualAt){
      thread.status=local.status; thread.desc=local.desc; thread.lastManualUpdatedAt=localManualAt;
      thread.lastUpdatedChapter=local.lastUpdatedChapter; thread.lastUpdatedTime=local.lastUpdatedTime;
      thread.statusHistory=Array.isArray(local.statusHistory)?local.statusHistory.slice():[];
    }
    return thread;
  });
  state.scenes=mergeArrayByIdOrName(state.scenes,incoming.scenes||[],"description");
  if(incoming.currentStatus)state.currentStatus=incoming.currentStatus;
  if(incoming.statusState){
    const localTimeLog=state.statusState&&Array.isArray(state.statusState.timeLog)?state.statusState.timeLog:[];
    const remoteTimeLog=Array.isArray(incoming.statusState.timeLog)?incoming.statusState.timeLog:[];
    state.statusState=incoming.statusState;
    const byChapter=new Map(); remoteTimeLog.concat(localTimeLog).forEach(x=>{if(x&&Number(x.chapter)>0)byChapter.set(Number(x.chapter),x);});
    state.statusState.timeLog=Array.from(byChapter.values()).sort((a,b)=>Number(a.chapter)-Number(b.chapter)).slice(-500);
  }
  state.lastStatusChapter=incoming.lastStatusChapter||state.lastStatusChapter;
  state.chaptersSinceBackup=incoming.chaptersSinceBackup!=null?incoming.chaptersSinceBackup:state.chaptersSinceBackup;
  /* v9.3: trước đây Timeline / Foreshadowing / Knowledge Ledger KHÔNG được hợp nhất từ job nền nên không bao giờ hiện. */
  state.timeline=mergeArrayByIdOrName(state.timeline,incoming.timeline||[],"id");
  state.foreshadowing=mergeArrayByIdOrName(state.foreshadowing,incoming.foreshadowing||[],"id");
  state.knowledgeLedger=mergeArrayByIdOrName(state.knowledgeLedger,incoming.knowledgeLedger||[],"id");
  state.memoryEvents=mergeArrayByIdOrName(state.memoryEvents,incoming.memoryEvents||[],"id");
  state.lastMemorySyncChapter=Math.max(Number(state.lastMemorySyncChapter)||0,Number(incoming.lastMemorySyncChapter)||0);
  state.canonVersion=mergeCanonVersion(state.canonVersion, incoming.canonVersion);
  /* V12.23: job nền trả gợi ý chương sau (rỗng = tạo thất bại -> xóa gợi ý cũ đã dùng). Không ghi đè nếu người dùng đã gõ gợi ý mới trong lúc job chạy. */
  if(typeof incoming.nextChapterHint === "string"){
    const curH=String(state.nextChapterHint||"").trim();
    const wasH=(record && typeof record.briefAtStart==="string") ? record.briefAtStart.trim() : null;
    if(!curH || wasH===null || curH===wasH){ state.nextChapterHint=incoming.nextChapterHint; state.nextChapterHintMeta={ targetChapter: state.chapters.length + 1, version: Number(state.nextChapterHintMeta && state.nextChapterHintMeta.version || 0) + 1, status: state.nextChapterHint.trim() ? "active" : "inactive", updatedAt: Date.now(), source: "background" }; if(nextChapterHintEl) nextChapterHintEl.value=state.nextChapterHint; }
  }
  persist();renderAll();
  try{ captureChapterSnapshot(state.chapters.length); }catch(e){}
  const last=state.chapters[state.chapters.length-1];
  const gateFailed=isGateFailedResult(statusData)||!!(last&&last.status==="REVISION_REQUIRED");
  if(statusData.draftOnly) setStatus("📝 Bản nháp nền: "+(last?last.title:"")+" ("+(last?last.wordCount:0)+" từ). CHƯA hậu kỳ/Canon."+(last&&last.quickCheck?draftQuickLabel(last):" Đọc thử, ổn thì bấm ☁ Chạy hậu kỳ server (hoặc 🔍 Duyệt lại)."),false);
  else if(gateFailed) setStatus("⛔ Background: chương "+(last?last.title:"")+" chưa vượt Quality Gate — bản nháp đã lưu, CHƯA ghi Canon. Bấm 🔍 Duyệt lại hoặc ↻ Viết lại.",false);
  else if(statusData.postProcessStatus && statusData.postProcessStatus!=="DONE"){
    /* V12.32.2: hậu kỳ server lỗi/chỉ cập nhật một phần -> KHÔNG báo "Đã đồng bộ" giả. */
    const failedTxt=(statusData.postProcessFailed||[]).join(", ");
    setStatus((statusData.postProcessStatus==="FAILED"?"⚠ Hậu kỳ THẤT BẠI — NV/World/Status/Memory CHƯA được cập nhật":"⚠ Hậu kỳ chỉ cập nhật một phần"+(failedTxt?" (chưa cập nhật: "+failedTxt+")":""))+(statusData.postProcessError?". Lý do: "+statusData.postProcessError:"")+" Bấm nút thử lại hậu kỳ.",false);
  }
  else setStatus("☁ Đã đồng bộ: "+(last?last.title:"")+" ("+(last?last.wordCount:0)+" từ). NV/World/Status/Scene đã hợp nhất.",false);
}
function checkPendingBackgroundJob(){
  const record=normalizeBgRecord(localStorage.getItem(BG_JOB_KEY));
  if(!record)return;
  setBgStatus("☁ Phát hiện job nền đang chờ đồng bộ...",true);pollBackgroundJob(record);
}

// V12.28: nút thủ công chỉ dùng để RETRY HẬU KỲ, không còn tạo job viết chương.
async function retryBackgroundPostProcess(){
  if(generating){ setStatus("Đang viết chương — hãy đợi chương lưu xong.",true); return; }
  const idx=state.currentChapterIndex;
  const ch=idx>=0?state.chapters[idx]:null;
  if(!ch || !String(ch.text||"").trim()){ setStatus("Chưa có chương để chạy hậu kỳ.",false); return; }
  try{
    /* V14.1.1: bấm ☁ Chạy hậu kỳ server = người dùng đã đọc và đồng ý -> tự duyệt chương nháp/cần sửa trước,
       nếu không worker sẽ chặn hậu kỳ (rào chắn Canon chỉ nhận chương đã được chấp nhận). */
    normalizeChapterPipelineState(ch);
    if(state.accuracyMode===true&&blockIfRequiredBeatsMissing(ch,"hậu kỳ/Sync Canon")) return;
    if(/^(draft|drafted|revision_required|rejected|failed|running|writing)$/i.test(String(ch.status||""))){
      if(/^(revision_required|rejected|failed)$/i.test(String(ch.status))){
        if(!await showConfirm("Chương "+(idx+1)+" đang ở trạng thái "+chapterStatusLabel(String(ch.status).toUpperCase())+".\nVẫn tự duyệt và chạy hậu kỳ/ghi Canon?")) return;
      }
      ch.status="APPROVED";
      if(state.accuracyMode!==true) ch.review=Object.assign({},ch.review||{},{verdict:(ch.review&&ch.review.verdict==="PASS")?"PASS":"MANUAL_OVERRIDE",status:"completed",overriddenAt:Date.now()});
      ch.sync=Object.assign(ch.sync||{},{status:"pending"});
      persist(); renderChapterNav(); renderCurrentChapter();
    }
    await startBackgroundPostProcess(ch,idx+1,ch.text,ch.briefUsed||state.nextChapterHint||"");
  }catch(e){
    setBgStatus("⚠ "+String(e&&e.message||e),true);
    setStatus("⚠ Không gửi được hậu kỳ server: "+String(e&&e.message||e),false);
  }
}
/* V14.0.6: VIẾT NHÁP NỀN. Server viết chương bằng đúng pipeline "Tạo Chương Hoàn Chỉnh" (Chapter Contract + Scene Graph + scene + top-up),
   lưu ở trạng thái "Bản nháp" và DỪNG. Người dùng đọc; ổn thì bấm ☁ Chạy hậu kỳ server (hoặc 🔍 Duyệt lại) để tóm tắt/canon/status.
   Chương nháp chưa hậu kỳ sẽ chặn viết chương kế tiếp (guard sẵn trong generateChapter) để không mất continuity. */
function draftQuickLabel(ch){
  const q=ch&&ch.quickCheck;
  if(!q) return "";
  if(!q.ok) return " ⚪ Chưa chấm được ("+String(q.reason||"").slice(0,60)+") — nên đọc kỹ.";
  const dot=q.verdict==="PASS"?"🟢 ĐẠT":(q.verdict==="SOFT_FAIL"?"🟡 CÓ CẢNH BÁO":"🔴 LỖI NẶNG");
  let hint=q.verdict==="PASS"?"Có thể chạy hậu kỳ luôn.":(q.verdict==="SOFT_FAIL"?"Chỉ cần đọc các điểm cảnh báo trong khung Quality.":"Nên ↻ Viết lại thay vì hậu kỳ.");
  /* V14.1.6: gợi ý hành động cụ thể + nội dung lỗi nặng ngay trên dòng trạng thái */
  try{
    const adv=reviewActionAdvice(ch.review);
    if(adv){ hint="👉 "+adv.action+(adv.issues.length?" Lỗi nặng: "+adv.issues.slice(0,2).map(x=>"• "+x.text).join(" "):""); }
  }catch(e){}
  let fixTxt="";
  if(q.fix && q.fix.rounds){
    const b=q.fix.before||{}, a=q.fix.after||{};
    fixTxt=" 🛠 Đã tự sửa "+q.fix.rounds+" vòng: "+(b.score==null?"—":b.score)+" → "+(a.score==null?"—":a.score)+"/100"+(q.fix.restored?" (bản sửa không tốt hơn nên giữ bản cũ)":"")+".";
  }
  return " "+dot+" · "+(q.score==null?"—":q.score)+"/100 · "+q.hard+" lỗi nặng · "+q.warn+" cảnh báo."+fixTxt+" "+hint;
}
async function startBackgroundDraft(){
  if(generating){ setStatus("Đang viết chương — hãy đợi xong.",true); return; }
  const key=(state.apiKey||apiKeyInput.value||"").trim();
  if(!key){ setStatus("Thiếu API Key để viết nền.",false); return; }
  if(!state.apiEndpoint&&!apiEndpointInput.value){ setStatus("Thiếu endpoint để viết nền.",false); return; }
  if(localStorage.getItem(BG_JOB_KEY)){ setStatus("Đã có Background Job khác đang chạy. Hãy chờ job đó xong.",false); return; }
  if(!(await outlinePreflight(state.chapters.length + 1))) return;
  await ensureCastPlanned(state.chapters.length + 1);
  normalizeAllChapterPipelineState();
  const last=state.chapters[state.chapters.length-1];
  if(last && !["SYNCED","SYNCED_WITH_WARNINGS","MODIFIED_AFTER_SYNC"].includes(last.status||"SYNCED")){
    setStatus("⛔ Chương "+state.chapters.length+" chưa hoàn tất hậu kỳ/Sync. Duyệt chương đó và bấm ☁ Chạy hậu kỳ server (hoặc 🔍 Duyệt lại) trước khi viết nháp chương kế tiếp.",false); return;
  }
  const pick=pickWritingModel(false);
  if(!pick.model){ setStatus("Chưa cấu hình model.",false); return; }
  const chapterNumber=state.chapters.length+1;
  const storyBlob={};
  Object.keys(state).forEach(k=>{if(!GLOBAL_KEYS.includes(k))storyBlob[k]=state[k];});
  BG_HEAVY_STATE_KEYS.forEach(k=>{ delete storyBlob[k]; }); // V14.3.1: như hậu kỳ
  if(Array.isArray(storyBlob.chapters)) storyBlob.chapters=storyBlob.chapters.map(ch=>{
    if(!ch||typeof ch!=="object") return ch;
    const o=Object.assign({},ch); BG_HEAVY_CHAPTER_KEYS.forEach(k=>{ delete o[k]; }); return o;
  });
  ["minChapterWords","descriptionLevel","explicitLevel","nsfwMode","nsfwAutoThreshold","chapterMatureFocus","modelNsfw","advancedRules","includeScenesInPrompt","autoContinueMax","spellCheckEnabled","adaptiveScenePipeline","semanticProseAuto","beatLedgerCheck","sceneAiReview","accuracyMode","qualityMaxAttempts","stepModels"].forEach(k=>{if(state[k]!==undefined)storyBlob[k]=state[k];});
  storyBlob.adaptiveScenePipeline=true; // nháp nền luôn dùng pipeline Contract-first
  const payload={
    mode:"write", draftOnly:true, quickCheck:(($ID("bgQuickCheck")||{}).checked!==false), autoFixQuick:(($ID("bgAutoFixQuick")||{}).checked!==false), chapterNumber,
    hintStyle:state.hintStyle||"normal", hintFormat:state.hintFormat||"detail",
    storyState:storyBlob, apiKey:key,
    apiEndpoint:state.apiEndpoint||apiEndpointInput.value.trim(),
    model:pick.model||state.model||"deepseek/deepseek-v3.2",
    modelNsfw:state.modelNsfw||"aion-labs/aion-2.0", forceNsfw:false
  };
  /* V14.2.2: như hậu kỳ — đo BYTE (Netlify ~6MB) và rút gọn văn bản chương cũ khi payload nặng (giữ 3 chương cuối đầy đủ); văn bản đầy đủ khôi phục từ bản local khi hợp nhất. */
  const _bytes=x=>{ try{ return new TextEncoder().encode(x).length; }catch(_){ return x.length*2; } };
  const _cr=bgNewJobCreds(); payload.clientJobId=_cr.jobId; payload.clientAccessToken=_cr.token;
  let bodyStr=JSON.stringify(payload), bodyBytes=_bytes(bodyStr), trimmedN=0;
  if(bodyBytes>1500000 && Array.isArray(storyBlob.chapters)){
    const nCh=storyBlob.chapters.length;
    storyBlob.chapters=storyBlob.chapters.map((c,i)=>{
      if(!c||typeof c!=="object"||i>=nCh-3) return c;
      const t=String(c.text||""); if(t.length<=2000) return c;
      trimmedN++; return Object.assign({},c,{text:t.slice(-1500),_bgTrimmed:true});
    });
    bodyStr=JSON.stringify(payload); bodyBytes=_bytes(bodyStr);
  }
  if(bodyBytes>5500000){ setStatus("Dữ liệu quá lớn ("+Math.round(bodyBytes/1024)+" KB, giới hạn Netlify ~6MB). Hãy backup và giảm dữ liệu lịch sử (Timeline/Memory/NV) trước khi viết nền.",false); return; }
  const pc=getAppPasscode(); const headers={"Content-Type":"application/json"}; if(pc)headers["X-App-Passcode"]=pc;
  setBgStatus("☁ Đang gửi lệnh viết nháp lên server...",true);
  const ac=new AbortController(); const timer=setTimeout(()=>ac.abort(),90000);
  try{
    let res;
    try{ res=await bgPostCreateJobRecover(BG_FUNCTIONS_BASE+"/create-job",headers,bodyStr,90000,_cr); }
    catch(e){
      let top=""; try{ top=Object.keys(storyBlob).map(k=>[k,JSON.stringify(storyBlob[k]||"").length]).sort((a,b)=>b[1]-a[1]).slice(0,4).map(x=>x[0]+" "+Math.round(x[1]/1024)+"KB").join(", "); }catch(_){}
      const info=" (đã gửi "+Math.round(bodyBytes/1024)+" KB"+(trimmedN?", đã rút gọn "+trimmedN+" chương cũ":"")+"; nặng nhất: "+top+")";
      const diag=await bgDiagnoseServer();
      if(e&&e.name==="AbortError") throw new Error("create-job không phản hồi sau 90 giây"+info+"."+bgUploadNote(e)+diag+" Job có thể đã được tạo — đợi vài phút rồi mở lại app trước khi gửi lại.");
      throw new Error(String(e&&e.message||e)+" — request không tới được server"+info+"."+diag);
    }
    const raw=await res.text().catch(()=>""); let data={}; try{data=JSON.parse(raw)||{};}catch(_){}
    if(res.status===401) throw new Error("Sai hoặc thiếu Mã truy cập server (mục 🔒).");
    if(res.status===413) throw new Error("Server từ chối vì dữ liệu quá lớn ("+Math.round(bodyBytes/1024)+" KB). Hãy backup và giảm dữ liệu lịch sử.");
    if(!res.ok || !data.jobId || !data.accessToken) throw new Error(data.error || ("HTTP "+res.status));
    bgWarnText=Array.isArray(data.warnings)&&data.warnings.length ? " ⚠ "+data.warnings.join(" | ") : "";
    const record={jobId:data.jobId,accessToken:data.accessToken,storyId:state.storyId,baseChapterCount:state.chapters.length,createdAt:Date.now(),briefAtStart:String(state.nextChapterHint||""),mode:"write",draftOnly:true,chapterNumber};
    localStorage.setItem(BG_JOB_KEY,JSON.stringify(record));
    setStatus("☁ Đã gửi lệnh viết nháp chương "+chapterNumber+" lên Netlify. Có thể khóa iPhone/thoát app.",false);
    setBgStatus("✓ Server đang viết nháp — có thể tắt máy.",true);
    pollBackgroundJob(record);
  }catch(e){
    setBgStatus("⚠ "+String(e&&e.message||e),true);
    setStatus("⚠ Không gửi được lệnh viết nháp: "+String(e&&e.message||e),false);
  }finally{ clearTimeout(timer); }
}
// Gắn sự kiện — script nằm cuối trang nên chỉ cần bind một lần.
(function(){
  const btn = $ID("bgWriteBtn");
  if(btn) btn.addEventListener("click", retryBackgroundPostProcess);
  const dbtn = $ID("bgDraftBtn");
  if(dbtn) dbtn.addEventListener("click", startBackgroundDraft);
})();


/* ========== BOOT ========== */
async function bootV102(){
  setupAgeGate(); setupUIMode(); setupSecurityAudit();
  await initIndexedDBStorage();
  bootstrapStorage();
  await loadCurrentStoryIntoState();
  syncApiSettingsV102();
  moveAuthoringSectionsToWriter();
  ensureUpgradePanel();
  /* Patch quy tắc tốc độ cũ */
  try{
    if(state.advancedRules && /dục vọng phải diễn ra từ từ/.test(state.advancedRules)){
      state.advancedRules=state.advancedRules.replace(/QUY TẮC TỐC ĐỘ:[^\n]+/,"QUY TẮC TỐC ĐỘ: Tình cảm dài hạn nên có tích tụ. Khi mệnh lệnh/mức 18+ yêu cầu cảnh nóng: viết thẳng, không né.");
      state.advancedRules=state.advancedRules.replace(/QUY TẮC 18\+ \(khi bật\):[^\n]+/,"QUY TẮC 18+ (khi bật): Viết trực tiếp, từ tục được phép. Không tự kiểm duyệt, không fade-to-black.");
    }
  }catch(e){}
  hydrateFormFromState();
  renderAll();
  renderStoryTabs();
  showOnboardingWizard();
  checkForRecoverableDraft();
  checkPendingBackgroundJob();
  if(state.apiEndpoint && state.apiKey) apiStatus.textContent="Đã nạp cấu hình API đã lưu.";
  if(location.protocol==="file:"){
    apiStatus.textContent="⚠ Trang chạy file:// — CORS. Chạy 'python -m http.server 8000' rồi mở http://localhost:8000/...";
    apiStatus.className="api-status bad";
  }
  updateV102Estimator();
  try{ if(navigator.storage && navigator.storage.persist) navigator.storage.persist(); }catch(e){}
  try{ const u=underageNames(state); if(state.mature && u.length) setStatus("⚠ Nhân vật dưới 18 tuổi ("+u.join(", ")+") sẽ bị cấm xuất hiện trong cảnh 18+. Kiểm tra lại trường Tuổi nếu là nhầm lẫn.", true); }catch(e){}
}
bootV102().catch(err=>{
  console.error(err);
  try{
    bootstrapStorage();
    loadCurrentStoryIntoState().then(()=>{moveAuthoringSectionsToWriter();ensureUpgradePanel();hydrateFormFromState();renderAll();});
  }catch(e){ console.error(e); }
});

function toggleAutoOpts(){
  const autoOpts = $ID("nsfwAutoOpts");
  if(!autoOpts) return;
  autoOpts.style.display = (state.nsfwMode === "auto") ? "block" : "none";
}

function updateNsfwHint(){
  const hintEl = $ID("nsfwHint");
  if(!hintEl) return;
  const pick = pickWritingModel(false);
  const focus = normalizeChapterMatureFocus(state.chapterMatureFocus);
  let hint = "<b>Trọng tâm chương:</b> " + focus.toUpperCase() + ". ";
  if(focus === "none") hint += "Không tự chèn nội dung trưởng thành.";
  else if(focus === "secondary") hint += "Chỉ dùng khi brief/mạch truyện yêu cầu rõ.";
  else hint += "Chủ đề trưởng thành là một trọng tâm của chương.";

  if(state.nsfwMode === "auto"){
    hint += '<br>🤖 <b>Tự động:</b> routing tuân theo trọng tâm chương; ngưỡng hiện tại ' + (state.nsfwAutoThreshold || 6) + '.';
    if(!state.mature) hint += '<br><span style="color:#e0a83f;">⚠ Cần bật "Cho phép trưởng thành".</span>';
    if(!state.modelNsfw) hint += '<br><span style="color:#e2584d;">⚠ Chưa cấu hình NSFW model.</span>';
  } else if(state.nsfwMode === "mature_only"){
    hint += '<br>📌 Chỉ khi bật 18+: model NSFW được phép theo trọng tâm chương.';
    if(state.mature && pick.isNsfw) hint += '<br><b style="color:#e2584d;">🔥 Đang dùng: ' + escapeHtml(shortModelName(pick.model)) + '</b>';
  } else if(state.nsfwMode === "always"){
    hint += '<br>🔥 Chế độ model NSFW luôn bật, nhưng NONE vẫn chặn nội dung trưởng thành.';
  } else {
    hint += '<br>🚫 Không dùng model NSFW.';
  }
  if(state.mature){
    const miss=[]; const mc=state.mainCharProfile;
    if(mc && mc.name && parseAgeNum(mc.age)===null) miss.push(mc.name);
    (state.characters||[]).forEach(c=>{ if(c && c.name && !c.dead && parseAgeNum(c.age)===null) miss.push(c.name); });
    if(miss.length) hint += '<br><span style="color:#8a8f98;">ℹ Chưa ghi tuổi (coi là người lớn): '+escapeHtml(miss.slice(0,8).join(", "))+(miss.length>8?"…":"")+'. Chỉ nhân vật ghi tuổi dưới 18 mới bị chặn khỏi cảnh 18+.</span>';
  }
  hintEl.innerHTML = hint;
}
function renderDeleteChapterSelect(){
  const prevVal = deleteChapterSelect.value;
  if(!state.chapters.length){ deleteChapterSelect.innerHTML = "<option>Chưa có chương</option>"; return; }
  deleteChapterSelect.innerHTML = state.chapters.map((c,i)=>
    '<option value="'+i+'">Chương '+(i+1)+': '+escapeHtml(c.title)+'</option>'
  ).join("");
  const p = parseInt(prevVal,10);
  if(!isNaN(p) && p >= 0 && p < state.chapters.length) deleteChapterSelect.value = String(p);
}

function renderQuickJump(){
  const prev = quickJumpSelect.value;
  quickJumpSelect.innerHTML = '<option value="">-- Nhảy tới chương --</option>' +
    state.chapters.map((c,i)=>'<option value="'+i+'">Chương '+(i+1)+': '+escapeHtml((c.title||"").slice(0,50))+'</option>').join("");
  if(prev && !isNaN(parseInt(prev,10))) quickJumpSelect.value = prev;
}

function renderChapterNav(){
  const query = (chapterSearch.value || "").toLowerCase().trim();
  chapterStrip.innerHTML = "";
  renderDeleteChapterSelect();
  renderQuickJump();
  renderSnapshotChapterSelect();
  let indices = state.chapters.map((_,i)=>i).reverse();
  if(!query && indices.length>20){
    const cur=state.currentChapterIndex>=0?state.currentChapterIndex:state.chapters.length-1;
    const min=Math.max(0,cur-10), max=Math.min(state.chapters.length-1,cur+9);
    indices=indices.filter(i=>i>=min&&i<=max);
  }
  indices.forEach(i=>{
    const c = state.chapters[i];
    let match = true;
    if(query){
      const inTitle = (c.title||"").toLowerCase().includes(query);
      const inText = (c.text||"").toLowerCase().includes(query);
      const inNum = String(i+1).includes(query);
      match = inTitle || inText || inNum;
    }
    if(!match) return;
    const chip = document.createElement("div");
    chip.className = "chapter-chip" + (i === state.currentChapterIndex ? " active" : "");
    chip.innerHTML = '<div class="cnum">Chương '+(i+1)+'</div>'
      + '<div class="ctitle">'+escapeHtml(c.title||"")+'</div>'
      + '<div class="cwords">'+(c.wordCount||countWords(c.text))+' từ</div>'
      + (c.summary ? '<div class="csum" title="'+escapeHtml(c.summary)+'">📄</div>' : '')
      + (c.isNsfw ? '<div class="cnsfw">🔥</div>' : '')
      + (c.polished ? '<div style="color:var(--green);font-size:10px;">✓</div>' : '')
      + (c.truncated ? '<div class="cflag">⚠ cắt</div>' : '')
      + ((c.continuityWarnings&&c.continuityWarnings.length) ? '<div class="cflag">🔍 '+c.continuityWarnings.length+'</div>' : '')
      + (()=>{
          const hardIssues=(c.autoUpdateIssues||[]).filter(x=>!/^Status(?:\b|:)|^Memory(?:\b|:)/i.test(String(x||"")));
          return hardIssues.length ? '<div class="cflag" title="Chưa cập nhật được: '+escapeHtml(hardIssues.join(", "))+' — bấm Rescan để đồng bộ lại">⚠ '+escapeHtml(hardIssues.join("/"))+'</div>' : '';
        })();
    chip.addEventListener("click", ()=>{
      state.currentChapterIndex = i;
      renderChapterNav(); renderCurrentChapter();
    });
    chapterStrip.appendChild(chip);
  });
  if(!state.chapters.length) chapterStrip.innerHTML = '<div class="empty-note">Chưa có chương.</div>';
  else if(!query && state.chapters.length>20){
    const note=document.createElement("div"); note.className="hint"; note.style.padding="6px 2px"; note.textContent="Đang hiển thị 20 chương quanh chương hiện tại để giảm tải Safari iOS. Dùng Nhảy nhanh để mở chương bất kỳ."; chapterStrip.prepend(note);
  }
  const activeChip = chapterStrip.querySelector(".chapter-chip.active");
  if(activeChip){ try{ activeChip.scrollIntoView({behavior:"smooth", block:"nearest", inline:"start"}); }catch(e){ activeChip.scrollIntoView(); } }
}

function renderCurrentChapter(){ renderCurrentChapterCore(); XTA_HOOKS.fire("chapter"); }
function renderCurrentChapterCore(){
  const idx = state.currentChapterIndex;
  try{ updateV102Estimator(); }catch(e){}
  editorBadges.innerHTML = "";
  summaryBox.classList.remove("show");
  planBox.classList.remove("show");
  sceneBox.classList.remove("show");
  const qualityBox=$ID("qualityBox"); if(qualityBox){ qualityBox.style.display="none"; qualityBox.innerHTML=""; }
  if(idx < 0 || !state.chapters[idx]){
    chapterTitleEl.textContent = "Truyện của bạn bắt đầu ở đây";
    chapterTextEl.textContent = "";
    return;
  }
  const c = state.chapters[idx];
  normalizeChapterPipelineState(c);
  chapterTitleEl.textContent = "Chương " + (idx+1) + ": " + (c.title||"");
  chapterTextEl.textContent = c.text || "";
  const wc = c.wordCount || countWords(c.text);
  const clockHtml = state.storyClock
    ? '<span class="badge clock">🕐 '+escapeHtml(state.storyClock)+'</span>'
    : '<span class="badge clock empty">🕐 chưa đặt</span>';
  const modelHtml = c.modelUsed
    ? '<span class="badge ' + (c.isNsfw ? 'model-nsfw' : 'model') + '">' + (c.isNsfw ? '🔥 ' : '🤖 ') + escapeHtml(shortModelName(c.modelUsed)) + '</span>'
    : '';
  const chTokens = estimateTokens(c.text);
  const tokenBadge = '<span class="badge token' + (chTokens > 20000 ? ' bad' : '') + '">≈'+chTokens+' token</span>';
  const pipelineBadge='<span class="badge '+((c.status||"").includes("FAIL")||c.status==="REVISION_REQUIRED"||c.status==="MODIFIED_AFTER_SYNC"?"warn":"")+'">'+escapeHtml(chapterStatusLabel(c.status))+'</span>';
  const audit=c.postWriteAudit, auditBadge=audit?'<button class="badge '+(audit.withinWordBounds?'':'warn')+'" id="postWriteAuditViewBtn" title="Mở báo cáo hậu kiểm">📏 '+audit.wordCount+'/'+audit.minWords+'–'+audit.maxWords+' từ · '+(audit.continuityIssues&&audit.continuityIssues.length?audit.continuityIssues.length+' cảnh báo':'hậu kiểm')+'</button>':'';
  editorBadges.innerHTML = '<span class="badge">'+wc+' từ</span>' + pipelineBadge + clockHtml + modelHtml + tokenBadge
    + (c.polished ? '<span class="badge polished">✓ đã rà</span>' : '')
    + (c.truncated ? '<span class="badge warn">⚠ có thể cắt</span>' : '')
    + ((c.continuityWarnings&&c.continuityWarnings.length) ? '<span class="badge warn">🔍 '+c.continuityWarnings.length+'</span>' : '') + auditBadge;
  const auditBtn=$ID("postWriteAuditViewBtn"); if(auditBtn&&audit) auditBtn.addEventListener("click",()=>showAlert(["HẬU KIỂM CHƯƠNG "+audit.chapterNumber,"Độ dài: "+audit.wordCount+" từ (mục tiêu "+audit.minWords+"–"+audit.maxWords+"); trạng thái: "+audit.lengthStatus,"Mốc thời gian lặp: "+(audit.timeStall?audit.timeStall.repeatedMarks+" chương — "+audit.timeStall.time:"không phát hiện"),"Tình tiết đang mở: "+audit.unresolvedThreads+" thread · "+audit.unresolvedForeshadowing+" foreshadowing","Cảnh báo nhất quán:",...(audit.continuityIssues||[]).map(x=>"• "+x),c.lengthWarning?"Ghi chú: "+c.lengthWarning:""].filter(Boolean).join("\n")));
  if(c.summary){ summaryBox.textContent = "📄 Tóm tắt: " + c.summary; summaryBox.classList.add("show"); }
  if(c.plan){
    const tele = c.adaptiveStats && Array.isArray(c.adaptiveStats.sceneTelemetry) ? c.adaptiveStats.sceneTelemetry : [];
    const teleText = tele.length ? "\n\n📊 TELEMETRY SCENE:\n" + tele.map(x => x.sceneId + " · " + (x.status || "?") + " · " + (x.outputWords || 0) + "/" + (x.targetWords || 0) + " từ · " + (x.attempts || 0) + " lượt · " + (x.durationMs || 0) + "ms" + (x.errors && x.errors.length ? " · " + x.errors[0] : "")).join("\n") : "";
    planBox.textContent = "Kế hoạch:\n" + c.plan + teleText; planBox.classList.add("show");
  }
  if(c.continuityWarnings && c.continuityWarnings.length) renderContinuityWarnings(c.continuityWarnings);
  renderQualityReview(c);
}

chapterSearch.addEventListener("input", renderChapterNav);

(function(){const t=document.querySelector(".topbar");if(!t)return;const f=()=>document.documentElement.style.setProperty("--topbar-h",t.offsetHeight+"px");f();addEventListener("resize",f);addEventListener("load",f);})();

window.__XTA__ = {
  state, persist, escapeHtml, setStatus, showAlert, callAI, renderCharacters, renderLocations, newCharacter, newItem, renderItems, genId,
  get generating(){ return generating; },
  core: { computeCanonDiff, undoCanonDiffItem, suggestCharacterCandidates, storyHealthReport, deterministicConsistencyCheck, buildConsistencyPrompt, parseConsistencyResponse, STEP_LABELS, buildLayeredMemoryRanges, upsertFrozenLayerSummary }
};

/* v11: móc kiểm thử — chỉ bật khi trang được nạp với window.__XTA_TEST__ = true (không ảnh hưởng người dùng thường). */
if(window.__XTA_TEST__){
  window.__xta = {
    get state(){ return state; },
    persist, persistNow, flushPersist, buildContextBlock, underageNames, ageGuardPrompt,
    writeEmergencyCopy, readEmergencyRecord, serializeStoryRecord, hydrateFromRecord, removeStoryFromDisk,
    setIdbPut(fn){ idbPut = fn; }, getIdbPut(){ return idbPut; },
    newCharacter, newMainCharProfile, renderCharacters, generateNextChapterHint,
    mergeCharacterUpdate, saveMainCharFromForm, hydrateMainCharForm, renderItems, buildChapterContractForGeneration,
    chapterWordLimits, condenseChapterToBounds, countWords
  };
}
})();
