// V12.32.14: kiểm tra dọn dẹp — tài liệu đã gộp, hàm chết không quay lại, site không phát công khai file nội bộ.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..'), rd=f=>fs.readFileSync(path.join(root,f),'utf8');
const removed={"index.html": ["extractBalancedJson", "idbGetAll", "loadStoryStateFromDisk", "syncMainCharCoreFromProfile", "buildFemaleDefinitionBlock", "matureFocusLabel", "timingSummary", "runFastPostTasks", "normalizeStoryControlClient", "qualityHardCheck", "applyNextChapterHint", "previewNextChapterHint", "beginCanonSync", "completeCanonSync", "checkCheckpoint", "startBackgroundWrite", "_fmtDur", "enqueueTask", "showCheckpointBanner", "runQueue", "hideCheckpointBanner"], "worker": ["genSecret", "encryptText", "recentContext", "generateSummary", "generateNextChapterHint", "updateCharacters", "updateWorld", "formatStatus", "updateCurrentStatus", "updateLongMemory", "scanScenes", "parseArrayWithRepair", "parseObjectWithRepair", "extractModelFor", "compactCharacterList", "repairJsonWithAI"]};
// 1) tài liệu
assert(fs.existsSync(path.join(root,'CHANGELOG.md'))&&fs.existsSync(path.join(root,'docs/ARCHITECTURE.md'))&&fs.existsSync(path.join(root,'docs/PROMPT_V12.22.md')),'thiếu CHANGELOG/docs');
const stray=fs.readdirSync(root).filter(f=>/^(PATCH_NOTES.*|README_V.*|PROMPT_V.*)\.md$/.test(f));
assert.deepStrictEqual(stray,[],'file ghi chú cũ nằm rải ở thư mục gốc: '+stray.join(', '));
const ver=JSON.parse(rd('package.json')).version; assert(rd('README.md').includes('V'+ver)&&rd('CHANGELOG.md').includes('V'+ver),'README/CHANGELOG chưa ghi bản hiện tại V'+ver);
// 2) hàm chết không quay lại
const wordRe=n=>new RegExp('(?<![\\w$])'+n.replace(/\$/g,'\\$')+'(?![\\w$])');
for(const [file,key] of [['index.html','index.html'],['netlify/functions/write-chapter-background.js','worker']]){
  const src=rd(file); removed[key].forEach(n=>assert(!wordRe(n).test(src),file+': hàm đã gỡ xuất hiện lại: '+n));
}
// 3) netlify.toml chặn đường dẫn nội bộ + có 404.html
const toml=rd('netlify.toml'), blocks=toml.split('[[redirects]]').slice(1);
const need=['/tests/*','/netlify/*','/shared/*','/lib/*','/scripts/*','/docs/*','/README.md','/CHANGELOG.md','/SECURITY_SETUP.md','/package.json','/netlify.toml','/TODO.md','/plan.md','/PROMPT_OPTIMIZER_AUDIT.md','/VALIDATION_V1233.md','/.pre-p0-p1-p2-backup.txt'];
need.forEach(p=>{ const b=blocks.find(x=>x.includes('from = "'+p+'"')); assert(b,'thiếu redirect chặn '+p); assert(/status\s*=\s*404/.test(b)&&/force\s*=\s*true/.test(b),p+': phải status 404 + force'); });
assert(!/from\s*=\s*"\/(index\.html)?"/.test(toml)&&!/from\s*=\s*"\/\.netlify/.test(toml),'không được chặn trang chính / hàm Netlify');
assert(fs.existsSync(path.join(root,'404.html')),'thiếu 404.html');
// 4) CORS: không ghi cứng "*" ở toml; mọi function đọc ALLOWED_ORIGIN
assert(!/Access-Control-Allow-Origin\s*=\s*"\*"/.test(toml),'netlify.toml không được đặt CORS * toàn site');
for(const f of ['netlify/functions/write-chapter-background.js','netlify/functions/create-job.js','netlify/functions/job-status.js','netlify/functions/security-status.js']) assert(/"Access-Control-Allow-Origin"\s*:\s*(process\.env\.ALLOWED_ORIGIN|origin)/.test(rd(f)),f+': CORS phải theo ALLOWED_ORIGIN');
// 5) DEPLOY.md không hứa file .github mà zip không có
if(!fs.existsSync(path.join(root,'.github'))) assert(/không kèm/.test(rd('DEPLOY.md')),'DEPLOY.md phải nói rõ gói không kèm .github');
console.log('PASS V12.32.14 repo hygiene');
