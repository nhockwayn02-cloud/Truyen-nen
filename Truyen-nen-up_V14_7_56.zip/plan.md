# Kế hoạch V14 — Contract-First Complete Chapter Pipeline

> **Trạng thái:** Kế hoạch đã triển khai đến V14.0.20. Các mục bên dưới mô tả kiến trúc hiện hành; phần còn lại là backlog cần ghi rõ trong `TODO.md`.

## Mục tiêu

Tạo chương tiểu thuyết tiếng Việt dài khoảng 4.500–5.500 từ, đặc biệt phù hợp với chương 18+, nhưng khóa cứng Arc/Outline, nhân vật được phép, continuity mở chương, required beat và thay đổi bắt buộc. AI được linh hoạt về số scene và chức năng scene nhưng không được tự đổi hướng truyện.

## Kế hoạch tiếp tục đã được duyệt — bộ nhớ sáu tầng

Tiếp tục trên app V14.5.15 hiện tại, giữ UI mobile, IndexedDB, backup/restore và kiến trúc `index.html` + `shared/core.js` + `app/features.js` + worker Netlify. Bộ nhớ dùng L0 = chương gốc; L1 = tóm tắt chương hiện có; L2 = chunk 4 chương; L3 = arc 20 chương (5 chunk); L4 = volume 60 chương (3 arc); L5 = toàn truyện tổng hợp từ L4. L1–L4 được đóng băng sau khi tạo; L5 lưu phiên bản cũ khi tái tạo; có luồng xây bù cho truyện cũ. Phạm vi nhóm lưu theo truyện, không tự thay đổi ranh giới đã tạo.

Bổ sung hồ sơ thế lực bên cạnh characters/locations/items; hoàn thiện hồ sơ và trạng thái cho timeline, threads, foreshadowing và mốc thời gian. Sau viết, giữ Quality Gate và lưu báo cáo kiểm tra độ dài/continuity theo bằng chứng. Bổ sung min/max chương; chương ngắn được mở rộng theo scene/đoạn, chương dài được rút gọn theo scene/đoạn, đều bảo toàn Outline/required beat/ending anchor, tạo version trước mỗi chỉnh sửa, tối đa hai vòng rồi giữ bản tốt nhất và báo rõ nếu vẫn ngoài ngưỡng. Truyện cũ giữ giới hạn hiện hành cho tới khi tác giả đặt min/max. Tận dụng UI hiện có, không thay nhà cung cấp AI hay thêm backend/vector DB.

## Chế độ bổ sung — Ưu tiên độ chính xác

Thêm cài đặt theo từng truyện, mặc định tắt để giữ nguyên hành vi cũ. Khi bật, chế độ tự bật/ép dùng Quality Gate, tắt chấp nhận SOFT_FAIL, bật rào chắn Required Beat và tăng tối đa ba lượt review/sửa. Mỗi lượt review có một kiểm tra beat độc lập: lấy mọi mã [R#] từ Outline/Contract, yêu cầu trạng thái cùng trích dẫn bằng chứng nguyên văn; trích dẫn không tồn tại, thiếu mã hoặc API/JSON kiểm tra thất bại đều không được coi là đã xác minh. Bản chưa xác minh beat bắt buộc không được Sync/Publish/Export Canon.

Trong cùng chế độ, quét các đoạn văn dài trùng/gần trùng trong một chương, báo vị trí và đưa lỗi vào targeted patch; tạo snapshot trước khi vá, rà lại sau vá, giữ bản tốt nhất và không fallback sang viết lại cả chương. Lỗi lặp chưa xử lý được hiển thị để tác giả sửa; missing [R#] tiếp tục chặn Sync. Lưu toggle trong story state/backup để mỗi truyện giữ cài đặt riêng; không cần backend mới.

Export backup JSON vẫn được phép để bảo toàn bản nháp; chỉ các luồng xuất bản/Canon bị rào chắn khi audit chưa đạt.

## Quyết định triển khai

- Một lần gọi AI lập Scene Graph/Scene Contract ngắn.
- Viết scene tuần tự; mỗi scene chỉ nhận contract, 600–900 từ cuối scene trước và state delta compact.
- Ghép scene bằng code, không gọi AI để viết lại toàn chương.
- Mục tiêu chương 5.000 từ; chấp nhận 4.500–5.500; hard cap khoảng 5.600 để bảo vệ ending.
- Khi các scene ban đầu thiếu độ dài, chạy Adaptive Scene Top-up tối đa 6 lượt; mỗi lượt chỉ gửi đoạn đuôi và state delta compact, không gửi lại toàn chương.
- Quality Gate giữ ở mức review cuối, có patch/targeted repair và Best Draft Guard; các cảnh báo mềm không tự gọi rewrite nếu không có hướng xử lý.
- Semantic Prose Check và AI spell-check không chạy mặc định trong pipeline nhanh/cân bằng.
- Hậu kỳ unified cập nhật summary, Character/World/Status/Memory/Continuity và next hint theo evidence; Canon Sync chỉ chạy sau barrier phù hợp.

## Cấu trúc chính

- `shared/core.js`: giới hạn từ và các helper prompt/parse cho Scene Graph, Scene Contract, state delta.
- `index.html`: pipeline client adaptive scene, ghi telemetry theo step và xử lý safe failure khi scene plan lỗi.
- `write-chapter-background.js`: worker dùng cùng `runAdaptiveChapterPipeline`, có draft mode, quick-fix và postprocess server-side.
- `tests/`: regression cho giới hạn từ, scene plan parse, prompt không gửi toàn bộ chương và ngân sách scene.

## Trạng thái

- V12.47.1: baseline lịch sử.
- V13.0: đợt đầu giới hạn từ + helper Scene Graph + client scene writer + regression.
- V13.1: system prompt compact riêng cho Scene Graph/scene writer; contract/state/tail được rút gọn, loại bỏ `lastTail` trùng và chỉ gửi ending anchor ở scene cuối.
- V13.2: Adaptive Scene Top-up và Hard Fail bắt buộc cho chương dưới 4.500 từ.
- V13.6: gom rào chắn Arc/Outline, allowed cast và forbidden drift vào Scene Graph, từng scene và top-up; không để nhân vật mới tự mở tuyến chính ngoài Arc.
- V14: Chapter Contract bất biến; validate plan trước khi viết; reject plan drift thay vì fallback âm thầm; kiểm tra scene theo contract; top-up chỉ mở rộng scene hợp lệ; Sync chỉ sau khi contract barrier đạt.
- V14.0.17–V14.0.20: hint provenance và active-record filtering; accepted-canon/Character Canon barrier; Vietnamese-native prose contract dùng chung cho client, worker và adaptive scene.

## Kiến trúc V14

- `Chapter Contract`: nguồn sự thật duy nhất cho Arc, Outline, cast, forbidden drift, opening continuity, required beats, ending anchor, must-change và ngân sách từ.
- `Plan Validator`: từ chối Scene Graph có nhân vật quan trọng ngoài cast, thiếu beat/must-change, hoặc mục tiêu lệch Arc; retry kế hoạch một lần rồi dừng an toàn.
- `Scene Contract Gate`: mỗi scene phải nhận cùng Chapter Contract; scene lỗi không được ghép tiếp vào chương.
- `Contract-first Gate`: Arc/beat/continuity/character barrier có thứ tự ưu tiên cao hơn score văn phong.
- `Safe failure`: plan không hợp lệ tạo `PLAN_REJECTED`, không gọi fallback writer và không ghi bản nháp sai vào Canon.
