const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../shared/core.js'), 'utf8');
const indexSrc = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
const box = { console, state: {} };
vm.createContext(box);
vm.runInContext(src + '\n;this.__t={safeDedupeRepeatedScene,dropRepeatedParagraphs,countWords,chapterWordLimits,adaptiveChapterWordLimits,compactSceneTail,compactSceneContract,compactSceneStateDelta,buildAdaptiveScenePlanPrompt,parseAdaptiveScenePlanResponse,normalizeAdaptiveScenePlan,validateAdaptiveScenePlan,validateSceneTextAgainstContract,compactChapterContract,buildAdaptiveSceneWritePrompt,buildAdaptiveSceneTopUpPrompt,gateHardChecks};', box);
const T = box.__t;
let pass = 0;
function test(name, fn){ fn(); console.log('PASS ' + name); pass++; }

test('giới hạn chương V13 là 4500–5500 và hard cap 5600', () => {
  const limits = T.chapterWordLimits({ minChapterWords: 500 });
  assert.strictEqual(limits.target, 5000);
  assert.strictEqual(limits.minAccept, 4500);
  assert.strictEqual(limits.maxAccept, 5500);
  assert.strictEqual(limits.hardMax, 5600);
  assert.strictEqual(T.adaptiveChapterWordLimits({ minChapterWords: 5200 }).target, 5200);
});

test('Scene Graph chấp nhận số scene linh hoạt và chuẩn hoá ngân sách', () => {
  const p = T.normalizeAdaptiveScenePlan({ chapterGoal: 'g', endingAnchor: 'e', scenes: [
    { id: 'S1', purpose: 'đối thoại và tiết lộ', targetWords: 100 },
    { id: 'S2', purpose: 'hậu quả', targetWords: 4000 },
    { id: 'S3', purpose: 'chuyển hướng', targetWords: 800 }
  ] }, { minChapterWords: 5000 });
  assert.strictEqual(p.scenes.length, 3);
  assert.strictEqual(p.scenes[0].targetWords, 350);
  assert.strictEqual(p.scenes[1].targetWords, 2200);
});

test('V14 Contract Validator từ chối nhân vật ngoài cast và thiếu mustChange', () => {
  const contract = { allowedCharacters: ['Bùi Lạc'], forbiddenDrift: ['Không mở tuyến vệ sĩ/Kim Chi/khách sạn.'] };
  const plan = T.normalizeAdaptiveScenePlan({ chapterGoal: 'g', endingAnchor: 'e', scenes: [{ id:'S1', characters:['Kim Chi'], mustChange:'', handoff:'' }] }, {});
  const result = T.validateAdaptiveScenePlan(plan, contract);
  assert(!result.ok);
  assert(result.errors.some(x => /Kim Chi/.test(x)));
});

test('V14 Canon Cast cho phép nhân vật hợp lệ ngoài Active Cast', () => {
  const contract = { allowedCharacters:['Bùi Lạc'], canonicalCharacters:['Bùi Lạc','Trần Mỹ Duyên'] };
  const plan = T.normalizeAdaptiveScenePlan({ chapterGoal:'g', endingAnchor:'e', scenes:[{id:'S1', characters:['Trần Mỹ Duyên'], mustChange:'m', handoff:'h'}] }, {});
  assert(T.validateAdaptiveScenePlan(plan, contract).ok);
  assert(T.validateSceneTextAgainstContract('Trần Mỹ Duyên bước vào phòng. Bùi Lạc đặt tập hồ sơ lên bàn và chờ cô đọc hết những dòng ghi chú về cuộc họp tối nay.', contract).ok);
});

test('V14 parser cứu Scene Graph trong markdown/lời dẫn/phần thừa', () => {
  const json = '{"chapterGoal":"g","endingAnchor":"e","scenes":[{"id":"S1","mustChange":"m","handoff":"h"}]}';
  for (const raw of ['```json\n' + json + '\n```', 'Đây là kế hoạch:\n' + json + '\nHết.', json]) {
    const p = T.normalizeAdaptiveScenePlan(raw, {});
    assert(p && p.scenes.length === 1 && p.chapterGoal === 'g');
  }
});

test('V14 Contract lấy cast từ toàn bộ Arc/Outline, không chỉ dòng chương hiện tại', () => {
  assert(indexSrc.includes('const arcSource = arc ? JSON.stringify(arc) : "";'));
  assert(indexSrc.includes('const outlineSource = ol ? String(ol.content || "") : "";'));
  assert(indexSrc.includes('arcSource, outlineSource, outlineLine'));
});

test('Scene write prompt chỉ truyền tail bị giới hạn, không truyền toàn chương', () => {
  const long = 'x'.repeat(20000);
  const prompt = T.buildAdaptiveSceneWritePrompt({
    state: { minChapterWords: 5000 },
    scene: { id: 'S1', targetWords: 900, purpose: 'p' },
    previousTail: long,
    stateDelta: { sceneId: 'S0', handoff: 'h' }
  });
  assert(prompt.includes('CONTRACT'));
  assert(prompt.length < 12000, 'prompt scene phải compact, thực tế ' + prompt.length);
  assert(!prompt.includes('x'.repeat(10000)));
});

test('scene đầu chương khóa nối địa điểm với đoạn kết trước', () => {
  const prompt = T.buildAdaptiveSceneWritePrompt({
    state: { minChapterWords: 5000 }, scene: { id: 'S1', targetWords: 900, purpose: 'mở chương' },
    previousTail: 'Bùi Lạc hòa vào dòng chảy im lặng của thành phố.', isOpeningScene: true
  });
  assert(/KHÓA CẢNH MỞ/.test(prompt));
  assert(/địa điểm, thời điểm và người/.test(prompt));
});

test('Scene Graph khóa Arc, allowed cast và chống tuyến drift', () => {
  const prompt = T.buildAdaptiveScenePlanPrompt({
    state: { minChapterWords: 5000 }, context: 'Arc 1: trả thù trong công ty',
    arcProgress: 'Arc 1 — trả thù trong công ty Vĩnh Phát; chương này phải tiếp tục khai thác Trần Mỹ Duyên',
    allowedCast: 'Bùi Lạc, Trần Mỹ Duyên, Lâm Tịnh Nhã',
    forbiddenDrift: 'Không chuyển sang tuyến vệ sĩ/Kim Chi/khách sạn nếu Outline không ghi rõ.'
  });
  assert(/ARC\/OUTLINE LOCK/.test(prompt));
  assert(/ALLOWED CAST/.test(prompt));
  assert(/FORBIDDEN DRIFT/.test(prompt));
  assert(/Không tự biến nhân vật phụ/.test(prompt));
});

test('state delta không chứa lastTail để tránh gửi đuôi scene hai lần', () => {
  const delta = T.compactSceneStateDelta({ sceneId: 'S1', location: 'phòng', lastTail: 'lặp rất dài', handoff: 'tiếp' });
  assert.strictEqual(delta.lastTail, undefined);
  assert.strictEqual(delta.sceneId, 'S1');
});

test('contract compact giữ beat cần thiết nhưng cắt trường dư', () => {
  const c = T.compactSceneContract({ id: 'S1', purpose: 'p'.repeat(900), beats: ['a', 'b'], targetWords: 900, debugOnly: 'x'.repeat(10000) });
  assert(c.beats.length === 2);
  assert(!('debugOnly' in c));
  assert(JSON.stringify(c).length < 700);
});

test('Scene Graph prompt cấm khuôn vai trò cố định', () => {
  const prompt = T.buildAdaptiveScenePlanPrompt({ state: {}, context: 'canon', directive: 'brief' });
  assert(/LINH HOẠT/.test(prompt));
  assert(/không dùng khuôn/.test(prompt));
  assert(/JSON object/.test(prompt));
});

test('required beat checklist được truyền trực tiếp vào plan và scene', () => {
  const required = '[OUTLINE Ch12] [S1] Tu luyện Huyền Nguyên Quyết; [R3] trinh sát hẻm Song Hành';
  const plan = T.buildAdaptiveScenePlanPrompt({ state: {}, context: 'canon', requiredBeats: required });
  const scene = T.buildAdaptiveSceneWritePrompt({ state: {}, scene: { id: 'S1', targetWords: 900 }, requiredBeats: required });
  assert(plan.includes(required));
  assert(scene.includes('REQUIRED CHECKLIST') && scene.includes('Huyền Nguyên Quyết'));
});

test('top-up prompt compact chỉ nhận đuôi và bắt buộc viết thêm diễn biến', () => {
  const prompt = T.buildAdaptiveSceneTopUpPrompt({ currentWords: 2886, needWords: 1614, previousTail: 'x'.repeat(10000), requiredBeats: '[S1] tu luyện' });
  assert(prompt.includes('còn thiếu khoảng 1614 từ'));
  assert(prompt.includes('REQUIRED BEATS') && prompt.includes('tu luyện'));
  assert(!prompt.includes('x'.repeat(10000)));
  assert(prompt.length < 7000);
});

test('Quality Gate hard-fail chương dưới 4.500 từ', () => {
  const short = T.gateHardChecks({ text: Array.from({length: 2886}, (_, i) => 'từ' + i).join(' ') });
  const lengthCheck = short.find(c => c.id === 'text_nonempty');
  assert(lengthCheck && lengthCheck.ok === false);
  assert(T.gateHardChecks({ text: Array.from({length: 4500}, (_, i) => 'từ' + i).join(' ') }).find(c => c.id === 'text_nonempty').ok);
});

test('viết lại chương vẫn đi qua Adaptive Scene + Top-up', () => {
  assert(indexSrc.includes('if(state.adaptiveScenePipeline !== false){'), 'nhánh viết lại không được bỏ qua adaptive pipeline');
  assert(indexSrc.includes('V13.3: viết lại chương cũng phải đi qua Adaptive Scene + Top-up'));
});

test('fallback ngắn cũng bị ép chạy hàng rào Top-up cuối', () => {
  assert(indexSrc.includes('async function topUpShortDraftText'), 'thiếu fallback top-up');
  assert(indexSrc.includes('rawText = await topUpShortDraftText'), 'fallback chưa gọi top-up');
  assert(indexSrc.includes('if(countWords(rawText) < adaptiveChapterWordLimits(state).minAccept){'), 'hard minimum không được phụ thuộc cờ pipeline cũ');
});

console.log(`\n${pass}/17 PASS`);

test('V14.0.6 forbidden drift theo cụm chủ đề, không chặn nhầm "bảo vệ"/"bác sĩ"/"khách"', () => {
  const contract = { allowedCharacters:['Bùi Lạc'], chapterOutline:'Lạc bảo vệ hồ sơ trước khách đến thăm', forbiddenDrift:['Không mở tuyến vệ sĩ, khách sạn, shop váy cưới hoặc tuyến xã hội khác nếu Outline không ghi rõ.'] };
  const mk = extra => T.normalizeAdaptiveScenePlan({ chapterGoal:'bảo vệ hồ sơ trước khách ' + extra, endingAnchor:'bác sĩ gọi điện', scenes:[{id:'S1', characters:['Bùi Lạc'], mustChange:'m', handoff:'h'}] }, {});
  assert(T.validateAdaptiveScenePlan(mk(''), contract).ok);
  assert(!T.validateAdaptiveScenePlan(mk('tại khách sạn'), contract).ok);
  const withOutline = Object.assign({}, contract, { chapterOutline:'Lạc thuê vệ sĩ ở khách sạn' });
  assert(T.validateAdaptiveScenePlan(mk('tại khách sạn'), withOutline).ok);
});

test('V14.0.6 forbidden drift cho phép chủ đề có trong Gợi ý/Mệnh lệnh hoặc đoạn kết chương trước', () => {
  const base = { allowedCharacters:['Bùi Lạc'], chapterOutline:'Lạc đối chất', forbiddenDrift:['Không mở tuyến vệ sĩ, khách sạn, shop váy cưới hoặc tuyến xã hội khác nếu Outline không ghi rõ.'] };
  const plan = T.normalizeAdaptiveScenePlan({ chapterGoal:'Lạc đối chất tại khách sạn', endingAnchor:'e', scenes:[{id:'S1', characters:['Bùi Lạc'], mustChange:'m', handoff:'h'}] }, {});
  assert(!T.validateAdaptiveScenePlan(plan, base).ok);
  assert(T.validateAdaptiveScenePlan(plan, Object.assign({}, base, { userBrief:'Lạc gặp đối tác ở khách sạn' })).ok);
  assert(T.validateAdaptiveScenePlan(plan, Object.assign({}, base, { openingContinuity:'Cửa phòng khách sạn khép lại sau lưng Lạc.' })).ok);
  const r = T.validateAdaptiveScenePlan(plan, base);
  assert(/Outline\/Brief\/Gợi ý/.test(r.errors[0]), r.errors[0]);
});

test('V14.0.9 safeDedupeRepeatedScene không cắt cụt chương ghép scene khi chỉ có vài đoạn lặp lẻ', () => {
  let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  const ON = 'b c d g h k l m n t v x ch th nh kh ph tr gi qu'.split(' '), RI = 'a à á ạ e ê ề i í o ô ố ơ u ư ừ an ân ăn em ên in on ôn ơn un ang anh ênh inh ong ông ung ưng at ât ap ep ip op ôp ưc ac oc ai ay ôi'.split(' ');
  const w = () => ON[Math.floor(rnd() * ON.length)] + RI[Math.floor(rnd() * RI.length)];
  const prose = n => { const ps = []; let c = 0; while (c < n) { const k = 10 + Math.floor(rnd() * 12), a = []; for (let i = 0; i < k; i++) a.push(w()); ps.push(a.join(' ') + '.'); c += k; } return ps.join('\n\n'); };
  const s1 = prose(1650), s2 = prose(1650), s3 = prose(1650);
  const withDup = s1 + '\n\n' + s1.split('\n\n').slice(0, 3).join('\n\n') + '\n\n' + s2 + '\n\n' + s3;
  const before = T.countWords(withDup);
  const safe = T.safeDedupeRepeatedScene(withDup);
  assert(T.countWords(safe) >= before * 0.8, 'safe dedupe không được mất > 20% từ: ' + before + ' -> ' + T.countWords(safe));
  const fixed = T.dropRepeatedParagraphs(s1, s1.split('\n\n').slice(0, 3).join('\n\n') + '\n\n' + s2);
  assert(T.countWords(fixed) >= T.countWords(s2) - 5 && T.countWords(fixed) <= T.countWords(s2) + 5, 'chỉ bỏ các đoạn lặp, giữ phần mới');
});

test('V14.0.9 parser Scene Graph chịu <think>, lời dẫn có dấu {, và JSON bị cắt giữa chừng', () => {
  const full = '{"chapterGoal":"g","endingAnchor":"e","scenes":[{"id":"S1","mustChange":"m","handoff":"h"},{"id":"S2","mustChange":"m2","handoff":"h2"}]}';
  const a = T.normalizeAdaptiveScenePlan('<think>để tôi nghĩ {a} thử</think>\n' + full, {});
  assert(a && a.scenes.length === 2, 'think');
  const b = T.normalizeAdaptiveScenePlan('Đây là kế hoạch {theo yêu cầu}: ' + full, {});
  assert(b && b.chapterGoal === 'g', 'lời dẫn chứa {');
  const cut = '{"chapterGoal":"g","endingAnchor":"e","scenes":[{"id":"S1","mustChange":"m","handoff":"h"},{"id":"S2","mustChange":"đang viết dở';
  const c = T.normalizeAdaptiveScenePlan(cut, {});
  assert(c && c.chapterGoal === 'g' && c.scenes.length >= 1, 'JSON bị cắt phải được cứu: ' + JSON.stringify(c));
  assert(T.normalizeAdaptiveScenePlan('Xin lỗi, tôi không thể giúp việc này.', {}) === null, 'văn bản từ chối -> null');
});
